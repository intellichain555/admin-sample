import { _decorator, Node, AnimationClip, Asset, AudioClip, Component, EffectAsset, ImageAsset, Label, Material, Mesh, Prefab, Skeleton, SpriteFrame, TextAsset, Texture2D, director, AudioSource, sys, animation } from 'cc';
import { LoadResUtil } from './Utils/LoadResUtil';
import { UIManager } from './UI/Common/UIManager';
import { Constant } from './Utils/Constant';
import { RandomUtils } from './Utils/RandomUtils';
import { SoundManager } from './Sound/SoundManager';
import { SoundDefine } from './Sound/SoundDefine';
const { ccclass, property } = _decorator;


@ccclass('HolPreLoad')
export class HolPreLoad extends Component {

    // Declare ValueNode and TipNode two properties
    @property(Node)
    public ValueNode: Node

    @property(Node)
    public TipNode: Node

    @property(Label)
    public prolabel!: Label;

    @property(Node)
    public age12Node: Node

    @property(Node)
    public age16Node: Node

    @property(Node)
    public tip16!: Node;

    private $tips: string[] = ["Reward center can claim large amounts of gold coins and resurrection coins...", "Destroying enemy crystal in game can achieve victory...", "Strengthening hero attributes can improve combat power..."] // Array storing tip information

    private $current: number = 0 // Current progress
    private $process: number = 0 // Target progress

    private $completeQueue: Function[] = [] // Completion queue, stores callback functions to execute when complete

    protected start(): void {
        console.log('Start loading')
        this.age12Node.active = true;
        this.age16Node.active = false;
        if (sys.platform == Constant.WECHAT_GAME) {
            let wx = window['wx'];
            wx.setKeepScreenOn({
                keepScreenOn: true,
                success: () => {
                    console.log("WeChat screen keep on success");
                }
            });

            // Listen for mini program version update events
            const updateManager = wx.getUpdateManager()
            updateManager.onCheckForUpdate(function (res) {
                // Callback after requesting new version info
                console.log('Listen for mini program version update event', res.hasUpdate)
            })
            updateManager.onUpdateReady(function () {
                wx.showModal({
                    title: 'Update prompt',
                    content: 'New version is ready, restart application?',
                    success(res) {
                        if (res.confirm) {
                            // New version has been downloaded, call applyUpdate to apply new version and restart
                            updateManager.applyUpdate()
                        }
                    }
                })
            })
            updateManager.onUpdateFailed(function () {
                // New version download failed
            })
        }
        if (sys.platform == Constant.BYTEDANCE_MINI_GAME) {
            SoundManager.Instance.PlayMusic(SoundDefine.Music_Douyin);
        } else {
            SoundManager.Instance.PlayMusic(SoundDefine.Music_Game);
        }
        this.preLoad();
    }

    private async preLoad(): Promise<void> {
        const loadedAssets: any[] = [];
        let _this = this;
        // Simulate progress bar
        setTimeout(function () {
            if (_this.$process < 100) {
                _this.setProcess(RandomUtils.limit2(5, 15));
            }
        }, 500)
        setTimeout(function () {
            if (_this.$process < 100) {
                _this.setProcess(RandomUtils.limit2(30, 45));
            }
        }, 2000)
        setTimeout(function () {
            if (_this.$process < 100) {
                _this.setProcess(RandomUtils.limit2(65, 80));
            }
        }, 4000)
        // Finally wait for real loading to complete before entering scene
        for (let i = 0; i < 1; i++) {
            const data = await LoadResUtil.loadDir("Game");
            // console.log('Data' + i, data);
            const progress = ((i + 1) / 1) * 100;
            this.setProcess(progress);
            loadedAssets.push(...data); // Add files loaded from current directory to array
        }
        LoadResUtil.setLoadedAssets(loadedAssets);
    }

    // Set progress value
    setProcess(num: number) {
        this.$process = num
        this.prolabel.string = `${Math.round(this.$process)}%`;
    }

    // Set tip information
    setTips(tips: string[]) {
        this.$tips = tips
    }

    // Add callback function to completion queue when complete
    listenComplete(com: Function) {
        this.$completeQueue.push(com)
    }

    private $currentIndex: number = 0 // Current displayed tip information index
    private $accumulateTime: number = 0 // Accumulated time, used to control frequency of switching tip information
    private isCompleteLoad: boolean = false;  // Whether loading is complete
    protected update(dt: number): void {
        if (this.$current >= 100) { // When progress reaches 100%, execute callback functions in completion queue and hide node
            this.TipNode.getComponent(Label).string = 'Initializing resources, please wait...';
            this.$completeQueue.forEach(c => c())
            if (!this.isCompleteLoad) {  // Loading not complete
                this.isCompleteLoad = true;
                UIManager.Instance.Init();
                director.loadScene('UIMain');
            }
            return
        }
        if (this.$current < this.$process) { // If current progress is less than target progress, increase progress value and update ValueNode scale
            this.$current += dt * 45
            let value = this.$current / 100 > 1 ? 1 : this.$current / 100;
            this.ValueNode.setScale(value, 1, 1)
        }
        this.$accumulateTime -= dt // Accumulated time decreases
        if (this.$accumulateTime <= 0) { // When accumulated time is less than or equal to 0, switch tip information
            this.TipNode.getComponent(Label).string =
                this.$tips[this.$currentIndex] // Update text content displayed by TipNode Label component
            this.$currentIndex++ // Switch to next tip information
            this.$accumulateTime = 4 // Reset accumulated time to 4 seconds
            if (this.$currentIndex >= this.$tips.length) this.$currentIndex = 0 // If index exceeds tip information array length, reset to 0
        }
    }

    public OnClickTip16() {
        if (this.tip16.active) {
            this.tip16.active = false;
        } else {
            this.tip16.active = true;
        }
    }

    onDestroy() {
        console.log('PreLoad onDestroy')
    }
}

if (!Constant.DEBUG_LOG) {
    console.log = () => {};
}
