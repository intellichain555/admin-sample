export class HashMap {
    public map = new Map();
    /**
     * Add data
     * @param key Key
     * @param value Value
     */
    put(key: any, value: any): void {
        this.map[key] = value;
    }

    /**
     * Get data
     * @param key Key
     */
    get(key: any): any {
        return this.map[key];
    }

    /**
     * Remove data
     * @param key Key
     */
    remove(key: any): any {
        var value = this.map[key];
        if (value) {
            this.map[key] = null;////////////////////zhengxin add at 2016-08-15
            delete this.map[key];//then undefined
        }
        return value;//should outter be = null, for clear memory
    }

    /**
     * Check if exists
     * @param key Key
     */
    contains(key: any): boolean {
        return this.map[key] != null;
    }

    /**
     * Get all keys
     */
    keys(): string[] {
        var keys = Object.keys(this.map);
        var index = keys.indexOf("_hashCode");
        if (index > -1) {
            keys.splice(index, 1);
        }
        return keys;
    }

    /**
     * Get all values
     */
    values(): any[] {
        var keys = Object.keys(this.map);
        let values = [];
        for (var i = 0; i < keys.length; i++) {
            let value = this.map[keys[i]];
            values.push(value);
        }
        return values;
    }

    /**
     * Fill array with all values (reuses out array to avoid allocation - for hot paths like frame update)
     */
    valuesInto(out: any[]): void {
        out.length = 0;
        var keys = Object.keys(this.map);
        for (var i = 0; i < keys.length; i++) {
            let value = this.map[keys[i]];
            if (value != null) out.push(value);
        }
    }

    /**
     * Get length
     */
    get length(): number {
        var keys = Object.keys(this.map);
        return keys.length;
    }

    /**
     * Get data
     */
    get data(): any {
        return this.map;
    }

    /**
    * Set data
    */
    set data(map) {
        this.map = map;
    }

    /**
     * Clear
     */
    clear(): void {
        var keys = Object.keys(this.map);
        var len = keys.length;
        for (var i = 0; i < len; i++) {
            let value = this.remove(keys[i]);
            value = null;////////////////////zhengxin at 2016-08-15
        }
    }
}