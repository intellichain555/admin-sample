
/**
 * Constant definitions
 */
export class Constant {
    /** Set to false to disable all console.log in the project. */
    public static DEBUG_LOG: boolean = true;
    public static SHOW_POPUP_TEXT: boolean = true;
    public static WECHAT_GAME: string = 'WECHAT_GAME';  // WeChat mini game    
    public static isQQ:boolean = false;  // QQ mini game    
    public static BYTEDANCE_MINI_GAME: string = 'BYTEDANCE_MINI_GAME';  // ByteDance mini game    
    public static qihu360Web: boolean = false;// Qihu 360 web game
    public static aesKey: string = 'sa23W$%234stWEG@';
    public static rsaKey: string = '';
    public static token: string = '';
    public static SidebarReward: boolean = false; // ByteDance mini game sidebar reward flag
    public static isOnline: boolean = true; // Is production environment
    public static preLoadEnd: boolean = false;// Battle server resources loaded

    /** When true, use next-tick scheduler for smoother behavior on slow devices; when false, use fixed setInterval(50ms). */
    public static USE_NEXT_TICK_LOGIC: boolean = true;

    // Permission types
    public static AuthType = {
        IllegalRequest: 0,  // Illegal request
        TokenInvalid: 1,  // Token invalid
        GameTimeOutOver: 2, // Game timeout end
    }

    // AI states
    public static AIState = {
        idle: 0,  // Idle 
        pathWay: 1,  // Pathfinding
        targetMove: 2,  // Move to enemy
        fight: 3,  // Fighting
        returningCity: 4,  // Returning to base
        enrichTheBlood: 5  // Healing
    }

    // AI top/bottom lane types
    public static AIRoadType = {
        up: 0,  // Top lane 
        down: 1,  // Bottom lane
    }

    // Result states
    public static Result = {
        Success: 0,
        Failed: 1,
    }

    // Character types
    public static CharacterClass = {
        WARRIOR: "WARRIOR",  // Warrior
        WIZARD: "WIZARD",   // Mage
        ASSASSIN: "ASSASSIN",  // Assassin
        Shooter: "Shooter", // Archer
        NoticeMonsters: "NoticeMonsters",
        Monsters: "Monsters",
        Soldier: "Soldier",
        Cart: "Cart",
        Boss: "Boss",
        Fyt: "Fyt",  // Defense tower
        ShuiJin: "ShuiJin",  // Crystal
        CallMonster: "CallMonster",  // Summoned monster
    }

    // Item types
    public static ItemType = {
        SPORTS: 0, // Sports item
        ATTSTONE: 1,// Attack stone
        DEFSTONE: 2, // Defense stone
        RESUSTONE: 3, // Resurrection stone
        HPSTONE: 4, // HP stone
        CDSTONE: 5,  // CD stone
        CRISTONE: 6,  // Critical stone
        SPEEDSTONE: 7,  // Speed stone
        HUIHPSTONE: 8, // HP recovery stone
        COIN: 9,  // Gold coins
        EXPE: 10,  // Experience    
        MOFU: 11, // Magic talisman
        OTHER: 12, // Other
        RESUCOIN: 13,  // Resurrection coin
        DALABA: 14,  // Big horn
    }

    // Enhancement types
    public static AddAttrType = {
        GEM: 0,
        SPAR: 1,
    }

    // Item functions
    public static ItemFunction = {
        RecoverHP: 0,
        RecoverMP: 1,
        AddBuf: 2,
        AddExp: 3,
        AddMoney: 4,
        AddItem: 5,
        AddBuff: 6,
        AddSkillPoint: 7,
    }

    // Tips types
    public static TipsType = {
        Tips: 0,
        Popup: 1,
        Data: 2,
    }

    // Post-processing states
    public static StatusAction = {
        UPDATE: 0,
        ADD: 1,
        DELETE: 2,
    }

    // Post-processing business
    public static StatusType = {
        MONEY: 0,
        EXP: 1,
        SKILL_POINT: 2,
        ITEM: 3,
        LEVEL: 4,
        LEVEL_Up_EXP: 5,
        ResuCoinUseCount: 6, // Today resurrection coin usage count
        TiLiUseCount: 7,  // Today stamina usage count
        TiLi: 8,  // Stamina
        DoubleRewardUseCount:9,  // Today's double battle reward usage count
    }

    // Enhancement types
    public static AttrPromoteType = {
        Att: 0,
        Def: 1,
        Hp: 2,
        Cri: 3,
        Resu: 4,
        Speed: 5,
        Cd: 6,
        HuiHp: 7,
    }

    // Tips business types
    public static TipsWorkType = {
        AuctionResult: 1,   // Auction settlement
        DismissRoom: 2,   // Dismiss room
        KickOutRoom: 3,  // Kick out of room
        OutRoom: 4,  // Exit room
        RoomMatch: 5, // Room matching
        CancelRoomMatch: 6, // Cancel room matching
        ReLogin: 7, // Re-login
        GameOver_: 8,  // Game over
        KickOutPlayer: 9,  // Account kicked out
    }

    // Team types
    public static TeamType = {
        My: 0,     // Friendly
        Enemy: 1,  // Enemy
    }

    // Room status
    public static RoomStatus = {
        Normal_: 0,   // Normal
        GameIn: 1,    // In game
        GameOver2: 2, // Game over
    }

    // Player status
    public static QueryUserState = {
        Live2_: 0,  // Live streaming
        OnLine: 1,  // Online
        OffLine: 2, // Offline
    }

    // Chat channels
    public static ChatChannel = {
        Comp: 0,      // General
        Private: 1,   // Private chat
        RoomChat: 2,  // Room
    }

    public static FanWeiType = {
        Team: 0, // Our team
        All: 1,  // All
    }

    public static ChatRoomType = {
        Room_: 0,  // Room
        Game_: 1,  // In game
        Live_: 2,  // Watching live
    }

    public static RankType = {
        Active: 0,  // Activity ranking
        Power: 1,   // Power ranking
        PvPRecord: 2,  // Battle record ranking
    }

    // Priority preload bundles
    public static ResBundleList = [
        "Game",
    ];

    // Start preloading battle bundles after login
    public static ResBattleBundleList = [
        "Battle",
    ];

    // Game modes
    public static PlayingMethod = {
        ThreeVsThree: 0,  //3v3
        OnlineBattle: 1,  // Online battle royale
        FiveVsFive: 2,    //5v5
    }
    
}