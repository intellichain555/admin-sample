##Development Guide

## Table of Contents
1. [Core Combat Mechanics](#core-combat-mechanics)
2. [Champion Stats & Attributes](#champion-stats--attributes)
3. [Minions & Wave Management](#minions--wave-management)
4. [Jungle Monsters](#jungle-monsters)
5. [Objectives](#objectives)
6. [Structures (Turrets, Inhibitors, Nexus)](#structures)
7. [Gold & Economy](#gold--economy)
8. [Vision & Map Awareness](#vision--map-awareness)
9. [Team Fighting Concepts](#team-fighting-concepts)

---

## Core Combat Mechanics

### Basic Attacks

**Auto-Attack Mechanics:**
- Each champion has base Attack Damage (AD) and Attack Speed
- Attack animations can be canceled by moving after damage applies
- Melee range: ~125-175 units
- Ranged: 425-650 units (varies by champion)

### Attack Speed (Detailed)

**Base Stats:**
- Starting Attack Speed: 0.6-0.7 for most champions
- Attack Speed increases with level
- Items provide % bonus Attack Speed
- Cap: 2.5 attacks per second (hard cap)

**Attack Speed Formula:**
```
Attacks per second = Base AS × (1 + Bonus AS%)
```

**Example - Jinx:**
- Base AS at level 1: 0.625
- With Rapid Firecannon (+35% AS): 0.625 × 1.35 = 0.844 AS
- With Gluttonous Greaves (+18% AS): 0.625 × 1.53 = 0.956 AS
- Time between attacks: 1 / 0.956 = 1.05 seconds

**Why Attack Speed Matters:**
- Higher DPS (damage per second)
- Faster on-hit effect procs
- Better kiting ability
- Faster tower pushing

---

### Damage Types and Calculations

#### Physical Damage

**Formula:**
```
Final Damage = Raw Damage × (100 / (100 + Armor))
```

**Example:**
- Your AD: 200
- Enemy Armor: 100
- Damage Dealt: 200 × (100/200) = 200 × 0.5 = **100 damage**

**With Armor Penetration:**
- Enemy Armor: 100
- Your Armor Penetration: 30%
- Effective Armor: 100 × 0.7 = 70
- Damage: 200 × (100/170) = 200 × 0.588 = **117.6 damage**

#### Magic Damage

**Formula:**
```
Final Damage = (Base + AP Scaling) × (100 / (100 + Magic Resist))
```

**Example:**
- Ability: 300 base + 60% AP
- Your AP: 400
- Total: 300 + 240 = 540 magic damage
- Enemy MR: 80
- Final: 540 × (100/180) = **300 damage**

#### True Damage

**Formula:**
```
Final Damage = Base Damage (no reduction)
```

- Ignores all Armor and Magic Resistance
- Cannot be reduced by any defensive stats
- Examples: Vayne's W, Fiora's passive, Ignite

---

### Crowd Control (CC)

**Hard CC (Prevents Actions):**
- **Stun**: Cannot move or use abilities
- **Knockup**: Airborne, cannot be reduced by Tenacity
- **Suppression**: Cannot be cleansed
- **Root**: Cannot move but can attack/use abilities
- **Charm/Taunt**: Forced to walk toward source

**Soft CC:**
- **Slow**: Reduced movement speed
- **Silence**: Cannot use abilities
- **Blind**: Auto-attacks miss
- **Cripple**: Reduced Attack Speed

---

## Champion Stats & Attributes

### Primary Stats

**Health (HP):**
- Base: 500-650 (varies by champion)
- Per level: +75-110
- Level 15: ~1800-2400 HP

**Mana/Energy:**
- Mana champions: 280-450 base
- Energy champions: 200 energy (fixed)
- Manaless champions: Use other resources

**Attack Damage (AD):**
- Base: 50-70
- Per level: +2-4
- Items add flat AD

**Ability Power (AP):**
- Base: 0
- Only from items and runes

### Defensive Stats

**Armor:**
- Reduces physical damage
- Base: 20-45
- Per level: +3-4
- Damage reduction = Armor / (100 + Armor)

**Magic Resistance (MR):**
- Reduces magic damage
- Base: 30-38
- Per level: +1-2
- Same formula as Armor

### Movement Speed

**Base Movement Speed:**
- Melee: 330-345
- Ranged: 325-335
- Items/abilities can increase

**Movement Speed Formula (Wild Rift):**
```
If MS < 415: Full value
If 415-490: 80% efficiency above 415
If MS > 490: 50% efficiency above 490
```

**Example:**
- Base MS: 340
- Boots: +45
- Trinity Force: +3% MS
- Raw: (340 × 1.03) + 45 = 395 MS
- Under 415, so final = **395 MS** (no reduction)

---

## Minions & Wave Management

### Minion Types (Wild Rift Specific)

#### Melee Minions
- **Health**: 477 HP + increases per minute
- **Attack Damage**: 12 + scales with time
- **Gold**: 60-65 gold
- **Spawn**: 3 per wave

#### Caster Minions
- **Health**: 296 HP + increases per minute
- **Attack Damage**: 23-25 + scales
- **Gold**: 32-35 gold
- **Range**: 550 units
- **Spawn**: 3 per wave

#### Siege Minions (Cannon)
- **Health**: 1250 HP + scales heavily
- **Attack Damage**: 40 + scales
- **Gold**: 60-65 gold (same as melee in Wild Rift!)
- **Spawn**: Every 3rd wave initially
- **Special**: Extra damage to turrets

#### Super Minions
- **When**: Inhibitor destroyed
- **Health**: 3000+ HP
- **Armor/MR**: 70/70
- **Gold**: 25 gold (LESS than normal minions)
- **Aura**: Reduces nearby enemy minion damage

### Wave Spawning (Wild Rift)

**Timing:**
- First wave: 0:15 (15 seconds)
- Subsequent waves: Every 30 seconds
- Waves meet at center: ~0:40

**Siege Minion Schedule:**
- 0:00-13:00: Every 3rd wave
- 13:00+: Every 2nd wave

### Wave Management States

**1. Freeze:**
- Keep wave near your turret
- Need 3-4 enemy caster minions alive
- Zone enemies from CS

**2. Slow Push:**
- Build up a large wave
- Takes 2-3 waves to accumulate
- Good before roaming

**3. Fast Push:**
- Clear wave quickly with abilities
- Reset wave position
- Good before recall

**4. Crash:**
- Wave hits enemy turret
- Turret kills your minions
- Wave bounces back

---

## Jungle Monsters

### Buff Camps

#### Red Brambleback (Red Buff)
- **Health**: 1800 HP (scales with game time)
- **Respawn**: 120 seconds (2 minutes)
- **Buff Duration**: 70 seconds (Wild Rift specific!)
- **Buff Effects**:
  - Auto-attacks slow by 20%
  - Burns for 15% bonus damage over 3 seconds
  - +8% Attack Damage
- **Gold**: 60 + 150 XP

#### Blue Sentinel (Blue Buff)
- **Health**: 1800 HP (scales)
- **Respawn**: 120 seconds
- **Buff Duration**: 70 seconds
- **Buff Effects**:
  - +10% Cooldown Reduction
  - +15 Mana regen per 5 seconds
  - +15 Energy regen per 5 seconds
- **Gold**: 60 + 150 XP

### Small Camps

#### Raptors (Crimson Raptors)
- **Large Raptor**: 800 HP
- **Small Raptors** (5): 240 HP each
- **Total Gold**: 45 + 90 XP
- **Respawn**: 90 seconds

#### Wolves (Murk Wolves)
- **Large Wolf**: 1000 HP
- **Small Wolves** (2): 380 HP each
- **Total Gold**: 40 + 80 XP
- **Respawn**: 90 seconds

#### Krugs (Ancient Krug)
- **Large Krug**: 1200 HP
- **Medium Krug**: Splits when killed
- **Total Gold**: 50 (highest gold/xp ratio!)
- **Respawn**: 90 seconds

#### Scuttle Crab
- **Health**: 900 HP
- **Armor/MR**: 80/80 normally
- **Reduced to**: 10/10 when CC'd
- **Gold**: 63 + 80 XP
- **Respawn**: 150 seconds
- **Spawn**: 1:05, alternates top/bottom river
- **Buff**: Vision + movement speed shrine (90 sec)

---

## Objectives

### Dragons (Wild Rift Specific)

**Spawn Times:**
- First Dragon: 4:00
- Respawn: 6:00 after killed
- Random type each spawn

**Dragon Types:**

#### Infernal Dragon (Red)
- **Buff**: +6% AD and +7% AP per stack
- **Soul (4 stacks)**: Abilities burn enemies

#### Mountain Dragon (Earth)
- **Buff**: +8% Armor and Magic Resist per stack
- **Soul**: Shield when below 30% HP

#### Ocean Dragon (Water)
- **Buff**: +2.5% missing HP regen per 5 sec per stack
- **Soul**: Deal damage → heal

#### Cloud Dragon (Air)
- **Buff**: +6% Movement Speed (out of combat) per stack
- **Soul**: Casting ultimate grants ghost + movement speed

#### Elder Dragon
- **Spawns**: After one team gets 4 dragons OR at 25:00
- **Health**: 8800 HP
- **Buff Duration**: 120 seconds
- **Effect**: 
  - Burn damage on attacks
  - Execute below 20% HP

**Dragon Stats:**
- Health: 3520 HP (first spawn, scales +240 per minute)
- Gold: 200 team gold + 100 individual
- XP: 150 per player

---

### Baron Nashor

- **Spawn Time**: 10:00
- **Respawn**: 7:00
- **Health**: 6500 HP + scales with time
- **Gold**: 300 team gold per player (1500 total)
- **Buff Duration**: 180 seconds (3 minutes)

**Baron Buff (Hand of Baron):**
- +40 Attack Damage
- +30 Ability Power  
- Enhanced Recall (4 seconds instead of 8)
- Nearby minions: +50% damage, +75% damage resist, +20% MS

**Baron Abilities:**
- Physical auto-attacks
- Acid pool (magic damage)
- Tentacle slam (knockback)
- Debuff: Reduces healing by 50%

---

### Rift Herald

- **Spawn**: 6:00
- **Despawns**: 13:30 (no longer available after)
- **Health**: 9000 HP
- **Eye Weakness**: 12% max HP per hit on eye
- **Gold**: 100 team gold

**Eye of the Herald:**
- Summon Herald to charge turrets
- Herald has 3200 HP
- Deals 1500-2000 damage per charge to turrets
- Lasts until killed or 20 seconds

---

## Structures

### Turrets (Wild Rift Mobile)

**Wild Rift has 3 turret tiers per lane (NOT 4 like PC):**

#### Tier 1 Turrets (Outer)
- **Health**: 3600 HP
- **Attack Damage**: 120 + 40% per hit on same target
- **Armor/MR**: 55/55
- **Range**: 775 units
- **Gold**: 150 local + 100 team (each player) = 650 total
- **First Blood Tower**: Extra 100 local gold (250 total to destroyer)
- **Fortification** (0:00-4:00): Takes 50% reduced champion damage

#### Tier 2 Turrets (Inner)
- **Health**: 4000 HP
- **Attack Damage**: 152 + 40% per hit
- **Armor/MR**: 65/65
- **Gold**: 200 local + 100 team = 700 total
- **Regeneration**: Regens when no enemies nearby

#### Tier 3 Turrets (Inhibitor)
- **Health**: 4000 HP
- **Attack Damage**: 170 + 40% per hit
- **Armor/MR**: 70/70
- **Gold**: 250 local + 100 team = 750 total
- **Special**: Must destroy to access Inhibitor
- **Regeneration**: Regenerates health when no enemies nearby

**Key Turret Mechanics:**

**Damage Amplification:**
- 1st shot: Base damage
- 2nd shot: +40%
- 3rd shot: +96%
- 4th shot: +174%
- Each consecutive hit on same target

**Targeting Priority:**
1. Champion attacking allied champion
2. Minion attacking allied champion
3. Minion attacking turret
4. Champion attacking turret
5. Closest minion
6. Closest champion

**Aggro Drop:**
- Leave turret range (775+ units)
- Enter brush (if no vision)
- Target dies

**Important Wild Rift Differences:**
- NO turret plates system
- Fortification only 4 minutes (not 5)
- Tier 3 has laser beam
- NO Nexus turrets!

---

### Inhibitors

- **Health**: 3000 HP
- **Respawn**: 240 seconds (4 minutes in Wild Rift)
- **Gold**: 50 gold
- **Effect**: Enemy lane spawns Super Minions
- **Must destroy**: Tier 3 turret first

---

### Nexus

- **Health**: 5500 HP
- **NO TURRETS**: Wild Rift Nexus has no turret protection
- **To Attack**: Must destroy 1 Inhibitor in any lane

---

#### Nexus Healing Logic (Detailed)

**Base Regeneration Rate:**
- **20 HP per second** (passive regeneration)
- Total heal time from 1 HP → 5500 HP: **275 seconds (4 minutes 35 seconds)**

**Regeneration Activation:**
- Regeneration occurs passively at all times when conditions are met
- **Delay after damage**: ~3 seconds (estimated - requires verification)
- Regeneration is paused during combat/enemy presence

**Conditions That STOP Regeneration:**
- Enemy champions within range (exact range: requires verification)
- Enemy minions within range
- Active combat/damage being dealt to Nexus

**Conditions That ALLOW Regeneration:**
- No enemy units nearby
- No damage taken for 3+ seconds
- Allied champions can be present (doesn't block healing)

**Regeneration Examples (20 HP/sec):**
- 200 damage dealt → heals in 10 seconds
- 1000 damage dealt → heals in 50 seconds  
- 2750 damage (50% HP) → heals in 137.5 seconds (~2.3 minutes)
- 5500 damage (0% HP) → heals in 275 seconds (~4.6 minutes)

**Strategic Implications:**
- **Poke damage is ineffective** - Nexus heals back quickly
- **Super minions critical** - Constant pressure prevents healing
- **Must commit fully** - Partial attempts allow full recovery
- **Wave management essential** - Need minions to prevent healing during siege

**Healing vs Damage Type:**
- All damage types (Physical/Magic/True) stop regeneration equally
- No difference in healing behavior based on damage source
- Tower damage, champion damage, minion damage - all treated the same

**Important Mechanics:**
- Nexus regeneration is a **passive ability**, not item-based
- Cannot be affected by Grievous Wounds or healing reduction
- Regeneration rate is constant (doesn't scale with game time)
- No difference between first damage and subsequent damage

**Critical Differences from PC:**
- **PC Nexus**: 5500 HP, 20 HP/sec, HAS 2 turrets protecting it
- **Wild Rift Nexus**: 5500 HP, 20 HP/sec, NO turrets (exposed after 1 Inhibitor)
- Wild Rift Nexus is much more vulnerable once exposed
- Fast regeneration compensates for lack of turret protection

**NEEDS VERIFICATION:**
The following details require testing/confirmation:
- Exact delay time before regeneration starts (estimated ~3 sec)
- Exact range for enemy presence to block regeneration
- Whether damage from different sources affects regeneration delay differently
- Interaction with specific game mechanics (Baron buff, etc.)

---

## Gold & Economy

### Gold Sources

**Minions:**
- Melee: 60-65g
- Caster: 32-35g
- Siege: 60-65g
- Full wave: ~270g
- Cannon wave: ~330g

**Jungle Camps:**
- Small camps: 40-50g
- Buff camps: 60g
- Scuttle: 63g

**Kills:**
- First Blood: 400g
- Kill: 300g base
- Shutdown: Up to 700g

**Assists:**
- 150g split among assisters

**Objectives:**
- Dragon: 200g team + 100g individual
- Baron: 300g per player (1500 total)
- Turrets: 150-250 local + 500 team

**Passive Gold:**
- 20 gold per 10 seconds
- 120 gold per minute
- 10 minutes = 1200 passive gold

---

## Vision & Map Awareness

### Vision Tools (Wild Rift)

**Stealth Wards:**
- Duration: 90 seconds (Wild Rift shorter than PC!)
- Invisible to enemies
- Each player can place 1 ward
- Revealed by Control Ward or Oracle

**Control Wards:**
- Duration: Permanent until destroyed
- Visible to enemies (150 HP)
- Reveals enemy wards
- Disables nearby enemy wards
- Cost: 50 gold

**Oracle Lens (Scanner):**
- Cooldown: 90 seconds
- Duration: 6 seconds
- Reveals and disables wards
- Available at level 9

**Farsight Ward (Blue Trinket):**
- Reveals area instantly
- No duration, one-time reveal
- Long range
- Cooldown: 90 seconds

---

## Team Fighting Concepts

### Positioning

**Frontline:**
- Tanks and Fighters
- Engage and absorb damage
- Create space for carries

**Backline:**
- ADC and Mage
- Stay behind frontline
- Maximum damage output
- Most important to protect

**Flanking:**
- Assassins
- Attack from sides/behind
- Target enemy carries

### Team Composition Roles

**Tank:** Malphite, Alistar, Leona
- High HP and resistances
- Engage tools (CC)
- Peel for carries

**Fighter:** Fiora, Camille, Irelia
- Sustained damage
- Moderate durability
- Split push threat

**Assassin:** Zed, Akali, Katarina
- High burst damage
- Mobility
- Eliminate carries

**Marksman (ADC):** Jinx, Vayne, Ezreal
- Sustained physical DPS
- Ranged auto-attacks
- Scale with items

**Mage:** Orianna, Lux, Ahri
- Magic damage
- Burst or control
- Abilities > auto-attacks

**Support:** Thresh, Lulu, Janna
- Utility and CC
- Protect carries
- Vision control

### Win Conditions

**Team Fighting:**
- Group and fight 5v5
- Best with strong teamfight ults

**Split Pushing:**
- 1 person pushes side lane
- Team holds 4v5
- Create map pressure

**Pick Composition:**
- Catch isolated enemies
- Assassinate before objectives

**Siege:**
- Poke from range
- Slowly break turrets
- Avoid direct fights

---

*Last Updated: 2026-02-09*
*This guide is specifically for League of Legends: Wild Rift (Mobile)*
