import { LogUtil } from "../Log/LogUtil";
import { SocketConst } from "./SocketConst";
import { Socket, director } from "cc";
import { EventManager } from "../UI/Common/Event/EventManager";
import { NetConfig } from "./NetConfig";
import { MessageDispatch } from "./MessageDispatch";
import { UserService } from "../Services/UserService";
import { MessageBox, MessageBoxType } from "../UI/Common/MessageBox";
import { EventType } from "../UI/Common/Event/EventType";
import { User } from "../Models/User";
import { LocalStorageUtil } from "../Utils/LocalStorageUtil";
import { NetClientBattle } from "./Battle/NetClientBattle";
import { UINetReconnect } from "../UI/Common/UINetReconnect";
import { Util } from "../Utils/Util";
import { UIManager } from "../../../Scripts/UI/Common/UIManager";

export class NetClientBase {

  public lockReconnect = false;//Avoid duplicate connections
  public reconnectCount: number = 0; //Reconnection count
  public uiNetReconnect: UINetReconnect = null;
  public isNetReconnect: boolean = true;  //Reconnection flag
  public lastConnectTime: number = 0; //Last reconnection time
  public kickOut = false;//Kicked players don't reconnect

  // Exponential backoff parameters (RISK 7 fix)
  private static readonly RECONNECT_BASE_DELAY_MS = 500;   // First retry after 500ms
  private static readonly RECONNECT_MAX_DELAY_MS  = 8000;  // Cap at 8 seconds

  /**
   * Compute exponential backoff delay for the current retry attempt.
   * 500ms → 1s → 2s → 4s → 8s (capped).
   */
  private getBackoffDelay(): number {
    const delay = NetClientBase.RECONNECT_BASE_DELAY_MS * Math.pow(2, this.reconnectCount - 1);
    return Math.min(delay, NetClientBase.RECONNECT_MAX_DELAY_MS);
  }

  /**
   * Reconnect with exponential backoff (RISK 7 fix).
   * Previously used a flat 3-second delay between every retry (up to 7×3 = 21s).
   * Now starts at 500ms and doubles each attempt, capped at 8s.
   */
  public async reconnect() {
    this.lastConnectTime = new Date().getTime();
    console.log('reconnect isNetReconnect=' + this.isNetReconnect + '，lockReconnect=' + this.lockReconnect + '，kickOut=' + this.kickOut);
    if (!this.isNetReconnect) {
      return;
    }
    if (this.kickOut) {
      return;
    }
    if (this.lockReconnect) {
      return;
    }
    this.lockReconnect = true;
    let this_ = this;
    //Validate reconnection count
    this.reconnectCount++;
    if (this.reconnectCount > NetConfig.maxReconnectCount) {
      this.reconnectCount = 0;
      if (this.uiNetReconnect) {
        this.uiNetReconnect.Close();
      }
      let confirmObj = await MessageBox.Show("Failed to reconnect to server, please check mobile network.", "Tip", MessageBoxType.Information, "OK");
      EventManager.Instance.addListener(EventType.UIMessageBox_OnClickYes, function () {
        this_.lockReconnect = false;
        Util.ReLogin();
      }, confirmObj);
      return;
    }

    //Open reconnection panel
    if (!this.uiNetReconnect || !this.uiNetReconnect.node || !this.uiNetReconnect.node.parent) {
      this.uiNetReconnect = await UIManager.Instance.show("UINetReconnect") as UINetReconnect;
    }
    if (this.uiNetReconnect) {
      this.uiNetReconnect.SetContent(this.reconnectCount);
    }

    // Exponential backoff: 500ms → 1s → 2s → 4s → 8s (was flat 3000ms)
    const delay = this.getBackoffDelay();
    console.log('[NetClientBase] reconnect attempt ' + this.reconnectCount + ' in ' + delay + 'ms');
    setTimeout(function () {
      this_.lockReconnect = false;
      this_.Connect();
    }, delay)
  }

  /**
   * Start Socket connection
   */
  public Connect(): void {
    this.isNetReconnect = true;
  }

  /**
  * Clean up current Socket connection
  */
  public closeCurrentSocket() {
    this.isNetReconnect = false;
  }

  public kickOutUser(){
    this.kickOut = true;
  }

}