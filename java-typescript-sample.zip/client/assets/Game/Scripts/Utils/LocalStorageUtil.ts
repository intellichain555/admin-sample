import { sys } from "cc";
import { User } from "../Models/User";

export class LocalStorageUtil{

    public static readonly privateMessagesKey="privateMessagesKey"; 
    public static readonly allFrameHandlesKey="allFrameHandlesKey"; 
    public static readonly userId:string='userId';
    public static readonly compLastMsgTime='compLastMsgTime';  
    public static readonly roomLastMsgTime='roomLastMsgTime';
    public static readonly privateLastMsgTime='privateLastMsgTime';
    public static readonly stateRecordKey="stateRecordKey";
    public static readonly matchRandomSeedKey="matchRandomSeedKey";  // RISK 5: persist initial match seed
    public static readonly taskRedPoint="taskRedPoint";  

   /**
     * Data storage
     * @param key
     * @param value 
     */
    public static SetItem(key:string, value:string){
      sys.localStorage.setItem(key, value);
   }
 
   /**
    * Data retrieval
    * @param key 
    */
   public static GetItem(key:string):string{
     let value = sys.localStorage.getItem(key);
     return value;
   }
 
   /**
    * Data deletion
    * @param key 
    */
   public static RemoveItem(key:string){    
     sys.localStorage.removeItem(key);
   }
 
}