import { game, Node, view, director, tween, Vec3, sys } from "cc";
import { EventManager } from "../UI/Common/Event/EventManager";
import { EventType } from "../UI/Common/Event/EventType";
import { DataManager } from "../Managers/DataManager";
import { Creature } from "../UI/Battle/Enities/Creature";
import { NetConfig } from "../Network/NetConfig";
import { DataUtil } from "./DataUtil";
import { NetClient } from "../Network/NetClient";
import { NetClientBattle } from "../Network/Battle/NetClientBattle";
import { User } from "../Models/User";
import { Constant } from "../../../Scripts/Utils/Constant";
import { BattleGlobal } from "../UI/Battle/Utils/BattleGlobal";

export class Util {
    private static isLogin: boolean = false;  //Whether logged in
    public static roomModeType:number = 0;  //Room mode type 0: Regular match 1: Free match  

    public static set IsLogin(value: boolean) {
        console.log('set IsLogin')
        this.isLogin = value;
        EventManager.Instance.dispatch(EventType.OnUserLoginRefresh);
    }

    public static get IsLogin(): boolean {
        return this.isLogin;
    }

    /**
     * Screen adaptation (widget has been adapted)
     * @param node 
     */
    public static ScreenAdapt(node: Node) {
        // let currentSize = view.getVisibleSize();
        // let size = view.getDesignResolutionSize();
        // let oldBl = size.height / size.width;
        // // let bl = game.canvas.height / game.canvas.width;
        // let bl = currentSize.height / currentSize.width;
        // let scale = bl / oldBl;
        // console.log("Screen adaptation scale="+scale)
        // node.setScale(scale, scale, scale);
    }

    /**
     * Screen background image adaptation
     */
    public static ScreenBgAdapt(node: Node) {
        let currentSize = view.getVisibleSize();
        let size = view.getDesignResolutionSize();  //Design resolution 
        let bl = currentSize.width > size.width ? currentSize.width / size.width : size.width / currentSize.width;
        let bl2 = currentSize.height > size.height ? currentSize.height / size.height : size.height / currentSize.height;
        let scale = Math.max(bl, bl2)
        scale = scale * 1.1;
        node.setScale(scale, scale, scale);
    }

    /**
     * Open window animation
     * @param node 
     * @param isPlayAni 
     */
    public static playOpenAni(node: Node, isPlayAni: boolean) {
        if (!node || !isPlayAni) {
            return;
        }
        let panelNode = node.getChildByName('Panel') || node;

        tween(panelNode).to(0.2, { scale: new Vec3(1.1, 1.1, 1) }, { easing: 'backOut' }).call(() => {

        }).to(0.2, { scale: new Vec3(1, 1, 1) }, { easing: 'backOut' }).call(() => {

        }).start();
    }

    /**
     * Close window animation
     * @param node 
     * @param isPlayAni 
     */
    public static playCloseAni(node: Node, isPlayAni: boolean) {
        if (!node) {
            return;
        }
        isPlayAni = false;
        if (!isPlayAni) {
            director.getScene()?.removeChild(node);
            return;
        }
        let panelNode = node.getChildByName('Panel') || node;

        tween(panelNode).to(0.1, { scale: new Vec3(0, 0, 1) }).call(() => {
            director.getScene().removeChild(node);
        }).start();
    }

    /**
     * Button start touch animation
     * @param node 
     */
    public static btnTouchStartAni(node: Node) {
        tween(node).to(0.1, { scale: new Vec3(1.2, 1.2, 1) }).start();
    }

    /**
     * Button end touch animation
     * @param node 
     */
    public static btnTouchEndAni(node: Node) {
        tween(node).to(0.1, { scale: new Vec3(1, 1, 1) }).start();
    }

    /**
     * Keep specified decimal places
     * @param num Decimal
     * @param ws  Places
     */
    public static toFixed(num: number, ws: number): number {
        if (!num) {
            return 0;
        }
        return Number(num.toFixed(ws));
    }

    /**
     * Use item to get buff
     * @param itemId Item id
     * @param target  Target
     * @param isRepeatUse Whether to allow repeated use
     * @return Whether use was successful
     */
    public static UseItemGetBuff(itemId: number, target: Creature, isRepeatUse: boolean): boolean {
        let itemDefine = DataManager.Instance.items[itemId];
        let isUseSuccess = false;  //Whether use was successful
        if (itemDefine) {
            if (itemDefine.Buff == null || itemDefine.Buff.length == 0) return;
            for (var buffId of itemDefine.Buff) {
                if (!buffId) {
                    continue;
                }
                var buffDefine = DataManager.Instance.buffs[buffId];
                let hasBuff = target.BuffMgr.HasBuff(buffDefine.ID);
                if (hasBuff && !isRepeatUse) {  //Buff exists, not allowed to repeat
                    continue;
                }

                isUseSuccess = true;
                console.log(buffId + '==' + buffDefine);
                target.AddBuf(null, buffDefine);
            }
        }
        return isUseSuccess;
    }

    /**
     * Re-login
     */
    public static ReLogin() {
        console.log('Util.ReLogin')
        Util.IsLogin = false;
        Constant.token = '';
        NetClient.Instance.closeCurrentSocket();
        NetClientBattle.Instance.closeCurrentSocket();
        director.loadScene('Preload');
    }

    /**
     * Jump to battle server
     */
    public static ToBattleScene() {
        //Connect to battle server
        let ipPortArr = User.Instance.room.ipPortStr.split(":");
        if (sys.platform == Constant.WECHAT_GAME && sys.isMobile) {   //WeChat platform
            NetConfig.battleUrl = ipPortArr[0];
            NetConfig.battlePort = parseInt(ipPortArr[3]);
        } else {
            let qianZhui = NetConfig.websocketUrl.substring(0, NetConfig.websocketUrl.indexOf(':'));
            let port = qianZhui == 'wss' ? parseInt(ipPortArr[2]) + 1 : ipPortArr[2];
            NetConfig.battleUrl = qianZhui + '://' + ipPortArr[0] + ':' + port + '/ws';
        }

        console.log('Battle server address: ' + NetConfig.battleUrl, NetConfig.battlePort)
        NetClientBattle.Instance.Connect();  //Connect to battle server
        // NetClient.Instance.closeCurrentSocket();  //Disconnect lobby server        
        let isSuccess = false;
        // 3v3 and 5v5 use same map
        if(BattleGlobal.playingMethod == Constant.PlayingMethod.ThreeVsThree || 
           BattleGlobal.playingMethod == Constant.PlayingMethod.FiveVsFive){  //3v3 or 5v5
            isSuccess = director.loadScene('Map01');//map03
        }else if(BattleGlobal.playingMethod == Constant.PlayingMethod.OnlineBattle){ //Online battle royale
            isSuccess = director.loadScene('Map02');
        }
        console.log('Jump to battle server ToBattleScene isSuccess='+isSuccess)
    }


    /**
     * Get text content
     * @param msg 
     */
    public static getChatContent(msg: string, enterFontCount: number): string {
        let contentStr = '';
        let tempStr = '';
        let startFlag = false;
        let endFlag = false;
        let i = 0;
        for (let char of msg) {
            i++;
            if (enterFontCount != -1 && i % enterFontCount == 0) {  //Line break
                char += '\n';
            }
            if (char == '[') {
                startFlag = true;
            }
            if (char == ']') {
                endFlag = true;
            }
            if (startFlag || endFlag) {
                tempStr += char;
            }
            if (startFlag && endFlag) {
                startFlag = endFlag = false;
                //Replace emoji
                let chatIconId = tempStr.replace('[', '').replace(']', '');
                contentStr += "<img src='" + chatIconId + "' width=25 height=25 />";
                tempStr = '';
                continue;
            }
            if (startFlag || endFlag) {
                continue;
            }
            contentStr += char;
        }
        contentStr += tempStr;
        // console.log('contentStr='+contentStr)
        // return '<color=#000000>' + contentStr + '</color>';
        return contentStr;
    }

    

}