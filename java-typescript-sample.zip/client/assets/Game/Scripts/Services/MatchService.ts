import { LogUtil } from "../Log/LogUtil";
import proto from '../../Proto/proto.js';
import { NetClient } from "../Network/NetClient";
import { MessageBox, MessageBoxType } from "../UI/Common/MessageBox";
import { EventManager } from "../UI/Common/Event/EventManager";
import { EventType } from "../UI/Common/Event/EventType";
import { SocketConst } from "../Network/SocketConst";
import { User } from "../Models/User";
import { director, sys } from "cc";
import { ItemManager } from "../Managers/ItemManager";
import { ChatManager } from "../Managers/ChatManager";
import { TipsManager } from "../UI/TipsManager";
import { UIMatchWait } from "../UI/Match/UIMatchWait";
import { LocalStorageUtil } from "../Utils/LocalStorageUtil";
import { RandomUtil } from "../UI/Battle/Utils/RandomUtil";
import { BattleGlobal } from "../UI/Battle/Utils/BattleGlobal";
import { BattleMode } from "../UI/Battle/enums/BattleMode";
import { Util } from "../Utils/Util";
import { NetConfig } from "../Network/NetConfig";
import { NetClientBattle } from "../Network/Battle/NetClientBattle";
import { UIManager } from "../../../Scripts/UI/Common/UIManager";
import { Constant } from "../../../Scripts/Utils/Constant";
import AdManager from "../../../Scripts/Platform/Sdk/AdManager";

export class MatchService {
    public static Instance: MatchService = new MatchService();

    private uiMatchWait: any = null;
    public Init() {
        EventManager.Instance.addListener(EventType.OnStartMatch, this.OnStartMatch, this)
        EventManager.Instance.addListener(EventType.OnMatchResponse, this.OnMatchResponse, this)
        EventManager.Instance.addListener(EventType.OnCancelMatchResponse, this.OnCancelMatchResponse, this)
    }

    /**
     * Check if match request exists
     */
    public CheckExistMatch(): void {
        LogUtil.log("CheckExistMatch");
        let message = new proto.Message.NetMessage();
        message.Request = new proto.Message.NetMessageRequest();
        message.Request.startMatchReq = new proto.Message.StartMatchRequest();
        message.Request.startMatchReq.checkExistMatch = true;
        NetClient.Instance.SendMessage(message);
    }


    private lastMatchType: number = 0;
    /**
     * Start match request
     */
    public SendStartMatch(type: number): void {
        LogUtil.log("SendStartMatch");
        BattleGlobal.isExistBattleFlag = false;
        if (type == -1) {
            type = this.lastMatchType;
        } else {
            this.lastMatchType = type;
        }
        let message = new proto.Message.NetMessage();
        message.Request = new proto.Message.NetMessageRequest();
        message.Request.startMatchReq = new proto.Message.StartMatchRequest();
        message.Request.startMatchReq.matchType = type;
        message.Request.startMatchReq.checkExistMatch = false;
        NetClient.Instance.SendMessage(message);

        AdManager.Instance.ShowChaPingAd();
        AdManager.Instance.HideBannerAd();
    }


    /** 
     * Start match response
     */
    private async OnStartMatch(param: any): Promise<void> {
        let response = param[0] as proto.Message.StartMatchResponse;
        LogUtil.log("OnStartMatch:{0}", response.result, response.errormsg);
        if (response.result == Constant.Result.Success) {
            await this.OpenUIMatchWait();
        } else {
            TipsManager.Instance.showTips(response.errormsg);
        }
    }

    /**
     * Open match wait
     */
    public async OpenUIMatchWait(isCancelMatchBtnFlag: boolean = true) {
        this.uiMatchWait = await UIManager.Instance.show("UIMatchWait", false) as UIMatchWait;  //Open match popup
        if (this.uiMatchWait) {
            this.uiMatchWait.show(isCancelMatchBtnFlag, 0, 50);
        }
    }

    /**
     * Open match wait
     */
    public async OpenUIRoomMatchWait(isCancelMatchBtnFlag: boolean = true) {
        this.uiMatchWait = await UIManager.Instance.show("UIMatchWait", false) as UIMatchWait;  //Open room match popup
        if (this.uiMatchWait) {
            this.uiMatchWait.show(isCancelMatchBtnFlag, 0, 50);
        }
    }

    /**
     * Close match wait
     */
    public CloseUIMatchWait() {
        if (this.uiMatchWait) {   //Close match popup 
            this.uiMatchWait.Close();
            this.uiMatchWait = null;
        }
    }

    private timer = null;
    private isCompleteLoad:boolean = false;  //Whether loading is complete
    /**
     * Match response
     */
    public OnMatchResponse(param: any) {
        let response = param[0] as proto.Message.MatchResponse;
        LogUtil.log("OnMatchResponse:{0}", response.result, response.errormsg, response.isClearTheLocalFrameCache);
        this.CloseUIMatchWait();
        TipsManager.Instance.showTips(response.errormsg);

        if (response.result == Constant.Result.Success) {  //Match successful
            if (response.isClearTheLocalFrameCache) {
                console.log('Clear last frame operation cache---------------------')
                LocalStorageUtil.RemoveItem(LocalStorageUtil.allFrameHandlesKey + User.Instance.user.id);  //Clear last frame operation cache
                LocalStorageUtil.RemoveItem(LocalStorageUtil.stateRecordKey + User.Instance.user.id);
            }
            if (response.errormsg == 'Match successful') {
            } else if (response.errormsg == 'Battle exists, resume game!') {
                BattleGlobal.isExistBattleFlag = true;
            }

            if (!Constant.preLoadEnd) {
                EventManager.Instance.dispatch(EventType.PreLoadShow);
            }

            BattleGlobal.battleMode = BattleMode.Battle;  //Set to battle mode

            User.Instance.room = response.room;
            RandomUtil.seed = response.room.randomSeed;   //Set battle random seed
            LocalStorageUtil.SetItem(LocalStorageUtil.matchRandomSeedKey + User.Instance.user.id, String(response.room.randomSeed));  // RISK 5: persist initial seed
            // BattleGlobal.playingMethod is already set in UIMain when user clicks match button
            // No need to override it here - it retains the user's selection (3v3 or 5v5)
            this.isCompleteLoad = false;  //Whether loading is complete
            let this_ = this;
            this.timer = setInterval(function () {
                if (Constant.preLoadEnd && !this_.isCompleteLoad) {
                    clearInterval(this_.timer);
                    this_.isCompleteLoad = true;
                    AdManager.Instance.HideBannerAd();
                    Util.ToBattleScene(); //Jump to battle server
                }
            }, 1000);

        }
    }

    /**
     * Cancel match request
     */
    public SendCancelMatch(): void {
        LogUtil.log("SendCancelMatch");
        let message = new proto.Message.NetMessage();
        message.Request = new proto.Message.NetMessageRequest();
        message.Request.cancelMatchReq = new proto.Message.CancelMatchRequest();
        NetClient.Instance.SendMessage(message);
    }

    /** 
     * Cancel match response
     */
    private async OnCancelMatchResponse(param: any): Promise<void> {
        let response = param[0] as proto.Message.CancelMatchResponse;
        LogUtil.log("OnCancelMatchResponse:{0}", response.result, response.errormsg);
        this.CloseUIMatchWait();
        TipsManager.Instance.showTips(response.errormsg);
    }
}