import { LogUtil } from "../Log/LogUtil";
import proto from '../../Proto/proto.js';
import { NetClient } from "../Network/NetClient";
import { MessageBox, MessageBoxType } from "../UI/Common/MessageBox";
import { EventManager } from "../UI/Common/Event/EventManager";
import { EventType } from "../UI/Common/Event/EventType";
import { SocketConst } from "../Network/SocketConst";
import { User } from "../Models/User";
import { director } from "cc";
import { TipsManager } from "../UI/TipsManager";
import { RandomUtil } from "../UI/Battle/Utils/RandomUtil";
import { LocalStorageUtil } from "../Utils/LocalStorageUtil";
import { BattleMode } from "../UI/Battle/enums/BattleMode";
import { BattleGlobal } from "../UI/Battle/Utils/BattleGlobal";
import { CharacterManager } from "../UI/Battle/Managers/CharacterManager";
import { MatchService } from "./MatchService";
import { Util } from "../Utils/Util";
import { ChatService } from "./ChatService";
import { ChatManager } from "../Managers/ChatManager";
import { UIManager } from "../../../Scripts/UI/Common/UIManager";
import { Constant } from "../../../Scripts/Utils/Constant";
import { HashMap } from "../../../Scripts/Utils/HashMap";

export class RoomService {

    public static Instance: RoomService = new RoomService();

    public Init() {
        EventManager.Instance.addListener(EventType.OnMyRoom, this.OnMyRoom, this)
        EventManager.Instance.addListener(EventType.OnInviteResponse, this.OnInviteResponse, this)
        EventManager.Instance.addListener(EventType.OnInviteRequest, this.OnInviteRequest, this)
        EventManager.Instance.addListener(EventType.OnKickOut, this.OnKickOut, this)
        EventManager.Instance.addListener(EventType.OnRoomStartGame, this.OnRoomStartGame, this)
        EventManager.Instance.addListener(EventType.OnNickNameSearch, this.OnNickNameSearch, this)
        EventManager.Instance.addListener(EventType.OnAddRoomRequest, this.OnAddRoomRequest, this)
        EventManager.Instance.addListener(EventType.OnAddRoomResponse, this.OnAddRoomResponse, this)
        EventManager.Instance.addListener(EventType.OnOutRoom, this.OnOutRoom, this)
        EventManager.Instance.addListener(EventType.OnAddLiveResponse, this.OnAddLiveResponse, this)
        EventManager.Instance.addListener(EventType.OnValidateOpenRoom, this.OnValidateOpenRoom, this)
        EventManager.Instance.addListener(EventType.OnTeamInfoLook, this.OnTeamInfoLook, this)
    }

    /**
     * Request my room
     */
    public SendMyRoom(type: number): void {
        LogUtil.log("SendMyRoom");
        let message = new proto.Message.NetMessage();
        message.Request = new proto.Message.NetMessageRequest();
        message.Request.myRoomReq = new proto.Message.MyRoomRequest();
        message.Request.myRoomReq.type = type;
        NetClient.Instance.SendMessage(message);
    }

    /**
     * My room response
     */
    private OnMyRoom(param: any): void {
        let response = param[0] as proto.Message.MyRoomResponse;
        // LogUtil.log("OnMyRoom:{0}", response.room);

        //Initialize chat info every time login or join new room
        if (!User.Instance.room) {
            ChatManager.Instance.ClearRoomChatMsg();
            let myList = response.room.my as unknown as Array<proto.Message.NRoomUser> || [];
            for (let i = 0; i < myList.length; i++) {
                if (response.room.userId == myList[i].user.id) {
                    ChatManager.Instance.AddRoomChatMsg("Ready for battle!", myList[i]);
                    EventManager.Instance.dispatch(EventType.OnChat_UI, proto.Message.ChatChannel.RoomChat);
                }
            }
        }
        User.Instance.room = response.room;
        EventManager.Instance.dispatch(EventType.OnMyRoom_UI, response.room);
    }

    /**
     * Send invite request
     */
    public SendInviteRequest(toUserId: number, toNickName: string, teamType: proto.Message.TeamType): void {
        LogUtil.log("SendInviteRequest");
        let message = new proto.Message.NetMessage();
        message.Request = new proto.Message.NetMessageRequest();
        message.Request.inviteReq = new proto.Message.InviteRequest();
        message.Request.inviteReq.fromUserId = User.Instance.user.id;
        message.Request.inviteReq.fromNickName = User.Instance.user.nickname;
        message.Request.inviteReq.toUserId = toUserId;
        message.Request.inviteReq.toNickName = toNickName;
        message.Request.inviteReq.teamType = teamType;
        NetClient.Instance.SendMessage(message);
    }

    /**
     * Send invite response
     */
    public SendInviteResponse(accept: boolean, inviteRequest: proto.Message.InviteRequest): void {
        LogUtil.log("SendInviteResponse");
        let message = new proto.Message.NetMessage();
        message.Request = new proto.Message.NetMessageRequest();
        message.Request.inviteRes = new proto.Message.InviteResponse();
        message.Request.inviteRes.result = accept ? Constant.Result.Success : Constant.Result.Failed;
        message.Request.inviteRes.errormsg = '';
        message.Request.inviteRes.inviteRequest = inviteRequest;
        NetClient.Instance.SendMessage(message);
    }

    /**
     * Receive invite request
     */
    private async OnInviteRequest(param: any) {
        let request = param[0] as proto.Message.InviteRequest;
        LogUtil.log("OnInviteRequest", request);
        let confirmObj = await MessageBox.Show(request.fromNickName + " invites you to join the room?", "Invite request", MessageBoxType.Confirm, "Accept", "Reject");
        let this_ = this;
        EventManager.Instance.addListener(EventType.UIMessageBox_OnClickYes, function () {
            this_.SendInviteResponse(true, request);
        }, confirmObj);
        EventManager.Instance.addListener(EventType.UIMessageBox_OnClickNo, function () {
            this_.SendInviteResponse(false, request);
        }, confirmObj);
    }

    /**
     * Receive invite response
     */
    private OnInviteResponse(param: any): void {
        let response = param[0] as proto.Message.InviteResponse;
        LogUtil.log("OnInviteResponse:{0}{1}", response.result, response.errormsg);
        TipsManager.Instance.showTips(response.errormsg);
        if (response.result == Constant.Result.Success) {
            //Invited user is current user
            if (response.inviteRequest.toUserId == User.Instance.user.id) {
                UIManager.Instance.show("UIRoom");
            } else {
                EventManager.Instance.dispatch(EventType.OnMyRoom_RefreshUI);
            }
        }
    }

    /**
     * Kick out request
     */
    public SendKickOut(userId: number): void {
        LogUtil.log("SendKickOut");
        let message = new proto.Message.NetMessage();
        message.Request = new proto.Message.NetMessageRequest();
        message.Request.kickOutReq = new proto.Message.KickOutRequest();
        message.Request.kickOutReq.userId = userId;
        NetClient.Instance.SendMessage(message);
    }

    /**
     * Kick out response
     */
    private OnKickOut(param: any): void {
        let response = param[0] as proto.Message.KickOutResponse;
        LogUtil.log("OnKickOut:{0}{1}", response.result, response.errormsg);
        TipsManager.Instance.showTips(response.errormsg);
    }

    /**
     * Start game request
     */
    public SendRoomStartGame(): void {
        LogUtil.log("SendRoomStartGame");
        let message = new proto.Message.NetMessage();
        message.Request = new proto.Message.NetMessageRequest();
        message.Request.roomStartGameReq = new proto.Message.RoomStartGameRequest();
        message.Request.roomStartGameReq.isMatchOther = true;
        
        // Get gold cost from invite mode session (if set)
        const goldCost = User.Instance.user['inviteModeGoldCost'] || 0;
        message.Request.roomStartGameReq.battleGoldCost = goldCost;
        
        // Get playing mode (3v3 or 5v5)
        message.Request.roomStartGameReq.playingMode = BattleGlobal.playingMethod;
        
        const playingModeText = BattleGlobal.playingMethod === Constant.PlayingMethod.ThreeVsThree ? "3v3" : "5v5";
        LogUtil.log(`SendRoomStartGame with gold cost: ${goldCost}, mode: ${playingModeText}`);
        NetClient.Instance.SendMessage(message);
    }

    /**
     * Start game response
     */
    public async OnRoomStartGame(param: any): Promise<void> {
        let response = param[0] as proto.Message.RoomStartGameResponse;
        LogUtil.log("OnRoomStartGame{0}{1}：", response.result, response.errormsg);
        if (response.result == Constant.Result.Success) {
            EventManager.Instance.dispatch(EventType.OnRoomStartGame_UI, response);
            await MatchService.Instance.OpenUIRoomMatchWait();
        } else {
            TipsManager.Instance.showTips(response.errormsg);
            //Room no longer exists, cache still there, request force refresh room
            if (response.result == 2) {
                EventManager.Instance.dispatch(EventType.OnMyRoom_ForceRefreshUI);
            }
        }
    }

    /**
     * Nickname search request
     */
    public SendNickNameSearch(nickName?: string): void {
        LogUtil.log("SendNickNameSearch");
        let message = new proto.Message.NetMessage();
        message.Request = new proto.Message.NetMessageRequest();
        message.Request.nickNameSearchReq = new proto.Message.NickNameSearchRequest();
        message.Request.nickNameSearchReq.nickName = nickName;
        NetClient.Instance.SendMessage(message);
    }

    /**
    * Nickname search response
    */
    public OnNickNameSearch(param: any): void {
        let response = param[0] as proto.Message.NickNameSearchResponse;
        LogUtil.log("OnNickNameSearch");
        EventManager.Instance.dispatch(EventType.OnNickNameSearch_UI, response.roomUser);
    }

    /**
     * Send join room request
     */
    public SendAddRoomRequest(roomId: number): void {
        LogUtil.log("SendAddRoomRequest");
        let message = new proto.Message.NetMessage();
        message.Request = new proto.Message.NetMessageRequest();
        message.Request.addRoomReq = new proto.Message.AddRoomRequest();
        message.Request.addRoomReq.roomId = roomId;
        message.Request.addRoomReq.fromUserId = User.Instance.user.id;
        message.Request.addRoomReq.fromNickName = User.Instance.user.nickname;
        NetClient.Instance.SendMessage(message);
    }

    /**
     * Send join room response
     */
    public SendAddRoomResponse(accept: boolean, teamType: proto.Message.TeamType, addRoomRequest: proto.Message.AddRoomRequest): void {
        LogUtil.log("SendAddRoomResponse");
        let message = new proto.Message.NetMessage();
        message.Request = new proto.Message.NetMessageRequest();
        message.Request.addRoomRes = new proto.Message.AddRoomResponse();
        message.Request.addRoomRes.result = accept ? Constant.Result.Success : Constant.Result.Failed;
        message.Request.addRoomRes.errormsg = '';
        message.Request.addRoomRes.teamType = teamType;
        message.Request.addRoomRes.addRoomRequest = addRoomRequest;
        NetClient.Instance.SendMessage(message);
    }

    /**
     * Receive join room request
     */
    private async OnAddRoomRequest(param: any) {
        let request = param[0] as proto.Message.AddRoomRequest;
        // LogUtil.log("OnAddRoomRequest", request);
        let confirmObj = await MessageBox.Show(request.fromNickName + " join room?", "Join room", MessageBoxType.Confirm, "Accept", "Reject");
        let this_ = this;
        EventManager.Instance.addListener(EventType.UIMessageBox_OnClickYes, async () => {
            if (Util.roomModeType == 0) {  //Regular match
                this_.SendAddRoomResponse(true, proto.Message.TeamType.My, request)
            } else {  //Free match
                let teamConfirmObj = await MessageBox.Show("Please choose " + request.fromNickName + " to join team!", "Choose team", MessageBoxType.Confirm, "Friendly team", "Enemy team");
                EventManager.Instance.addListener(EventType.UIMessageBox_OnClickYes, () => {
                    this_.SendAddRoomResponse(true, proto.Message.TeamType.My, request)
                }, teamConfirmObj);
                EventManager.Instance.addListener(EventType.UIMessageBox_OnClickNo, () => {
                    this_.SendAddRoomResponse(true, proto.Message.TeamType.Enemy, request)
                }, teamConfirmObj);
            }
        }, confirmObj);
        EventManager.Instance.addListener(EventType.UIMessageBox_OnClickNo, async () => {
            this_.SendAddRoomResponse(false, proto.Message.TeamType.My, request)
        }, confirmObj);
    }


    /**
     * Receive join room response
     */
    private OnAddRoomResponse(param: any): void {
        let response = param[0] as proto.Message.AddRoomResponse;
        LogUtil.log("OnAddRoomResponse:{0}{1}", response.result, response.errormsg);
        //If gathering expires, clicking can enter own room
        if (response.errormsg == 'NotFoundRoom') {
            UIManager.Instance.Close("UIChat");
            UIManager.Instance.show("UIRoom");
        } else {
            TipsManager.Instance.showTips(response.errormsg);
        }
        if (response.result == Constant.Result.Success) {
            //Joiner is current user
            if (response.addRoomRequest.fromUserId == User.Instance.user.id) {
                UIManager.Instance.Close("UIChat");
                UIManager.Instance.show("UIRoom");
            } else {
                EventManager.Instance.dispatch(EventType.OnMyRoom_RefreshUI);
            }
        }
    }

    /**
     * Exit room request
     */
    public SendOutRoom(): void {
        LogUtil.log("SendOutRoom");
        let message = new proto.Message.NetMessage();
        message.Request = new proto.Message.NetMessageRequest();
        message.Request.outRoomReq = new proto.Message.OutRoomRequest();
        NetClient.Instance.SendMessage(message);
    }

    /**
     * Exit room response
     */
    public OnOutRoom(param: any): void {
        let response = param[0] as proto.Message.OutRoomResponse;
        LogUtil.log("OnOutRoom{0}{1}：", response.result, response.errormsg);
        TipsManager.Instance.showTips(response.errormsg);
    }

    /**
     * Request game end
     */
    public SendGameOver2(data: string, otherData: string): void {
        // LogUtil.log("SendGameOver2 data="+data);
        let message = new proto.Message.NetMessage();
        message.Request = new proto.Message.NetMessageRequest();
        message.Request.gameOver2Req = new proto.Message.GameOver2Request();
        message.Request.gameOver2Req.data = data;
        message.Request.gameOver2Req.otherData = otherData;
        NetClient.Instance.SendMessage(message);
    }

    /**
     * Upload score request
     */
    public SendUploadBiFen(biFen: string): void {
        // LogUtil.log("SendUploadBiFen");
        let message = new proto.Message.NetMessage();
        message.Request = new proto.Message.NetMessageRequest();
        message.Request.uploadBiFenReq = new proto.Message.UploadBiFenRequest();
        message.Request.uploadBiFenReq.biFen = biFen;
        NetClient.Instance.SendMessage(message);
    }

    /**
     * Enter live request
     */
    public SendAddLive(targetUserId: number): void {
        LogUtil.log("SendAddLive");
        BattleGlobal.targetLiveUserId = targetUserId;
        let message = new proto.Message.NetMessage();
        message.Request = new proto.Message.NetMessageRequest();
        message.Request.addLiveReq = new proto.Message.AddLiveRequest();
        message.Request.addLiveReq.userId = targetUserId;
        NetClient.Instance.SendMessage(message);
    }

    /**
     * Receive enter live response
     */
    private OnAddLiveResponse(param: any): void {
        let response = param[0] as proto.Message.AddLiveResponse;
        LogUtil.log("OnAddLiveResponse:{0}{1}", response.result, response.errormsg);
        TipsManager.Instance.showTips(response.errormsg);
        if (response.result == Constant.Result.Success) {  //Enter live room
            LocalStorageUtil.RemoveItem(LocalStorageUtil.allFrameHandlesKey + User.Instance.user.id);
            LocalStorageUtil.RemoveItem(LocalStorageUtil.stateRecordKey + User.Instance.user.id);
            BattleGlobal.battleMode = BattleMode.Live;

            User.Instance.room = response.room;
            RandomUtil.seed = response.room.randomSeed;   //Set battle random seed
            LocalStorageUtil.SetItem(LocalStorageUtil.matchRandomSeedKey + User.Instance.user.id, String(response.room.randomSeed));  // RISK 5: persist initial seed
            // Note: For live watching, playingMethod should be determined from the room being watched
            // For now, keep the existing mode selection
            Util.ToBattleScene(); //Jump to battle server
        }
    }

    /**
     * Request verify if can create room
     */
    public SendValidateOpenRoom(): void {
        LogUtil.log("SendValidateOpenRoom");
        let message = new proto.Message.NetMessage();
        message.Request = new proto.Message.NetMessageRequest();
        message.Request.validateOpenRoomReq = new proto.Message.ValidateOpenRoomRequest();
        NetClient.Instance.SendMessage(message);
    }

    /**
     * Verify if can create room response
     */
    private OnValidateOpenRoom(param: any): void {
        let response = param[0] as proto.Message.ValidateOpenRoomResponse;
        LogUtil.log("OnValidateOpenRoom:{0}", response);
        if (response.result == Constant.Result.Success) {
            UIManager.Instance.show("UIRoom");
        } else {
            TipsManager.Instance.showTips(response.errormsg);
        }
    }

    /**
     * Request team info view
     */
    public SendTeamInfoLook(): void {
        LogUtil.log("SendTeamInfoLook");
        let message = new proto.Message.NetMessage();
        message.Request = new proto.Message.NetMessageRequest();
        message.Request.teamInfoLookReq = new proto.Message.TeamInfoLookRequest();
        NetClient.Instance.SendMessage(message);
    }

    /**
     * Team info view response
     */
    private OnTeamInfoLook(param: any): void {
        let response = param[0] as proto.Message.TeamInfoLookResponse;
        LogUtil.log("OnTeamInfoLook:{0}", response);
        let teamInfoList = response.teamInfos || [];
        //Convert to map
        let teamInfoMap = new HashMap();
        for (let i = 0; i < teamInfoList.length; i++) {
            let teamInfo = teamInfoList[i];
            teamInfoMap.put(teamInfo.userId, teamInfo);
        }

        //Update battle record values
        // let characterList = CharacterManager.Instance.characterList;
        // for (let j = 0; j < characterList.length; j++) {
        //     let characterObj = characterList[j];
        //     let teamInfo = teamInfoMap.get(characterObj.user.id);
        //     characterObj.user.barrageCount = teamInfo ? teamInfo.barrageCount : 0;
        // }
        //User does not have barrageCount property

        EventManager.Instance.dispatch(EventType.OnTeamInfoLook_UI);

    }

    /**
    * Request exit live
    */
    public SendOutLive(): void {
        LogUtil.log("SendOutLive");
        let message = new proto.Message.NetMessage();
        message.Request = new proto.Message.NetMessageRequest();
        message.Request.outLiveReq = new proto.Message.OutLiveRequest();
        NetClient.Instance.SendMessage(message);
    }
}