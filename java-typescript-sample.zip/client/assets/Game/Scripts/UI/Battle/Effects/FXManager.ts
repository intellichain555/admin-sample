import { _decorator, instantiate, Node, Component, Vec3, AnimationComponent, Prefab, UITransform, Vec2 } from 'cc';
import { EffectController } from './EffectController';
import { EffectType } from './EffectType';
import { BattleManager } from '../Managers/BattleManager';
import { DeferredWorkManager } from '../Managers/DeferredWorkManager';
import { BattleGlobal } from '../Utils/BattleGlobal';
import { PoolManager } from '../../../Managers/PoolManager';
import { HashMap } from '../../../../../Scripts/Utils/HashMap';
const { ccclass, property } = _decorator;

@ccclass('FXManager')
export class FXManager extends Component{

    @property([Prefab])
    public prefabs=new Array<Prefab>();
    // key=>name  value=>node
    private Effects = new HashMap();

    public static Instance:FXManager=null;

    onLoad () {
        FXManager.Instance=this;
        console.log('FXManager Instance')
    }

    public start()
    {
        // FXManager.Instance=this;
        // console.log('FXManager Instance')
        this.Effects.clear();
        for(let i = 0; i < this.prefabs.length; i++)
        {
            let rootNode = this.prefabs[i].data;
            rootNode.active=false;
            this.Effects.put(rootNode.name, rootNode);

            // Create object pool
            PoolManager.instance.preloadPool(rootNode, 2, rootNode.name);
            
            // console.log('FXManager createPool name='+rootNode.name)
        }

    }

    public CreateEffect(name:string):EffectController
    {
            // console.log('FXManager CreateEffect：'+name)
            // Get object instance
            let go = PoolManager.instance.getNode2(name, { optimizeParticles: true });
            if(go){
                BattleManager.Instance.AllBattleEffectsNode.addChild(go);
                return go.getComponent(EffectController);
            }
        return null;
    }

    public CreateEffect2(name:string, pos:Vec3, parentNode?:Node):Node
    {
            // console.log('FXManager CreateEffect2：'+name)
            // Get object instance
            if(parentNode && parentNode.children.length > 0){  // Parent node already has effects, use previous effects
              let go = parentNode.children[0];
              go.worldPosition = pos;
              return go;
            }else{
                let go = PoolManager.instance.getNode2(name, { optimizeParticles: true });
                if(go){
                    if(parentNode){
                        parentNode.addChild(go);
                    }else{
                        BattleManager.Instance.AllBattleEffectsNode.addChild(go);
                    }
                    go.worldPosition = pos;
                    return go;
                }
            }
        return null;
    }
 
    public PlayEffect(type:EffectType,  name:string, target:Node, pos:Vec3, duration:number)
    {
        let effect = this.CreateEffect(name);
        if (!effect)
        {
            console.log("Effect:{0} not found.", name);
            return;
        }
        effect.Init(type, this.node, target, pos, duration);
        BattleGlobal.playParticleEffect(effect.node);
    }

	public PlayEffect2(name:string, pos:Vec3, parentNode?:Node):Node
    {
        let effectNode = this.CreateEffect2(name, pos, parentNode);
        if (!effectNode)
        {
            console.log("effectNode:{0} not found.", name);
            return null;
        }
        BattleGlobal.playParticleEffect(effectNode);
        return effectNode;
    }

    /**
     * Play effect attached to parent, or defer for safe processing (WeakRef + worldPos fallback).
     * @param defer When true, enqueues for deferred processing; parent may be destroyed before execution.
     * @param resultHolder When defer, if provided and parent valid at process time, set resultHolder.node for recovery.
     * @param opts When defer, optional yValue (set world Y) or scale applied after attach.
     */
    public PlayEffect3(name: string, parentNode: Node, defer = false, resultHolder?: { node: Node | null }, opts?: { yValue?: number; scale?: import('cc').Vec3 }): Node | null {
        if (defer) {
            DeferredWorkManager.Instance.enqueuePlayEffect3FX(name, parentNode, resultHolder, opts);
            return null;
        }
        const effectNode = PoolManager.instance.getNode2(name, { optimizeParticles: true });
        if (effectNode) {
            parentNode.addChild(effectNode);
            BattleGlobal.playParticleEffect(effectNode);
        }
        return effectNode;
    }

    /**
     * Recycle particle node
     */
    public recoveryNode(node:Node){
        if(!node){
            return;
        }
        node.active = false;
        node.removeFromParent();  // Remove node from parent node
        PoolManager.instance.putNode(node);  // Recycle to object pool
    }

    /**
     * Pre-warm effect prefabs so shaders/materials compile at load instead of during gameplay.
     * Reduces frame hitches when effects are first played in battle.
     * @param parentNode Parent to attach effects to briefly (e.g. AllBattleEffectsNode)
     * @param onComplete Optional callback when pre-warm is done
     */
    public preWarmEffects(parentNode: Node, onComplete?: () => void): void {
        if (!parentNode || this.prefabs.length === 0) {
            onComplete?.();
            return;
        }
        const warmedNodes: Node[] = [];
        for (let i = 0; i < this.prefabs.length; i++) {
            let name = this.prefabs[i].data.name;
            let node = PoolManager.instance.getNode2(name, { optimizeParticles: true });
            if (node) {
                parentNode.addChild(node);
                node.setWorldPosition(0, -1000, 0);  // Off-screen so not visible
                node.active = true;
                BattleGlobal.playParticleEffect(node);
                warmedNodes.push(node);
            }
        }
        // Put all back after 2–3 frames so renderer processes them (shader/material compile)
        this.scheduleOnce(() => {
            for (let j = 0; j < warmedNodes.length; j++) {
                let n = warmedNodes[j];
                if (n && n.isValid) {
                    n.active = false;
                    n.removeFromParent();
                    PoolManager.instance.putNode(n);
                }
            }
            onComplete?.();
        }, 0.15);
    }

}