import { _decorator, instantiate, Node, Component, Vec3, AnimationComponent, Prefab, UITransform, Vec2, director, Settings, animation } from 'cc';
import { EffectType } from './EffectType';
import { EffectController } from './EffectController';
import { BattleManager } from '../Managers/BattleManager';
import { Creature } from '../Enities/Creature';
import { DeferredWorkManager } from '../Managers/DeferredWorkManager';
import { Bullet } from '../Models/Bullet';
import { BattleGlobal } from '../Utils/BattleGlobal';
import { DataUtil } from '../../../Utils/DataUtil';
import { SkillDefine } from '../../../Data/SkillDefine';
import { AniState } from '../enums/AniState';
import { CreatureManager } from '../Managers/CreatureManager';
import { PoolManager } from '../../../Managers/PoolManager';
import { TeamType2 } from '../enums/TeamType2';
import { HashMap } from '../../../../../Scripts/Utils/HashMap';
const { ccclass, property } = _decorator;

@ccclass('EntityEffectManager')
export class EntityEffectManager extends Component{

    @property(Node)
    public Root:Node;
    @property([Node])
    public Props=new Array<Node>();
    
    // key=>name  value=>node
    private Effects = new HashMap();
    // key=>name  value=>posArr
    private posMap = new HashMap();

    public start()
    {
        this.Effects.clear();
        this.posMap.clear();

        let children = this.Root.children;
        if(this.Root !=null && children.length > 0)
        {
            for(let i = 0; i < children.length; i++)
            {
                let node = children[i];
                this.preloadCreate(node);
            }
        }
        if(this.Props != null)
        {
            for (let i = 0; i < this.Props.length; i++)
            {
                let node = this.Props[i];
                this.preloadCreate(node);
            }
        }
    }

    /**
     * Pre-create
     */
    private preloadCreate(node:Node){
        node.active = false;
        let nodeName = node.name;
        this.Effects.put(nodeName, node)
        this.posMap.put(nodeName, [node.position.x, node.position.y, node.position.z]);
        let count:number = 1;
        let effectController = node.getComponent(EffectController);
        if(effectController){
            count = effectController.preloadCount;
        }
        // Create object pool
        PoolManager.instance.preloadPool(node, count, nodeName+this.uuid);
    }

    private worldRotation_ = new Vec3();

    /**
     * Execute PlayEffect3 logic - called by DeferredWorkManager when processing deferred queue.
     * Validates creature before running (may have been destroyed since enqueue).
     */
    public executeDeferredPlayEffect3(name: string, isEffectFollowHero?: boolean, teamType2?: TeamType2 | number): void {
        const entityId = this.node['entityId'];
        const creature = CreatureManager.Instance.GetCreature(entityId);
        if (!creature || !creature.node?.isValid) return;
        if (teamType2 !== undefined && teamType2 >= 0 && creature.teamType2 !== teamType2) return;
        if (BattleGlobal.validateIsSkillInterrupt(creature)) return;
        this.playEffect3Impl(name, isEffectFollowHero, creature);
    }

    public PlayEffect3(name: string, isEffectFollowHero?: boolean, teamType2?: TeamType2, defer = false) {
        if (defer) {
            DeferredWorkManager.Instance.enqueuePlayEffect3Entity(this, name, isEffectFollowHero, teamType2 as number);
            return;
        }
        const entityId = this.node['entityId'];
        const creature = CreatureManager.Instance.GetCreature(entityId);
        if (teamType2 || teamType2 >= 0) {
            if (!creature || creature.teamType2 != teamType2) return;
        }
        if (BattleGlobal.validateIsSkillInterrupt(creature)) return;
        this.playEffect3Impl(name, isEffectFollowHero, creature);
    }

    private playEffect3Impl(name: string, isEffectFollowHero?: boolean, creature?: Creature) {
        if (!creature) return;
        const prefab = this.Effects.get(name) as Node;
        const node = PoolManager.instance.getNode(prefab, undefined, undefined, name + this.uuid, { optimizeParticles: true });
        if (!node || !prefab) return;
        const allBattleEffectsNode = BattleManager.Instance?.AllBattleEffectsNode;
        if (!allBattleEffectsNode || isEffectFollowHero) {
            creature.effectParentNode.addChild(node);
            node.position = prefab.position;
            node.rotation = prefab.rotation;
        } else {
            allBattleEffectsNode.addChild(node);
            node.worldPosition = this.node.worldPosition;
            node.worldRotation = this.node.worldRotation;
        }
        creature.SkillMgr.setSkillEffectNode(creature.aniState, node);
        node.worldRotation.getEulerAngles(this.worldRotation_);
        this.worldRotation_.y = creature.logicRotation.y;
        node.setWorldRotationFromEuler(this.worldRotation_.x, this.worldRotation_.y, this.worldRotation_.z);
        BattleGlobal.playParticleEffect(node);
    }


    /**
     * Bullet type effect
     */
    public PlayEffect2(type:EffectType,  name:string, target:Node, pos:Vec3, duration:number, bullet?:Bullet, isUseGlobalEffect?:boolean, scale?:number) :Node{
        if (type == EffectType.Bullet || type == EffectType.Hit || type == EffectType.Position) {
            let node = this.InstantiateEffect(name, isUseGlobalEffect);
            if(node){
                // console.log('PlayEffect2 name='+name+',node=',node.worldPosition)
                let effectController = node.getComponent(EffectController);
                if(!effectController){
                    // console.log('not find prefab')
                    return;
                }
                // BattleManager.Instance.AllBattleEffectsNode.addChild(node);
                effectController.Init(type, this.node, target, pos, duration, bullet);
                BattleGlobal.playParticleEffect(node, undefined, scale);
                // console.log('PlayEffect2 worldPosition=', node.worldPosition, 'pos=', pos)
            }
            return node;
        }else{
            this.PlayEffect3(name);
        }
        return null;
    }

    public PlayEffectBulletRealCheck(type:EffectType, name:string, bullet:Bullet) {
        if (type == EffectType.BulletRealCheck) {
            let node = this.InstantiateEffect(name, false, true);  // addAsInactive: defer activateNode
            if(node){
                let effectController = node.getComponent(EffectController);
                if(!effectController){
                    return;
                }
                effectController.InitBulletRealCheck(type, bullet);
                DeferredWorkManager.Instance.enqueueParticleActivation(node);
            }
        }
    }

    private nodeCurrentPosition = new Vec3();
    public InstantiateEffect(name:string, isUseGlobalEffect?:boolean, addAsInactive?:boolean):Node {
        let prefab:Node = null;
        let go:Node = null;
        if(isUseGlobalEffect){
            go = PoolManager.instance.getNode2(name, { optimizeParticles: true });
            prefab = go;
        }else{
            prefab = this.Effects.get(name) as Node;
            // let go = PoolManager.instance.getNode2(name+this.uuid);  // Get object instance
            go = PoolManager.instance.getNode(prefab, undefined, undefined, name+this.uuid, { optimizeParticles: true });   // Get object instance
        }
        if(go && prefab && this.node.parent) {
            if (addAsInactive) {
                go.active = false;
            }
            BattleManager.Instance.AllBattleEffectsNode.addChild(go);
            
           this.node.parent.getWorldPosition(this.nodeCurrentPosition);   
           let posArr =  this.posMap.get(name);
           if(posArr){
             this.nodeCurrentPosition.add3f(posArr[0], posArr[1], posArr[2]);
           }

            go.worldPosition = this.nodeCurrentPosition;
            go.worldRotation = prefab.worldRotation;
           
            // if(name == 'bullet'){
            //     console.log('InstantiateEffect bullet worldPosition=', go.worldPosition, go.position)
            // }
            return go;
        }
        return null;
    }


    /**
     * Delay display
     * @param delayTime Delay time
     */
    public DelayShow(delayTime:number, aniState:AniState){
        let this_ = this;
        setTimeout(function(){
          this_.node.active = true;
          // Set ghost play animation
          if(aniState){
              let animationController = this_.node.getComponent(animation.AnimationController);
              BattleGlobal.SetAnim(aniState, true, animationController);
              animationController.setValue(AniState[AniState.IsGhost], true);  // Set as ghost
          }
        }, delayTime)
    } 

}