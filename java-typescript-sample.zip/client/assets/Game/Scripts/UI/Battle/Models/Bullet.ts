import { Skill } from "./Skill";
import { Creature } from "../Enities/Creature";
import { NetConfig } from "../../../Network/NetConfig";
import { CreatureManager } from "../Managers/CreatureManager";
import { DataManager } from "../../../Managers/DataManager";
import { LogicRenderConvert } from "../Utils/LogicRenderConvert";
import { MathUtil } from "../../../Utils/MathUtil";
import { EffectType } from "../Effects/EffectType";
import { EffectController } from "../Effects/EffectController";
import { ShapeType } from "../enums/ShapeType";
import { TestSkillEfectsCube } from "../UI/TestSkillEfectsCube";
import { BattleGlobal } from "../Utils/BattleGlobal";
import { BuffEffect } from "../enums/BuffEffect";
import { BattleManager } from "../Managers/BattleManager";
import { DeferredWorkManager } from "../Managers/DeferredWorkManager";
import { IStateRollback } from "../StateRecord/IStateRollback";
import { BulletRecord } from "../StateRecord/Models/BulletRecord";
import { DeseTypeConve } from "../Utils/DeseTypeConve";
import { HashMap } from "../../../../../Scripts/Utils/HashMap";

export class Bullet implements IStateRollback{
       public skill:Skill;
       public duration:number = 0;  // Animation time
       public flyTime:number = 0;  // Flight time
       public positionX:number;  // X position
       public positionZ:number;  // Z position
       public startPositionX:number;  // Start X position
       public startPositionZ:number;  // Start Z position
       // Targets that have already caused damage key=>entityId  value=>1
       public hitMap=new HashMap(); 
       public hitArr:Array<Creature> = [];

       public Stoped:boolean=false;
    //    private effect:EffectController;
       public targetArr:Array<Creature>;
       public dirDegree:number = 0;  // Bullet angle
       public anglesOffest:number = 0;  // Bullet offset angle
       public stopTime:number = 0;  // Bullet stop time
       public isExecuteEnd:boolean=false;  // Whether bullet execution is ended
       public delayTime:number = 0;  // Delay creation time
       public isCreate:boolean = false;  // Whether already created
       public target_:Creature = null; // Target object
       public isRealDetection:boolean = false;  // Whether real-time detection

        public constructor(skill:Skill, targetArr:Array<Creature>, anglesOffest:number = 0, delayTime:number = 0) {
            this.skill = skill;
            if(targetArr){
              this.targetArr = [];
              for(let target of targetArr){
                this.targetArr.push(target);
              }
            }
            // console.log('Bullet constructor targetArr=', targetArr)
            this.anglesOffest = anglesOffest;
            this.delayTime = delayTime;
            
            // console.log('Bullet：'+this.skill.Define.Name+'，CastBullet：'+this.skill.Define.BulletResource+'，Target：'+(target ? target.characterDefine.Name : '')+'，Distance：'+distance+'，Time：'+this.duration+'，RealDetection：'+this.skill.Define.RealDetection);
            this.dirDegree = BattleGlobal.AngleRangeHandle(Math.round(this.skill.Context.dirDegree + anglesOffest));
            // console.log('Player angle='+skill.Owner.logicRotation.y+'，bullet angle='+this.dirDegree)
           this.stopTime = this.skill.Define.BulletStopTime || 0;
            // TestSkillEfectsCube.Instance.CastTestEffects(this, this.skill);
           
            // Displacement stops when hitting enemy
            let isDisplacement = this.skill.Define.isDisplacement;
            let isStop = this.skill.Define.isStop;  // Whether displacement stops when hitting enemy
            if(isDisplacement && isStop){  
              let offsetArr = this.GetBulletOffset();
              this.positionX = this.skill.Owner.logicPosition.x + offsetArr[0];
              this.positionZ = this.skill.Owner.logicPosition.z + offsetArr[1];
              let creatureArr = this.FindUnitsInRange();
              if(creatureArr.length > 0){
                this.skill.Context.isDisplacementStop = true;
                // Logic range target test==============
            // BattleManager.Instance.LogicRangeTargetTestNode.active = true;
            // BattleManager.Instance.LogicRangeTargetTestNode.setWorldPosition(LogicRenderConvert.LogicToRender_Value(this.positionX), 0.1, LogicRenderConvert.LogicToRender_Value(this.positionZ))
            // BattleManager.Instance.LogicRangeTargetTestNode.setScale(this.skill.Define.BulletWidth, 1, this.skill.Define.BulletHeight);
            // BattleManager.Instance.LogicRangeTargetTestNode.setRotationFromEuler(0, this.dirDegree, 0);   
              }
            }
        }

        /**
         * Get bullet offset
         * @returns 
         */
        private GetBulletOffset():Array<number>{
          // Bullet initial offset
          let rockerSpeedVo = DataManager.Instance.rockerSpeeds[this.dirDegree];
          if (!rockerSpeedVo) {
            console.log('rockerSpeedVo does not exist!' + this.dirDegree)
            return [0, 0];
          }
          let bulletPositionOffset = this.skill.Define.BulletPositionOffset;
          if(bulletPositionOffset){ // Bullet position offset
            let offsetX = bulletPositionOffset * 10 * rockerSpeedVo.x;
            let offsetZ = bulletPositionOffset * 10 * rockerSpeedVo.y;
            return [offsetX, offsetZ];
          }
          return [0, 0];
        }

        /**
         * Delay creation
         */
        private DelayCreate(){
          // console.log('Create bullet isRealDetection='+this.isRealDetection)
            this.isCreate = true;
            if (!this.skill.Define.RealDetection && !this.isRealDetection) {  // Non-real-time detection
                // let distance = this.skill.Owner.Distance(this.target);
                // this.duration = distance / this.skill.Define.BulletSpeed;
                // Play effect, bullet flies toward target
                // this.skill.Owner.PlayEffect(EffectType.Bullet, this.skill.Define.BulletResource, this.target, this.duration)
                // console.log('Bullet flies toward target')
                // //Render distance * 10 / speed = logic frame count   logic frame count * 66 = milliseconds 
                let sumDuration:number = 0;
                for(let target of this.targetArr){
                  let duration = this.getTargetDuration(target);
                  sumDuration += duration;
                }           
                // Set target
                this.setTarget();

                // Play effect, bullet flies toward target (deferred)
                DeferredWorkManager.Instance.enqueuePlayEffectBullet(this.skill.Owner, this.skill.Define.BulletResource, sumDuration, this);

                // this.startPositionX = this.positionX = this.skill.Owner.logicPosition.x;
                // this.startPositionZ = this.positionZ = this.skill.Owner.logicPosition.z;
                //  // Play effect
                //  this.skill.Owner.PlayEffectBulletRealCheck(EffectType.BulletRealCheck, this.skill.Define.BulletResource, this);
             }else{    // Real-time detection - execute in same frame
               let offsetArr = this.GetBulletOffset();
               this.startPositionX = this.positionX = this.skill.Owner.logicPosition.x + offsetArr[0];
               this.startPositionZ = this.positionZ = this.skill.Owner.logicPosition.z + offsetArr[1];      
               this.skill.Owner.PlayEffectBulletRealCheck(EffectType.BulletRealCheck, this.skill.Define.BulletResource, this);
               this.HitDamageEnemy();    // Cause damage to enemy
            }
        }

        /**
         * Get animation time from character to target
         * @param target 
         * @returns 
         */
        private getTargetDuration(target:Creature):number{
          let logicDistance = this.skill.Owner.Distance(target);
          let duration = LogicRenderConvert.LogicToRender_Value(logicDistance) * 10 / this.skill.Define.BulletSpeed * NetConfig.frameTime / NetConfig.speedFactor;
          return duration;
        }

        /**
         * Set target
         */
        private setTarget(){
          if(this.targetArr && this.targetArr.length > 0){
            let target = this.targetArr[0];  // First element as target
            this.target_ = target;
            this.flyTime = 0;
            this.duration = this.getTargetDuration(target);  
          }else{
            this.target_ = null;
          }
        }

        public LogicUpdate() {
            if (this.Stoped) {
                return;
            }
            if(!this.isCreate){  // Not created
              if(this.skill.validateIsSkillInterrupt()){   // Skill interrupt
                console.error('Create bullet, skill interrupted exit============================')
                this.Stoped = true;
                return;
              }
              if(this.delayTime <= 0){ 
                this.DelayCreate();  
              }else{
                this.delayTime -= NetConfig.frameTime;
              }
              return;
            }
            
            if(this.isExecuteEnd){ // Bullet execution ended
              this.stopTime -= NetConfig.frameTime;
              // console.log('Bullet execution ended='+this.stopTime)
              if(this.stopTime <= 0){  // Stop time ended
                if(this.skill.Define.BulletIsConvergeHero){  // Whether bullet converges to hero
                  this.BulletConvergeHero();
                }else{
                  // console.log('Bullet execution ended====')
                  this.Stoped = true;
                }
              }
            }else{
              if (!this.skill.Define.RealDetection && !this.isRealDetection) {  // Non-real detection
                this.UpdateTime();
              } else {
                this.UpdatePos();
              }  
            }
        }

        /**
         * Bullet converges to hero
         */
        private BulletConvergeHero(){
            let newDegree = Math.round(MathUtil.GetAngle(this.skill.Owner.logicPosition.z - this.positionZ, this.skill.Owner.logicPosition.x - this.positionX));
            newDegree = BattleGlobal.AngleRangeHandle(newDegree);
            
            this.Move(newDegree);  // Move bullet          

            let dis = this.skill.Owner.Distance3(this.positionX, this.positionZ);  
            if (dis <= LogicRenderConvert.RenderToLogic_Value(this.skill.Owner.characterDefine.Radius * 2)) {  // Bullet too close to hero
                // console.log('Bullet converges to hero, bullet too close to hero, recycling==============')
                this.Stoped = true;
                return;
            }
            this.HitDamageEnemy();  // Cause damage to enemy
        }

        private UpdateTime() {
          if(!this.targetArr || this.targetArr.length < 1){  // No target
              this.Stoped = true;
              return;
            }            

            this.flyTime += NetConfig.frameTime;
            if(this.flyTime > this.duration) {
              this.targetArr.shift();    // Remove first element     
              this.skill.Context.Target = this.target_; // Set target
              this.skill.DoHitHandle(true);
              // Set target
              this.setTarget();
            }
            
            // if(!this.targetArr || this.targetArr.length < 1){  // No target
            //   this.Stoped = true;
            //   return;
            // }
            // let target = this.targetArr[0];  // First element as target
            // this.target_ = target;
            // let newDegree = Math.round(MathUtil.GetAngle(target.logicPosition.z - this.positionZ, target.logicPosition.x - this.positionX));
            // newDegree = BattleGlobal.AngleRangeHandle(newDegree);
            
            // this.Move(newDegree);  // Move bullet
            
            // let dis = target.Distance3(this.positionX, this.positionZ);  
            // if(target.IsDeath){  // Target dead
            //   this.targetArr.shift();    // Remove first element     
            // }else if (dis <= LogicRenderConvert.RenderToLogic_Value(target.characterDefine.Radius)) {  // Bullet too close to hero
            //   this.targetArr.shift();    // Remove first element     
            //   this.skill.Context.Target = target; // Set target
            //   this.skill.DoHitHandle(true);
            // } 
        }

        private lastDis:number = 0;
        private UpdatePos() {
            let isDisplacement = this.skill.Define.isDisplacement;
            let isTuiKai = this.skill.Define.isTuiKai;
            if(isDisplacement){  // Displacement thrust skill, bullet follows player, player's actual movement distance as damage range, avoid hitting through walls
              let owner = this.skill.Owner;
              if(this.skill.validateIsSkillInterrupt()){  // Check if skill is interrupted
                // console.log('Bullet interrupted 22--------')
                this.Stoped = true;
                this.skill.SkillInterruptHandle(); // Skill interrupt
                return;
              }
              let offsetArr = this.GetBulletOffset();

              this.positionX = owner.logicPosition.x + offsetArr[0]; 
              this.positionZ = owner.logicPosition.z + offsetArr[1];
              if(!owner.IsDisplacementing){  // Displacement ended
                this.Stoped = true;
                if(isTuiKai){  // Displacement push away
                 this.RemoveTuiKaiEffect();  
                }
                return;
              }
              // console.log('Displacement thrust skill: positionX='+this.positionX+'，positionZ='+this.positionZ+'，IsDisplacementing='+owner.IsDisplacementing)
            }else{
                let rockerSpeedVo = this.Move(this.dirDegree);  // Move bullet
              
                let dis = Math.floor(MathUtil.GetDistance(this.startPositionX, this.startPositionZ, this.positionX, this.positionZ));
                // Actual cast range = cast range - bullet length
                let logicCastRange = LogicRenderConvert.RenderToLogic_Value(this.skill.Define.CastRange) - LogicRenderConvert.RenderToLogic_Value(this.skill.Define.BulletHeight / 2);
                //console.log('Bullet execution trajectory: dis='+dis+'，CastRange='+logicCastRange)
                if(dis >= logicCastRange){  // Stop if out of range
                    // Correct to circle for detection
                    /*let d = dis - logicCastRange;  // Excess distance
                    let xScale = 0;  // X direction ratio
                    let yScale = 0;  // Y direction ratio
                    let xRatio = rockerSpeedVo.x < 0 ? -1 : 1;
                    let yRatio = rockerSpeedVo.y < 0 ? -1 : 1;
                    let rockerSpeedVoX = Math.abs(rockerSpeedVo.x);
                    let rockerSpeedVoY = Math.abs(rockerSpeedVo.y);

                    if(rockerSpeedVoX < rockerSpeedVoY){
                      xScale = rockerSpeedVoX / rockerSpeedVoY;
                      yScale = 1 - xScale;
                    }else{
                      yScale = rockerSpeedVoY / rockerSpeedVoX;
                      xScale = 1 - yScale;
                    }
                    let xLen = Math.ceil(d * xScale * xRatio);  // X excess distance
                    let yLen = Math.ceil(d * yScale * yRatio);  // Y excess distance
                    this.positionX -= xLen;
                    this.positionZ -= yLen; */
                    this.HitDamageEnemy();  // Cause damage to enemy

                    // let newDis = Math.floor(MathUtil.GetDistance(this.startPositionX, this.startPositionZ, this.positionX, this.positionZ));
                    // console.log('Bullet out of range stopped: lastDis='+this.lastDis+'，dis='+dis+'，CastRange='+logicCastRange)
                    this.isExecuteEnd = true;
                    this.hitMap.clear();  // Clear damage list
                    return;
                } else{
                    this.lastDis = dis;
                }
            }
          this.HitDamageEnemy();    // Deal damage to enemy
        }

        /**
         * Find enemies within bullet range
         * @returns c
         */
        private FindUnitsInRange():Array<Creature> {
          let creatureArr = CreatureManager.Instance.FindUnitsInRange(this.positionX, this.positionZ, 0, -1, this.skill.Owner.teamType2, true, ShapeType.rect,
            LogicRenderConvert.RenderToLogic_Value(this.skill.Define.BulletWidth), LogicRenderConvert.RenderToLogic_Value(this.skill.Define.BulletHeight), this.dirDegree);
            return creatureArr;
        }

        /**
         * Cause damage to enemy
         */
        private HitDamageEnemy(){
            let isDisplacement = this.skill.Define.isDisplacement;
            let isTuiKai = this.skill.Define.isTuiKai;
            let isStop = this.skill.Define.isStop;  // Whether displacement stops when hitting enemy
            // Logic range target test==============
            // BattleManager.Instance.LogicRangeTargetTestNode.active = true;
            // BattleManager.Instance.LogicRangeTargetTestNode.setWorldPosition(LogicRenderConvert.LogicToRender_Value(this.positionX), 0.1, LogicRenderConvert.LogicToRender_Value(this.positionZ))
            // BattleManager.Instance.LogicRangeTargetTestNode.setScale(this.skill.Define.BulletWidth, 1, this.skill.Define.BulletHeight);
            // BattleManager.Instance.LogicRangeTargetTestNode.setRotationFromEuler(0, this.dirDegree, 0);   

            let creatureArr = this.FindUnitsInRange();
           if(creatureArr.length > 0){ // Hit enemy
              //  console.log('Hit enemy: count='+creatureArr.length);
              for(let i=0; i < creatureArr.length; i++){
                  let creature = creatureArr[i];
                  if(isDisplacement && (isStop || isTuiKai)){  
                    if(isStop){ // Stop
                      this.Stoped = true;
                      this.skill.Owner.EffectMgr.RemoveEffect(BuffEffect.Disp);
                      return;
                    }else if(isTuiKai){  // Displacement push away
                      this.AddTuiKaiEffect(creature);
                    }
                    continue;
                  }
                  if(this.hitMap.get(creature.entityId)){  // Already caused damage, enter next loop
                    continue;
                  }
                  this.hitMap.put(creature.entityId, 1);

                  this.skill.Context.Target = creature; // Set target
                  this.skill.DoHitHandle(true);
                  if(!this.skill.Define.MultipleHit){  // Non-multiple damage stop
                      this.Stoped = true;
                      break;
                  }
              }  
           }
        }

        /**
         * Move bullet
         * @param dirDegree Angle
         */
        private Move(dirDegree:number){
          let rockerSpeedVo = DataManager.Instance.rockerSpeeds[dirDegree];
          if(!rockerSpeedVo){
              // console.log('Bullet UpdatePos not rockerSpeedVo! dirDegree='+dirDegree+'，skillId='+this.skill.Define.ID)
              return;
          }                
          let speed = this.skill.Define.BulletIsConvergeHero ? this.skill.Define.BulletConvergeHeroSpeed : this.skill.Define.BulletSpeed;

          // Math.round ensures integer-only logic positions for cross-device determinism (RISK 4)
          this.positionX += Math.round(rockerSpeedVo.x * speed * NetConfig.speedFactor);
          this.positionZ += Math.round(rockerSpeedVo.y * speed * NetConfig.speedFactor);
          this.dirDegree = dirDegree;
          
           // Logic range target test==============
          //  let logicRangeTargetTestNode = BattleManager.Instance.LogicRangeTargetTestNode;
          //  if(!logicRangeTargetTestNode.active){
          //    logicRangeTargetTestNode.active = true;
          //    logicRangeTargetTestNode.setWorldPosition(LogicRenderConvert.LogicToRender_Value(this.positionX), 0.1, LogicRenderConvert.LogicToRender_Value(this.positionZ))
          //    logicRangeTargetTestNode.setScale(this.skill.Define.BulletWidth, 1, this.skill.Define.BulletHeight);
          //    logicRangeTargetTestNode.setRotationFromEuler(0, dirDegree, 0);   
          //  }
            return rockerSpeedVo;
        }

        /**
         * Add push away effect
         * @param creature 
         */
        private AddTuiKaiEffect(creature:Creature){
          if(this.hitMap.get(creature.entityId)){  // Already added
            return;
          }  
          
          this.hitMap.put(creature.entityId, 1);
          this.hitArr.push(creature);
          let ownerEffectMgr = this.skill.Owner.EffectMgr;
          console.log('AddTuiKaiEffect name='+creature.characterDefine.Name+'，speed='+(ownerEffectMgr.dispSpeed )+'，dirDegree='+ownerEffectMgr.dirDegree)
          ownerEffectMgr.hitArr = this.hitArr;  // Set damage list for pushed away people
          creature.EffectMgr.AddEffect(BuffEffect.TuiKai, null, ownerEffectMgr.dispSpeed, ownerEffectMgr.dirDegree);
          if(creature.AI.ai){  // Set attacker for pushed away person
            creature.AI.ai.attackedTarget = this.skill.Owner;
          }
        }

        /**
         * Remove push away effect
         */
        private RemoveTuiKaiEffect(){
          // console.log('RemoveTuiKaiEffect')
          let keys =  this.hitMap.keys();
          for(let entityId of keys){
            let creature = CreatureManager.Instance.GetCreature(Number(entityId));
            if(creature && creature.EffectMgr){
              creature.EffectMgr.RemoveEffect(BuffEffect.TuiKai);
            }
          }
          this.hitMap.clear();
        }

   /**
    * Rollback state
    */
    rollback(data:BulletRecord):void{
        this.duration = data.duration; 
        this.flyTime = data.flyTime; 
        this.positionX = data.positionX; 
        this.positionZ = data.positionZ; 
        this.startPositionX = data.startPositionX; 
        this.startPositionZ = data.startPositionZ; 
        this.hitMap = DeseTypeConve.conveHashMap(data.hitMap); 
        if(data.hitCreatureIdArr){
            this.hitArr = [];
            for(let entityId of data.hitCreatureIdArr){
                let targetCreature = CreatureManager.Instance.GetCreature(entityId);
                if(targetCreature){
                    this.hitArr.push(targetCreature); 
                }
            }
        }
        this.Stoped = data.Stoped; 
        if(data.targetIdArr){
            this.targetArr = [];
            for(let entityId of data.targetIdArr){
                let targetCreature = CreatureManager.Instance.GetCreature(entityId);
                if(targetCreature){
                    this.targetArr.push(targetCreature); 
                }
            }
        }
        this.dirDegree = data.dirDegree; 
        this.anglesOffest = data.anglesOffest; 
        this.stopTime = data.stopTime; 
        this.isExecuteEnd = data.isExecuteEnd; 
        this.delayTime = data.delayTime; 
        this.isCreate = data.isCreate; 
        if(data.targetId_){
            let targetCreature = CreatureManager.Instance.GetCreature(data.targetId_);
            this.target_ = targetCreature;
        }
        this.isRealDetection = data.isRealDetection; 
    }
 
}