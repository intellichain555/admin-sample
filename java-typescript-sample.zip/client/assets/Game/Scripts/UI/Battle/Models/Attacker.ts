import { Creature } from "../Enities/Creature";
import Decimal from "decimal.js";
import { IStateRollback } from "../StateRecord/IStateRollback";
import { AttackerRecord } from "../StateRecord/Models/AttackerRecord";
import { DeseTypeConve } from "../Utils/DeseTypeConve";

/**
 * Attacker
 */
export class Attacker implements IStateRollback{
    
    public zhuGongCreature:Creature;  // Attacker
    public damage:Decimal;  // Damage
    public isZhuGongFlag:boolean; // Whether assist
    public time:Date;  // Time (wall-clock, for backwards compatibility)
    public timeFrame:number;  // ✅ Frame when attacker was added (for deterministic expiration)

    constructor(zhuGongCreature:Creature, damage:Decimal, isZhuGongFlag:boolean, timeFrame:number, time?:Date){
        this.zhuGongCreature = zhuGongCreature;
        this.damage = damage;
        this.isZhuGongFlag = isZhuGongFlag;
        if(time){
            this.time = DeseTypeConve.conveDate(time);
        }else{
            this.time = new Date();
        }
        // ✅ Use frame-based time for deterministic expiration
        this.timeFrame = timeFrame;
    }

   /**
    * Rollback state
    */
    rollback(data:AttackerRecord):void{
        this.damage = DeseTypeConve.conveDecimal(data.damage);
        this.isZhuGongFlag = data.isZhuGongFlag;  // ✅ Restore isZhuGongFlag
        this.time = DeseTypeConve.conveDate(data.time);  // ✅ Restore time (wall-clock)
        this.timeFrame = data.timeFrame;  // ✅ Restore frame time
    }
 
 
}