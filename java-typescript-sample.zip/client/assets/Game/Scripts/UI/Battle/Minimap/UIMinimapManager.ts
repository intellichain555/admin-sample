
import { _decorator, Component, Node, UITransform, Rect, instantiate, MeshRenderer, /*BoxCollider,*/ Vec3, Sprite, Vec2, input, Input, Graphics } from 'cc';
import { TeamType2 } from '../enums/TeamType2';
import { User } from '../../../Models/User';
import { CharacterManager } from '../Managers/CharacterManager';
import { MinimapBoxVo } from '../../../Vo/MinimapBoxVo';
import { UIMinimapCreature } from './UIMinimapCreature';
import { Creature } from '../Enities/Creature';
import { BattleGlobal } from '../Utils/BattleGlobal';
import { MathUtil } from '../../../Utils/MathUtil';
import { PoolManager } from '../../../Managers/PoolManager';
import { UIMinimapEffectsManager } from './UIMinimapEffectsManager';
import { BattleManager } from '../Managers/BattleManager';
import { EventManager } from '../../Common/Event/EventManager';
import { EventType } from '../../Common/Event/EventType';
import { NodeTipsManager } from '../../Common/NodeTipsManager';
import { WindosAni } from '../../Common/enums/WindosAni';
import { CreatureClickUI } from './CreatureClickUI';
import { UIMinimapFogCircles } from './UIMinimapFogCircles';
import { Constant } from '../../../../../Scripts/Utils/Constant';
const { ccclass, property } = _decorator;

@ccclass('UIMinimapManager')
export class UIMinimapManager extends Component {

    public static Instance:UIMinimapManager=null;
   
    @property(Node)
    private minimapBoundingBox:Node = null;
    @property(Node)
    private minimapCharacterPrfab:Node = null;   // Character
    @property(Node)
    private greatMonsterNode:Node = null;    // Great monster
    @property(Node)
    private soldierNode:Node = null;    // Soldier
    // @property(Node)
    // private creepMonsterNode:Node = null;    // Wild monster
    // @property(Node)
    // private bossNode:Node = null;    //Boss
    // @property(Node)
    // private npcNode:Node = null;    // Blue team npc
    // private redNpcNode:Node = null;    // Red team npc
    // @property(Node)
    // private blueNpcPosNode:Node = null;    // Blue team npc position node
    // @property(Node)
    // private redNpcPosNode:Node = null;    // Red team npc position node
    @property(CreatureClickUI)
    private creatureClickUI:CreatureClickUI = null;
    @property(Node)
    private fytNode:Node = null;    // Defense tower
    @property(Node)
    private shuiJinNode:Node = null;    // Crystal
    @property(Sprite)
    private rectKuangSprite:Sprite = null; // Move frame image
    @property(Sprite)
    private mapSprite:Sprite = null; // Minimap image
    @property(Node)
    private callMonsterNode:Node = null;    // Great monster

    private currentMoveVec2 = new Vec2();   // Current move point position
    private minimapBoxVo:MinimapBoxVo = null;

    /** Used by UIMinimapFogCircles to draw vision circles. */
    public getMinimapBoxVo(): MinimapBoxVo {
        return this.minimapBoxVo;
    }

    onLoad () {
        UIMinimapManager.Instance=this;
        
        //BoxCollider available in editor to view map size, not available in runtime because it's 3D physics library
        // let boxBgVec3 = new Vec3(32.64, 1, 119.68);//this.minimapBoundingBox.getComponent(BoxCollider).size;
        let boxBgVec3 = new Vec3(25, 1, 108);
        let minimapSize=this.node.getComponent(UITransform).contentSize;
        let kuangSize=this.rectKuangSprite.getComponent(UITransform).contentSize;
        this.minimapBoxVo=new MinimapBoxVo(boxBgVec3.x, boxBgVec3.z, this.minimapBoundingBox.worldPosition.x, 
            this.minimapBoundingBox.worldPosition.z, minimapSize.width, minimapSize.height, kuangSize.width, kuangSize.height);


        EventManager.Instance.addListener(EventType.OnCreatureClick,this.OnCreatureClick,this);
        this.mapSprite.node.on(Input.EventType.TOUCH_START, this.OnTouchStart, this);
        this.mapSprite.node.on(Input.EventType.TOUCH_MOVE, this.OnTouchMove, this);
        this.mapSprite.node.on(Input.EventType.TOUCH_END, this.OnTouchEnd, this);
        this.mapSprite.node.on(Input.EventType.TOUCH_CANCEL, this.OnTouchEnd, this);

        this.hideKuang();  // Hide frame
    }
    /**
     * Creature click message response
     */
    OnCreatureClick(param: any) {
        if(!this.creatureClickUI){
            return;
        }
        NodeTipsManager.Instance.openNodeTips(this.creatureClickUI.node, 2000, WindosAni.None, WindosAni.None, this.creatureClickUI, param);
    }

    Init () {
        // this.CreateMinimapFogCircles();
        this.CreateMinimapCreature();
        // this.npcCreate();
    }

    /**
     * Create minimap fog-of-view circles (main player + allies vision radius).
     * Node is added as first child so it renders behind character icons.
     */
    private CreateMinimapFogCircles() {
        const parent = this.minimapCharacterPrfab?.parent;
        if (!parent) return;
        const fogNode = new Node('MinimapFogCircles');
        fogNode.setPosition(0, 0, 0);
        parent.insertChild(fogNode, 0);
        fogNode.addComponent(Graphics);
        fogNode.addComponent(UIMinimapFogCircles);
    }

    /**
     * Create minimap creature
     */
    CreateMinimapCreature(){
        // Create minimap characters
        let characterList = CharacterManager.Instance.characterList;
        this.minimapCharacterPrfab.active=true;
        for(let i=0;i<characterList.length;i++){
           let character = characterList[i];
             let minimapCharacterNode = instantiate(this.minimapCharacterPrfab);
             let uiMinimapCreature = minimapCharacterNode.getComponent(UIMinimapCreature);
             this.minimapCharacterPrfab.parent.addChild(minimapCharacterNode);
             uiMinimapCreature.SetItemInfo(character, this.minimapBoxVo);

             character.minimapCharacterNode = minimapCharacterNode;
        }
        this.minimapCharacterPrfab.active=false;
    }

    
    /**
     * Great monster update time
     * @param frameId Current frame
     * @param frameCount Announcement monster spawn frame
     * @param noticeMonstersParentNode Announcement monster parent node
     */
    public greatMonsterUpdateTime(frameId: number, frameCount:number, noticeMonstersParentNode:Node){
      let startFrameId = frameCount - BattleGlobal.greatMonsterTipsFrameCount;
      if(frameId >= startFrameId && frameId < frameCount){  
          if(frameId == startFrameId){  // Play particle effect
            UIMinimapEffectsManager.Instance.playEffect(0, this.greatMonsterNode);
          }
           let syFrameCount = frameCount - frameId; // Remaining frames
           let sySecond = MathUtil.frameToSecond(syFrameCount);  // Remaining seconds
 
           let uiMinimapCreature = this.greatMonsterNode.getComponent(UIMinimapCreature);
           uiMinimapCreature.updateTime(sySecond, this.minimapBoxVo);
           uiMinimapCreature.updatePos(noticeMonstersParentNode.worldPosition.x, noticeMonstersParentNode.worldPosition.z);
           uiMinimapCreature.show();
      }
    } 

    /**
     * Summoned monster create
     */
    public callMonsterCreate(creature: Creature){
        UIMinimapEffectsManager.Instance.playEffect(0, this.callMonsterNode);
        let uiMinimapCreature = this.callMonsterNode.getComponent(UIMinimapCreature);
        uiMinimapCreature.SetItemInfo(creature, this.minimapBoxVo);
    }

    /**
     * Great monster create
     * @param creature Created announcement monster
     */
    public greatMonsterCreate(creature: Creature){
        let uiMinimapCreature = this.greatMonsterNode.getComponent(UIMinimapCreature);
        uiMinimapCreature.updateTime(0, this.minimapBoxVo);
        uiMinimapCreature.SetItemInfo(creature, this.minimapBoxVo);
    }

    /**
     * Soldier create
     * @param creature 
     */
    public soldierCreate(creature: Creature){
        this.soldierNode.active = true;
        let soldierNode = instantiate(this.soldierNode);
        let uiMinimapCreature = soldierNode.getComponent(UIMinimapCreature);
        uiMinimapCreature.SetItemInfo(creature, this.minimapBoxVo);
        this.soldierNode.parent.addChild(soldierNode);
        this.soldierNode.active = false;
    }

    /**
     * Defense tower create
     * @param creature 
     */
     public FytCreate(creature: Creature){
        this.fytNode.active = true;
        let fytNode = instantiate(this.fytNode);
        let uiMinimapCreature = fytNode.getComponent(UIMinimapCreature);
        uiMinimapCreature.SetItemInfo(creature, this.minimapBoxVo);
        this.fytNode.parent.addChild(fytNode);
        this.fytNode.active = false;
    }

    /**
     * Crystal create
     * @param creature 
     */
    public ShuiJinCreate(creature: Creature){
        this.shuiJinNode.active = true;
        let shuiJinNode = instantiate(this.shuiJinNode);
        let uiMinimapCreature = shuiJinNode.getComponent(UIMinimapCreature);
        uiMinimapCreature.SetItemInfo(creature, this.minimapBoxVo);
        this.shuiJinNode.parent.addChild(shuiJinNode);
        this.shuiJinNode.active = false;
    }


    /**
     * Wild monster create
     * @param creature 
     */
    // public creepMonsterCreate(creature: Creature){
    //     this.creepMonsterNode.active = true;
    //     let creepMonsterNode = instantiate(this.creepMonsterNode);
    //     let uiMinimapCreature = creepMonsterNode.getComponent(UIMinimapCreature);
    //     uiMinimapCreature.SetItemInfo(creature, this.minimapBoxVo);
    //     this.creepMonsterNode.parent.addChild(creepMonsterNode);
    //     this.creepMonsterNode.active = false;
    // }

    /**
     * Boss creation
     * @param creature 
     */
    // public bossCreate(creature: Creature){
    //     this.bossNode.active = true;
    //     let bossNode = instantiate(this.bossNode);
    //     let uiMinimapCreature = bossNode.getComponent(UIMinimapCreature);
    //     uiMinimapCreature.SetItemInfo(creature, this.minimapBoxVo);
    //     this.bossNode.parent.addChild(bossNode);
    //     this.bossNode.active = false;
    // }
    
    /**
     * NPC create
     */
    // private npcCreate(){
    //     // Blue team npc
    //     let blueNpcCreature = this.npcNode.getComponent(UIMinimapCreature);
    //     blueNpcCreature.minimapBoxVo = this.minimapBoxVo;
    //     blueNpcCreature.updatePos(this.blueNpcPosNode.worldPosition.x, this.blueNpcPosNode.worldPosition.z);
    //     blueNpcCreature.show();

    //     // Red team npc
    //     let redNpcCreature = this.redNpcNode.getComponent(UIMinimapCreature);
    //     redNpcCreature.minimapBoxVo = this.minimapBoxVo;
    //     redNpcCreature.updatePos(this.redNpcPosNode.worldPosition.x, this.redNpcPosNode.worldPosition.z);
    //     redNpcCreature.show();
    // }


    /**
     * Character command play effect
     */
    public characterMingLingPlayEffect(index:number){
        let characterList = CharacterManager.Instance.characterList;
        for(let i=0;i<characterList.length;i++){
           let character = characterList[i];
           if(BattleManager.Instance.currentCharacter.entityId == character.entityId && character.minimapCharacterNode){
             UIMinimapEffectsManager.Instance.playEffect(index, character.minimapCharacterNode);
             break;
           }
        }
    }

    /**
     * Touch start
     */
    private OnTouchStart(e) {
        e.getUIStartLocation(this.currentMoveVec2);  // Start move point
        this.isEndFlag = false;
        BattleManager.Instance.camera.getWorldPosition(this.newCameraWorldPosition);
        this.updateMinimapKuangMovePos();
    }
    
    /**
     * Touch move
     */
    public OnTouchMove(e){
        e.getUILocation(this.currentMoveVec2);   // Current move point
        this.isEndFlag = false;
        this.updateMinimapKuangMovePos(true);
    }

    private newCameraWorldPosition:Vec3 = new Vec3();
    public isEndFlag = true;  // Whether end click
    /**
     * Update minimap frame move camera position
     */
    private updateMinimapKuangMovePos(isTouchMove:boolean = false){
        BattleManager.Instance.isLookAtCharacterFlag = false;
        // this.rectKuangSprite.node.active = true;
        // if(isTouchMove && !this.judgeKuangIsInMinimap()){ // Not in minimap
        //     return;
        // }
        this.rectKuangSprite.node.setWorldPosition(this.currentMoveVec2.x,  this.currentMoveVec2.y, this.rectKuangSprite.node.worldPosition.z);
        let pos = this.rectKuangSprite.node.position;
        // console.log('updateMinimapKuangMovePos pos=', pos, this.minimapBoxVo.minimapWidth, this.minimapBoxVo.minimapHeight)
        // Get touch point ratio in minimap
        // let pivoX = (BattleManager.Instance.currentCharacter.teamType2 == TeamType2.Blue ? -1 : 1) * (pos.y / (this.minimapBoxVo.minimapHeight)); 
        let pivoX = -(pos.y / (this.minimapBoxVo.minimapHeight)); 
        let pivoY = -(pos.x / (this.minimapBoxVo.minimapWidth)); 
        
        // Get camera actual position
        let x = pivoX * this.minimapBoxVo.width  + this.minimapBoxVo.x + BattleManager.Instance.cameraDisOffset.x;
        let z = pivoY * this.minimapBoxVo.height  + this.minimapBoxVo.z + BattleManager.Instance.cameraDisOffset.z;

        this.newCameraWorldPosition.set(x, this.newCameraWorldPosition.y, z);


        // console.log('updateMinimapKuangMovePos pos=', BattleManager.Instance.camera.worldPosition)
    }

    /**
     * Touch end
     */
     private OnTouchEnd(e) {
        BattleManager.Instance.isLookAtCharacterFlag = true;
        this.isEndFlag = true;
        this.hideKuang();  // Hide frame
    }

    /**
     * Move camera update frame position
     */
    public moveCameraUpdateKuangPos(cameraNode:Node){
        // this.rectKuangSprite.node.active = true;
        // let currentX = cameraNode.worldPosition.x - BattleManager.Instance.cameraDisOffset.x;
        // let currentZ = cameraNode.worldPosition.z - BattleManager.Instance.cameraDisOffset.z;
        // // Get camera x, y position in bounding box
        // let relaX = -(currentX - this.minimapBoxVo.x) + this.minimapBoxVo.width / 2;
        // let relaY = -(currentZ - this.minimapBoxVo.z) + this.minimapBoxVo.height / 2;

        // // Get camera x, y ratio in bounding box
        // let pivoX = relaX / this.minimapBoxVo.width;
        // let pivoY = relaY / this.minimapBoxVo.height;

        // this.rectKuangSprite.node.setPosition(this.minimapBoxVo.minimapWidth * pivoY - this.minimapBoxVo.minimapWidth / 2,
        //     this.minimapBoxVo.minimapHeight * pivoX - this.minimapBoxVo.minimapHeight / 2, this.node.position.z)
    }


    /**
     * Hide frame
     */
    public hideKuang(){
        // this.rectKuangSprite.node.active = false;
    }
    
    /**
     * Judge whether frame is in minimap
     */
    // public judgeKuangIsInMinimap() : boolean{
    //     let pos = this.rectKuangSprite.node.position;
    //     let flag:boolean = false;
    //     if((pos.x + (this.minimapBoxVo.kuangWidth / 2) > -this.minimapBoxVo.minimapWidth / 2) && 
    //        (pos.x + (this.minimapBoxVo.kuangWidth / 2) < this.minimapBoxVo.minimapWidth / 2) &&
    //        (pos.y + (this.minimapBoxVo.kuangHeight / 2) > -this.minimapBoxVo.minimapHeight / 2) && 
    //        (pos.y + (this.minimapBoxVo.kuangHeight / 2) < this.minimapBoxVo.minimapHeight / 2)){
    //         flag = true;
    //     }
    //     console.log('judgeKuangIsInMinimap' 
    //     +' 1='+(pos.x + (this.minimapBoxVo.kuangWidth / 2) > -this.minimapBoxVo.minimapWidth / 2)
    //     +'，2='+(pos.x + (this.minimapBoxVo.kuangWidth / 2) < this.minimapBoxVo.minimapWidth / 2)
    //     +'，3='+(pos.y + (this.minimapBoxVo.kuangHeight / 2) > -this.minimapBoxVo.minimapHeight / 2)
    //     +'，4='+(pos.y + (this.minimapBoxVo.kuangHeight / 2) < this.minimapBoxVo.minimapHeight / 2)
    //     +'，====posX='+pos.x+'，posY='+pos.y+'，kuangWidth='+this.minimapBoxVo.kuangWidth+'，kuangHeight='+this.minimapBoxVo.kuangHeight
    //     +'，minimapWidth='+this.minimapBoxVo.minimapWidth+'，minimapHeight='+this.minimapBoxVo.minimapHeight)
    //     return flag;
    // }

    private cameraPosTemp = new Vec3();
    private _minimapFrameCount = 0;
    update(dt: number) {
        if (this.isEndFlag) return;
        if (Constant.REDUCE_WORLD_UI_UPDATES) {
            this._minimapFrameCount++;
            if ((this._minimapFrameCount & 1) !== 0) return;
        }
        const camera = BattleManager.Instance.camera;
        camera.getWorldPosition(this.cameraPosTemp);
        this.cameraPosTemp.lerp(this.newCameraWorldPosition, 0.1);
        camera.setWorldPosition(this.cameraPosTemp);
    }
}
