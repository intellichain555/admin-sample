import { _decorator, Component, Graphics, Color, Vec3 } from 'cc';
import { BattleManager } from '../Managers/BattleManager';
import { CreatureManager } from '../Managers/CreatureManager';
import { Creature } from '../Enities/Creature';
import { BattleGlobal } from '../Utils/BattleGlobal';
import { Constant } from '../../../../../Scripts/Utils/Constant';
import { UIMinimapManager } from './UIMinimapManager';
import { MinimapBoxVo } from '../../../Vo/MinimapBoxVo';
import { FogOfViewManager } from '../Managers/FogOfViewManager';
const { ccclass, property } = _decorator;

/**
 * Draws fog-of-view vision circles on the minimap for the main player and allies
 * (towers, crystal, minions). Uses the same vision radius and provider list as FogOfViewManager.
 *
 * Setup: Add a child node under the minimap (same parent as the minimap character nodes),
 * with position (0,0). Add this component and a Graphics component (or assign one).
 * Place this node before the character nodes in hierarchy so circles render behind icons.
 */
@ccclass('UIMinimapFogCircles')
export class UIMinimapFogCircles extends Component {

    @property(Graphics)
    graphics: Graphics = null;

    /** Alpha for main player vision circle (0–255). */
    @property
    mainPlayerAlpha: number = 55;
    /** Alpha for ally vision circles (0–255). */
    @property
    allyAlpha: number = 45;

    private _vo: MinimapBoxVo = null;
    private _providerPos = new Vec3();
    private _creatureList: Creature[] = [];
    /** Cached colors to avoid per-frame allocations (low-end). */
    private _allyColor = new Color();
    private _mainColor = new Color();
    private _frameCount = 0;

    onLoad() {
        if (!this.graphics) {
            this.graphics = this.getComponent(Graphics);
        }
        if (!this.graphics) {
            this.graphics = this.addComponent(Graphics);
        }
    }

    start() {
        const manager = UIMinimapManager.Instance;
        if (manager) {
            this._vo = manager.getMinimapBoxVo();
        }
        this._allyColor.fromHEX(BattleGlobal.friendColor);
        this._allyColor.a = this.allyAlpha;
        this._mainColor.fromHEX(BattleGlobal.myColor);
        this._mainColor.a = this.mainPlayerAlpha;
    }

    /**
     * World (x, z) to minimap node position (same as UIMinimapCreature.updatePos).
     */
    private worldToMinimap(vo: MinimapBoxVo, worldX: number, worldZ: number): { x: number; y: number } {
        const relaX = -(worldX - vo.x) + vo.width / 2;
        const relaY = -(worldZ - vo.z) + vo.height / 2;
        const pivoX = relaX / vo.width;
        const pivoY = relaY / vo.height;
        return {
            x: vo.minimapWidth * pivoY - vo.minimapWidth / 2,
            y: vo.minimapHeight * pivoX - vo.minimapHeight / 2
        };
    }

    /**
     * Vision radius in minimap pixels (world radius mapped to UI using same scale as map).
     */
    private visionRadiusMinimap(vo: MinimapBoxVo): number {
        const R = BattleGlobal.visionRadius;
        const scaleX = vo.minimapHeight / vo.width;
        const scaleZ = vo.minimapWidth / vo.height;
        return R * Math.min(scaleX, scaleZ);
    }

    private collectVisionProviders(): { main: Creature | null; allies: Creature[] } {
        const currentCharacter = BattleManager.Instance?.currentCharacter;
        const allyTeam = currentCharacter?.teamType2;
        const allies: Creature[] = [];
        this._creatureList.length = 0;
        CreatureManager.Instance.creatureMap.valuesInto(this._creatureList);
        for (let i = 0; i < this._creatureList.length; i++) {
            const c = this._creatureList[i];
            if (!c || c.IsDeath || !c.node?.isValid || c.teamType2 !== allyTeam) continue;
            const cls = c.characterDefine?.Class;
            if (cls === Constant.CharacterClass.Fyt || cls === Constant.CharacterClass.ShuiJin || cls === Constant.CharacterClass.Soldier) {
                allies.push(c);
            }
        }
        return {
            main: currentCharacter && !currentCharacter.IsDeath && currentCharacter.node?.isValid ? currentCharacter : null,
            allies
        };
    }

    update(_dt: number) {
        if (!this._vo || !this.graphics) return;
        if (FogOfViewManager.Instance && !FogOfViewManager.Instance.fogEnabled) {
            this.graphics.clear();
            return;
        }
        this._frameCount++;
        if (Constant.REDUCE_WORLD_UI_UPDATES && (this._frameCount & 1) !== 0) {
            return;
        }
        const vo = this._vo;
        const { main, allies } = this.collectVisionProviders();
        const radius = this.visionRadiusMinimap(vo);
        this.graphics.clear();

        this._allyColor.a = this.allyAlpha;
        this.graphics.fillColor = this._allyColor;
        for (let i = 0; i < allies.length; i++) {
            allies[i].node.getWorldPosition(this._providerPos);
            const pos = this.worldToMinimap(vo, this._providerPos.x, this._providerPos.z);
            this.graphics.circle(pos.x, pos.y, radius);
            this.graphics.fill();
        }

        if (main) {
            main.node.getWorldPosition(this._providerPos);
            const pos = this.worldToMinimap(vo, this._providerPos.x, this._providerPos.z);
            this._mainColor.a = this.mainPlayerAlpha;
            this.graphics.fillColor = this._mainColor;
            this.graphics.circle(pos.x, pos.y, radius);
            this.graphics.fill();
        }
    }
}
