import { NetConfig } from "../../../Network/NetConfig";
import { BattleData } from "../Utils/BattleData";
import { BattleGlobal } from "../Utils/BattleGlobal";

/**
 * Frame synchronization performance monitor.
 *
 * Tracks real-world timing of both the render loop and logic frame
 * processing.  Collects rolling-window statistics and logs a summary
 * to the console every `logIntervalSec` seconds.
 *
 * Usage (inside BattleManager):
 *   this.frameSyncMonitor = new FrameSyncMonitor();
 *   // In update():
 *   this.frameSyncMonitor.onRenderFrame(dtMs);
 *   // In ChasingFrame(), after processing:
 *   this.frameSyncMonitor.onLogicFramesProcessed(count, chasingMode, accResetFlag);
 *   // In OnHandlerFrame(), around the logic:
 *   this.frameSyncMonitor.onLogicFrameStart();
 *   ... do work ...
 *   this.frameSyncMonitor.onLogicFrameEnd();
 *
 * Toggle at runtime:
 *   BattleManager.Instance.frameSyncMonitor.enabled = true / false;
 */
export class FrameSyncMonitor {

    // ── Configuration ──────────────────────────────────────────────
    /** Master switch (can be toggled at runtime) */
    public enabled: boolean = true;
    /** How often to print a summary (seconds) */
    public logIntervalSec: number = 5;

    // ── Rolling-window counters (reset every log interval) ────────
    private windowStartMs: number = 0;

    // Render loop
    private renderFrameCount: number = 0;
    private renderDtSum: number = 0;
    private renderDtMin: number = Infinity;
    private renderDtMax: number = 0;
    private renderDtOverrunCount: number = 0;   // dt > frameTime

    // Logic frames
    private logicFrameCount: number = 0;        // authoritative frames processed
    private logicFrameTimeSum: number = 0;       // total ms spent in OnHandlerFrame
    private logicFrameTimeMin: number = Infinity;
    private logicFrameTimeMax: number = 0;
    private logicOverrunCount: number = 0;       // single frame took > frameTime
    private logicBatchMax: number = 0;           // max frames processed in a single tick

    // Catch-up & stalls
    private mildCatchUpCount: number = 0;
    private heavyCatchUpCount: number = 0;
    private accResetCount: number = 0;           // accumulator was reset (no frame data)
    private noFrameDataCount: number = 0;        // frames where server data was missing

    // Input capture
    private inputCaptureCount: number = 0;

    // Frame gap tracking
    private gapSamples: number = 0;
    private gapSum: number = 0;
    private gapMax: number = 0;

    // Per-frame scratch (not reset per window)
    private _frameStartMs: number = 0;

    // Lifetime counters (never reset)
    private totalLogicOverruns: number = 0;
    private totalRenderOverruns: number = 0;
    private totalHeavyCatchUps: number = 0;

    constructor() {
        this.windowStartMs = performance.now();
    }

    // ── Called once per render frame (from update) ─────────────────
    public onRenderFrame(dtMs: number): void {
        if (!this.enabled) return;

        this.renderFrameCount++;
        this.renderDtSum += dtMs;
        if (dtMs < this.renderDtMin) this.renderDtMin = dtMs;
        if (dtMs > this.renderDtMax) this.renderDtMax = dtMs;
        if (dtMs > NetConfig.frameTime) {
            this.renderDtOverrunCount++;
        }

        // Sample frame gap
        const gap = BattleData.newFrameId - BattleData.executeFrameId;
        this.gapSamples++;
        this.gapSum += gap;
        if (gap > this.gapMax) this.gapMax = gap;

        // Check if it's time to log
        const elapsed = performance.now() - this.windowStartMs;
        if (elapsed >= this.logIntervalSec * 1000) {
            this.printSummary(elapsed);
            this.resetWindow();
        }
    }

    // ── Called from ChasingFrame after frame loop ──────────────────
    /**
     * @param processedCount  Number of logic frames processed this render tick
     * @param chasingMode     0 = normal, 1 = mild catch-up, 2 = heavy catch-up
     * @param accWasReset     true if the accumulator was reset to 0 (no frame data)
     */
    public onLogicFramesProcessed(processedCount: number, chasingMode: number, accWasReset: boolean): void {
        if (!this.enabled) return;

        if (processedCount > this.logicBatchMax) {
            this.logicBatchMax = processedCount;
        }
        if (chasingMode === 1) this.mildCatchUpCount++;
        if (chasingMode === 2) this.heavyCatchUpCount++;
        if (accWasReset) this.accResetCount++;
    }

    // ── Called when OnHandlerFrame returns NoFrameData ──────────────
    public onNoFrameData(): void {
        if (!this.enabled) return;
        this.noFrameDataCount++;
    }

    // ── Wrap OnHandlerFrame logic ──────────────────────────────────
    public onLogicFrameStart(): void {
        if (!this.enabled) return;
        this._frameStartMs = performance.now();
    }

    public onLogicFrameEnd(): void {
        if (!this.enabled) return;
        const elapsed = performance.now() - this._frameStartMs;
        this.logicFrameCount++;
        this.logicFrameTimeSum += elapsed;
        if (elapsed < this.logicFrameTimeMin) this.logicFrameTimeMin = elapsed;
        if (elapsed > this.logicFrameTimeMax) this.logicFrameTimeMax = elapsed;
        if (elapsed > NetConfig.frameTime) {
            this.logicOverrunCount++;
            this.totalLogicOverruns++;
        }
    }

    // ── Called when input capture fires ─────────────────────────────
    public onInputCapture(): void {
        if (!this.enabled) return;
        this.inputCaptureCount++;
    }

    // ── Summary ────────────────────────────────────────────────────
    private printSummary(elapsedMs: number): void {
        const sec = elapsedMs / 1000;
        const frameTimeMs = NetConfig.frameTime;

        const renderFps = this.renderFrameCount / sec;
        const logicFps = this.logicFrameCount / sec;
        const expectedLogicFps = 1000 / frameTimeMs;   // 20
        const inputRate = this.inputCaptureCount / sec;

        const avgRenderDt = this.renderFrameCount > 0 ? (this.renderDtSum / this.renderFrameCount) : 0;
        const avgLogicTime = this.logicFrameCount > 0 ? (this.logicFrameTimeSum / this.logicFrameCount) : 0;
        const avgGap = this.gapSamples > 0 ? (this.gapSum / this.gapSamples) : 0;

        // Accumulate lifetime counters
        this.totalRenderOverruns += this.renderDtOverrunCount;
        this.totalHeavyCatchUps += this.heavyCatchUpCount;

        console.log(
            `[FrameSyncMonitor] ═══════════════════════════════════════\n` +
            `  Window: ${sec.toFixed(1)}s\n` +
            `  ── Render Loop ──\n` +
            `    FPS:          ${renderFps.toFixed(1)}\n` +
            `    dt (ms):      avg=${avgRenderDt.toFixed(1)}  min=${this.renderDtMin === Infinity ? '-' : this.renderDtMin.toFixed(1)}  max=${this.renderDtMax.toFixed(1)}\n` +
            `    dt > ${frameTimeMs}ms:  ${this.renderDtOverrunCount} times (lifetime: ${this.totalRenderOverruns})\n` +
            `  ── Logic Frames ──\n` +
            `    Logic FPS:    ${logicFps.toFixed(1)} / ${expectedLogicFps} expected\n` +
            `    Process (ms): avg=${avgLogicTime.toFixed(2)}  min=${this.logicFrameTimeMin === Infinity ? '-' : this.logicFrameTimeMin.toFixed(2)}  max=${this.logicFrameTimeMax.toFixed(2)}\n` +
            `    > ${frameTimeMs}ms:     ${this.logicOverrunCount} overruns (lifetime: ${this.totalLogicOverruns})\n` +
            `    Batch max:    ${this.logicBatchMax} frames/tick\n` +
            `  ── Frame Gap ──\n` +
            `    Server-Client gap:  avg=${avgGap.toFixed(1)}  max=${this.gapMax}\n` +
            `    handleFrameId:      ${BattleData.handleFrameId}\n` +
            `    executeFrameId:     ${BattleData.executeFrameId}\n` +
            `    newFrameId:         ${BattleData.newFrameId}\n` +
            `  ── Catch-up & Stalls ──\n` +
            `    Mild catch-ups:     ${this.mildCatchUpCount}\n` +
            `    Heavy catch-ups:    ${this.heavyCatchUpCount} (lifetime: ${this.totalHeavyCatchUps})\n` +
            `    Acc resets (stalls): ${this.accResetCount}\n` +
            `    No frame data:      ${this.noFrameDataCount}\n` +
            `  ── Input ──\n` +
            `    Capture rate:  ${inputRate.toFixed(1)}/sec (expected ${expectedLogicFps})\n` +
            `  ── Flags ──\n` +
            `    isChasingFrame: ${BattleGlobal.isChasingFrameFlag}\n` +
            `    isNormalPlay:   ${BattleGlobal.isNormalPlay}\n` +
            `    isStandalone:   ${BattleGlobal.isStandaloneFlag}\n` +
            `    isGameEnd:      ${BattleGlobal.isGameEndFlag}\n` +
            `═══════════════════════════════════════════════════════════`
        );
    }

    private resetWindow(): void {
        this.windowStartMs = performance.now();
        this.renderFrameCount = 0;
        this.renderDtSum = 0;
        this.renderDtMin = Infinity;
        this.renderDtMax = 0;
        this.renderDtOverrunCount = 0;

        this.logicFrameCount = 0;
        this.logicFrameTimeSum = 0;
        this.logicFrameTimeMin = Infinity;
        this.logicFrameTimeMax = 0;
        this.logicOverrunCount = 0;
        this.logicBatchMax = 0;

        this.mildCatchUpCount = 0;
        this.heavyCatchUpCount = 0;
        this.accResetCount = 0;
        this.noFrameDataCount = 0;

        this.inputCaptureCount = 0;

        this.gapSamples = 0;
        this.gapSum = 0;
        this.gapMax = 0;
    }

    /** Get a snapshot object (useful for on-screen UI or external tooling) */
    public getSnapshot(): FrameSyncSnapshot {
        const now = performance.now();
        const sec = (now - this.windowStartMs) / 1000 || 1;
        return {
            renderFps: this.renderFrameCount / sec,
            logicFps: this.logicFrameCount / sec,
            avgRenderDtMs: this.renderFrameCount > 0 ? this.renderDtSum / this.renderFrameCount : 0,
            maxRenderDtMs: this.renderDtMax,
            avgLogicFrameMs: this.logicFrameCount > 0 ? this.logicFrameTimeSum / this.logicFrameCount : 0,
            maxLogicFrameMs: this.logicFrameTimeMax,
            logicOverruns: this.logicOverrunCount,
            renderOverruns: this.renderDtOverrunCount,
            frameGap: BattleData.newFrameId - BattleData.executeFrameId,
            maxFrameGap: this.gapMax,
            heavyCatchUps: this.heavyCatchUpCount,
            accResets: this.accResetCount,
            noFrameDataCount: this.noFrameDataCount,
            inputCaptureRate: this.inputCaptureCount / sec,
            totalLogicOverruns: this.totalLogicOverruns,
            totalRenderOverruns: this.totalRenderOverruns,
        };
    }
}

export interface FrameSyncSnapshot {
    renderFps: number;
    logicFps: number;
    avgRenderDtMs: number;
    maxRenderDtMs: number;
    avgLogicFrameMs: number;
    maxLogicFrameMs: number;
    logicOverruns: number;
    renderOverruns: number;
    frameGap: number;
    maxFrameGap: number;
    heavyCatchUps: number;
    accResets: number;
    noFrameDataCount: number;
    inputCaptureRate: number;
    totalLogicOverruns: number;
    totalRenderOverruns: number;
}

