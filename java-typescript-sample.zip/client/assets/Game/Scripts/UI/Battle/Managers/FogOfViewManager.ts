import { _decorator, Component, Vec3 } from 'cc';
import { BattleManager } from './BattleManager';
import { CreatureManager } from './CreatureManager';
import { Creature } from '../Enities/Creature';
import { BattleGlobal } from '../Utils/BattleGlobal';
import { Constant } from '../../../../../Scripts/Utils/Constant';

const { ccclass } = _decorator;

/**
 * Fog of view: enemy and neutral units are only visible when within vision radius
 * of the local player's allied vision providers. Runs in lateUpdate before camera and UI.
 */
@ccclass('FogOfViewManager')
export class FogOfViewManager extends Component {

  public static Instance: FogOfViewManager | null = null;

  /** When false, all creatures are shown (no fog). Can be toggled via config or debug. */
  public fogEnabled = true;

  private readonly _visionProviders: Creature[] = [];
  private readonly _creatureList: Creature[] = [];
  /** Only enemy/neutral alive creatures that need fog distance check; avoids work for allies and always-visible. */
  private readonly _hideableList: Creature[] = [];
  private readonly _providerPos = new Vec3();
  private readonly _creaturePos = new Vec3();

  onLoad() {
    FogOfViewManager.Instance = this;
  }

  onDestroy() {
    this.setAllCreaturesVisible();
    FogOfViewManager.Instance = null;
  }

  /**
   * Call from BattleManager.Clear() or when fog is disabled: make all creatures visible
   * so no unit stays hidden after battle end.
   */
  public setAllCreaturesVisible(): void {
    const list = this._creatureList;
    list.length = 0;
    CreatureManager.Instance.creatureMap.valuesInto(list);
    for (let i = 0; i < list.length; i++) {
      const c = list[i];
      if (c && c.node && c.node.isValid) {
        c.SetFogVisibility(true);
      }
    }
  }

  /**
   * Run once per frame in BattleManager.lateUpdate (before camera and updateRendering).
   * Computes visibility for hideable creatures and sets Creature.isVisibleToLocalPlayer and node.active.
   */
  public updateFog(_dt: number): void {
    if (!this.fogEnabled) {
      this.setAllCreaturesVisible();
      return;
    }

    const currentCharacter = BattleManager.Instance?.currentCharacter;
    const visionRadiusSq = BattleGlobal.visionRadius * BattleGlobal.visionRadius;

    const list = this._creatureList;
    list.length = 0;
    CreatureManager.Instance.creatureMap.valuesInto(list);

    const providers = this._visionProviders;
    providers.length = 0;
    const hideable = this._hideableList;
    hideable.length = 0;

    const allyTeam = currentCharacter?.teamType2;

    // Single pass: build providers and hideable list; set visibility for allies and always-visible
    for (let i = 0; i < list.length; i++) {
      const creature = list[i];
      if (!creature || !creature.node || !creature.node.isValid) continue;

      if (currentCharacter && creature.teamType2 === currentCharacter.teamType2) {
        creature.SetFogVisibility(true);
        continue;
      }
      if (creature.characterDefine?.Class === Constant.CharacterClass.Fyt ||
          creature.characterDefine?.Class === Constant.CharacterClass.ShuiJin ||
          creature.characterDefine?.Class === Constant.CharacterClass.Boss) {
        creature.SetFogVisibility(true);
        continue;
      }
      if (creature.IsDeath) continue;

      hideable.push(creature);
    }

    if (currentCharacter && !currentCharacter.IsDeath && currentCharacter.node && currentCharacter.node.isValid) {
      providers.push(currentCharacter);
    }
    for (let i = 0; i < list.length; i++) {
      const c = list[i];
      if (!c || c.IsDeath || !c.node?.isValid || c.teamType2 !== allyTeam) continue;
      const cls = c.characterDefine?.Class;
      if (cls === Constant.CharacterClass.Fyt || cls === Constant.CharacterClass.ShuiJin || cls === Constant.CharacterClass.Soldier) {
        providers.push(c);
      }
    }

    const hasVision = providers.length > 0;

    // Only do expensive getWorldPosition + distance for hideable creatures
    for (let i = 0; i < hideable.length; i++) {
      const creature = hideable[i];
      if (!hasVision) {
        creature.SetFogVisibility(false);
        continue;
      }
      creature.node.getWorldPosition(this._creaturePos);
      let minDistSq = Infinity;
      for (let p = 0; p < providers.length; p++) {
        providers[p].node.getWorldPosition(this._providerPos);
        const dSq = Vec3.squaredDistance(this._providerPos, this._creaturePos);
        if (dSq < minDistSq) minDistSq = dSq;
      }
      creature.SetFogVisibility(minDistSq <= visionRadiusSq);
    }
  }
}
