import { Creature } from "../Enities/Creature";
import { UIWorldElementManager } from "../UIWorldElementManager";
import { Vec3, instantiate, Node } from "cc";
import { PoolManager } from "../../../Managers/PoolManager";
import { BattleManager } from "./BattleManager";
import { TeamType2 } from "../enums/TeamType2";
import { DataManager } from "../../../Managers/DataManager";
import { SpawnRuleDefine } from "../../../Data/SpawnRuleDefine";
import { CollisionCheckManager } from "./CollisionCheckManager";
import { CreatureType } from "../enums/CreatureType";
import { ShapeType } from "../enums/ShapeType";
import { MathUtil } from "../../../Utils/MathUtil";
import { LogicRenderConvert } from "../Utils/LogicRenderConvert";
import proto from "../../../../Proto/proto.js";
import { BuffType } from "../enums/BuffType";
import { IStateRollback } from "../StateRecord/IStateRollback";
import { CreatureManagerRecord } from "../StateRecord/Managers/CreatureManagerRecord";
import { CreatureRecord } from "../StateRecord/Enities/CreatureRecord";
import { SpawnMonManager } from "../SpawnMon/SpawnMonManager";
import { DeseTypeConve } from "../Utils/DeseTypeConve";
import { HashMap } from "../../../../../Scripts/Utils/HashMap";

/**
 * Creature manager
 */
export class CreatureManager implements IStateRollback{

    public static Instance:CreatureManager=new CreatureManager(); 

    //key：entityId   value：Creature
    public creatureMap=new HashMap();
    public removeCreatureMap=new HashMap();
    public idx:number=0;

    public Clear(){
        // Remove creature health bar nodes
        // let creatureData = this.creatureMap.data;
        // for(let entityId in creatureData){
        //     let creature = this.creatureMap.get(entityId);
        //     UIWorldElementManager.Instance.RemoveCharacterHpBar(creature);
        // }

        this.creatureMap.clear();
        this.removeCreatureMap.clear();
        this.idx=0;
    }

    /**
     * Add creature
     * @param node Model node
     * @param creature  Creature object
     * @param idx Unique identifier id
     */
    public AddCreature(node, creature:Creature, idx:number=undefined){
        if(idx){
            if(idx > this.idx){
                this.idx=idx;
            }
        }else{
            this.idx++;
            idx = this.idx;
        }
        creature.entityId = idx;
        node.entityId = idx;
        this.creatureMap.put(idx, creature);
        // console.log('idx='+idx+',name='+creature.node.name)
        // Add health bar (defer for minions to avoid blocking spawn on material/UI init)
        if (creature.creatureType === CreatureType.Monster) {
            setTimeout(() => {
                if (creature.node && creature.node.isValid && this.creatureMap.get(creature.entityId) === creature) {
                    UIWorldElementManager.Instance.AddCharacterHpBar(node, creature);
                }
            }, 0);
        } else {
            UIWorldElementManager.Instance.AddCharacterHpBar(node, creature);
        }
        // Add to collision manager
      if(creature.characterDefine.IsCollision){  // With collision
        CollisionCheckManager.Instance.creatureList.push(creature);
      } 
    }

    /**
     * Remove creature
     * @param entityId Entity id
     */
    public RemoveCreature(entityId:number){
        this.creatureMap.remove(entityId);
        // Remove collision manager creature
        let creatureList = CollisionCheckManager.Instance.creatureList;
        for(let i=0; i < creatureList.length; i++){
            let creature = creatureList[i];
            if(creature.entityId == entityId){
                this.removeCreatureMap.put(entityId, creature);
                UIWorldElementManager.Instance.RemoveCharacterHpBar(creature);
                // Return minion node to pool for reuse
                if (creature.creatureType === CreatureType.Monster && creature.node && creature.node.isValid) {
                    let resource = (creature.teamType2 === TeamType2.Red ? creature.characterDefine.RedResource : creature.characterDefine.Resource) || creature.characterDefine.Resource;
                    if (resource && creature.characterDefine.ShadowName && creature.node.parent) {
                        let children = creature.node.parent.children;
                        for (let j = 0; j < children.length; j++) {
                            if (children[j].name === creature.characterDefine.ShadowName) {
                                children[j].destroy();
                                break;
                            }
                        }
                    }
                    creature.node.removeFromParent();
                    // Keep node active so reuse doesn't re-run activateNode/AnimationGraphEval (~4–5ms)
                    PoolManager.instance.putNode(creature.node, resource);
                }
                creatureList.splice(i, 1);
                i--;
                break;
            }
        }
    }

    /**
     * Get creature
     * @param entityId Entity id
     */
    public GetCreature(entityId:number, isQueryRemove:boolean = false) : Creature {
        let creature = this.creatureMap.get(entityId);
        if(!creature && isQueryRemove){
            creature = this.removeCreatureMap.get(entityId);
        }
        return creature;
    }

    public update(){
        let creatureData = this.creatureMap.data;
        for(let entityId in creatureData){
            let creature = this.creatureMap.get(entityId) as Creature;
            creature.update();
        }
    }

    /**
     * Query count by type
     * @param characterClass 
     */
    public GetCountByClass(characterClass:string):number{
        let count:number = 0;
        let creatureData = this.creatureMap.data;
        for(let entityId in creatureData){
          let creature = this.creatureMap.get(entityId) as Creature;
          if(creature.characterDefine.Class == characterClass){  
              count++;
          }
        }
        return count;
    }

    /**
     * Query creature by type and team
     * @param characterClass 
     */
     public GetCreatureByClassTeamType2(characterClass:string, teamType2:TeamType2) : Creature{
        let creatureData = this.creatureMap.data;
        for(let entityId in creatureData){
          let creature = this.creatureMap.get(entityId) as Creature;
          if(creature.characterDefine.Class == characterClass && creature.teamType2 == teamType2){  
            return creature;
          }
        }
        return null;
    }

    /**
     * Query creature by team
     * @param characterClass 
     */
     public GetCreatureByTeamType2(teamType2:TeamType2) : Array<Creature>{
        let creatureList = new Array<Creature>();  // Creature collection
        let creatureData = this.creatureMap.data;
        for(let entityId in creatureData){
          let creature = this.creatureMap.get(entityId) as Creature;
          if(creature.teamType2 == teamType2){  
            creatureList.push(creature);
          }
        }
        return creatureList;
    }

    private characterList=new Array<Creature>();
    private monsterList=new Array<Creature>();    
    private emptyList=new Array<Creature>();
    private tempVec3=new Vec3();

    /**
     * Query creatures within specified shape range
     * @param positionX Position x  Logic value
     * @param positionZ Position z  Logic value
     * @param radius Radius  Logic value
     * @param blowsNum Count  Less than 0 for all
     * @param teamType2 Team type
     * @param isDirOrder Whether sort by distance  (default no)
     * @param shapeType Shape  (default circle)
     * @param width Width  Logic value
     * @param height Height  Logic value
     * @param rectAngle Rectangle angle
     * @param isHeroFirst  Whether hero priority (default yes)
     * @param buffType Buff type
     * @param priorityHitTarget Priority damage target
     * @param isAggroOrder Whether sort by aggro  (default no)
     * @param useTo Purpose 1, find target 2, damage
     * @param isAttackStealth Whether can attack stealth players
     */
    public FindUnitsInRange(positionX:number, positionZ:number, radius:number, blowsNum:number, teamType2:TeamType2, isDirOrder:boolean = false, shapeType:ShapeType = ShapeType.circle,width?:number,height?:number,rectAngle?:number,isHeroFirst:boolean = true, buffType?:BuffType, priorityHitTarget?:Creature, 
        isAggroOrder = false, useTo:number = 1, isAttackStealth:boolean = false):Array<Creature> {
        // console.log('FindUnitsInRange buffType='+buffType);
        // console.log('FindUnitsInRange positionX='+positionX+'，positionZ='+positionZ+'，radius='+radius+'，blowsNum='+blowsNum+'，teamType2='+teamType2+'，isDirOrder='+isDirOrder)
        if(this.characterList.length > 0){
            this.characterList.length = 0;
        }
        if(this.monsterList.length > 0){
            this.monsterList.length = 0;
        }
        if(this.emptyList.length > 0){
            this.emptyList.length = 0;
        }

        let creatureMap = CreatureManager.Instance.creatureMap;
        let creatureData = creatureMap.data;
        for (let entityId in creatureData) 
        {
            let creature = creatureMap.get(entityId) as Creature;
            if(creature.IsDeath || ((!buffType || buffType != BuffType.MoveTreatmentFormation) && creature.isRetreat)){  // Death, retreat
                continue;
            }
            if((!buffType || buffType != BuffType.MoveTreatmentFormation) && teamType2==creature.teamType2){  // Own team
                continue;
            }
            if(!isAttackStealth && useTo == 1 && creature.battleAttribute.StealthCount > 0) {  // Find target, already stealthed
                continue;
            }
            let isCollision:boolean=false;  // Whether collision 
            let targetShape = creature.characterDefine.Shape.toString();
          if(shapeType == ShapeType.circle){    // Circle
            if(targetShape==ShapeType[ShapeType.circle]){  // Creature is circle
                // Two circle collision detection
                if(creature.Distance3(positionX, positionZ) < LogicRenderConvert.RenderToLogic_Value(creature.characterDefine.Radius) + radius){
                    isCollision=true;
                }
            }else if(targetShape==ShapeType[ShapeType.rect]){  // Creature is rectangle
                // Rectangle and circle collision detection
                this.tempVec3.set(positionX, 0, positionZ);
                isCollision=MathUtil.CollideCircleAndRectRotateRevise(this.tempVec3, radius, creature.CollisionTempVec3, LogicRenderConvert.RenderToLogic_Value(creature.characterDefine.Width), LogicRenderConvert.RenderToLogic_Value(creature.characterDefine.Long_),  creature._amend, 360-creature.logicRotation.y);
            }
          }else if(shapeType == ShapeType.rect){  // Rectangle
            if(targetShape==ShapeType[ShapeType.circle]){  // Creature is circle
                let myLogicPosition = creature.CollisionTempVec3;
                this.tempVec3.set(positionX, 0, positionZ);
                isCollision=MathUtil.CollideCircleAndRectRotateRevise(myLogicPosition, LogicRenderConvert.RenderToLogic_Value(creature.characterDefine.Radius), this.tempVec3, width, height,  creature._amend, 360-rectAngle);
                // if(isCollision){
                //   console.log('myLogicPosition='+myLogicPosition+'，Radius='+LogicRenderConvert.RenderToLogic_Value(creature.characterDefine.Radius)+'，tempVec3='+this.tempVec3+'， width='+ width+'，height='+ height+'，_amend='+  creature._amend)
                // }
                // console.log('Circle and rectangle collision detection result:'+isCollision)
            }else if(targetShape==ShapeType[ShapeType.rect]){  // Creature is rectangle
                let myLogicPosition = creature.CollisionTempVec3; 
                isCollision=MathUtil.rectInRect(myLogicPosition.x, myLogicPosition.z, LogicRenderConvert.RenderToLogic_Value(creature.characterDefine.Width), LogicRenderConvert.RenderToLogic_Value(creature.characterDefine.Long_), 360-creature.logicRotation.y,
                positionX, positionZ, width, height, 360-rectAngle);
                // console.log('Rectangle and rectangle collision detection result:'+isCollision)
            }
          } 
            if(isCollision) {  // Collision
                // Calculate distance to detection point
                creature.dir = creature.Distance3(positionX, positionZ);
                // console.log('id='+creature.entityId+', distance='+creature.dir+', current shape='+ShapeType[shapeType]+', enemy shape='+targetShape)

                if(creature.creatureType == CreatureType.Character){
                    this.characterList.push(creature);
                }else if(creature.creatureType == CreatureType.Monster){
                    this.monsterList.push(creature);
                }
            }
        }
        if(blowsNum==0 || (this.characterList.length + this.monsterList.length) == 0) {
            return this.emptyList;
        }else {
            let resultList:Array<Creature> = null;
            if(isAggroOrder){  // Sort by aggro value, heroes without aggro value default to back, prioritize heroes
               resultList = this.monsterList.concat(this.characterList);
               resultList = resultList.sort(MathUtil.sortBy('aggro', false));
            }else{
                if(isDirOrder){  // Whether sort by distance
                    if(isHeroFirst){   // Whether hero priority
                        // Sort first then concatenate
                        this.characterList = this.characterList.sort(MathUtil.sortBy('dir', true));
                        this.monsterList = this.monsterList.sort(MathUtil.sortBy('dir', true));
                        resultList = this.characterList.concat(this.monsterList);
                    }else{
                        // Concatenate first then sort
                        resultList = this.characterList.concat(this.monsterList);
                        resultList = resultList.sort(MathUtil.sortBy('dir', true));
                    }
                }else{
                    // Only concatenate
                     resultList = this.characterList.concat(this.monsterList);
                }
            }

            // console.log('characterList leng='+this.characterList.length+'，monsterList leng='+this.monsterList.length
            // +'，resultList leng='+resultList.length)
            
            // Put priority damage target first
            if(priorityHitTarget){  // Priority damage target exists
                for(let i = 0; i < resultList.length; i++){
                    let target = resultList[i];
                    if(target.entityId == priorityHitTarget.entityId){
                        if(i != 0){    // Swap position 0 and current position
                          let temp0 = resultList[0];
                          resultList[0] = target;
                          resultList[i] = temp0;
                        }
                        break;
                    }
                }
            }
 
            if(blowsNum < 0){
                return resultList;
            }else {
                if(blowsNum >= resultList.length) {
                    return resultList;                
                }else{
                    resultList.splice(blowsNum); 
                    return  resultList;
                }
            }
        }
    }

    /**
     * Rollback state
     */
   rollback(data:CreatureManagerRecord):void{
        let creatureDataRecordMap = DeseTypeConve.conveHashMap(data.creatureMap);
        let creatureDataRecord = creatureDataRecordMap.data;
        if(creatureDataRecord){
            for (let key in creatureDataRecord) {
              let entityId = Number(key);
              let creatureRecord = creatureDataRecordMap.get(entityId) as CreatureRecord;
              let creature = this.GetCreature(entityId);
            //   console.log('rollback SpawnId='+creatureRecord.SpawnId+'，entityId='+entityId,creature)
              if(!creature){   // Does not exist, then it's a monster
                let callMonster = BattleManager.Instance.callMonster;
                if(creatureRecord.SpawnId){
                  let spawn = SpawnMonManager.Instance.getSpawn(creatureRecord.SpawnId);
                  if(spawn){
                    creature = spawn.RefreshMon(entityId);
                  }
                }else if(creatureRecord.defineId == callMonster.characterId){  // Is summoned monster
                    callMonster.create(creatureRecord.teamType2, creatureRecord.entityId);
                }
              }              
            }
            console.log('Rollback all creature object states rollback cache data id=',creatureDataRecordMap.keys(),', created creature data id=',this.creatureMap.keys())
            // console.log('Rollback all creature object states, total count='+stateData.creatureManagerRecord.creatureMap.length+', created count='+CreatureManager.Instance.creatureMap.length)
            // Note: Two loops are needed to ensure all creatures created above are added to the map, because rollback below may need to query by creature entity id
            for (let key in creatureDataRecord) {
              let entityId = Number(key);
              let creatureRecord = creatureDataRecordMap.get(entityId) as CreatureRecord;
              let creature = this.GetCreature(entityId);
              if(creature){
                creature.rollback(creatureRecord);
              }
            }
        }  
        this.idx = data.idx;
    }    

}