import { Creature } from "../Enities/Creature";
import { Attacker } from "../Models/Attacker";
import { BattleGlobal } from "../Utils/BattleGlobal";
import { DataManager } from "../../../Managers/DataManager";
import { Decimal } from "decimal.js";
import { CreatureType } from "../enums/CreatureType";
import { IStateRollback } from "../StateRecord/IStateRollback";
import { AttackerManagerRecord } from "../StateRecord/Managers/AttackerManagerRecord";
import { CreatureManager } from "./CreatureManager";
import { BattleManager } from "./BattleManager";
import { AttackerVo } from "../Vo/AttackerVo";
import { User } from "../../../Models/User";
import { HashMap } from "../../../../../Scripts/Utils/HashMap";
import { BattleData } from "../Utils/BattleData";

/**
 * Attacker manager
 */
export class AttackerManager implements IStateRollback{

    private Owner:Creature;
    public Attackers=new Array<Attacker>();

    public lastAttackHero:Creature = null;  // Last attacking hero
    private zhuGongMap = new HashMap();
    public attackerVoList = new Array<AttackerVo>();
    public sumDamage:number = 0;  // Total damage
    public maxTime:number = 0; // Time

    public constructor(creature:Creature)
    {
        this.Owner = creature;
    }
    
    /**
     * Add attacker
     * @param zhuGongCreature 
     * @param damage 
     */
    public AddAttacker(caster:Creature, damage:Decimal, isDeath:boolean){
        if(caster.creatureType == CreatureType.Character){  // Hero
          this.lastAttackHero = caster;
        }
        if((this.Owner.creatureType == CreatureType.Character && caster.creatureType != CreatureType.Monster) || 
           this.Owner.creatureType == CreatureType.Monster){   
          // ✅ Pass current frame ID for deterministic expiration
          this.Attackers.push(new Attacker(caster, damage, !isDeath, BattleData.executeFrameId));
        }
        if(isDeath){  // Current character death
            this.lastAttackHero = null;             
            this.zhuGongMap.clear();
            // Update assist killer count
            console.log('[ASSIST] Death of ' + this.Owner.characterDefine.Name + ' by ' + caster.characterDefine.Name + 
                        ', processing ' + this.Attackers.length + ' attackers');
            for(let i = 0; i < this.Attackers.length; i++){
                let attacker = this.Attackers[i];
                let zhuGongEntityId = attacker.zhuGongCreature.entityId;
                if(zhuGongEntityId == caster.entityId){  // Assister is death killer, update assister status to non-assister
                    console.log('[ASSIST] Skipping ' + attacker.zhuGongCreature.characterDefine.Name + ' (is killer)');
                    attacker.isZhuGongFlag = false;
                }else if(attacker.isZhuGongFlag){    // Is assist
                    if(this.zhuGongMap.get(zhuGongEntityId)){  // Already added
                        console.log('[ASSIST] Skipping ' + attacker.zhuGongCreature.characterDefine.Name + ' (already counted)');
                        continue;
                    }
                    let oldCount = attacker.zhuGongCreature.zhuGong;
                    attacker.zhuGongCreature.zhuGong++;
                    console.log('[ASSIST] ' + attacker.zhuGongCreature.characterDefine.Name + ' assist: ' + oldCount + ' → ' + attacker.zhuGongCreature.zhuGong);
                    this.zhuGongMap.put(zhuGongEntityId, '1');
                } else {
                    console.log('[ASSIST] Skipping ' + attacker.zhuGongCreature.characterDefine.Name + ' (isZhuGongFlag=false)');
                }
            }

            // Calculate damage ratio            
            this.CalculationDamageProportion();            
        }
    }

    /**
     * Calculate damage ratio
     */
    private CalculationDamageProportion() {
        let sumDamage:number = 0;  // Total damage
        let maxTime:number = 0; // Time
        let killedAttackers = this.Owner.AttackerMgr.Attackers;
        this.attackerVoList.length = 0;
        for(let i = killedAttackers.length - 1; i >= 0; i--){  // Recent kills should display first, so reverse order (fixed: was i > 0, now i >= 0)
           let killedAttacker = killedAttackers[i];
           let jg = Math.floor((this.Owner.deathTime.getTime() - killedAttacker.time.getTime()) / 1000);  // Interval seconds           
           if(jg > maxTime){ 
             maxTime = jg;
           }
           sumDamage += Number(killedAttacker.damage.toFixed(0));

           // Loop to check if already exists
           let exeistFlag:boolean = false;
           for(let j = 0; j < this.attackerVoList.length; j++){
             let attackerVo = this.attackerVoList[j];
             if(attackerVo.zhuGongCreature.entityId == killedAttacker.zhuGongCreature.entityId){
                attackerVo.damage += Number(killedAttacker.damage.toFixed(0));
                exeistFlag = true;
                break;
             }
           }
           if(!exeistFlag){  // Does not exist
            this.attackerVoList.push(new AttackerVo(killedAttacker.zhuGongCreature, Number(killedAttacker.damage.toFixed(0)), killedAttacker.isZhuGongFlag));
           }
        }
        // Calculate ratio
        let biLiSum:number = 0;
        for(let j = 0; j < this.attackerVoList.length; j++){
            let attackerVo = this.attackerVoList[j];
            if(j == this.attackerVoList.length - 1){
                attackerVo.zhanBi = 100 - biLiSum;
            }else{
                let biLi = Math.ceil(attackerVo.damage / sumDamage * 100);
                biLiSum += biLi;
                attackerVo.zhanBi = biLi;
            }
        }       
        this.sumDamage = sumDamage;
        this.maxTime = maxTime;
    }

    /**
     * Clear
     */
    public Clear(){
        this.Attackers.length = 0;
    }

    public LogicUpdate(currentFrameId: number)
    {
        if(this.Owner.IsDeath){
            return;
        }
        let removedCount = 0;
        for(let i = 0; i < this.Attackers.length; i++){
            let attacker = this.Attackers[i];
            // ✅ Use frame-based age calculation (deterministic)
            let frameAge = currentFrameId - attacker.timeFrame;
            let secondsAge = frameAge / 15;  // 15 frames per second
            
            if (secondsAge > DataManager.Instance.gameConfig.zhenWangTongJiTime) {   // Stop and delete
                console.log('[ASSIST EXPIRE] Removing old attacker: ' + attacker.zhuGongCreature.characterDefine.Name + 
                           ', frameAge=' + frameAge + ', secondsAge=' + secondsAge.toFixed(1) + 's (max=' + DataManager.Instance.gameConfig.zhenWangTongJiTime + 's)');
                this.Attackers.splice(i,1);
                i--;
                removedCount++;
            }
        }
        if(removedCount > 0){
            console.log('[ASSIST EXPIRE] Removed ' + removedCount + ' expired attackers, remaining: ' + this.Attackers.length);
        }
    }

   /**
    * Rollback state
    */
   rollback(data:AttackerManagerRecord):void{
    let oldCount = this.Attackers.length;
    console.log('[ASSIST ROLLBACK] Restoring attackers for ' + this.Owner.characterDefine.Name + ', old count=' + oldCount + ', new count=' + data.Attackers.length);
    // ✅ Clear existing attackers array before restoring (prevents duplicates!)
    this.Attackers.length = 0;
    for(let attackerRecord of data.Attackers){
        let creature = CreatureManager.Instance.GetCreature(attackerRecord.zhuGongCreatureId);
        if (!creature) {
            console.warn('[ASSIST ROLLBACK] Creature not found for entityId=' + attackerRecord.zhuGongCreatureId);
            continue;
        }
        // ✅ Pass saved timeFrame and time from snapshot
        let attacker = new Attacker(creature, attackerRecord.damage, attackerRecord.isZhuGongFlag, attackerRecord.timeFrame, attackerRecord.time);
        attacker.rollback(attackerRecord);
        console.log('[ASSIST ROLLBACK] Restored attacker: ' + creature.characterDefine.Name + 
                   ', isZhuGongFlag=' + attacker.isZhuGongFlag + ', timeFrame=' + attacker.timeFrame);
        this.Attackers.push(attacker);
    }
    if(data.lastAttackHeroId){
        let creature = CreatureManager.Instance.GetCreature(data.lastAttackHeroId);
        this.lastAttackHero = creature;
    }
    console.log('[ASSIST ROLLBACK] Final attackers count=' + this.Attackers.length + ' (cleared ' + oldCount + ' old attackers)');
   }

}