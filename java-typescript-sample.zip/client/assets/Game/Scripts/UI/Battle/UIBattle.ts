
import { _decorator, Component, Node, instantiate, input, Vec2, Vec3, game, v3, Label, SpriteFrame, Sprite, RichText, Prefab, view, math, director, UITransform, Input, EventTouch, Size } from 'cc';
import { EventManager } from '../Common/Event/EventManager';
import proto from '../../../Proto/proto.js';
import { OptType } from './enums/OptType';
import { BattleService } from '../../Services/BattleService';
import { NetConfig } from '../../Network/NetConfig';
import { EventType } from '../Common/Event/EventType';
import { LogUtil } from '../../Log/LogUtil';
import { User } from '../../Models/User';
import { DataManager } from '../../Managers/DataManager';
import { CreatureManager } from './Managers/CreatureManager';
import { TeamType2 } from './enums/TeamType2';
import { MathUtil } from '../../Utils/MathUtil';
import { BattleManager } from './Managers/BattleManager';
import { NetClientBattle } from '../../Network/Battle/NetClientBattle';
import { RoomService } from '../../Services/RoomService';
import { LocalStorageUtil } from '../../Utils/LocalStorageUtil';
import { BattleGlobal } from './Utils/BattleGlobal';
import { BattleMode } from './enums/BattleMode';
import { ChatManager } from '../../Managers/ChatManager';
import { UILiveMsg } from './UILiveMsg';
import { RandomUtil } from "./Utils/RandomUtil";
import { UIDieInBattle } from './UI/UIDieInBattle';
import { UIGameAchievements } from './UI/UIGameAchievements';
import { NetClient } from '../../Network/NetClient';
import { BattleData } from './Utils/BattleData';
import { UIMingLingTips } from './UI/UIMingLingTips';
import { CharacterManager } from './Managers/CharacterManager';
import { NodeTipsManager } from '../Common/NodeTipsManager';
import { WindosAni } from '../Common/enums/WindosAni';
import { UILabelSetData } from '../Common/UILabelSetData';
import { UIKillTips } from './UI/UIKillTips';
import { Creature } from './Enities/Creature';
import { CreatureType } from './enums/CreatureType';
import { UIEnterGameLoad } from '../Match/UIEnterGameLoad';
import { UIGameEnd } from './UI/UIGameEnd';
import Decimal from "decimal.js";
import { UISkillDataSet } from './UI/UISkillDataSet';
import { UIReturnCity } from './UI/ReturnCity/UIReturnCity';
import { DateUtil } from '../../Utils/DateUtil';
import { UIMinimapManager } from './Minimap/UIMinimapManager';
import { UISkillDescPanel } from '../SkillDescPanel/UISkillDescPanel';
import { TipsManager } from '../TipsManager';
import { Constant } from '../../../../Scripts/Utils/Constant';
const { ccclass, property } = _decorator;

@ccclass('UIBattle')
export class UIBattle extends Component {

    @property([Node])
    public controlActiveNodeArr = [];   //Control show/hide nodes
    @property([Node])
    public controlActiveNodeLiveArr = [];   //Control live show/hide nodes

    @property(Label)
    public FenSiCountLabel: Label = null;   //Follower count
    @property([SpriteFrame])
    public networkSpriteFrameArr: Array<SpriteFrame> = [];    //Network image collection
    @property(Sprite)
    public networkSprite: Sprite = null;    //Network image
    @property(Label)
    public networkLabel: Label = null;  //Network text
    @property(Label)
    public gameTimeLable: Label = null;  //Game time
    @property(Label)
    public fpsLabel: Label = null;  //FPS text
    @property(Node)
    public ChatUI: Node = null;  //Battle chat UI
    @property(Node)
    public LiveChatUI: Node = null;  //Watch live chat UI
    @property(Sprite)
    public chatBtnSprite: Sprite = null;    //Chat button
    @property(RichText)
    public myChatLastRichText: RichText = null;  //Our last message
    @property(Prefab)
    public uiLiveMsg: Prefab = null;

    @property(Label)
    public handleFrameLabel: Label = null;  //Processed frames
    @property(Label)
    public blueBiFenLabel: Label = null;   //Blue team score
    @property(Label)
    public redBiFenLabel: Label = null;   //Red team score
    @property(UIGameAchievements)
    public uiGameAchievements: UIGameAchievements = null;
    @property(Label)
    public logLabel: Label = null;  //Log label
    @property(UILabelSetData)
    public achievementStrUILabelSetData: UILabelSetData = null;  //Reward data
    @property(RichText)
    public mainQuestsRichText: RichText = null;  //Main quest description
    @property(Node)
    public mingLingUI: Node = null;  //Command UI
    @property(UIMingLingTips)
    public uiMingLingTips: UIMingLingTips = null;  //Command tips UI
    @property(UILabelSetData)
    public gongGaoUILabelSetData: UILabelSetData = null;  //Announcement data
    @property(UIKillTips)
    public uiKillTips: UIKillTips = null;   //Kill tips UI
    @property(UIEnterGameLoad)
    public uiEnterGameLoad: UIEnterGameLoad = null;   //Enter game loading page
    @property(UIGameEnd)
    public uiGameEnd: UIGameEnd = null;   //Game end
    @property(Label)
    public jiShaCountLabel: Label = null;  //Kill count
    @property(Label)
    public siWangCountLabel: Label = null;  //Death count
    @property(Label)
    public zhuGongCountLabel: Label = null;  //Assist count
    @property(Label)
    public bossKillShowTipsLabel: Label = null;  //Boss kill tips

    @property(UISkillDataSet)
    public uiSkillDataSet: UISkillDataSet = null;

    @property(UIReturnCity)
    public uiReturnCity: UIReturnCity = null;
    @property(Node)
    public battleUI: Node = null;

    @property(Node)
    public backUI: Node = null;  //Exit game UI

    @property(SpriteFrame)
    public chatBtnCloseSpriteFrame: SpriteFrame = null;    //Chat button close image
    private chatBtnDefaultSpriteFrame: SpriteFrame = null;  //Chat button default image

    private startMoveVec2 = new Vec2();   //Start move point position
    private currentMoveVec2 = new Vec2();   //Current move point position
    private isMoveFlag = false;  //Whether moving
    private moveTime: number = 0;  //Move time
    public isEndFlag = false;  //Whether end click
    private frameJgSs: number = 0;  //Two frame interval seconds
    private liveMsgPoolList: Array<Node> = []; //Live message cache pool
    private windowSize: math.Size = null as unknown as math.Size;
    private moveLiveMsgList: Array<Node> = [];    //Move live message collection
    private gameTime: number = 0;  //Game duration
    private gameTimeAdd: number = 0;  //Game duration accumulation
    private currentSize:Size = new Size();
    private camera:Node = null;

    onEnable() {
        // 3v3 and 5v5 show loading screen
        if(BattleGlobal.playingMethod == Constant.PlayingMethod.ThreeVsThree || 
           BattleGlobal.playingMethod == Constant.PlayingMethod.FiveVsFive){     //3v3 or 5v5
            this.uiEnterGameLoad.open();
        }else if(BattleGlobal.playingMethod == Constant.PlayingMethod.OnlineBattle){     //Battle royale
            this.uiEnterGameLoad.close();
        }
        this.backUI.active = false;
        if(!Constant.isOnline){
            this.backUI.active = true;
        }
    }

    /**
     * Whether to open enter game loading page
     */
    public isOpenUIEnterGameLoad(): boolean {
        return this.uiEnterGameLoad.node.active;
    }


    start() {
        this.camera = BattleManager.Instance.camera;
        this.bossKillShowTipsLabel.node.active = false;
        this.windowSize = view.getCanvasSize();

        if (BattleGlobal.battleMode == BattleMode.Battle) {    //Battle mode
            // this.FenSiCountLabel.node.active = true;
            this.networkSprite.node.active = true;
            this.networkLabel.node.active = true;
            this.fpsLabel.node.active = true;
        } else if (BattleGlobal.battleMode == BattleMode.Live) {  //Watch live mode
            // this.FenSiCountLabel.node.active = false;
            this.networkSprite.node.active = false;
            this.networkLabel.node.active = false;
            this.fpsLabel.node.active = false;
        }

        for (let i = 0; i < this.controlActiveNodeArr.length; i++) {
            let node = this.controlActiveNodeArr[i] as Node;
            if (BattleGlobal.battleMode == BattleMode.Battle) {    //Battle mode
                node.active = true;
            } else if (BattleGlobal.battleMode == BattleMode.Live) {  //Watch live mode
                node.active = false;
            }
        }

        for (let i = 0; i < this.controlActiveNodeLiveArr.length; i++) {
            let node = this.controlActiveNodeLiveArr[i] as Node;
            if (BattleGlobal.battleMode == BattleMode.Battle) {    //Battle mode
                node.active = false;
            } else if (BattleGlobal.battleMode == BattleMode.Live) {  //Watch live mode
                node.active = true;
            }
        }


        input.on(Input.EventType.TOUCH_START, this.OnTouchStart, this);
        input.on(Input.EventType.TOUCH_MOVE, this.OnTouchMove, this);
        input.on(Input.EventType.TOUCH_END, this.OnTouchEnd, this);
        input.on(Input.EventType.TOUCH_CANCEL, this.OnTouchEnd, this);
        EventManager.Instance.addListener(EventType.OnUserInfoRes, this.OnUserInfoRes, this);
        EventManager.Instance.addListener(EventType.OnClickQuickMessage, this.OnChatClick, this);
        EventManager.Instance.addListener(EventType.OnMingLingMsg, this.OnMingLingMsg, this);


        //Our messages and follower messages
        this.ChatUI.active = false;
        this.LiveChatUI.active = false;
        this.chatBtnSprite.node.on(Input.EventType.TOUCH_END, this.OnChatClick, this);
        this.chatBtnDefaultSpriteFrame = this.chatBtnSprite.spriteFrame;  //Chat button default image

        //Update our last message
        EventManager.Instance.addListener(EventType.OnChat_UI, this.OnChat_UI, this);
        this.updateMyChatLastRichText();

        //Reward data
        EventManager.Instance.addListener(EventType.OnAchievementStrChange, this.OnAchievementStrChange, this);

        EventManager.Instance.addListener(EventType.OnOutLiveRes2, this.OnOutLiveRes2, this)
        let this_ = this;
        // setInterval(function(){
        //     this_.ShowGonGaoContent(['Kirin appears!'])
        // },10000)

        this.currentSize = view.getVisibleSize();
    }

    /**
     * Show boss kill tips
     * @param tips Tips
     */
    public ShowKillBossTips(tips:string){
      this.bossKillShowTipsLabel.string = tips;
      this.bossKillShowTipsLabel.node.active = true;  
      let this_ = this;
      setTimeout(function(){
        this_.bossKillShowTipsLabel.node.active = false;  
      }, 5000)
    }

    /**
     * Show kill tips
     * @param killCreature Killer
     * @param KilledCreature Killed
     */
    public ShowKillTips(killCreature: Creature, KilledCreature: Creature) {
        // console.log('ShowKillTips===========')
        //Show killer and killed popup
        NodeTipsManager.Instance.openNodeTips(this.uiKillTips.node, 2500, WindosAni.None, WindosAni.None, this.uiKillTips, [killCreature.entityId, KilledCreature.entityId, killCreature.lianXuRenTou, KilledCreature.lianXuRenTou]);
    }

    /**
     * Reward changed
     * @param param 
     */
    private OnAchievementStrChange(param: any) {
        // console.log('OnAchievementStrChange', param)
        // NodeTipsManager.Instance.openNodeTips(this.achievementStrUILabelSetData.node, 3000, WindosAni.None, WindosAni.None, this.achievementStrUILabelSetData, param);
    }

    /**
     * Show announcement information
     * @param content Content
     */
    public ShowGonGaoContent(content: any) {
        NodeTipsManager.Instance.openNodeTips(this.gongGaoUILabelSetData.node, 2000, WindosAni.flicker, WindosAni.None, this.gongGaoUILabelSetData, [content]);
    }

    /**
     * Message received update
     * @param param 
     */
    private OnChat_UI(param: any) {
        let channel = param[0] as proto.BattleMessage.ChatChannel;
        if (channel == proto.BattleMessage.ChatChannel.RoomChat) {  //Room
            this.updateMyChatLastRichText();
            this.updateLiveChatLastMsg();
        }
    }

    /**
     * Update our last message
     */
    private updateMyChatLastRichText() {
        let len = ChatManager.Instance.gameMessages.length;
        if (len > 0) {
            let start = len < 5 ? 0 : len - 5;
            let msg = '';
            for (let i = start; i < len; i++) {
                let chatMessage = ChatManager.Instance.gameMessages[i];
                msg += BattleGlobal.getBattleMsgContent(chatMessage, -1, 0) + '\n';
            }
            this.myChatLastRichText.string = msg;
        }
    }

    /**
     * Update live last message
     */
    private updateLiveChatLastMsg() {
        let len = ChatManager.Instance.liveMessages.length;
        if (len > 0) {
            let chatMessage = ChatManager.Instance.liveMessages[len - 1];
            let liveMsgStr = BattleGlobal.getBattleMsgContent(chatMessage, 50, 1);
            let node: Node = null;
            if (this.liveMsgPoolList.length > 0) {
                node = this.liveMsgPoolList.shift()
                console.log('Cache get, remaining len=' + this.liveMsgPoolList.length)
            } else {
                node = instantiate(this.uiLiveMsg)
            }
            //Set content
            let uiLiveMsg = node.getComponent(UILiveMsg);
            uiLiveMsg.Text = liveMsgStr;
            let heightRange = this.windowSize.height / 2 - 30;  //Height positive and negative range random
            uiLiveMsg.richText.node.setPosition(this.windowSize.width / 2, RandomUtil.limit2(0, heightRange), 0);
            console.log('Live message pos=' + uiLiveMsg.richText.node.position)
            director.getScene()?.addChild(node);
            this.moveLiveMsgList.push(node);
        }
    }

    /**
     * Click chat
     */
    private OnChatClick() {
        if (BattleGlobal.battleMode == BattleMode.Battle) {    //Battle mode
            this.ChatUI.active = !this.ChatUI.active;
            this.chatBtnSprite.spriteFrame = this.ChatUI.active ? this.chatBtnCloseSpriteFrame : this.chatBtnDefaultSpriteFrame;
        } else if (BattleGlobal.battleMode == BattleMode.Live) {  //Watch live mode
            this.LiveChatUI.active = !this.LiveChatUI.active;
        }
    }

    /**
     * Update ping
     * @param pingTime 
     */
    public updatePingTime(pingTime: number) {
        this.networkLabel.string = pingTime + 'ms';
        //Set icon
        let index = 0;
        if (pingTime < 80) {
            index = 5;
        } else if (pingTime >= 80 && pingTime < 90) {
            index = 4;
        } else if (pingTime >= 90 && pingTime < 100) {
            index = 3;
        } else if (pingTime >= 100 && pingTime < 110) {
            index = 2;
        } else if (pingTime >= 110 && pingTime < 120) {
            index = 1;
        } else if (pingTime >= 120) {
            index = 0;
        }
        this.networkSprite.spriteFrame = this.networkSpriteFrameArr[index];
        // console.log('ping=' + pingTime)
    }

    /**
     * Update FPS
     */
    private updateFrameTime() {
        let frameJgMs = this.frameJgSs * 1000;
        let fps = Math.floor(1000 / frameJgMs);
        fps = fps > 60 ? 60 : fps;
        this.fpsLabel.string = 'FPS:' + fps;
        // console.log('Frame rate two frame interval milliseconds='+frameJgMs)
    }

    /**
     * User info response
     */
    private OnUserInfoRes(param: any) {
        let response = param[0];
        // this.FenSiCountLabel.string = 'Viewer count:' + (response.liveFenSiCount || 0);
    }
    private touchTempVec2 = new Vec2();
    private newCameraWorldPosition:Vec3 = new Vec3();

    /**
     * Touch start
     */
    private OnTouchStart(e) {
        if(BattleGlobal.isTouchSkillBtnFlag || BattleGlobal.isGameEndFlag){
            return;
        }
        e.getUIStartLocation(this.touchTempVec2);  //Start move point
        if (this.touchTempVec2.x < this.currentSize.width * 0.5) {  //Screen left 50% swipe invalid
            return;
        }
        this.startMoveVec2.set(this.touchTempVec2.x, this.touchTempVec2.y);
        this.camera.getWorldPosition(this.newCameraWorldPosition);
        this.isEndFlag = false;
    }

    /**
     * Touch move
     */
    private OnTouchMove(e) {
        if(BattleGlobal.isTouchSkillBtnFlag || BattleGlobal.isGameEndFlag || this.isEndFlag){
            return;
        }
        // if (BattleGlobal.battleMode != BattleMode.Live) {  //Non-watch live mode
        //     return;
        // }
        e.getUIStartLocation(this.touchTempVec2);  

        if (this.touchTempVec2.x < this.currentSize.width * 0.5) {  //Screen left 50% swipe invalid
            return;
        }
        // this.currentMoveVec2.set(this.touchTempVec2.x, this.touchTempVec2.y);
        e.getUILocation(this.currentMoveVec2);   //Current move point

        //Control button move position
        let len=MathUtil.GetDistance(this.startMoveVec2.x, this.startMoveVec2.y, this.currentMoveVec2.x, this.currentMoveVec2.y);
        if (len <= 4) {  //No movement
            return;
        }
        this.isMoveFlag = true;  //Moved
        this.isEndFlag = false;
        BattleManager.Instance.isLookAtCharacterFlag = false;

        this.moveTime = new Date().getTime();
        
        let angle = Math.round(MathUtil.GetAngle(this.currentMoveVec2.y - this.startMoveVec2.y, this.currentMoveVec2.x - this.startMoveVec2.x));
        let teamType2 = BattleManager.Instance.currentCharacter.teamType2;
        angle = BattleGlobal.AngleHandle(-angle); 
        let rockerSpeedVo = DataManager.Instance.rockerSpeeds[angle];
        if (!rockerSpeedVo) {
          console.log('rockerSpeedVo does not exist!' + '===' + angle)
          return;
        }
        let cameraPos = this.newCameraWorldPosition;
        let speed: number = 4;
        let vx = cameraPos.x + ((teamType2 == TeamType2.Blue ? -1 : -1) * (rockerSpeedVo.x * 0.001) * speed);
        let vz = cameraPos.z + ((teamType2 == TeamType2.Blue ? -1 : -1) * (rockerSpeedVo.y * 0.001) * speed);
        // camera.setWorldPosition(vx, cameraPos.y, vz);
        this.newCameraWorldPosition.set(vx, cameraPos.y, vz);

        this.startMoveVec2.set(this.currentMoveVec2.x, this.currentMoveVec2.y);

        UIMinimapManager.Instance.moveCameraUpdateKuangPos(this.camera);  //Update minimap frame
    }

    /**
     * Touch end
     */
    private OnTouchEnd(e) {
        if(BattleGlobal.isTouchSkillBtnFlag || BattleGlobal.isGameEndFlag){
            return;
        }
        e.getUIStartLocation(this.touchTempVec2);  
        if (this.touchTempVec2.x < this.currentSize.width * 0.5) {  //Screen left 50% swipe invalid
            return;
        }
        this.isEndFlag = true;
        UIMinimapManager.Instance.hideKuang();  //Hide frame
    }
    private updateIndex: number = 0;   //Control update frequency
    private cameraPosTemp:Vec3 = new Vec3();
    // Cache last displayed values to avoid redundant label.string updates (reduces measureText/fillText/texSubimage2D)
    private _lastJiSha: string = '';
    private _lastSiWang: string = '';
    private _lastZhuGong: string = '';
    private _lastBlueScore: string = '';
    private _lastRedScore: string = '';
    private _lastLogStr: string = '';
    private _lastGameTimeStr: string = '';
    private _lastFpsStr: string = '';
    update(dt: number) {
        if(!BattleManager.Instance){
            return;
        }
        let currentCharacter = BattleManager.Instance.currentCharacter;
        if (!currentCharacter) {
            return;
        }
        this.frameJgSs = dt;
        this.updateIndex++;
        if (this.updateIndex % 10 == 0) {
            const jiSha = currentCharacter.renTou + '';
            const siWang = currentCharacter.zhenWang + '';
            const zhuGong = currentCharacter.zhuGong + '';
            const blueScore = BattleGlobal.BlueScore + '';
            const redScore = BattleGlobal.RedScore + '';
            const logStr = BattleGlobal.logStr;
            const gameTimeStr = DateUtil.convertSecondsToMS(BattleData.newFrameId * NetConfig.frameTime / 1000);

            if (jiSha !== this._lastJiSha) { this.jiShaCountLabel.string = jiSha; this._lastJiSha = jiSha; }
            if (siWang !== this._lastSiWang) { this.siWangCountLabel.string = siWang; this._lastSiWang = siWang; }
            if (zhuGong !== this._lastZhuGong) { this.zhuGongCountLabel.string = zhuGong; this._lastZhuGong = zhuGong; }
            if (blueScore !== this._lastBlueScore) { this.blueBiFenLabel.string = blueScore; this._lastBlueScore = blueScore; }
            if (redScore !== this._lastRedScore) { this.redBiFenLabel.string = redScore; this._lastRedScore = redScore; }
            if (logStr !== this._lastLogStr) { this.logLabel.string = logStr; this._lastLogStr = logStr; }
            if (gameTimeStr !== this._lastGameTimeStr) { this.gameTimeLable.string = gameTimeStr; this._lastGameTimeStr = gameTimeStr; }
        }
        if (this.updateIndex % 60 == 0) {
            const fps = Math.floor(1000 / (this.frameJgSs * 1000));
            const fpsStr = 'FPS:' + (fps > 60 ? 60 : fps);
            if (fpsStr !== this._lastFpsStr) {
                this._lastFpsStr = fpsStr;
                this.fpsLabel.string = fpsStr;
            }
        }
        // this.handleFrameLabel.string = 'Frame count:' + BattleData.handleFrameId;

        // this.gameTimeAdd += dt;
        // let seconds = this.gameTimeAdd % 1000;
        // if (seconds >= 1) {
        //     this.gameTime += seconds;
        //     this.gameTimeLable.string = DateUtil.convertSecondsToMS(this.gameTime);
        //     this.gameTimeAdd = 0
        // }

        
        
        
        if(this.isMoveFlag){
            //Camera end movement
          if (currentCharacter.IsDeath || this.isEndFlag) {            
            this.isEndFlag = false;
            this.isMoveFlag = false;
            BattleManager.Instance.isLookAtCharacterFlag = true;
            UIMinimapManager.Instance.hideKuang();  //Hide frame
          }else{
            this.camera.getWorldPosition(this.cameraPosTemp);
            this.cameraPosTemp.lerp(this.newCameraWorldPosition, 0.1)
            this.camera.setWorldPosition(this.cameraPosTemp);
          }
        }

        //Move live messages
        if (this.moveLiveMsgList.length > 0) {
            for (let i = 0; i < this.moveLiveMsgList.length; i++) {
                let node = this.moveLiveMsgList[i];
                let richTextNode = node.getComponent(UILiveMsg).richText.node;
                let richTextWidth = richTextNode.getComponent(UITransform).contentSize.width;  //Text width

                let pos = richTextNode.position;
                let x = pos.x - 1;
                richTextNode.setPosition(x, pos.y, pos.z);
                if (x < -(this.windowSize.width / 2) - richTextWidth) {  //Out of screen
                    console.log('Out of screen remove, text width=' + richTextWidth)
                    director.getScene()?.removeChild(node);
                    this.liveMsgPoolList.push(node);  //Recycle object pool
                    this.moveLiveMsgList.splice(i, 1);
                }
            }
        }
    }


    onDestroy() {
      EventManager.Instance.removeAll(this);
      input.off(Input.EventType.TOUCH_START, this.OnTouchStart, this);
      input.off(Input.EventType.TOUCH_MOVE, this.OnTouchMove, this);
      input.off(Input.EventType.TOUCH_END, this.OnTouchEnd, this);
      input.off(Input.EventType.TOUCH_CANCEL, this.OnTouchEnd, this);
    }


    /**
     * Print result
     */
    public OnClickPrintResult() {
        let allFrameHandlesStr = LocalStorageUtil.GetItem(LocalStorageUtil.allFrameHandlesKey + User.Instance.user.id);
        console.log(allFrameHandlesStr)
        // let characterList = CharacterManager.Instance.characterList;
        // for(let i=0; i < characterList.length; i++){
        //     let c = characterList[i];
        //     c.attributes.printTest();
        // }
    }

    /**
     * Click more
     */
    public async OnClickMore() {
        console.log('OnClickMore')
        BattleManager.Instance.LookBattleTeamInfo(1);
    }

    /**
     * Click exit
     */
    public async OnClickBack() {
        console.log('OnClickBack')
        if (BattleGlobal.battleMode == BattleMode.Battle) {    //Battle mode
          // 3v3 and 5v5 use same exit logic
          if(BattleGlobal.playingMethod == Constant.PlayingMethod.ThreeVsThree || 
             BattleGlobal.playingMethod == Constant.PlayingMethod.FiveVsFive){     //3v3 or 5v5
            //Below is battle exit test code
            let currentCharacter = BattleManager.Instance.currentCharacter;
            let blueGameIsVictory:boolean = currentCharacter.teamType2 != TeamType2.Blue;
            BattleData.frameHandle.opt=OptType.handGameOver;
            BattleData.frameHandle.optValue1 = User.Instance.user.id;
            BattleData.frameHandle.optValue2 = blueGameIsVictory ? TeamType2.Blue : TeamType2.Red;
          }else if(BattleGlobal.playingMethod == Constant.PlayingMethod.OnlineBattle){     //Battle royale
            LocalStorageUtil.RemoveItem(LocalStorageUtil.allFrameHandlesKey + User.Instance.user.id);
            LocalStorageUtil.RemoveItem(LocalStorageUtil.stateRecordKey + User.Instance.user.id);
            LocalStorageUtil.RemoveItem(LocalStorageUtil.matchRandomSeedKey + User.Instance.user.id);  // RISK 5: clear match seed
            director.loadScene('UIMain');
          }            
        } else if (BattleGlobal.battleMode == BattleMode.Live) {  //Watch live mode, catch up frames
            BattleService.Instance.SendOutLive();
        }
    }
    /**
     * Exit live response
     * @param param 
     */
    private OnOutLiveRes2(param: any) {
        let response = param[0];
        LogUtil.log("OnOutLiveRes2", response);
        director.loadScene('UIMain');
    }

    /**
     * Click command shortcut icon
     */
    private OnMingLingQuickClick() {
        this.mingLingUI.active = !this.mingLingUI.active;
    }


    /**
     * Click command button
     */
    private OnMingLingBtnClick(param: any, customEventData: any) {
        console.log(customEventData)
        this.mingLingUI.active = false;
        if (customEventData == 5) {  //Close
            return;
        }
        BattleService.Instance.SendMingLing(customEventData, 0);
    }

    /**
     * Response command message
     */
    private OnMingLingMsg(param: any) {
        console.log('OnMingLingMsg', param)
        let fromId = param[0];
        let msg = param[1];
        let msgArr = msg.split(',') as Array<string>;
        // console.log('AddMessages msgArr=', msgArr)
        let mingLing: string = '';
        let userIdStr: string = '';
        if (msgArr.length > 0) {
            mingLing = msgArr[0].replace('[mingling]', '');
        }
        if (msgArr.length > 1) {
            userIdStr = msgArr[1];
        }
        // console.log('mingLing=' + mingLing + ',userIdStr=' + userIdStr)
        if (userIdStr && userIdStr != '0') {  //Received good response
            console.log('OnMingLingMsg========' + userIdStr)
            let flag = this.uiMingLingTips.addHaoDeUserId(parseInt(mingLing), parseInt(userIdStr));
            if (flag) {  //Add success update survival time
                NodeTipsManager.Instance.ResetSurvivalTime();
            }
        } else {
            console.log('OnMingLingMsg========2222222')
            NodeTipsManager.Instance.openNodeTips(this.uiMingLingTips.node, 2000, WindosAni.None, WindosAni.None, this.uiMingLingTips, [fromId, mingLing]);
        }
    }


    /**
     * Click blood loss test
     */
    public OnShedBloodClick() {
        BattleData.frameHandle.opt = OptType.ShedBlood;
        BattleData.frameHandle.optValue1 = 50;
    }

    /**
     * Click head revive test
     */
    public OnResuClick() {
        BattleData.frameHandle.opt = OptType.ResuRenTou;
    }

    /**
     * Skill data setting test
     */
    public OnSkillDataSetTest() {
        this.uiSkillDataSet.show();
    }

     /**
     * Click instant revive
     */
    public OnLjResuClick() {
        let currentCharacter = BattleManager.Instance.currentCharacter;
        console.log('OnLjResuClick resuCount='+currentCharacter.resuCoinCount)
        if(currentCharacter.resuCoinCount > 0){
            BattleData.frameHandle.opt = OptType.LjResu;
        }else{
            TipsManager.Instance.showTips("You don't have revive coins!");
        }
    }


}
