
import { _decorator, Component, Node, Label, tween, Vec3, CCFloat, UITransform, view, CameraComponent } from 'cc';
import { PopupType } from './enums/PopupType';
import { RandomUtil } from './Utils/RandomUtil';
import { BattleManager } from './Managers/BattleManager';
import { UIWorldElementManager } from './UIWorldElementManager';
import { Creature } from './Enities/Creature';
import { BattleGlobal } from './Utils/BattleGlobal';
const { ccclass, property } = _decorator;


@ccclass('UIPopupText')
export class UIPopupText extends Component {

    @property(Label)
    public normalDamageText: Label = null;
    @property(Label)
    public critDamageText: Label = null;
    @property(Label)
    public healText: Label = null;
    @property(Label)
    public effectTipsText: Label = null;
    @property(Label)
    public hitText: Label = null;
    @property(Label)
    public critHitText: Label = null;

    // @property(Label)
    // public buffDamageText:Label=null;
    @property(CCFloat)
    public floatTime: number = 0.5;
    @property(CameraComponent)
    private cameraComponent: CameraComponent;

    private _tweenTip: any = null;// Tween instance
    private _costTime: number = 1.5;// Tween required time
    private _isChangePos: boolean = false;// Whether change position
    private _targetPos: Vec3 = new Vec3(0, 0, 0);// Target position
    private _oriWorPos: Vec3 = new Vec3();// Initial position
    private _curWorPos: Vec3 = new Vec3();// Current position
    private _oriScale: Vec3 = new Vec3(0.7, 0.7, 0.7);// Initial scale
    private _scale_1: Vec3 = new Vec3(1, 1, 1);// Start scale
    private _scale_2: Vec3 = new Vec3();// Final scale
    
    private owner: Creature = null;
    private caster: Creature = null;
    private popupOffset : Vec3 = new Vec3();  // Font offset
    private popup2Offset : Vec3 = new Vec3();  // Font offset
    private type: PopupType = PopupType.None;
    private ownerParent:Node = null; 
    private isFollowOwner:boolean = false;  // Whether follow owner
    public height:number = 0;

    private normalDamageTransform: UITransform | null = null;
    private critDamageTransform: UITransform | null = null;
    private healTransform: UITransform | null = null;
    private effectTipsTransform: UITransform | null = null;
    private hitTransform: UITransform | null = null;
    private critHitTransform: UITransform | null = null;

    private children: Node[] = [];

    private static viewportRect = view.getViewportRect();
    private static lastViewportUpdate = 0;
    private static readonly VIEWPORT_UPDATE_INTERVAL = 1000;

    private static updateViewportRect(): void {
        const now = Date.now();
        if (now - UIPopupText.lastViewportUpdate > UIPopupText.VIEWPORT_UPDATE_INTERVAL) {
            UIPopupText.viewportRect = view.getViewportRect();
            UIPopupText.lastViewportUpdate = now;
        }
    }

    onLoad() {
        this.cacheComponents();
        this.children = this.node.children;
    }

    private cacheComponents(): void {
        if (this.normalDamageText) {
            this.normalDamageTransform = this.normalDamageText.getComponent(UITransform);
        }
        if (this.critDamageText) {
            this.critDamageTransform = this.critDamageText.getComponent(UITransform);
        }
        if (this.healText) {
            this.healTransform = this.healText.getComponent(UITransform);
        }
        if (this.effectTipsText) {
            this.effectTipsTransform = this.effectTipsText.getComponent(UITransform);
        }
        if (this.hitText) {
            this.hitTransform = this.hitText.getComponent(UITransform);
        }
        if (this.critHitText) {
            this.critHitTransform = this.critHitText.getComponent(UITransform);
        }
    }

    public InitPopup(type: PopupType, text: string, isCrit: boolean, owner: Creature, costTime:number=1.5, caster?: Creature): void {
        this._isChangePos = false;
        this.isFollowOwner = false;
        this.type = type;
        this.owner = owner;
        this.caster = caster;
        this._costTime = costTime;
        this.ownerParent = this.owner.node.parent;
        this.popupOffset.set(this.owner.GetPopupOffset());
        this.popup2Offset.set(this.owner.GetPopup2Offset());

        const children = this.children;
        const len = children.length;
        for (let i = 0; i < len; i++) {
            children[i].active = false;
        }

        let labelTransform: UITransform | null = null;
        if (type == PopupType.Damage) {
            this.normalDamageText.string = text;
            this.critDamageText.string = text;
            if (isCrit) {
                type = PopupType.Crit;
                this.critDamageText.node.active = true;
                labelTransform = this.critDamageTransform;
                this._oriWorPos.set(this.popupOffset).add(this.ownerParent.worldPosition);
            } else {
                this.normalDamageText.node.active = true;
                labelTransform = this.normalDamageTransform;
                this._oriWorPos.set(this.popup2Offset).add(this.ownerParent.worldPosition);
            }
        } else if (type == PopupType.Hit) {
            this.hitText.string = text;
            this.critHitText.string = text;
            if (isCrit) {
                type = PopupType.Crit;
                this.critHitText.node.active = true;
                labelTransform = this.critHitTransform;
                this._oriWorPos.set(this.popup2Offset).add(this.ownerParent.worldPosition);
            } else {
                this.hitText.node.active = true;
                labelTransform = this.hitTransform;
                this._oriWorPos.set(0, 0, 0).add(this.ownerParent.worldPosition);
            }
        } else if (type == PopupType.Heal) {
            this.healText.string = text;
            this.healText.node.active = true;
            labelTransform = this.healTransform;
            this._oriWorPos.set(this.popupOffset);
            this.isFollowOwner = true;
        } else if (type == PopupType.EffectTips) {
            this.effectTipsText.string = text;
            this.effectTipsText.node.active = true;
            labelTransform = this.effectTipsTransform;
            this._oriWorPos.set(0, this.owner.characterDefine.Height + 0.5, 0);
            this.isFollowOwner = true;
        }

        this.height = this._oriWorPos.y;
        if (!labelTransform) {
            return;
        }

        this._closeTweenTip();
        this.node.setScale(this._oriScale);

        const pos = this.node.getPosition();
        const width = labelTransform?.width ?? 0;
        const height = labelTransform?.height ?? 0;

        UIPopupText.updateViewportRect();
        const rect = UIPopupText.viewportRect;
        const halfWidth = width * 0.5;
        const halfHeight = height * 0.5;
        const rectHalfWidth = rect.width * 0.5;
        const rectHalfHeight = rect.height * 0.5;

        if ((Math.abs(pos.x) + halfWidth) > rectHalfWidth) {
            const w = rectHalfWidth - halfWidth;
            pos.x = pos.x > 0 ? w : -w;
        }

        if ((Math.abs(pos.y) + halfHeight) > rectHalfHeight) {
            const h = rectHalfHeight - halfHeight;
            pos.y = pos.y > 0 ? h : -h;
        }
        this.node.setPosition(pos);

        this.getTargetPos(type);

        this._isChangePos = true;
        this.startTween(type);
    }

    private startTween(type: PopupType): void {
        if (type == PopupType.Crit) {
            this._tweenTip = tween(this.node)
                .to(this._costTime * 0.4, { scale: this._scale_1 }, { easing: 'smooth' })
                .delay(0.5)
                .to(this._costTime * 0.4, { scale: this._scale_2 })
                .call(() => this.complete())
                .start();
        } else if (type == PopupType.Damage || type == PopupType.Hit) {
            this._tweenTip = tween(this.node)
                .to(this._costTime * 0.4, { scale: this._scale_1 }, { easing: 'smooth' })
                .to(this._costTime * 0.4, { scale: this._scale_2 }, { easing: "smooth" })
                .call(() => this.complete())
                .start();
        } else if (type == PopupType.Heal) {
            this._tweenTip = tween(this.node)
                .to(this._costTime * 0.3, { scale: this._scale_1 }, { easing: 'smooth' })
                .to(this._costTime * 0.3, { scale: this._scale_1 }, { easing: "smooth" })
                .call(() => this.complete())
                .start();
        } else if (type == PopupType.EffectTips) {
            this.node.setScale(this._scale_1.x, this._scale_1.y, this._scale_1.z);
            this._tweenTip = tween(this.node)
                .delay(this._costTime)
                .to(0, { scale: this._scale_2 }, { easing: "backIn" })
                .call(() => this.complete())
                .start();
        }
    }

    /**
     * Complete
     */
    private complete(){
        this._closeTweenTip();
        this._isChangePos = false;
        UIWorldElementManager.Instance.RemovePopupText(this);  // Remove popup text
    }

    /**
    * Get HP target position
    */
    private getTargetPos(type: PopupType) {
        const ownerHeight = this.owner.characterDefine.Height;
        const ownerWorldPos = this.ownerParent.worldPosition;

        if (type == PopupType.Crit) {
            const creature = this.caster || BattleManager.Instance.currentCharacter;
            const nor = creature.node.parent.forward.normalize();
            this._targetPos.set(-nor.x, ownerHeight, -nor.z);
            this._targetPos.add(ownerWorldPos);

        } else if (type == PopupType.Damage) {
            const currentCharacter = BattleManager.Instance.currentCharacter;
            const nor = currentCharacter.node.parent.forward.normalize();
            const disperse = RandomUtil.limit2(-0.8, 1.5);
            this._targetPos.set(-nor.x + disperse, ownerHeight * 1.8, -nor.z + disperse);
            this._targetPos.add(ownerWorldPos);

        } else if (type == PopupType.Hit) {
            if (!this.caster) {
                return;
            }
            const nor = this.caster.node.parent.forward.normalize();
            const disperse = RandomUtil.limit2(-0.7, -0.3);
            this._targetPos.set(-nor.x + disperse, ownerHeight * 0.7, -nor.z + disperse);
            this._targetPos.add(ownerWorldPos);

        } else if (type == PopupType.Heal) {
            this._targetPos.set(0, ownerHeight + 0.5, 0);

        } else if (type == PopupType.EffectTips) {
            this._targetPos.set(0, ownerHeight + 0.5, 0);
        }
    }

    private _closeTweenTip() {
        if (this._tweenTip) {
            this._tweenTip.stop();
            this._tweenTip = null;
        }
    }

    private newWorPos: Vec3 = new Vec3();

    onDisable() {
        this._closeTweenTip();
        this._isChangePos = false;
    }

    lateUpdate(deltaTime: number) {
        if (!this._isChangePos) return;

        this._oriWorPos.lerp(this._targetPos, BattleGlobal.piaoZiChaZhi);
        if (this.isFollowOwner) {
            Vec3.add(this.newWorPos, this._oriWorPos, this.ownerParent.worldPosition);
            this.cameraComponent?.convertToUINode(this.newWorPos, this.node.parent, this._curWorPos);
            this.node.setPosition(this._curWorPos);
        } else {
            this.cameraComponent?.convertToUINode(this._oriWorPos, this.node.parent, this._curWorPos);
            this.node.setPosition(this._curWorPos);
        }
    }
}
 
