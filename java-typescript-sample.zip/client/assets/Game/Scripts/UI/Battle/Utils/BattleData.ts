import { BattleService } from "../../../Services/BattleService";
import { OptType } from "../enums/OptType";
import proto from '../../../../Proto/proto.js';
import { HandlerFrameResult } from "../enums/HandlerFrameResult";
import { LocalStorageUtil } from "../../../Utils/LocalStorageUtil";
import { User } from "../../../Models/User";
import { BattleManager } from "../Managers/BattleManager";
import { AniState } from "../enums/AniState";
import { Creature } from "../Enities/Creature";
import { DataManager } from "../../../Managers/DataManager";
import { TeamType2 } from "../enums/TeamType2";
import { BattleContext } from "../Models/BattleContext";
import { TargetType } from "../enums/TargetType";
import { CharacterManager } from "../Managers/CharacterManager";
import { BattleGlobal } from "./BattleGlobal";
import { BuffEffect } from "../enums/BuffEffect";
import { CreatureManager } from "../Managers/CreatureManager";
import { SkillResult } from "../enums/SkillResult";
import { SkillType } from "../enums/SkillType";
import { NetConfig } from "../../../Network/NetConfig";
import { NetClientBattle } from "../../../Network/Battle/NetClientBattle";
import { MathUtil } from "../../../Utils/MathUtil";
import { BattleMode } from "../enums/BattleMode";
import { TipsManager } from "../../TipsManager";
import { Util } from "../../../Utils/Util";
import { StateHandleManager } from "../StateRecord/StateHandleManager";
import { StateData } from "../StateRecord/StateData";
import { HashMap } from "../../../../../Scripts/Utils/HashMap";
import { Constant } from "../../../../../Scripts/Utils/Constant";
import { LogicRenderConvert } from "./LogicRenderConvert";
import { RandomUtil } from "./RandomUtil";

export class BattleData {

    //key: frame id  value: player operation map
    public static allFrameHandles: HashMap = new HashMap();   // Server authenticated all frame operations
    //key: frame id  value: player operation collection
    public static clientPredictionFrameHandles: HashMap = new HashMap();   // Client prediction frame operations

    private static repairWaitTime: number = NetConfig.frameTime;  // Frame repair wait milliseconds
    private static currentRepairTime: number = 0;  // Current frame repair execution milliseconds

    public static frameHandle = new proto.BattleMessage.FrameHandle();  // Player frame operation object
    public static handleFrameId: number = -1;  // Already processed frame
    public static executeFrameId: number = -1;  // Already executed frame
    // private static liveNotExecuteFrameCount:number = 0;  // Live stream unexecuted frame count
    public static newFrameId: number = -1;  // Latest frame
    // private static sendFrameId: number = -1;   // Current sending frame id
    public static isReceiveServerFrame: boolean = false;  // Whether received server frame
    public static redundantFrameCount:number = 0;  // Redundant frame count
    public static predictionExecuteFrameId: number = -1;  // Pre-performance already executed frame

    /** Number of past frames to keep for repair purposes (~30 seconds) */
    private static readonly PRUNE_WINDOW = 600;
    /** How often to run pruning (every N executed frames) */
    private static readonly PRUNE_INTERVAL = 200;

    public static init(skipClearFrames: boolean = false) {
        this.isReceiveServerFrame = false;
        this.newFrameId = -1;
        this.executeFrameId = -1;
        this.handleFrameId = -1;
        this.predictionExecuteFrameId = -1;
        if (!skipClearFrames) {
            this.allFrameHandles.clear();   // Clear all frames
        }
        this.clientPredictionFrameHandles.clear();
    }

    /**
     * Prune old frame data to prevent unbounded memory growth (RISK 6).
     * Keeps the last PRUNE_WINDOW frames (default 600 = 30 seconds at 20fps)
     * for frame repair purposes.  Should be called periodically from
     * OnHandlerFrame.
     */
    public static pruneOldFrames(): void {
        const cutoff = this.executeFrameId - this.PRUNE_WINDOW;
        if (cutoff <= 0) return;

        const keys = this.allFrameHandles.keys();
        let pruned = 0;
        for (let i = 0; i < keys.length; i++) {
            const frameId = Number(keys[i]);
            if (frameId < cutoff) {
                this.allFrameHandles.remove(keys[i]);
                pruned++;
            }
        }

        // Also prune old prediction frames
        const predKeys = this.clientPredictionFrameHandles.keys();
        for (let i = 0; i < predKeys.length; i++) {
            const frameId = Number(predKeys[i]);
            if (frameId < cutoff) {
                this.clientPredictionFrameHandles.remove(predKeys[i]);
            }
        }

        if (pruned > 0) {
            console.log('[BattleData] Pruned ' + pruned + ' old frames (cutoff=' + cutoff + ', remaining=' + this.allFrameHandles.length + ')');
        }
    }

    /**
     * Check if pruning should run this frame.
     */
    public static shouldPrune(frameId: number): boolean {
        return frameId > 0 && frameId % this.PRUNE_INTERVAL === 0;
    }

    /**
     * Restore frame data
     */
    public static recoverFrameData() {
        let allFrameHandlesStr = LocalStorageUtil.GetItem(LocalStorageUtil.allFrameHandlesKey + User.Instance.user.id);
        if (allFrameHandlesStr) {  // Restore progress
            console.log('Restore progress cached frame data')
            BattleData.allFrameHandles.data = JSON.parse(allFrameHandlesStr).map || {};
        }
        if(BattleGlobal.isStandaloneFlag){  // Standalone mode
           this.newFrameId = 0;
           let keys = BattleData.allFrameHandles.keys();
           if(keys){
            let maxKey:number = 0;
            for(let key of keys){
              let k = Number(key);
              if(k > maxKey){
                maxKey = k;
              }
            }
            this.newFrameId = maxKey;
           }
        }
    }

    /**
     * Frame repair response
     */
    public static OnRepairFrame(param: any): void {
        let response = param as proto.BattleMessage.RepairFrameResponse;
        let len = response.repairFrames.length;
        for (let i = 0; i < len; i++) {
            let repairFrame = response.repairFrames[i];
            BattleData.allFrameHandles.put(repairFrame.frame, repairFrame.userFrameHandleMap || {});
        }
    }

    /**
     * Get frame repair end frame
     * @param startFrameId Start frame
     * @returns End frame ID for repair request (includes ALL gaps, not just first)
     */
     private static GetEndFrameId(startFrameId: number): number {
        // Request all frames up to newFrameId to cover all gaps
        // Server will only send missing frames anyway
        return this.newFrameId;
    }

    /**
    * Frame operation response
    */
    public static OnFrameHandle(param: any) {
        let response = param as proto.BattleMessage.FrameHandleResponse;
        let frameId = response.frame;
        // if(frameId % 10 == 0){
        //     console.log('OnFrameHandle frameId='+frameId)
        // }
        if (this.newFrameId < frameId) {
            this.newFrameId = frameId;
        }

        this.isReceiveServerFrame = true;

        // Already processed frames
        if (frameId <= this.handleFrameId) {
            return;
        }
        this.allFrameHandles.put(frameId, response.userFrameHandleMap || {}); // Save received frames

    }

    /**
     * Game progress recovery validation
     */
    private static GameProgressRecoveryValidate(){
        if (BattleGlobal.isGameEndFlag) {  // Game ended
            BattleManager.Instance.uiGameProgressRecovery.hide();
            return;
        }
       
        let cha = this.newFrameId - this.handleFrameId;
        if (cha > 30) {
            BattleManager.Instance.uiGameProgressRecovery.show();
            
            // console.log('GameProgressRecoveryValidate newFrameId='+this.newFrameId+'，handleFrameId='+this.handleFrameId+'，executeFrameId='+this.executeFrameId
            //     +', predictionExecuteFrameId='+this.predictionExecuteFrameId+', no frame data='+(!BattleData.getFrameData(this.handleFrameId + 1))
            // )
        } else {
            BattleManager.Instance.uiGameProgressRecovery.hide();
        }
        
    }

    /**
     * Frame repair validation
     * @param handlerFrameResult 
     * @return  Whether frame repair occurred
     */
    public static RepairFrameRequest(handlerFrameResult: HandlerFrameResult, waitTime: number): boolean {
        if(BattleGlobal.isStandaloneFlag){  // Exit if standalone mode
            return false;
        }
        if (handlerFrameResult == HandlerFrameResult.NoFrameData) {  // Frame dropped
            // let gapFrameCount = BattleData.newFrameId - BattleData.executeFrameId;  // Gap frame count
            if (this.currentRepairTime <= 0) {
                // if(gapFrameCount > 1){    
                // Frame repair request - request ALL missing frames up to newFrameId
                let start = this.handleFrameId + 1;
                let end = this.GetEndFrameId(start);
                if (start > end) {
                    return;
                }
                // Count how many frames we're missing for logging
                let missingCount = 0;
                for (let i = start; i <= end; i++) {
                    if (!this.allFrameHandles.contains(i)) {
                        missingCount++;
                    }
                }
                BattleService.Instance.SendRepairFrame(start, end);
                this.currentRepairTime = this.repairWaitTime;
                console.log('Frame repair request start=' + start + ', end=' + end + ', missing=' + missingCount + ', handleFrameId=' + this.handleFrameId)
            } else {
                this.currentRepairTime -= (waitTime <= 0 ? 1 : waitTime);
            }
            return true;
        }else{  // No frame dropped
            this.currentRepairTime = 0;
            return false;
        }
    }

    /**
     * Live frame response
     * @param param 
     */
    public static OnLiveFrame(param: any) {
        let response = param as proto.BattleMessage.LiveFrameResponse;
        let liveFrames = response.liveFrames;
        for (let i = 0; i < liveFrames.length; i++) {
            let liveFrame = liveFrames[i];
            let frameId = liveFrame.frame;
            this.allFrameHandles.put(liveFrame.frame, liveFrame.userFrameHandleMap || {});

            if (this.newFrameId < frameId) {
                this.newFrameId = frameId;
            }
        }
        this.isReceiveServerFrame = true;
    }

    
    /**
    * Collect player operations
    */
    public static CapturePlayerOpts(): void {
        this.GameProgressRecoveryValidate();  // Game progress recovery validation
        let userId = User.Instance.user.id;
        this.frameHandle.userId = userId;
        let currentCharacter = BattleManager.Instance.currentCharacter;

        if(!BattleGlobal.isStandaloneFlag){  // Non-standalone             
            // Prediction  
            // this.DoPrediction(undefined);                   
            // No operation, player death
            if (this.frameHandle.opt == OptType.None || (this.frameHandle.opt != OptType.LjResu && this.frameHandle.opt != OptType.handGameOver &&
                currentCharacter.IsDeath)) {
                this.ResetFrameHandleData();
                return;
            }
            let myFrameHandle = new proto.BattleMessage.FrameHandle(this.frameHandle);
            // LogUtil.log(this.frameHandle);
            // Rocker operation execute locally
            if(myFrameHandle.opt == OptType.Rocker && !currentCharacter.IsDeath){  // Rocker operation, not dead
                this.DoHandlerFrameHandle(currentCharacter, myFrameHandle, true);
                // let angle = this.frameHandle.optValue1 || 0;
                //     angle = BattleGlobal.AngleRangeHandle(Math.round(currentCharacter.teamType2 == TeamType2.Red ? angle + 180 : Math.abs(angle)))               
                // // currentCharacter.RotateHandle(angle, false, true);
                // currentCharacter.Move(angle, currentCharacter.attributes.Speed.toNumber(), false, true, undefined);
                // currentCharacter.SetAnim(AniState.Move, true);

                myFrameHandle.optValue2 = LogicRenderConvert.RenderToLogic_Value(currentCharacter.renderPosition.x);
                myFrameHandle.optValue3 = LogicRenderConvert.RenderToLogic_Value(currentCharacter.renderPosition.y);
                myFrameHandle.optValue4 = LogicRenderConvert.RenderToLogic_Value(currentCharacter.renderPosition.z);
                myFrameHandle.optValue5 = 1;
            }
            // Send operation
            // setTimeout(function(){
                BattleService.Instance.SendFrameHandle(myFrameHandle);         
            // }, RandomUtil.limit2(0, 50))
            // console.log((this.newFrameId + 1)+'Actual self angle='+myFrameHandle.optValue1)   
            this.ResetFrameHandleData();
        }else{  // Standalone, client frame calculation
            // No operation, player death
            // if(!NetClientBattle.Instance.connected){  // Not connected
            //     return;
            // }
            if (this.frameHandle.opt == OptType.None || (this.frameHandle.opt != OptType.LjResu && this.frameHandle.opt != OptType.handGameOver &&
                currentCharacter.IsDeath)) {
                this.ResetFrameHandleData();
            }
            let userFrameHandleMap = {};
            if(this.frameHandle.opt != OptType.None){
                let userFrameHandle = new proto.BattleMessage.UserFrameHandle({frameHandles : [new proto.BattleMessage.FrameHandle(this.frameHandle)]});
                userFrameHandleMap[userId] = userFrameHandle;
            }
            this.allFrameHandles.put(this.newFrameId, userFrameHandleMap || {}); // Save received frames              
            this.newFrameId++;
            this.ResetFrameHandleData();
        } 
    }

    /**
     * Prediction
     * Prediction for self is based on client's real-time operations.
     * Prediction for other players is based on their most recent 1 frame operation.
     */
    public static DoPrediction(predictionFrameId:number) {
        if (!this.isExecutenNewFrame()) {  // Not executed to latest frame
            return;
        }
        if(!predictionFrameId){
            predictionFrameId = this.newFrameId + 1;
        }
        if(this.clientPredictionFrameHandles.contains(predictionFrameId)){  // Prediction frame already exists          
          let cjFrameId = predictionFrameId - this.newFrameId;
          if(cjFrameId >= BattleGlobal.preperformanceFrameCount){  // Exceed prediction frame count, exit
            return;
          }
          predictionFrameId += 1;
          this.DoPrediction(predictionFrameId);
          return;
        }        
        let userId = User.Instance.user.id;
        let userFrameHandleMapRes:{ [k: number]: proto.BattleMessage.IUserFrameHandle } = {};
        let userFrameHandleMap = BattleData.getFrameData(this.newFrameId); // Latest frame count
        
        // Predict other players' operations
        let characterList = CharacterManager.Instance.characterList;
        for (let i = 0; i < characterList.length; i++) {  // Iterate all heroes
            let character = characterList[i];        
            if(character.isAiControlFlag){  // AI control active
                if(character.aniState == AniState.Move){
                    // console.log('Robot prediction 00000000============')                    
                    let newDegree = character.lastMoveAngle;  // Last move angle
                    let fh = new proto.BattleMessage.FrameHandle();
                    fh.opt = OptType.Rocker;
                    fh.optValue1 = newDegree;  // Angle
                    let userFrameHandle = new proto.BattleMessage.UserFrameHandle({frameHandles : [fh]});
                    userFrameHandleMapRes[character.user.id] = userFrameHandle;
                }
            }else if(character.user.id == userId){  // Is self
                continue;
            }else { // Other players, extrapolate forward frames               
               if (userFrameHandleMap) {            
                // console.log('Other players prediction 111111111============')
                 let userFrameHandle = userFrameHandleMap[character.user.id];
                 if(!userFrameHandle || !userFrameHandle.frameHandles || userFrameHandle.frameHandles.length < 1){
                    // console.log('Other players prediction 22222222============')
                   continue;
                 }
                 let frameHandles = userFrameHandle.frameHandles;
                 let fh = frameHandles[frameHandles.length - 1] as proto.BattleMessage.FrameHandle;  // Last operation
                 if (frameHandles.length == 1 && fh && fh.opt == OptType.Rocker) {  // Is joystick operation
                   let userFrameHandle = new proto.BattleMessage.UserFrameHandle({frameHandles : frameHandles});
                   userFrameHandleMapRes[character.user.id] = userFrameHandle;
                //    console.log('Other players prediction 33333333============')
                   break;
                 }              
               }           
            }
        } 
        this.clientPredictionFrameHandles.put(predictionFrameId, userFrameHandleMapRes);
    }

    /**
     * Pre-render self rotation
     */
    public static DoPredictionMyRotate() {
        // Pre-render self rotation
        let currentCharacter = BattleManager.Instance.currentCharacter;
        if (!currentCharacter.SkillMgr.ValidateSkillActionPlayEnd(true) || !currentCharacter.isCanMove 
            || currentCharacter.battleAttribute.CanMoveCount > 0 
            || currentCharacter.SkillMgr.GetSkillCastIsOnlyRotate()) {  // Skill action finished, cannot move
            return;
        }
        if(this.frameHandle.opt == OptType.Rocker && !currentCharacter.IsDeath){  // Joystick operation, not dead
            let angle = this.frameHandle.optValue1 || 0;
            angle = BattleGlobal.AngleRangeHandle(Math.round(currentCharacter.teamType2 == TeamType2.Red ? angle + 180 : Math.abs(angle)));
            currentCharacter.RotateHandle(angle, true, true);
        }
    } 

    // private static currentPredictionCount:number = 0; // Current move pre-render count
    /**
     * Execute pre-render (only pre-render movement)
     * Use pre-render algorithm, pre-render all players, only change render data, temporarily only pre-render movement, premise is self has caught up,
     * Pre-render self is based on client's real-time operations.
     * Pre-render other players is based on their most recent n frame operations.
     */
   /* public static DoPrediction() {
        let currentCharacter = BattleManager.Instance.currentCharacter;
        if (!this.isExecutenNewFrame() || !currentCharacter) {  // Not executed to latest frame
            return;
        }
        if (this.executeFrameId == this.newFrameId) {  // Executed to latest frame, validate pre-render frame count
            let count = Math.floor(NetConfig.frameTime / BattleGlobal.fastestWaitTime);  // 1 logic frame is 4 move pre-renders
            if(this.currentPredictionCount >= count * BattleGlobal.preperformanceFrameCount){
                this.currentPredictionCount = 0;
                return;
            }
            this.currentPredictionCount++;
        }
        // console.log('DoPrediction')
        
        // Pre-render self rotation
        // if(this.frameHandle.opt == OptType.Rocker && !currentCharacter.IsDeath){  // Joystick operation, not dead
        //     let angle = this.frameHandle.optValue1 || 0;
        //     angle = BattleGlobal.AngleRangeHandle(Math.round(currentCharacter.teamType2 == TeamType2.Red ? angle + 180 : Math.abs(angle)));
        //     currentCharacter.RotateHandle(angle, true, true);
        // }


        // Pre-render self
        if(this.frameHandle.opt == OptType.Rocker && !currentCharacter.IsDeath){  // Joystick operation, not dead
          this.DoHandlerFrameHandle(currentCharacter, this.frameHandle, true);
        }

        // Pre-render other players
        let characterList = CharacterManager.Instance.characterList;
        for (let i = 0; i < characterList.length; i++) {  // Iterate all heroes
            let character = characterList[i];
            if(character.user.id == currentCharacter.user.id){  // Is self
                continue;
            }
            if(character.user.isRobot){  // Robot
                if(character.aniState == AniState.Move){                    
                    let newDegree = character.lastMoveAngle;  // Last move angle
                    character.RotateHandle(newDegree);
                    character.Move(newDegree, character.attributes.Speed.toNumber(), true);
                }
            }else { // Real player, extrapolate forward frames
              for(let j = 0; j < BattleGlobal.preperformanceFrameCount; j++){   
               let userFrameHandleMap = BattleData.getFrameData(this.newFrameId - j); // Latest frame count
               if (userFrameHandleMap) {            
                 let userFrameHandle = userFrameHandleMap[character.user.id];
                 if(!userFrameHandle || !userFrameHandle.frameHandles || userFrameHandle.frameHandles.length < 1){
                   continue;
                 }
                 let frameHandles = userFrameHandle.frameHandles;
                 let fh = frameHandles[frameHandles.length - 1] as proto.BattleMessage.FrameHandle;  // Last operation
                 if (fh && fh.opt == OptType.Rocker) {  // Is joystick operation
                   this.DoHandlerFrameHandle(character, fh, true);
                   break;
                 }              
               }
              }
            }
        }     
    }*/


    /**
     * Execute frame operation
     * @param isPrediction Whether pre-render
     */
    public static DoHandlerFrame(userFrameHandleMap: { [k: number]: proto.BattleMessage.IUserFrameHandle }, frameHandle:proto.BattleMessage.FrameHandle, isPrediction: boolean) {
        if (BattleGlobal.isGameEndFlag) {  // Game ended
            return;
        }
        // Sync heroes
        let characterList = CharacterManager.Instance.characterList;
        for (let i = 0; i < characterList.length; i++) {  // Iterate all heroes
            let character = characterList[i];
           if(userFrameHandleMap){
               let userFrameHandle = userFrameHandleMap[character.user.id];
               // No operation exists
               if(!userFrameHandle || !userFrameHandle.frameHandles || userFrameHandle.frameHandles.length < 1){
                   this.DoHandlerFrameHandle(character, null, isPrediction);
                   continue;
               }
               let frameHandles = userFrameHandle.frameHandles;
               for (let j = 0; j < frameHandles.length; j++) {  // Iterate all operations
                   let fh = frameHandles[j];
                   this.DoHandlerFrameHandle(character, fh, isPrediction);
               }
           } else if(frameHandle && frameHandle.userId == character.user.id){
             this.DoHandlerFrameHandle(character, frameHandle, isPrediction);
             break;
           }
            
        }
    }

    private static DoHandlerFrameHandle(character:Creature, frameHandle: proto.BattleMessage.IFrameHandle, isPrediction: boolean){
        let isMove = (character.aniState == AniState.Move);
        if (!isPrediction && character.IsDeath) {  // Already dead
          character.newExistOptFrameId = this.executeFrameId;
        }
        if (!frameHandle || frameHandle.opt == OptType.None) {  // User has no operation
            // if (character.isAiControlFlag) {  // AI control active
            //     continue;
            // }
            // if (isPrediction) {
            //     return;
            // }
            let notHandleFrameCount = (!BattleGlobal.isStandaloneFlag && (!character.user || character.user.id != User.Instance.user.id)) ? BattleGlobal.aniPredictionFrameCount2 : BattleGlobal.aniPredictionFrameCount;
            if (character.notHandleFrameCount > notHandleFrameCount) {
                if (isMove) {
                    // console.log('User nickname: ' + character.user.nickname + ', stop animation, is pre-render=' + isPrediction + ', logicPosition=', character.logicPosition)
                    character.SetAnim(AniState.Idle, true);
                }
                character.notHandleFrameCount = 0;
            } else {
                // if (!isPrediction) {
                    character.notHandleFrameCount++;
                // }
            }
        } else {
            character.notHandleFrameCount = 0;
            if (!isPrediction) {  // Not pre-render
                character.newExistOptFrameId = this.executeFrameId;
            }
            if (frameHandle.opt != OptType.LjResu && frameHandle.opt != OptType.handGameOver && character.IsDeath) {  // Not immediate revival, already dead
                return;
            }
            
            // Record existing operation frame 
            // if (frameHandle.opt != OptType.None) {
            //     character.newExistOptFrameId = this.executeFrameId;
            // }
            // Joystick operation
            if (frameHandle.opt == OptType.Rocker) {
                if(!isPrediction){
                    character.aiHeroSkillMoveTarget.isMoveTargetFlag = false;   // Cancel AI move to target
                }

                // Cancel recall buff
                if (!isPrediction && character.EffectMgr.HasEffect(BuffEffect.HuiCheng)) {   // Recall buff exists
                    character.EffectMgr.RemoveEffect(BuffEffect.HuiCheng);
                }
                // Cancel AI auto buff (3v3 or 5v5)
                if (!isPrediction && character.EffectMgr.HasEffect(BuffEffect.ZiDong) 
                    && (BattleGlobal.playingMethod == Constant.PlayingMethod.ThreeVsThree || 
                        BattleGlobal.playingMethod == Constant.PlayingMethod.FiveVsFive)) {   // AI auto buff exists
                    character.EffectMgr.RemoveEffect(BuffEffect.ZiDong);
                }
                
                if (!character.SkillMgr.ValidateSkillActionPlayEnd(true) || !character.isCanMove || character.battleAttribute.CanMoveCount > 0) {  // Skill action finished, cannot move
                    return;
                }                    
                
                // Whether to update render movement 
                let isUpdateRendering: boolean = true;      
                // Whether to update render rotation 
                let isUpdateRenderingRotate:boolean = true;
               if (!isPrediction && this.executeFrameId == this.predictionExecuteFrameId) {  // Not pre-render
                    // Validate if current user pre-render operation matches server authoritative operation
                    let userFrameHandleMapRes:{ [k: number]: proto.BattleMessage.IUserFrameHandle } = this.clientPredictionFrameHandles.get(this.executeFrameId);
                    if(userFrameHandleMapRes){
                        let userFrameHandle = userFrameHandleMapRes[character.user.id];
                        if(userFrameHandle){
                            let frameHandles = userFrameHandle.frameHandles;
                            if(frameHandles && frameHandles.length > 0){
                                let fh = frameHandles[0];
                                if(fh.optValue1 == frameHandle.optValue1){  // Pre-render successful
                                    isUpdateRendering = isUpdateRenderingRotate = false;
                                } 
                                // if(character.user.id == User.Instance.user.id){
                                //     if(!isUpdateRendering){
                                //         // console.log('User id=' + character.user.id +', pre-render successful==, no render update. optValue1='+fh.optValue1);
                                //     }else{
                                //         console.log('Frame=' + this.executeFrameId +', prediction frame='+this.predictionExecuteFrameId+', pre-render failed, update render. Predicted optValue1='+fh.optValue1
                                //             +', actual optValue1='+frameHandle.optValue1
                                //         );
                                //     }
                                // }                      
                            }
                        }
                    }                    
                }

                if(character.user.id == User.Instance.user.id && this.isExecutenNewFrame()){  // Is self and executed to latest frame, don't update rotation
                    isUpdateRenderingRotate = false;
                    if(!isPrediction && !BattleGlobal.isStandaloneFlag){  // Authoritative input + network, don't update render movement
                        isUpdateRendering = false;
                    }
                }

                // if(!isPrediction && !BattleGlobal.isStandaloneFlag && character.user.id == User.Instance.user.id){  // Not prediction, not standalone, executing self                    
                //     isUpdateRendering = false;
                //     isUpdateRenderingRotate = false;
                // }

                // if(character.user.id == User.Instance.user.id){
                //     console.log('Frame=' + this.executeFrameId +' execute, prediction='+isPrediction+', update rotation='+isUpdateRenderingRotate
                //         +'，isStandaloneFlag='+BattleGlobal.isStandaloneFlag);
                // }
                

                let angle = frameHandle.optValue1 || 0;
                if(!character.isAiControlFlag){  // Not AI control active
                    angle = BattleGlobal.AngleRangeHandle(Math.round(character.teamType2 == TeamType2.Red ? angle + 180 : Math.abs(angle)))
                }
                // During skill cast, cannot move, only rotate
                let skill = character.SkillMgr.GetSkillCastIsOnlyRotate();                
                if (skill) {
                    if(isPrediction){
                        return;
                    }
                    isUpdateRenderingRotate = true;
                    // console.log('skillRotate angle='+angle+',lastAngle='+character.lastSkillRotateAngle)
                    // Rotate skill direction sticky frame
                    if(character.lastSkillRotateAngle != -1){   // If there was a previous operation, can control max rotation angle per frame
                      let cha  = 0;  
                      if(angle > character.lastSkillRotateAngle){
                        cha = angle - character.lastSkillRotateAngle;
                        if(cha > BattleGlobal.rotateFrameMoveMaxAngle){
                          if(cha > 180){
                            angle = character.lastSkillRotateAngle - BattleGlobal.rotateFrameMoveMaxAngle;
                          }else{
                            angle = character.lastSkillRotateAngle + BattleGlobal.rotateFrameMoveMaxAngle;
                          }
                        }
                      }else{
                        cha = character.lastSkillRotateAngle - angle;
                        if(cha > BattleGlobal.rotateFrameMoveMaxAngle){
                          if(cha > 180){
                            angle = character.lastSkillRotateAngle + BattleGlobal.rotateFrameMoveMaxAngle;
                          }else{
                            angle = character.lastSkillRotateAngle - BattleGlobal.rotateFrameMoveMaxAngle;
                          }
                        }
                      }
                    }
                    console.log('skillRotate22 angle='+angle)
                    angle = BattleGlobal.AngleRangeHandle(Math.round(angle));
                    
                    character.RotateHandle(angle, isPrediction, isUpdateRenderingRotate, undefined);
                    skill.Context.dirDegree = angle;  // Update skill direction
                } else {
                    if(!isPrediction){
                        character.RotateHandle(angle, isPrediction, isUpdateRenderingRotate);
                    }
                    let logicX;
                    let logicY;
                    let logicZ;
                    let isReadStateValueFlag:boolean = (frameHandle.optValue5 == 1);  // Whether to read state value
                    let isCalculationPredictionStateFlag:boolean = false;  // Whether to calculate prediction state
                    if(isReadStateValueFlag){
                      logicX = frameHandle.optValue2;
                      logicY = frameHandle.optValue3;
                      logicZ = frameHandle.optValue4;
                    }else if(isPrediction && !BattleGlobal.isStandaloneFlag 
                         && character.user.id == User.Instance.user.id){      // Prediction and not standalone and is self and caught up to latest frame                  
                            isCalculationPredictionStateFlag = true;
                    }

                // if(character.user.id == User.Instance.user.id){
                //     console.log('Frame=' + this.executeFrameId +' execute, prediction='+isPrediction+', update rotation='+isUpdateRenderingRotate
                //         +'，isStandaloneFlag='+BattleGlobal.isStandaloneFlag+'，update render movement='+isUpdateRendering+'，whether to read state value='+isReadStateValueFlag
                //     +'，whether to calculate prediction state='+isCalculationPredictionStateFlag);
                // }

                    character.Move(angle, character.attributes.Speed.toNumber(), isPrediction, isUpdateRendering, undefined, logicX, logicY, logicZ, isReadStateValueFlag, isCalculationPredictionStateFlag);
                    if(character.isAiControlFlag){  // AI control active
                        let ai = character.AI.ai;
                        if(ai && (ai.aiState == Constant.AIState.pathWay) || (ai.aiState == Constant.AIState.targetMove) ||
                                 (ai.aiState == Constant.AIState.returningCity)){
                            character.SetAnim(AniState.Move, true);
                        }

                    }else{
                        if (!isMove && !character.SkillMgr.GetSkillPlayingCanMoveNoChangeAni()) {   // Not in playing state
                            //console.log('Move execution, isPrediction='+isPrediction+', speed='+character.attributes.Speed+', angle='+angle+', action='+AniState[character.aniState])
                            character.SetAnim(AniState.Move, true);
                        }
                    }
                }

            } else if (frameHandle.opt == OptType.Skill) {  // Attack                                   
                let skillId = frameHandle.optValue1 || 0;
                let angle = frameHandle.optValue4 || 0;
                let skill = character.SkillMgr.GetSkill(skillId);
                let context = new BattleContext(skill, character);

                character.aiHeroSkillMoveTarget.isMoveTargetFlag = false;   // Cancel AI move to target
                // Cancel recall buff
                if (character.EffectMgr.HasEffect(BuffEffect.HuiCheng)) {   // Recall buff exists
                    character.EffectMgr.RemoveEffect(BuffEffect.HuiCheng);
                    if (skill.Define.Type && skill.Define.Type.toString() == SkillType[SkillType.HuiCheng]) {  // If recall skill then exit
                        return;
                    }
                }
                // Cancel AI auto buff (3v3 or 5v5)
                if (character.EffectMgr.HasEffect(BuffEffect.ZiDong)
                    && (BattleGlobal.playingMethod == Constant.PlayingMethod.ThreeVsThree || 
                        BattleGlobal.playingMethod == Constant.PlayingMethod.FiveVsFive)) {   // AI auto buff exists
                    character.EffectMgr.RemoveEffect(BuffEffect.ZiDong);
                    if (skill.Define.Type && skill.Define.Type.toString() == SkillType[SkillType.ZiDong]) {  // If AI auto skill then exit
                        return;
                    }
                }

                if (skill.CanCast(context) != SkillResult.Ok) {  // Validate skill can be cast
                    return;
                }

                //    if(skill.Define.CastTarget.toString() == TargetType[TargetType.RangeTarget]){  // Range target     
                //    }     
                if (character.teamType2 == TeamType2.Red) {
                    context.dirDegree = angle + 180;
                } else {
                    context.dirDegree = angle - 180 < 0 ? angle + 180 : angle - 180;
                }
                context.dirDegree = BattleGlobal.AngleRangeHandle(Math.round(context.dirDegree));

                // console.warn('Non-range target CastTarget='+(skill.Define.CastTarget.toString())+', angle='+angle+', dirDegree='+(context.dirDegree)+', character angle='+character.logicRotation.y)

                if (skill.Define.CastTarget.toString() == TargetType[TargetType.SelectedRange]) {  // Selected range
                    context.logicPositionX = frameHandle.optValue2 || 0;
                    context.logicPositionZ = frameHandle.optValue3 || 0;
                } else if (skill.Define.CastTarget.toString() == TargetType[TargetType.Des]) {  // Designated target type
                    if (frameHandle.optValue2 && frameHandle.optValue3) {  // No target, go to specified position
                        context.logicPositionX = frameHandle.optValue2 || 0;
                        context.logicPositionZ = frameHandle.optValue3 || 0;
                    } else { // Target exists
                        context.Target = CreatureManager.Instance.GetCreature(frameHandle.optValue2);
                    }
                }
                // console.warn('Attack server confirmation skillId=' + skillId + ', angle=' + angle + ', dirDegree=' + context.dirDegree
                //     + '，positionX=' + context.logicPositionX + '，positionZ=' + context.logicPositionZ)
                
                let isMoveTargetFlag = character.aiHeroSkillMoveTarget.SearchRangeTarget(context, skill);
                if(!isMoveTargetFlag){
                    character.CastSkill(context, skill);
                }           
                // console.log('SearchRangeTarget isMoveTargetFlag='+isMoveTargetFlag)   
            } else if (frameHandle.opt == OptType.SportsItem) {  // Use sports item
                let itemId = frameHandle.optValue1 || 0;
                character.UseSportsItem(itemId);
            } else if (frameHandle.opt == OptType.ShedBlood) {  // Blood loss test
                console.log('Blood loss test=================')
                let lv = frameHandle.optValue1 || 0;
                character.attributes.SetHp(lv);
            } else if (frameHandle.opt == OptType.ResuRenTou) {  // Resurrect kill count
                character.resuFlag = true;
            } else if (frameHandle.opt == OptType.handGameOver) {  // Manual end
                let userId = frameHandle.optValue1; // End user id
                let team =  frameHandle.optValue2; // Winning team 
                console.log('Game settlement, handGameOver manual end userId='+userId+'，team='+team)
                BattleGlobal.GameOver(team == TeamType2.Blue); 
            }else if (frameHandle.opt == OptType.CancelSkill) {  // Cancel skill cast
                let skillId = frameHandle.optValue1 || 0;
                let skill = character.SkillMgr.GetSkill(skillId);
                skill.CancelCastSkill();
            }else if (frameHandle.opt == OptType.LjResu) {  // Immediate resurrection
                // console.log('Immediate resurrection =======')
                if(character.user && character.user.id == User.Instance.user.id){  // Is self 
                    if(character.resuCoinCount < 1){
                        TipsManager.Instance.showTips("You don't have resurrection coins!");
                        return;
                    }
                    character.resuCoinCount--;
                        TipsManager.Instance.showTips("You have been resurrected!");
                }else{
                    if(character.resuCoinCount < 1){
                        return;
                    }
                    character.resuCoinCount--;
                }
                character.resuCoinUseCount++;
                character.ResuCharacterHandle();
            }
         /*else if(frameHandle.opt == OptType.Up){  // Joystick, keyboard lift
            console.log('BattleData Up')
            character.SetAnim(AniState.Idle, true);
         }*/ else {
                // if (isMove) {
                //     console.log('User id: ' + character.user.id + ', stop animation, is prediction=' + isPrediction)
                //     character.SetAnim(AniState.Idle, true);
                // }
            }
        }
    }


    /**
     * Reset frame operation data
     */
    private static ResetFrameHandleData() {
        this.frameHandle.opt = OptType.None;
        this.frameHandle.optValue1 = undefined;
        this.frameHandle.optValue2 = undefined;
        this.frameHandle.optValue3 = undefined;
        this.frameHandle.optValue4 = undefined;
        this.frameHandle.optValue5 = undefined;
    }

    /**
     * Get frame data
     * @param frameId 
     */
    public static getFrameData(frameId: number): { [k: number]: proto.BattleMessage.IUserFrameHandle } {
        let userFrameHandleMap = BattleData.allFrameHandles.get(frameId);
        return userFrameHandleMap;
    }

  /**
   * Cache frame data.
   *
   * Optimised: only serializes frames within the PRUNE_WINDOW (last ~30s)
   * instead of the entire match history.  Also reduced frequency from
   * every 30 frames (1.5s) to every 100 frames (5s) to lower GC pressure
   * on budget devices (RISK 6).
   * @param frameId 
   */
  public static async cacheFrame(frameId:number){
    if (!this.isExecutenNewFrame()) {  // Not executed to latest frame
      return;
    }
    if (BattleGlobal.battleMode == BattleMode.Battle) {
      if (frameId % 100 == 0) {  // Cache once every 5 seconds (was 30/1.5s)
        try{
          // Only serialize recent frames (within prune window) to reduce
          // JSON.stringify cost and GC pressure on budget devices
          const cutoff = this.executeFrameId - this.PRUNE_WINDOW;
          const recentFrames: { [key: string]: any } = {};
          const keys = BattleData.allFrameHandles.keys();
          for (let i = 0; i < keys.length; i++) {
            const fid = Number(keys[i]);
            if (fid >= cutoff) {
              recentFrames[keys[i]] = BattleData.allFrameHandles.get(keys[i]);
            }
          }
          let data = JSON.stringify({ map: recentFrames });
          LocalStorageUtil.SetItem(LocalStorageUtil.allFrameHandlesKey + User.Instance.user.id, data);
        }catch(err){
        }
      }
    }
  }

  /**
   * Cache state data
   * @param frameId 
   */
  public static cacheStateDate(frameId:number){
    if (!this.isExecutenNewFrame()) {  // Not executed to latest frame
        return;
    }
    StateHandleManager.Instance.recordAllState(frameId);
  }

  /**
   * Validate whether executed to latest frame
   * @returns 
   */
  public static isExecutenNewFrame():boolean{
    // Difference between latest frame and processed frame
    let cha = this.newFrameId - this.handleFrameId;
    if (cha > 10) {  // Not executed to latest frame
        return false;
    }
    return true;
  }


}