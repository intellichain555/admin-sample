
import { _decorator, Component, Node, Sprite, Label, Color, instantiate, UITransform, math } from 'cc';
import { Creature } from './Enities/Creature';
import { User } from '../../Models/User';
import { TeamType2 } from './enums/TeamType2';
import { BattleManager } from './Managers/BattleManager';
import { CreatureType } from './enums/CreatureType';
import { UIBuffIcons } from './UI/UIBuffIcons';
import { BattleGlobal } from './Utils/BattleGlobal';
import { Constant } from '../../../../Scripts/Utils/Constant';
const { ccclass, property } = _decorator;
/**
 * Health bar
 */
@ccclass('UIHpBar')
export class UIHpBar extends Component {
   
    @property(Sprite)
    public hpSprite:Sprite=null;
    @property(Label)
    public hpLabel:Label=null;
    @property(Label)
    public nameLabel:Label=null;
    @property(UIBuffIcons)
    public buffIcons:UIBuffIcons;
    @property(Sprite)
    public levelSprite:Sprite=null;
    @property(Label)
    public levelLabel:Label=null;
    
    @property(Node)
    public hpStripNode:Node = null;

    private owner:Creature=null;
    private width:number = 0;
    private lastHP:number = -1;   //Last recorded health
    private lastMaxHP:number = -1;  //Last recorded max health
    private lastLevel:string = '';
    private lastNickName:string = '';
    private lastType:number = -1;
    private lastIsCharacter:boolean = false;

    onLoad () {
      let uiTransform = this.hpSprite.node.getComponent(UITransform);
      this.width = uiTransform.width;

    }

    onEnable(){
        this.lastHP = -1;
        this.lastMaxHP = -1;
        this.lastLevel = '';
        this.lastNickName = '';
        this.lastType = -1;
    }

    public set Owner(owner:Creature){
        this.owner = owner;
        this.buffIcons.SetOwner(owner);

        if(owner.creatureType == CreatureType.Character){
            let uiTransform = this.node.getComponent(UITransform);  
            //Set my health bar layer to not be blocked
            if(owner.user && owner.user.id == User.Instance.user.id){
              uiTransform.priority = 999;
            }else{
              uiTransform.priority = 888;
            }
        } else if (owner.creatureType === CreatureType.Monster && owner.characterDefine.Class === Constant.CharacterClass.Soldier) {
            // Minion: only show HP bar when health is below max (starts hidden at full HP)
            let HP = owner.attributes.HP.toNumber();
            let MaxHP = owner.attributes.MaxHP.toNumber();
            owner.IsShowHpNode = HP < MaxHP;
        }
    }

    private tempColor = new Color();
    // private count:number = 0;
    /**
     * Set health bar info
     * @param level Level 
     * @param exp  Experience
     * @param levelExp  Level up experience
     * @param nickName  Nickname
     * @param currentHp Current hp
     * @param maxHp  Max hp
     * @param isCharacter Whether is character
     * @param type Type 1、self  2、teammate  3、enemy
     */
    private SetItemInfo(level:string, exp:number, levelExp:number, nickName:string, currentHp:number, maxHp:number, isCharacter:boolean, type:number){
        if(isCharacter){
           this.nameLabel.string = nickName;
           this.levelLabel.string = level;
           this.levelSprite.fillRange = -((exp / levelExp) || 0);
           //Display grid gaps based on health
           let stripCount = Math.ceil(maxHp / 600);  //Strip count
           let stripWidth = this.width / stripCount;  //Strip width
           let startPos = -this.width / 2;  //Start position
           let endPos = this.width / 2;  //End position

           let hpStripNodeArr = this.hpStripNode.children;           
           let nodePrefab:Node = null;
           for(let i = 0; i < stripCount; i++){
            let x = startPos + (stripWidth * (i + 1)); 
            if(x >= endPos){
                stripCount--;
                continue;
            }
            // if(this.count % 300 == 0){
            //   console.log(nickName+'，x='+x)  
            // }
             let currentNode:Node = null;
             if(hpStripNodeArr.length > i){
                let node = hpStripNodeArr[i];
                node.active = true;
                nodePrefab = node;
                currentNode = node;
             }else{
                let newNode = instantiate(nodePrefab);
                this.hpStripNode.addChild(newNode);
                currentNode = newNode;    
             }            
             currentNode.setPosition(x, currentNode.position.y, currentNode.position.z);
           }
           //Hide excess strips           
           if(hpStripNodeArr.length > stripCount){
             for(let i = hpStripNodeArr.length - 1; i > stripCount - 1; i--){
                let node = hpStripNodeArr[i];
                node.active = false;
             }
           }
        //    this.count++;
        }else{
           this.nameLabel.string='';
        //    this.nameLabel.string = nickName;
           this.levelLabel.node.parent.active = false;
           this.hpStripNode.active = false;
        }
     
        this.hpSprite.fillRange=currentHp/maxHp;
        this.tempColor.fromHEX(type==1 ? BattleGlobal.myColor : (type==2 ? BattleGlobal.friendColor : BattleGlobal.enemyColor));
        this.hpSprite.color = this.tempColor;
    }

    /** Update only fill and color to avoid label/sprite texture work (measureText, fillText, texSubimage2D). */
    private setHPAndColorOnly(currentHp: number, maxHp: number, exp: number, levelExp: number, isCharacter: boolean, type: number): void {
        this.hpSprite.fillRange = currentHp / maxHp;
        if (isCharacter) {
            this.levelSprite.fillRange = -((exp / levelExp) || 0);
        }
        this.tempColor.fromHEX(type === 1 ? BattleGlobal.myColor : (type === 2 ? BattleGlobal.friendColor : BattleGlobal.enemyColor));
        this.hpSprite.color = this.tempColor;
    }

    update(){
        if(this.owner){
            let HP = this.owner.attributes.HP.toNumber();
            let MaxHP = this.owner.attributes.MaxHP.toNumber();
            // Minion (soldier): only show HP bar when health is below max
            let isMinion = this.owner.creatureType === CreatureType.Monster && this.owner.characterDefine.Class === Constant.CharacterClass.Soldier;
            if (isMinion) {
                this.owner.IsShowHpNode = HP < MaxHP;
            }
            //Health hasn't changed, no need to update
            if(HP == this.lastHP && MaxHP == this.lastMaxHP){
                return;
            }
            let currentCharacter = BattleManager.Instance.currentCharacter;
            if(currentCharacter && this.owner.creatureType==CreatureType.Character){  //Character
                let user = this.owner.user;
                let type = user.id==currentCharacter.user.id ? 1:(this.owner.teamType2 == currentCharacter.teamType2 ? 2 : 3);
                let levelStr = user.character.level + '';
                let nickName = user.nickname;
                if (levelStr === this.lastLevel && nickName === this.lastNickName && type === this.lastType && this.lastIsCharacter) {
                    this.setHPAndColorOnly(HP, MaxHP, user.character.exp, user.character.levelExp, true, type);
                } else {
                    this.SetItemInfo(levelStr, user.character.exp, user.character.levelExp, nickName, HP, MaxHP, true, type);
                    this.lastLevel = levelStr;
                    this.lastNickName = nickName;
                    this.lastType = type;
                    this.lastIsCharacter = true;
                }
            } else if(this.owner.creatureType==CreatureType.Monster){  //Monster
                let type = currentCharacter ? (this.owner.teamType2==currentCharacter.teamType2 ? 2 : 3) : 3;
                if (type === this.lastType && !this.lastIsCharacter) {
                    this.setHPAndColorOnly(HP, MaxHP, 0, 1, false, type);
                } else {
                    this.SetItemInfo(undefined, undefined, undefined, this.owner.characterDefine.ID+'', HP, MaxHP, false, type);
                    this.lastLevel = '';
                    this.lastNickName = '';
                    this.lastType = type;
                    this.lastIsCharacter = false;
                }
            }
            this.lastHP = HP;
            this.lastMaxHP = MaxHP;
        }
    }
 
}

