# Game Synchronization Risk Analysis — Mobile MOBA

> **Date:** 2026-02-09  
> **Scope:** Client (`assets/`) and Server (`Server/GameServer/`, `Server/BattleServer/`)  
> **Architecture:** Lockstep frame synchronization with client-side prediction

---

## Table of Contents

1. [Architecture Overview](#architecture-overview)
2. [RISK 1 — No App Background/Foreground Handling (CRITICAL) ✅ RESOLVED](#risk-1--no-app-backgroundforeground-handling-critical--resolved)
3. [RISK 2 — setInterval Input Capture Unreliable on Mobile (HIGH) ✅ RESOLVED](#risk-2--setinterval-input-capture-unreliable-on-mobile-high--resolved)
4. [RISK 3 — Accumulator Reset Causes Permanent Frame Drift (MEDIUM-HIGH) ✅ RESOLVED](#risk-3--accumulator-reset-causes-permanent-frame-drift-medium-high--resolved)
5. [RISK 4 — Floating-Point Determinism Partially Addressed (MEDIUM) ✅ RESOLVED](#risk-4--floating-point-determinism-partially-addressed-medium--resolved)
6. [RISK 5 — Seeded Random Never Synced or Saved (MEDIUM) ✅ RESOLVED](#risk-5--seeded-random-never-synced-or-saved-medium--resolved)
7. [RISK 6 — Unbounded Memory Growth of Frame Data (MEDIUM) ✅ RESOLVED](#risk-6--unbounded-memory-growth-of-frame-data-medium--resolved)
8. [RISK 7 — Reconnection Drops All Input, Slow Recovery (MEDIUM) ✅ RESOLVED](#risk-7--reconnection-drops-all-input-slow-recovery-medium--resolved)
9. [RISK 8 — Server Frame Rate Drift (LOW-MEDIUM) ✅ RESOLVED](#risk-8--server-frame-rate-drift-low-medium--resolved)
10. [RISK 9 — No Frame Validation / Anti-Cheat on Server (HIGH for security) ✅ RESOLVED](#risk-9--no-frame-validation--anti-cheat-on-server-high-for-security--resolved)
11. [Summary Risk Matrix](#summary-risk-matrix)
12. [Recommended Fix Priority](#recommended-fix-priority)
13. [TOOL — FrameSyncMonitor (Performance Checker)](#tool--framesyncmonitor-performance-checker)

---

## Architecture Overview

```
┌─────────────┐         HTTP (room setup)        ┌──────────────┐
│  GameServer  │◄────────────────────────────────►│ BattleServer │
│  (Lobby)     │                                  │ (Real-time)  │
└──────┬───────┘                                  └──────┬───────┘
       │ WebSocket                                       │ WebSocket / UDP
       │ (login, room, matchmaking)                      │ (frame sync)
       ▼                                                 ▼
┌──────────────────────────────────────────────────────────────────┐
│                        Mobile Client                             │
│                                                                  │
│  BattleManager.update(dt)                                        │
│    └─► ChasingFrame(dt*1000)    ◄── wall-clock accumulator       │
│          └─► OnHandlerFrame()   ◄── process one logic frame      │
│                └─► BattleData.DoHandlerFrame()                   │
│                      └─► Creature.Move() / Skill / AI            │
│                                                                  │
│  update(dt) input accumulator                                     │
│    └─► BattleData.CapturePlayerOpts()  ◄── input sampling        │
│          └─► BattleService.SendFrameHandle()                     │
│                                                                  │
│  FrameSyncMonitor (perf checker)                                 │
│    └─► logs render FPS, logic FPS, overruns, gaps every 5s       │
└──────────────────────────────────────────────────────────────────┘
```

**Key timing values:**
- Server authoritative frame rate: `Thread.sleep(50)` → ~20 Hz (`Server/BattleServer/.../Constant.java`)
- Client logic frame budget: `NetConfig.frameTime = 50` ms (`assets/.../NetConfig.ts`)
- Client input capture: wall-clock accumulator in `BattleManager.update(dt)` (was `setInterval`, fixed)
- Client frame processing: wall-clock accumulator in `BattleManager.ChasingFrame()`
- Performance monitor: `FrameSyncMonitor` logs sync stats every 5 seconds

---

## RISK 1 — No App Background/Foreground Handling (CRITICAL) ✅ RESOLVED

### Severity: 🔴 Critical | Likelihood on Mobile: Very High

### Status: ✅ **Fixed** — `Game.EVENT_HIDE` / `Game.EVENT_SHOW` handlers added with tiered recovery strategy.

### Problem (was)

There was **zero handling** for the app going to background on mobile devices. No `game.on(Game.EVENT_SHOW)` / `game.on(Game.EVENT_HIDE)` listeners existed. When the player returned, `dt` could be several seconds, accumulators would burst, and the client would be hundreds of frames behind with max 5 frames/tick catch-up — taking many seconds to recover.

### Fix Applied

**`BattleManager.ts`** — registered `Game.EVENT_HIDE` and `Game.EVENT_SHOW` listeners in `start()`, cleaned up in `onDestroy()`.

**`_onAppHide()`** — records `performance.now()` timestamp, sets background flag.

**`_onAppShow()`** — tiered recovery based on background duration:

| Duration | Action |
|---|---|
| **< 2s** (short) | Reset accumulators (`logicTimeAccMs`, `inputAccMs`) to prevent burst. Normal catch-up handles the rest. |
| **2–30s** (medium) | Reset accumulators + show "Game Progress Recovery" overlay + request aggressive frame repair (`SendRepairFrame`) for all missing frames + increase burst limit from 5 → 20 frames/tick. |
| **> 30s** (long) | All of the above + immediately reconnect WebSocket via `NetClientBattle.immediateReconnect()` (iOS kills background sockets after ~30s). |

**`ChasingFrame()`** — burst limit is now dynamic:
- Normal: `NORMAL_BURST_LIMIT = 5` frames/tick
- Post-background recovery: `RECOVERY_BURST_LIMIT = 20` frames/tick
- Recovery flag auto-clears when frame gap ≤ `redundantFrameCount`, hides the overlay.

**`NetClientBattle.ts`** — added `immediateReconnect()` method that bypasses the 3-second reconnection delay, resets counters, and connects immediately.

### Files Modified

- `assets/Game/Scripts/UI/Battle/Managers/BattleManager.ts` — lifecycle listeners, tiered recovery, dynamic burst limit
- `assets/Game/Scripts/Network/Battle/NetClientBattle.ts` — `immediateReconnect()` method

---

## RISK 2 — setInterval Input Capture Unreliable on Mobile (HIGH) ✅ RESOLVED

### Severity: 🔴 High | Likelihood on Mobile: High

### Status: ✅ **Fixed** — Input capture moved from `setInterval` to `update(dt)` accumulator.

### Problem (was)

Player input (joystick, skills) was captured and sent to the server on a `setInterval(50ms)` timer. On mobile, `setInterval(50ms)` is **not guaranteed** to fire at 20 Hz:
- Budget Android phones under CPU thermal throttling: may fire only 5-10 times/sec
- iOS can throttle timers in low-power mode
- Any GC pause > 50ms skips an interval

### Fix Applied

Input capture now uses a wall-clock accumulator driven by the render loop in `BattleManager.update(dt)`:

```typescript
// BattleManager.ts — update(dt)
if (BattleGlobal.battleMode == BattleMode.Battle) {
    this.inputAccMs += dtMs;
    if (this.inputAccMs >= NetConfig.frameTime) {
        this.inputAccMs -= NetConfig.frameTime;
        if (this.inputAccMs > NetConfig.frameTime) {
            this.inputAccMs = 0;  // Cap to avoid burst after long pause
        }
        BattleData.CapturePlayerOpts();
        this.frameSyncMonitor.onInputCapture();
    }
}
```

This guarantees input capture fires at the same cadence as frame processing, since `update()` always fires once per render frame regardless of timer throttling. The `FrameSyncMonitor` tracks the actual capture rate to verify it stays near 20/s.

### Remaining Optional Improvement

- **Buffer rapid input changes** — instead of overwriting `frameHandle`, queue important operations (skill casts) so they're never lost between capture intervals.

### Files Modified

- `assets/Game/Scripts/UI/Battle/Managers/BattleManager.ts` — moved `CapturePlayerOpts` into `update()`, removed `setInterval` timer

---

## RISK 3 — Accumulator Reset Causes Permanent Frame Drift (MEDIUM-HIGH) ✅ RESOLVED

### Severity: 🟠 Medium-High | Likelihood on Mobile: High (especially on cellular)

### Status: ✅ **Fixed** — Accumulator now capped to one frame instead of reset to zero.

### Problem (was)

When the client tried to process a frame but the server frame hadn't arrived yet, the entire accumulated time was **thrown away** (`this.logicTimeAccMs = 0`). On a 30fps device with 80ms network jitter, this caused ~49ms of permanent time loss per stall, compounding over the match.

### Fix Applied

```typescript
// BattleManager.ts — ChasingFrame()
if (!anyProcessed) {
    // Cap accumulator to at most one frame's worth of time instead
    // of resetting to zero.  Preserves partial progress so the next
    // tick can fire immediately once server data arrives.
    this.logicTimeAccMs = Math.min(this.logicTimeAccMs, frameTimeMs);
}
```

### Files Modified

- `assets/Game/Scripts/UI/Battle/Managers/BattleManager.ts` — changed accumulator reset to cap

---

## RISK 4 — Floating-Point Determinism Partially Addressed (MEDIUM) ✅ RESOLVED

### Severity: 🟡 Medium | Likelihood: Low-Medium

### Status: ✅ **Fixed** — All movement deltas rounded to integers before accumulation.

### Problem (was)

Movement computed `logicX = position + (rockerSpeed × speed × factor)` using IEEE 754 floats. On different ARM chip implementations, intermediate results could differ by ±1 ULP, causing logic positions to drift across devices.

### Fix Applied

**`Creature.ts` — `Move()` method:**
```typescript
// Both normal and prediction-state paths now round to integer
logicX = Math.round(this.logicPosition.x + (rockerSpeedVo.x * speed * NetConfig.speedFactor));
logicZ = Math.round(this.logicPosition.z + (rockerSpeedVo.y * speed * NetConfig.speedFactor));
```

**`Bullet.ts` — `Move()` method:**
```typescript
this.positionX += Math.round(rockerSpeedVo.x * speed * NetConfig.speedFactor);
this.positionZ += Math.round(rockerSpeedVo.y * speed * NetConfig.speedFactor);
```

### Notes

- Authoritative frames still carry integer position corrections (`optValue2-4`), providing periodic re-sync.
- AI characters now also produce integer positions, eliminating cross-device drift.
- Collision detection still uses float math but is read-only and doesn't affect authoritative positions.

### Files Modified

- `assets/Game/Scripts/UI/Battle/Enities/Creature.ts` — `Move()` integer rounding
- `assets/Game/Scripts/UI/Battle/Models/Bullet.ts` — `Move()` integer rounding

---

## RISK 5 — Seeded Random Never Synced or Saved (MEDIUM) ✅ RESOLVED

### Severity: 🟡 Medium | Likelihood: Medium

### Status: ✅ **Fixed** — Seed is now persisted, restored on recovery, and synced from server.

### Problem (was)

1. `RandomUtil.seed` defaults to `5` but match seed comes from the server (`room.randomSeed`).
2. If a client recovered from a crash with no cached state, it would replay frames with the wrong initial seed.
3. `StateHandleManager.recordAllState()` already saved the seed, but the fallback path (no state record) didn't restore it.

### Fix Applied

**Seed persistence:**
- `LocalStorageUtil.matchRandomSeedKey` added to persist the server-provided seed.
- All battle entry points (`MatchService`, `RoomService`, `UIMain`) now persist the initial seed to LocalStorage.

**Seed restoration in `BattleManager`:**
- With state record: `rollbackAllState()` restores the seed (already existed).
- Without state record: reads from `User.Instance.room.randomSeed`, falling back to the persisted `matchRandomSeedKey`.

**Cleanup:**
- `matchRandomSeedKey` is cleared on game settlement in both `BattleManager` and `UIBattle`.

### Files Modified

- `assets/Game/Scripts/Utils/LocalStorageUtil.ts` — added `matchRandomSeedKey`
- `assets/Game/Scripts/Services/MatchService.ts` — persist seed on match start
- `assets/Game/Scripts/Services/RoomService.ts` — persist seed on room join
- `assets/Game/Scripts/UI/UIMain.ts` — persist seed on local battle start
- `assets/Game/Scripts/UI/Battle/Managers/BattleManager.ts` — restore seed on recovery, clear on settlement
- `assets/Game/Scripts/UI/Battle/UIBattle.ts` — clear seed on exit

---

## RISK 6 — Unbounded Memory Growth of Frame Data (MEDIUM) ✅ RESOLVED

### Severity: 🟡 Medium | Likelihood: High on budget devices

### Status: ✅ **Fixed** — Frame data is now pruned on both client and server; caching optimised.

### Problem (was)

Neither client nor server removed old frame data during a match. For a 15-minute game that's 18,000 frames kept in memory. Client also JSON-serialized all frames every 1.5 seconds, causing GC spikes on budget devices.

### Fix Applied

**Client (`BattleData.ts`):**
- `pruneOldFrames()`: removes frames older than `executeFrameId - 600` (keeps ~30s window for repair). Also prunes old prediction frames.
- `shouldPrune(frameId)`: returns true every 200 frames (~10s) to trigger pruning.
- Called from `BattleManager.OnHandlerFrame()` after each frame is processed.
- `cacheFrame()` optimised: frequency reduced from every 30 frames (1.5s) to every 100 frames (5s); only serializes frames within the prune window instead of the entire history.

**Server (`Room.java`):**
- `pruneOldFrames()`: removes entries from `frameHandles` ConcurrentHashMap where frameId < `currentFramId - 600`.
- Called from `BattleRoomThread` game loop every 200 frames.

### Files Modified

- `assets/Game/Scripts/UI/Battle/Utils/BattleData.ts` — `pruneOldFrames()`, `shouldPrune()`, optimised `cacheFrame()`
- `assets/Game/Scripts/UI/Battle/Managers/BattleManager.ts` — call pruning from `OnHandlerFrame()`
- `Server/BattleServer/src/main/java/com/game/models/Room.java` — `pruneOldFrames()`
- `Server/BattleServer/src/main/java/com/game/thread/BattleRoomThread.java` — call pruning from game loop

---

## RISK 7 — Reconnection Drops All Input, Slow Recovery (MEDIUM) ✅ RESOLVED

### Severity: 🟡 Medium | Likelihood: Medium on cellular networks

### Status: ✅ **Fixed** — Exponential backoff, message buffering, and faster heartbeat detection.

### Problem (was)

1. Reconnection used a flat 3s delay between retries (up to 7×3 = 21s downtime).
2. All input during disconnection was silently dropped — no buffering.
3. Server heartbeat checked every 30s, marking offline after 60s of silence.

### Fix Applied

**`NetClientBase.ts`** — Exponential backoff: 500ms → 1s → 2s → 4s → 8s (capped). First reconnect attempt now fires in 500ms instead of 3000ms.

**`NetClientBattle.ts`** — Message buffer:
- Non-heartbeat messages are buffered (up to 100) during disconnection instead of being silently dropped.
- On `onSocketOpen()`, all buffered messages are flushed immediately.

**`ScheduleTask.java`** — Faster detection:
- Heartbeat check interval: 30s → 10s.
- Offline threshold: 60s → 20s.
- Server stops wasting bandwidth on dead sockets 3× faster.

**Note:** `immediateReconnect()` (added in RISK 1 fix) already handles the `EVENT_SHOW` case.

### Files Modified

- `assets/Game/Scripts/Network/NetClientBase.ts` — exponential backoff
- `assets/Game/Scripts/Network/Battle/NetClientBattle.ts` — message buffer + flush on reconnect
- `Server/BattleServer/src/main/java/com/game/spring/ScheduleTask.java` — faster heartbeat

---

## RISK 8 — Server Frame Rate Drift (LOW-MEDIUM) ✅ RESOLVED

### Severity: 🟢 Low-Medium | Likelihood: Always present

### Status: ✅ **Fixed** — Compensating sleep pattern applied.

### Problem (was)

The main game loop did `Thread.sleep(50)` *before* the work, so the actual frame period was `50ms + work time`. Over a 15-minute game the clock drifted ~4% slow.

### Fix Applied

```java
// BattleRoomThread.java — main game loop
long frameStartNs = System.nanoTime();
// ... do work (setFrameData, broadcast, etc.) ...
long elapsedMs = (System.nanoTime() - frameStartNs) / 1_000_000;
long sleepMs = Math.max(0, Constant.FPS - elapsedMs);
if (sleepMs > 0) {
    Thread.sleep(sleepMs);
}
```

### Files Modified

- `Server/BattleServer/src/main/java/com/game/thread/BattleRoomThread.java` — compensating sleep

---

## RISK 9 — No Frame Validation / Anti-Cheat on Server (HIGH for security) ✅ RESOLVED

### Severity: 🔴 High (security) | Likelihood: N/A (exploitable by any motivated player)

### Status: ✅ **Fixed** — Token validation re-enabled; frame handle validation added.

### Problem (was)

1. Token validation was commented out — any socket could send messages.
2. Server blindly accepted any frame operation (unknown opt types, out-of-range values, unlimited ops/frame, handGameOver at will).

### Fix Applied

**`MessageDispatch.java`** — Token validation re-enabled:
- If both the channel token and user token are present but don't match, the request is rejected with `AuthType.TokenInvalid`.

**`BattleServiceImpl.java`** — Frame handle validation:
- **Unknown opt type check**: rejects any operation not in `EnumUtil.OptType`.
- **Per-user rate limit**: max 6 operations per user per frame (via `Room.getUserOpsThisFrame()`).
- **Value range check**: all `optValue1–5` must be within `[-100,000, 100,000]`.
- **handGameOver guard**: rejected if `room.isGameOver` is already true.
- All violations are logged with `[AntiCheat]` prefix.

**`Room.java`** — `getUserOpsThisFrame(userId)` helper counts existing ops for a user in the current frame.

### Files Modified

- `Server/BattleServer/src/main/java/com/game/network/MessageDispatch.java` — re-enabled token validation
- `Server/BattleServer/src/main/java/com/game/service/impl/BattleServiceImpl.java` — frame validation logic
- `Server/BattleServer/src/main/java/com/game/models/Room.java` — `getUserOpsThisFrame()` helper

---

## Summary Risk Matrix

| # | Risk | Severity | Likelihood | Impact | Fix Complexity |
|---|------|----------|------------|--------|----------------|
| 1 | ~~No background/foreground handling~~ | ✅ Resolved | — | — | — |
| 2 | ~~`setInterval(50ms)` input unreliable~~ | ✅ Resolved | — | — | — |
| 3 | ~~Accumulator reset loses time~~ | ✅ Resolved | — | — | — |
| 4 | ~~Float math in movement~~ | ✅ Resolved | — | — | — |
| 5 | ~~Random seed not synced/saved~~ | ✅ Resolved | — | — | — |
| 6 | ~~Unbounded frame data + JSON serialize~~ | ✅ Resolved | — | — | — |
| 7 | ~~Reconnection drops input, slow~~ | ✅ Resolved | — | — | — |
| 8 | ~~Server frame rate drift~~ | ✅ Resolved | — | — | — |
| 9 | ~~No frame validation (security)~~ | ✅ Resolved | — | — | — |

---

## Recommended Fix Priority

### Phase 1 — Critical (Do First)
1. **RISK 1**: ~~Add `EVENT_SHOW` / `EVENT_HIDE` handlers with aggressive frame recovery~~ ✅ Done
2. **RISK 2**: ~~Move input capture into `update(dt)` with accumulator~~ ✅ Done
3. **RISK 3**: ~~Change accumulator reset to cap instead of zero~~ ✅ Done

### Phase 2 — Important
4. **RISK 8**: ~~Server compensating sleep (simple fix, big correctness gain)~~ ✅ Done
5. **RISK 6**: ~~Frame data pruning and async serialization~~ ✅ Done
6. **RISK 7**: ~~Faster reconnection with exponential backoff and message buffering~~ ✅ Done

### Phase 3 — Hardening
7. **RISK 9**: ~~Server-side frame validation and anti-cheat~~ ✅ Done
8. **RISK 5**: ~~Save/restore random seed in state cache~~ ✅ Done
9. **RISK 4**: ~~Integer-only movement arithmetic in logic layer~~ ✅ Done

---

## TOOL — FrameSyncMonitor (Performance Checker)

> **File:** `assets/Game/Scripts/UI/Battle/Managers/FrameSyncMonitor.ts`  
> **Added:** 2026-02-09

A lightweight, always-on performance monitor that tracks real-world frame synchronization timing and logs a summary to the console every 5 seconds.

### What It Tracks

| Section | Metrics |
|---|---|
| **Render Loop** | FPS, `dt` avg / min / max (ms), count of render frames where `dt > 50ms` |
| **Logic Frames** | Logic FPS (expected 20), per-frame processing time avg / min / max (ms), overrun count (single `OnHandlerFrame` took > 50ms), max batch size per tick |
| **Frame Gap** | Avg & max `newFrameId − executeFrameId`, current `handleFrameId` / `executeFrameId` / `newFrameId` |
| **Catch-up & Stalls** | Mild / heavy catch-up events, accumulator resets (server data missing), no-frame-data events |
| **Input Capture** | Actual capture rate per second (expected 20/s) |
| **Flags** | `isChasingFrame`, `isNormalPlay`, `isStandalone`, `isGameEnd` |

### Integration Points in BattleManager

```
update(dt)
  ├─ frameSyncMonitor.onRenderFrame(dtMs)          — every render frame
  ├─ frameSyncMonitor.onInputCapture()              — each time input is captured
  └─ ChasingFrame(dtMs)
       ├─ frameSyncMonitor.onLogicFrameStart()      — before OnHandlerFrame()
       ├─ frameSyncMonitor.onLogicFrameEnd()        — after OnHandlerFrame()
       ├─ frameSyncMonitor.onNoFrameData()          — when server frame is missing
       └─ frameSyncMonitor.onLogicFramesProcessed() — end of frame loop
```

### Runtime Control

```typescript
// Toggle on/off (enabled by default)
BattleManager.Instance.frameSyncMonitor.enabled = false;

// Change log interval (default 5 seconds)
BattleManager.Instance.frameSyncMonitor.logIntervalSec = 3;

// Get a snapshot object for on-screen UI or external tooling
const snap = BattleManager.Instance.frameSyncMonitor.getSnapshot();
// snap.renderFps, snap.logicFps, snap.maxLogicFrameMs, snap.frameGap, ...
```

### Example Console Output

```
[FrameSyncMonitor] ═══════════════════════════════════════
  Window: 5.0s
  ── Render Loop ──
    FPS:          59.8
    dt (ms):      avg=16.7  min=14.2  max=33.1
    dt > 50ms:  0 times (lifetime: 0)
  ── Logic Frames ──
    Logic FPS:    20.0 / 20 expected
    Process (ms): avg=1.23  min=0.41  max=4.87
    > 50ms:     0 overruns (lifetime: 0)
    Batch max:    1 frames/tick
  ── Frame Gap ──
    Server-Client gap:  avg=1.2  max=3
    handleFrameId:      1204
    executeFrameId:     1202
    newFrameId:         1204
  ── Catch-up & Stalls ──
    Mild catch-ups:     0
    Heavy catch-ups:    0 (lifetime: 0)
    Acc resets (stalls): 0
    No frame data:      0
  ── Input ──
    Capture rate:  20.0/sec (expected 20)
  ── Flags ──
    isChasingFrame: false
    isNormalPlay:   true
    isStandalone:   false
    isGameEnd:      false
═══════════════════════════════════════════════════════════
```

### How to Read the Output

| Metric | Healthy | Warning | Action |
|---|---|---|---|
| Render FPS | ≥ 30 | < 20 | Profile render pipeline |
| Logic FPS | ~20 | < 18 or > 22 | Check accumulator & frame data arrival |
| dt max | < 50ms | > 100ms | GC pressure or heavy work on main thread |
| Logic overruns | 0 | > 0 | Specific `OnHandlerFrame` is too expensive |
| Frame gap avg | 0–2 | > 5 | Network latency; check catch-up modes |
| Frame gap max | < 10 | ≥ 50 | Heavy catch-up triggered; check background/stall |
| Heavy catch-ups | 0 | > 0 | Investigate cause (background, network, GC) |
| Acc resets | 0 | frequent | Server frames arriving late (see RISK 3) |
| Input capture rate | ~20/s | < 15/s | Render FPS too low or accumulator issue |

