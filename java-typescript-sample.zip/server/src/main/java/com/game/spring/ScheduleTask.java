package com.game.spring;

import java.util.List;

import javax.annotation.PostConstruct;

import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.scheduling.annotation.Scheduled;

import com.game.manager.ChatManager;
import com.game.manager.RoomManager;
import com.game.manager.UserManager;
import com.game.models.User;

@Configuration      //1.主要用于标记配置类，兼备Component的效果。
@EnableScheduling   // 2.开启定时任务
public class ScheduleTask {
	
//	/**
//	 * 更新配置
//	 */ 
//    @Scheduled(cron = "0 */5 * * * ?")
//    private void updateConfig() {
//    	Set<Object> keys=PropertyUtil.keys();
//    	for (Object key : keys) {
//    		if(key==null) {
//    			continue;
//    		}
//    		String keyStr=key.toString();
//    		if (keyStr.equals("hall.service")) {  //大厅服务
//    			
//			}
//		}
//    }
//    


	 /**
     * 每2小时执行
     */
    @Scheduled(cron = "0 0 0/2 * * ?")
    private void timerExecute2() {
        //清理聊天数据
        ChatManager.Instance.ClearChatMessage();
        //清理超时房间
        RoomManager.Instance.ClearTimeOutRoom();
    }
	
	/**
	 * 心跳检测 （每隔10秒执行一次 — was 30s, reduced for RISK 7）
	 */ 
   @Scheduled(cron = "*/10 * * * * ? ")
   private void heartBeatCheck() {
	   List<User> allUserList = UserManager.Instance.getAllUser();
	   this.heartBeatHeadle(allUserList);
	   
   }
   
   private void heartBeatHeadle(List<User> users) {
	   for (User user : users) {
		   if(user.lastPacketReceiveTime == 0) {
			   continue;
		   }
		   if(System.currentTimeMillis() - user.lastPacketReceiveTime > 20*1000) {  //大于20秒 (was 60s, reduced for RISK 7)
			   user.setOnline(false);
			   user.lastPacketReceiveTime = 0;
		   }else {  //小于20秒
			   user.setOnline(true);
		   }
	   }
   }
	
    /**
     * 启动执行
     */
    @PostConstruct
    public void init(){ 
//      this.updateConfig();
    	this.heartBeatCheck();
    	
    }
}