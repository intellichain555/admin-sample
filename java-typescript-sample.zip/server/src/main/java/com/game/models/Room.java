package com.game.models;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.game.enums.EnumUtil;
import com.game.enums.UserStatus;
import com.game.manager.DataManager;
import com.game.manager.RoomManager;
import com.game.proto.Message.FrameHandle;
import com.game.proto.Message.RepairFrame;
import com.game.proto.Message.UserFrameHandle;
import com.game.thread.BattleRoomThread;
import com.game.util.CachedThreadPoolUtil;

public class Room {
	private static Logger logger = LoggerFactory.getLogger(Room.class);
    public int id; // 房间id
    private Queue<User> users; // 用户集合
    public long createTime = 0; // 创建时间
    public int loadResOverMs = 15000; //加载资源超时15秒

    // 帧操作数据 key:帧id value：key:用户id value：帧操作
    public Map<Integer, Map<Integer, UserFrameHandle>> frameHandles = new ConcurrentHashMap<>();
    public int currentFramId; // 当前帧号
    public boolean isCreateThread = false; // 是否创建线程
    public boolean isGameOver = false; // 是否游戏结束
    public boolean isGameTimeOutOver = false; // 是否游戏超时结束
    public int overFramId = -1; // 结束帧号
    public boolean isStartGame = false; //是否开始游戏

    private boolean isAllUserLoadSucess = false; // 是否所有用户资源都加载成功
    public String biFen = "";  //比分

    public int peopleNum = 0;  //人数
    public boolean isStandaloneFlag = false; //是否单机


    public Room(int id, Queue<User> users) {
        super();
        this.id = id;
        this.users = users;
        this.createTime = System.currentTimeMillis();
        this.peopleNum = users.size();
        this.setIsStandalone();  //设置对局是否单机
    }
    
    /**
     * 设置对局是否单机
     */
    public void setIsStandalone() {
    	if(this.users != null) {
    		int noRobotCount = 0;  //非机器人数量
    		for (User user : users) {
				if(!user.isRobot) {  //非机器人
					noRobotCount++;
				}
			}
    		if(noRobotCount <= 1) {  
    			isStandaloneFlag = true;
    			System.out.println(this.id+"，单机模式====================================================================");
    		}else {
    			System.out.println(this.id+"，联机模式====================================================================");
    		}
    	}
    }


    /**
     * 添加用户
     *
     * @param user
     */
    public boolean addUser(User user) {
        User user2 = this.ExistUser(user.id);
        if (user2 == null) {
            this.users.add(user);
            this.peopleNum++;
            return true;
        }
        return false;
    }

    /**
     * 移除用户
     *
     * @param userId
     * @param isUpdatePeopleNum 是否更新人数
     * @return
     */
    public boolean removeUser(int userId, boolean isUpdatePeopleNum) {
        User user2 = this.ExistUser(userId);
        if (user2 != null) {
            this.users.remove(user2);
            if (isUpdatePeopleNum) {
                this.peopleNum--;
            }
            return true;
        }
        return false;
    }

    /**
     * 是否存在用户
     *
     * @param userId
     * @return
     */
    public User ExistUser(int userId) {
        for (User user2 : users) {
            if (user2.id == userId) {
                return user2;
            }
        }
        return null;
    }

    /** Number of past frames to keep for repair (RISK 6 fix) */
    private static final int PRUNE_WINDOW = 600;
    /** How often to run pruning (every N frames) */
    private static final int PRUNE_INTERVAL = 200;

    /**
     * Prune old frame data to prevent unbounded memory growth (RISK 6).
     * Called periodically from the game loop.
     */
    public void pruneOldFrames() {
        int cutoff = currentFramId - PRUNE_WINDOW;
        if (cutoff <= 0) return;

        int pruned = 0;
        var it = frameHandles.entrySet().iterator();
        while (it.hasNext()) {
            var entry = it.next();
            if (entry.getKey() < cutoff) {
                it.remove();
                pruned++;
            }
        }
        if (pruned > 0) {
            logger.debug("Pruned {} old frames (cutoff={}, remaining={})", pruned, cutoff, frameHandles.size());
        }
    }

    /**
     * Get how many operations a user has already submitted for the current frame.
     * Used for per-user rate limiting (RISK 9 anti-cheat).
     */
    public int getUserOpsThisFrame(int userId) {
        Map<Integer, UserFrameHandle> userFrameHandleMap = frameHandles.get(currentFramId);
        if (userFrameHandleMap == null) return 0;
        UserFrameHandle ufh = userFrameHandleMap.get(userId);
        if (ufh == null) return 0;
        return ufh.getFrameHandlesCount();
    }

    /**
     * 添加用户帧操作
     *
     * @param userId      用户id
     * @param frameHandle 帧操作对象
     */
    public void AddUserFrameHandle(int userId, FrameHandle frameHandle) {    	
    	Map<Integer, UserFrameHandle> userFrameHandleMap = frameHandles.computeIfAbsent(currentFramId, k -> new HashMap<>());
    	UserFrameHandle userFrameHandle = userFrameHandleMap.get(userId);
    	if(userFrameHandle == null) {
    		UserFrameHandle.Builder userFrameHandleBuilder = UserFrameHandle.newBuilder();
    		userFrameHandleBuilder.addFrameHandles(frameHandle);
    		userFrameHandleMap.put(userId, userFrameHandleBuilder.build());
    	}else {
    		//效验当前帧是否已经存在当前操作了
    		if (userFrameHandle.getFrameHandlesCount() > 0) {
				List<FrameHandle> frameHandles = userFrameHandle.getFrameHandlesList();
				for (int i = 0; i < frameHandles.size(); i++) {
					FrameHandle fh = frameHandles.get(i);
					if (fh.getOpt() == frameHandle.getOpt()) {
						return;
					}
				}
			}
    		
    		UserFrameHandle.Builder userFrameHandleBuilder = userFrameHandle.toBuilder();
    		userFrameHandleBuilder.addFrameHandles(frameHandle);
    		userFrameHandleMap.put(userId, userFrameHandleBuilder.build());
    	}            	
    }
    
    /**
     * 效验所有用户资源是否加载成功
     *
     * @return
     */
    public synchronized boolean ValidateAllUserLoadSucess(User currentUser) {
        boolean isLoadSucess = true;
        if (!currentUser.isOneEnter) {  //非第一次进入，只需要看自己的进度
            isLoadSucess = currentUser.percent >= 100;
        } else {  //第一次进入，看是否超时，然后看其它玩家的进度
            // 判断是否超时
            if (!this.getMatchOverMsFlag()) { // 未超时
                // 判断用户资源是否加载成功
                for (User user : users) {
                    if (!user.isRobot && user.percent < 100) {
                        isLoadSucess = false;
                        break;
                    }
                }
            }
        }

//		this.isAllUserLoadSucess = isLoadSucess;
        return isLoadSucess;
    }

    /**
     * 判断匹配是否超时
     *
     * @return
     */
    private boolean getMatchOverMsFlag() {
        // 判断是否超时
        long jg = System.currentTimeMillis() - this.createTime;
        return jg >= this.loadResOverMs;
    }

    /**
     * 效验游戏是否结束
     *
     * @return
     */
    public synchronized void ValidateGameIsOver() {
        int gameOverNum = 0; // 游戏结束人数
        for (User user : users) {
            if (user.userStatus == UserStatus.GameOver) {
                gameOverNum++;
            }
        }
        // 游戏正常结束
        if (gameOverNum >= DataManager.gameConfig.overNum && !this.isGameOver) {
            RoomManager.Instance.GameNormalOver(id);
        }
    }

    /**
     * 游戏超时结束
     */
    public void GameTimeOutOver() {
        RoomManager.Instance.GameTimeOutOver(id);
    }

    /**
     * 获取范围帧数据
     */
    public void GetRangeFrame(int startFrame, int endFrame, List<RepairFrame> repairFrameList) {
//		if (endFrame == -1) {  //查询所有帧
//			endFrame=currentFramId-1;
//		}
        // 补帧集合
        for (int frame = startFrame; frame <= endFrame; frame++) {
            Map<Integer, UserFrameHandle> userFrameHandleMap = frameHandles.get(frame);
            // 补帧对象
            RepairFrame.Builder repairFrameBuilder = RepairFrame.newBuilder();
            repairFrameBuilder.setFrame(frame);
                        
            if (userFrameHandleMap != null) {
            	repairFrameBuilder.putAllUserFrameHandleMap(userFrameHandleMap);          	
            }
            repairFrameList.add(repairFrameBuilder.build());
        }
    }

    public void Update(int millisecond) {
        // 超时或资源都加载成功并且都未开启线程
        if (!this.isCreateThread /*&& (this.getMatchOverMsFlag() || this.isAllUserLoadSucess)*/) {
            this.isCreateThread = true;

            if(!isStandaloneFlag) {  //非单机          	
            	// 获取线程池对象
            	ExecutorService cachedThreadPool = CachedThreadPoolUtil.instance();
            	cachedThreadPool.execute(new BattleRoomThread(this));
            }
        }
     // 效验是否游戏是否超时
        if (this.IsTimeOut()) { // 超时
			logger.error("房间id:" + this.id + "，游戏超时结束");
			this.GameTimeOutOver();
			this.overFramId = this.currentFramId;
			return;
		}
    }

    public Queue<User> getUsers() {
        return users;
    }

    /**
     * 是否已超时
     *
     * @return
     */
    public boolean IsTimeOut() {
        long jg = System.currentTimeMillis() - this.createTime;
        if (jg > DataManager.gameConfig.gameOverMs * 60 * 1000) {
            return true;
        }
        return false;
    }
}
