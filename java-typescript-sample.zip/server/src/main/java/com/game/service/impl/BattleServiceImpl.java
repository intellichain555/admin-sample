package com.game.service.impl;

import java.net.InetSocketAddress;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.game.enums.EnumUtil.ChatRoomType;
import com.game.enums.UserStatus;
import com.game.enums.UserType;
import com.game.manager.ChatManager;
import com.game.manager.ConnectionManager;
import com.game.manager.RoomManager;
import com.game.manager.UserManager;
import com.game.models.Room;
import com.game.models.User;
import com.game.network.NetConnection;
import com.game.proto.Message.AuthType;
import com.game.proto.Message.AuthenticationFailResponse;
import com.game.proto.Message.ChatChannel;
import com.game.proto.Message.ChatMessage;
import com.game.proto.Message.ChatRequest;
import com.game.proto.Message.FrameHandle;
import com.game.proto.Message.GameOverRequest;
import com.game.proto.Message.HeartBeatRequest;
import com.game.proto.Message.HeartBeatResponse;
import com.game.proto.Message.NTeamInfo;
import com.game.proto.Message.NetMessageResponse;
import com.game.proto.Message.OutLiveRequest;
import com.game.proto.Message.OutLiveResponse;
import com.game.proto.Message.PercentForward;
import com.game.proto.Message.PercentForwardResponse;
import com.game.proto.Message.RepairFrameRequest;
import com.game.proto.Message.SetTokenRequest;
import com.game.proto.Message.StartBattleRequest;
import com.game.proto.Message.StartBattleResponse;
import com.game.proto.Message.TeamInfoLookRequest;
import com.game.proto.Message.TeamInfoLookResponse;
import com.game.proto.Message.UploadBiFenRequest;
import com.game.proto.Message.UserInfoResponse;
import com.game.enums.EnumUtil.OptType;
import com.game.service.BattleService;
import com.game.util.Constant;
import com.game.vo.ResultInfo;

import io.netty.buffer.ByteBuf;
import io.netty.buffer.Unpooled;
import io.netty.channel.ChannelHandlerContext;
import io.netty.channel.socket.DatagramPacket;

@Service
public class BattleServiceImpl implements BattleService {
    private static Logger logger = LoggerFactory.getLogger(BattleServiceImpl.class);

    // ── Valid operation type IDs for frame validation (RISK 9) ──────
    private static final java.util.Set<Integer> VALID_OPT_TYPES = new java.util.HashSet<>();
    static {
        for (OptType ot : OptType.values()) {
            VALID_OPT_TYPES.add(ot.id);
        }
    }
    /** Max operations a single user can submit per frame (anti-spam, RISK 9) */
    private static final int MAX_OPS_PER_USER_PER_FRAME = 6;
    /** Reasonable value range for optValue1-5 (RISK 9) */
    private static final int VALUE_RANGE_MIN = -100_000;
    private static final int VALUE_RANGE_MAX =  100_000;

    /**
     * 帧操作 — with server-side validation (RISK 9)
     */
    @Override
    public void OnFrameHandle(NetConnection connection, FrameHandle frameHandle) {
        User user = connection.user;
        Room room = RoomManager.Instance.rooms.get(user.roomId);
        if (room == null) {
            return;
        }
        // --- Validation (RISK 9) ---
        // 1. Reject unknown operation types
        if (!VALID_OPT_TYPES.contains(frameHandle.getOpt())) {
            logger.warn("[AntiCheat] User {} sent unknown opt type: {}", user.id, frameHandle.getOpt());
            return;
        }
        // 2. Rate-limit: reject if user already has too many ops this frame
        if (room.getUserOpsThisFrame(user.id) >= MAX_OPS_PER_USER_PER_FRAME) {
            logger.warn("[AntiCheat] User {} exceeded max ops/frame ({})", user.id, MAX_OPS_PER_USER_PER_FRAME);
            return;
        }
        // 3. Value range check on opt values
        if (!isValueInRange(frameHandle.getOptValue1()) ||
            !isValueInRange(frameHandle.getOptValue2()) ||
            !isValueInRange(frameHandle.getOptValue3()) ||
            !isValueInRange(frameHandle.getOptValue4()) ||
            !isValueInRange(frameHandle.getOptValue5())) {
            logger.warn("[AntiCheat] User {} sent out-of-range opt values", user.id);
            return;
        }
        // 4. handGameOver can only be sent if game is NOT already over
        if (frameHandle.getOpt() == OptType.handGameOver.id && room.isGameOver) {
            logger.warn("[AntiCheat] User {} sent handGameOver after game already ended", user.id);
            return;
        }

        room.AddUserFrameHandle(user.id, frameHandle);
    }

    /** Check if a value is within the acceptable range */
    private boolean isValueInRange(int value) {
        return value >= VALUE_RANGE_MIN && value <= VALUE_RANGE_MAX;
    }

    /**
     * 进度转发
     */
    @Override
    public void OnPercentForward(NetConnection connection, PercentForward percentForward) {
        User user = connection.user;
        // 当前资源加载成功
//		if (percentForward.getPercent() >= 100) {
//			user.userStatus = UserStatus.resourcesLoadSucess;
//		}
        user.percent = percentForward.getPercent();
        // 将当前用户加载进度转发其它人
        Room room = RoomManager.Instance.rooms.get(user.roomId);
        if (room == null) {
            return;
        }

        PercentForwardResponse.Builder percentForwardBuilder = PercentForwardResponse.newBuilder();
        for (User u : room.getUsers()) {
            PercentForward.Builder pf = PercentForward.newBuilder();
            pf.setUserId(u.id);
            pf.setPercent(u.percent);
            percentForwardBuilder.addRoomUserPercents(pf);

        }
        percentForwardBuilder.setAllUserLoadSucess(room.ValidateAllUserLoadSucess(user));

        NetMessageResponse.Builder response = NetMessageResponse.newBuilder();
        response.setPercentForwardRes(percentForwardBuilder);

        if (user.userType == UserType.Game) {  //游戏中
            //转发房间所有玩家
            for (User u : room.getUsers()) {
                NetConnection conn = ConnectionManager.getConnection(u.id);
                if (conn == null) {
                    continue;
                }
                conn.send(response);
            }
        } else {  //观看直播者
            //转发给自己
            connection.send(response);
        }
    }

    /**
     * 游戏结束
     */
    @Override
    public void OnGameOver(NetConnection connection, GameOverRequest gameOverRequest) {
        User user = connection.user;
        user.userStatus = UserStatus.GameOver;
        Room room = RoomManager.Instance.rooms.get(user.roomId);
        if (room == null) {
            return;
        }
        room.ValidateGameIsOver(); // 效验游戏是否结束
    }

    /**
     * 补帧
     */
    @Override
    public void OnRepairFrame(NetConnection conn, RepairFrameRequest repairFrameRequest) {
        User user = conn.user;
        Room room = RoomManager.Instance.rooms.get(user.roomId);
        if (room == null) {
            return;
        }
        user.endMultipleFramesTime = System.currentTimeMillis() + Constant.multipleFramesTime;
        user.SetRepairFrame(repairFrameRequest.getStartFrame(), repairFrameRequest.getEndFrame(), false);
        user.RramingRepairFrame(room, conn, false); //分帧补帧
        conn.send();
        
        // 获取补帧数据
		/*List<RepairFrame> rangeFrameList = new ArrayList<>();
		room.GetRangeFrame(repairFrameRequest.getStartFrame(), repairFrameRequest.getEndFrame(), rangeFrameList);

		RepairFrameResponse.Builder repairFrameResponseBuilder = RepairFrameResponse.newBuilder();
		repairFrameResponseBuilder.addAllRepairFrames(rangeFrameList);
		NetMessageResponse2.Builder response = conn.getResponse();
		response.setRepairFrameRes(repairFrameResponseBuilder);*/
//		conn.send();
    }

    /**
     * 开始对战请求
     */
    @Override
    public void OnStartBattle(NetConnection conn, StartBattleRequest startBattleRequest) {
        User user = conn.user;
        user.userStatus = UserStatus.StartBattleReady;
        Room room = RoomManager.Instance.rooms.get(user.roomId);
        if (room != null && room.isStartGame) {
            NetMessageResponse.Builder message = conn.getResponse();
            message.setStartBattleRes(StartBattleResponse.newBuilder());
            conn.send();
        }
    }

    /**
     * 设置token请求
     */
    @Override
    public void OnSetToken(ChannelHandlerContext ctx, SetTokenRequest setTokenRequest) {
        ConnectionManager.addToToken(ctx, setTokenRequest.getToken());
    }

    /**
     * 鉴权失败响应
     */
    @Override
    public void OnAuthenticationFailResponse(ChannelHandlerContext ctx, InetSocketAddress sender, AuthType authType) {
        NetMessageResponse.Builder message = NetMessageResponse.newBuilder();
        AuthenticationFailResponse.Builder authenticationFailRes = AuthenticationFailResponse.newBuilder();
        authenticationFailRes.setAuthType(authType);
        message.setAuthenticationFailRes(authenticationFailRes);
        if (sender != null) {  //udp
            ByteBuf byteBufRes = Unpooled.copiedBuffer(message.build().toByteArray());
            ctx.writeAndFlush(new DatagramPacket(byteBufRes, sender));
        } else {
            ctx.writeAndFlush(message);
        }
    }

    @Override
    public void OnChat(NetConnection sender, ChatRequest chatRequest) {
        User user = sender.user;
//		NetMessageResponse2.Builder senderResponse = udpSender.getResponse();

        ChatMessage.Builder chatMessage = chatRequest.getChatMessage().toBuilder();
        chatMessage.setTime((int) (System.currentTimeMillis() / 1000));
//		ChatResponse.Builder senderChatResponseBuilder = ChatResponse.newBuilder();
        if (chatMessage.getChatChannel() == ChatChannel.RoomChat) {
            if (user.userType == UserType.Game) {
                chatMessage.setEnterLiveUserId(user.id);
            } else if (user.userType == UserType.Live) {
                chatMessage.setEnterLiveUserId(user.enterLiveUserId);
            }

            if (chatMessage.getChatRoomType() == ChatRoomType.Live_.id) { // 判断用户弹幕
                if (chatMessage.getEnterLiveUserId() == user.id) { //自己发送的消息
                    user.barrageCount++;
                } else if (chatMessage.getEnterLiveUserId() == user.enterLiveUserId) {  //进入别的玩家直播发送的消息
                    User u = UserManager.Instance.getOnlineUser(user.enterLiveUserId);
                    u.barrageCount++;
                }
            }

            ChatManager.Instance.AddChat(user, chatMessage.build());

            // 房间内玩家或粉丝（把管道内存在的房间消息刷出去）
            List<Integer> userIdList = RoomManager.Instance.GetRoomUserIds(user.roomId);
            if (userIdList != null && userIdList.size() > 0) {
                for (Integer userId : userIdList) {
                    NetConnection connection = ConnectionManager.getConnection(userId);
                    if (connection == null) {
                        continue;
                    }
                    connection.packet(true);
                }
            }
        }

//			    udpSender.send();
    }

    /**
     * 退出直播请求
     */
    @Override
    public void OnOutLive(NetConnection sender, OutLiveRequest outLiveRequest) {
        User user = sender.user;
        NetMessageResponse.Builder response = sender.getResponse();

        ResultInfo ret = RoomManager.Instance.OutLive(user);

        OutLiveResponse.Builder outLiveResponse = OutLiveResponse.newBuilder();
        outLiveResponse.setResult(ret.result).setErrormsg(ret.errormsg);
        response.setOutLiveRes2(outLiveResponse);
        sender.send();
    }

    /**
     * 上传比分请求
     */
    @Override
    public void OnUploadBiFen(NetConnection sender, UploadBiFenRequest uploadBiFenRequest) {
        User user = sender.user;
        RoomManager.Instance.UploadBiFen(user, uploadBiFenRequest.getBiFen());
    }

    /**
     * 队伍信息查看请求
     */
    @Override
    public void OnTeamInfoLook(NetConnection connection, TeamInfoLookRequest teamInfoLookRequest) {
        User user = connection.user;
        NetMessageResponse.Builder response = connection.getResponse();
        Room room = RoomManager.Instance.GetRoom(user.roomId);
        if (room == null) {
            return;
        }
        TeamInfoLookResponse.Builder teamInfoLookResponse = TeamInfoLookResponse.newBuilder();
        if (room != null) {
            for (User u : room.getUsers()) {
                NTeamInfo.Builder teamInfo = NTeamInfo.newBuilder();
                teamInfo.setUserId(u.id);
                teamInfo.setBarrageCount(u.barrageCount);
                teamInfoLookResponse.addTeamInfos(teamInfo);
            }
        }
        response.setTeamInfoLookRes2(teamInfoLookResponse);
        connection.send();
    }

    /**
     * 用户信息响应
     */
    @Override
    public void OnUserInfoResponse(int userId) {
        NetConnection connection = ConnectionManager.getConnection(userId);
        if (connection == null) {
            return;
        }
        NetMessageResponse.Builder response = connection.getResponse();
        UserInfoResponse.Builder userInfoResponse = UserInfoResponse.newBuilder();
        userInfoResponse.setLiveFenSiCount(connection.user.getLiveFenSiIdList().size());
        response.setUserInfoRes(userInfoResponse);
    }

    /**
     * 心跳响应
     */
    @Override
    public void heartBeat(NetConnection connection, HeartBeatRequest heartBeatRequest) {
    	NetMessageResponse.Builder response = connection.getResponse();
    	HeartBeatResponse.Builder heartBeatResponse = HeartBeatResponse.newBuilder();
    	response.setHeartBeatRes2(heartBeatResponse);
    	connection.send();
    }
}
