package com.game.network;

import java.net.InetSocketAddress;

import com.game.manager.ConnectionManager;
import com.game.manager.UserManager;
import com.game.models.User;
import com.game.proto.Message.AuthType;
import com.game.proto.Message.NetMessageRequest;
import com.game.service.BattleService;
import com.game.spring.SpringBeanUtil;

import io.netty.channel.ChannelHandlerContext;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

// 接收消息分发
public class MessageDispatch {
    private static Logger logger = LoggerFactory.getLogger(MessageDispatch.class);
    
    BattleService battleService;
    UserManager userManager;

    public MessageDispatch() {
        battleService = SpringBeanUtil.getBean(BattleService.class);
        userManager = UserManager.Instance;
    }

    public static MessageDispatch Instance = new MessageDispatch();

    public void receiveData(ChannelHandlerContext ctx, NetMessageRequest message, InetSocketAddress sender, boolean isBinaryFrame) {
        int userId = message.getUserId();
        User battleUser = userManager.users.get(userId);  //对战用户
        User liveUser = userManager.liveUsers.get(userId);  //直播用户
        if (battleUser != null) {
            battleUser.lastPacketReceiveTime = System.currentTimeMillis();
        }
        if (liveUser != null) {
            liveUser.lastPacketReceiveTime = System.currentTimeMillis();
        }

        //设置token请求
        if (message.hasSetTokenReq()) {
        	logger.info("设置token请求 老token="+ConnectionManager.getToken(ctx)+"，userId="+userId+
        			"，新token="+message.getSetTokenReq()+"，ip="+sender.getAddress().getHostAddress()+"，port="+sender.getPort());
            battleService.OnSetToken(ctx, message.getSetTokenReq());
            return;
        }
        if (battleUser == null && liveUser == null) {  //非法请求
            logger.info("非法请求 userId=" + userId);
            battleService.OnAuthenticationFailResponse(ctx, sender, AuthType.IllegalRequest);
            return;
        }
    	// Token validation (RISK 9 — re-enabled, was previously commented out)
    	//String token = ConnectionManager.getToken(ctx);  //管道token
    	String currentUserToken = battleUser != null ? battleUser.token : liveUser.token;  //用户token
    	if(token != null && currentUserToken != null && !token.equals(currentUserToken)) {
    		logger.warn("[AntiCheat] 鉴权失败，token无效 userId={}", userId);
    		battleService.OnAuthenticationFailResponse(ctx, sender, AuthType.TokenInvalid);
    		return;
    	}

        NetConnection conn = ConnectionManager.getConnection(userId);
        if (conn == null) {
            conn = new NetConnection(ctx, battleUser != null ? battleUser : liveUser, sender);
            ConnectionManager.addToConnection(userId, conn);
            if (liveUser != null) {
                conn.packet(true);
            }
        } else {
            conn.ctx = ctx;
            conn.udpSender = sender;
        }
        conn.isBinaryFrame = isBinaryFrame;

        //帧操作请求
        if (message.hasFrameHandle()) {
            battleService.OnFrameHandle(conn, message.getFrameHandle());
            return;
        }

        //补帧请求
        if (message.hasRepairFrameReq()) {
            battleService.OnRepairFrame(conn, message.getRepairFrameReq());
            return;
        }

        //进度转发请求
        if (message.hasPercentForward()) {
            battleService.OnPercentForward(conn, message.getPercentForward());
            return;
        }

        //游戏结束请求
        if (message.hasGameOverReq()) {
            battleService.OnGameOver(conn, message.getGameOverReq());
            return;
        }

        //开始对战请求
        if (message.hasStartBattleReq()) {
            battleService.OnStartBattle(conn, message.getStartBattleReq());
            return;
        }

        if (message.hasChatReq2()) {
            logger.info("收到聊天 请求");
            battleService.OnChat(conn, message.getChatReq2());
        }

        if (message.hasOutLiveReq2()) {
            logger.info("收到 退出直播请求");
            battleService.OnOutLive(conn, message.getOutLiveReq2());
            ;
        }

        if (message.hasUploadBiFenReq2()) {
            logger.info("收到 上传比分请求");
            battleService.OnUploadBiFen(conn, message.getUploadBiFenReq2());
            ;
        }

        if (message.hasTeamInfoLookReq2()) {
            logger.info("收到 队伍信息查看请求");
            battleService.OnTeamInfoLook(conn, message.getTeamInfoLookReq2());
        }

        if (message.hasHeartBeatReq()) {
//          logger.info("收到心跳 请求");
            battleService.heartBeat(conn, message.getHeartBeatReq());
        }

    }

}
