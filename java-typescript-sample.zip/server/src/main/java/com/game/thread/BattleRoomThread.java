package com.game.thread;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.game.enums.EnumUtil;
import com.game.enums.UserStatus;
import com.game.manager.ConnectionManager;
import com.game.models.Room;
import com.game.models.User;
import com.game.network.NetConnection;
import com.game.proto.Message.FrameHandle;
import com.game.proto.Message.FrameHandleResponse;
import com.game.proto.Message.NetMessageResponse;
import com.game.proto.Message.StartBattleResponse;
import com.game.proto.Message.UserFrameHandle;
import com.game.util.CachedThreadPoolUtil;
import com.game.util.Constant;
import com.game.util.GsonUtils;

/**
 * 对战房间线程
 *
 * @author Administrator
 */
public class BattleRoomThread extends Thread {
	private static Logger logger = LoggerFactory.getLogger(BattleRoomThread.class);

	private Room room;
	private FrameHandleResponse.Builder frameHandleResponseBuilder = FrameHandleResponse.newBuilder();
	private NetMessageResponse.Builder response = NetMessageResponse.newBuilder();

	public BattleRoomThread(Room room) {
		this.room = room;
	}

	/**
	 * 设置帧数据
	 */
	private void setFrameData() {
		frameHandleResponseBuilder.clear();

		// 当前帧所有用户的操作
		Map<Integer, UserFrameHandle> userFrameHandleMap = room.frameHandles.get(room.currentFramId);
		if (userFrameHandleMap != null) {
			frameHandleResponseBuilder.putAllUserFrameHandleMap(userFrameHandleMap);
		}
		frameHandleResponseBuilder.setFrame(room.currentFramId);
		response.setFrameHandleRes(frameHandleResponseBuilder);
	}

	public void run() {
		// 效验玩家是否都准备就绪
		int sleepTime = 500;
		int waitTime = 0;
		while (true) {
			try {
				Thread.sleep(sleepTime);
				waitTime += sleepTime;
				boolean noReadyFlag = false; // 是否存在未准备就绪玩家
				for (User user : room.getUsers()) {
					if (!user.isRobot && user.userStatus != UserStatus.StartBattleReady) {
						noReadyFlag = true;
						break;
					}
				}
				if (!noReadyFlag || waitTime > Constant.StartBattleMaxWaitTime) { // 不存在未准备就绪玩家 或 超时 ，则进入游戏
					break;
				}
			} catch (Exception e) {
				logger.error("异常", e);
			}
		}
		// 下发准备就绪包
		for (User user : room.getUsers()) {
			NetConnection conn = ConnectionManager.getConnection(user.id);
			if (conn == null) {
				continue;
			}
			NetMessageResponse.Builder message = conn.getResponse();
			message.setStartBattleRes(StartBattleResponse.newBuilder());
			conn.send();
		}

		room.isStartGame = true;
		// 开直播线程
		ExecutorService cachedThreadPool = CachedThreadPoolUtil.instance();
		cachedThreadPool.execute(new BattleRoomLiveThread(this.room));
		logger.info("房间线程启动 房间id=" + room.id);
		// 同步玩家操作
		// Use compensating sleep so the actual frame period stays close to
		// Constant.FPS (50ms) regardless of how long the work takes.
		// Previously the loop did Thread.sleep(50) + work, making the real
		// period ~52ms and causing the game clock to drift ~4% slow (RISK 8).
		while (true) {
			try {
				long frameStartNs = System.nanoTime();

				// 移动帧平滑处理
//				this.moveFrameSmoothHandle();
				// 设置帧数据
				this.setFrameData();
				// 下发房间用户当前帧所有用户的操作
				for (User user : room.getUsers()) {
					NetConnection conn = ConnectionManager.getConnection(user.id);
					if (conn == null) {
						continue;
					}
					boolean isComplete = user.RramingRepairFrame(room, conn, false); // 分帧补帧
					if(isComplete && System.currentTimeMillis() < user.endMultipleFramesTime) {  //已经完成补帧并且没有到达多发帧截止时间
						user.SetRepairFrame(room.currentFramId-1, room.currentFramId-Constant.multipleFramesCount, true);  //多发帧
					}
					conn.sendFrameHandleRes(response);
				}

				if (room.isGameOver) { // 游戏结束
					room.overFramId = room.currentFramId;
				}else {
					room.currentFramId++; // 帧号+1
					// Prune old frames to prevent unbounded memory growth (RISK 6)
					if (room.currentFramId % 200 == 0) {
						room.pruneOldFrames();
					}
				}
				if(room.isGameTimeOutOver) {  //游戏超时结束退出线程				
					return;
				}

				// Compensating sleep: subtract work time from the target period
				long elapsedMs = (System.nanoTime() - frameStartNs) / 1_000_000;
				long sleepMs = Math.max(0, Constant.FPS - elapsedMs);
				if (sleepMs > 0) {
					Thread.sleep(sleepMs);
				}
			} catch (Exception e) {
				logger.error("异常", e);
			}
		}
	}


	private int preperformanceFrameCount = 1; //推演帧数量
	/**
	 * 移动帧平滑处理(避免用户网络抖动带来的移动延迟抖动)
	 */
	private void moveFrameSmoothHandle() {
		// 可以在服务器响应的逻辑帧上做数据的复制，比如当前99帧是移动，当100帧服务器响应玩家空操作，那么我们设置100帧是99帧的移动操作，连续3个空操作则停止预演。
		Map<Integer, UserFrameHandle> userFrameHandleMap = room.frameHandles.get(room.currentFramId);
		for (User user : room.getUsers()) {
			int rockerCount = 0; // 摇杆操作次数
			if (userFrameHandleMap != null) {
				UserFrameHandle userFrameHandle = userFrameHandleMap.get(user.id);
				if (userFrameHandle != null && userFrameHandle.getFrameHandlesCount() > 0) {
					List<FrameHandle> frameHandles = userFrameHandle.getFrameHandlesList();
					for (int i = 0; i < frameHandles.size(); i++) {
						FrameHandle fh = frameHandles.get(i);
						if (fh.getOpt() == EnumUtil.OptType.Rocker.id) { // 摇杆
							rockerCount++;
							break;
						}
					}
				}
			}
			if (rockerCount < 1) { // 当前帧无摇杆操作
				user.noOptFrame++;
				if(user.noOptFrame > preperformanceFrameCount) {
					user.noOptFrame = 0;
					continue;
				}
				FrameHandle rockerFhPrev = this.getUserRockerFrameHandle(room.currentFramId - 1, user.id);  
				if(rockerFhPrev != null) { //上帧存在摇杆操作，则预演上帧移动
					room.AddUserFrameHandle(user.id, rockerFhPrev);
//					logger.info(room.currentFramId+"帧，用户id="+user.id+"，预演上帧移动操作");
//					FrameHandle rockerFhPrev2 = this.getUserRockerFrameHandle(room.currentFramId - 2, user.id);  
//					if(rockerFhPrev2 == null || rockerFhPrev.getOptValue1() == rockerFhPrev2.getOptValue1()) {  //上两帧角度相同，则说明没旋转，则预演						
//						room.AddUserFrameHandle(user.id, rockerFhPrev);
//					}
				}
			}else {
				user.noOptFrame = 0;
			}
		}
	}
	
	private FrameHandle getUserRockerFrameHandle(int framId, int userId) {
		FrameHandle frameHandle = null;
		Map<Integer, UserFrameHandle> userFrameHandleMap = room.frameHandles.get(framId);
		if (userFrameHandleMap != null) {
			UserFrameHandle userFrameHandle = userFrameHandleMap.get(userId);
			if (userFrameHandle != null && userFrameHandle.getFrameHandlesCount() > 0) {
				List<FrameHandle> frameHandles = userFrameHandle.getFrameHandlesList();
				for (int i = 0; i < frameHandles.size(); i++) {
					FrameHandle fh = frameHandles.get(i);
					if (fh.getOpt() == EnumUtil.OptType.Rocker.id) { // 摇杆
						frameHandle = fh;
					}
				}
			}
		}
		return frameHandle;
	}

}
