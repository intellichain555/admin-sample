---
name: Frame Work Distribution
overview: Implement a DeferredWorkManager system that spreads expensive visual/UI work (bullet effects, death animations, drop displays) across multiple frames to eliminate frame time spikes, while keeping deterministic logic immediate.
todos: []
isProject: false
---

# Frame Work Distribution - Performance Optimization Plan

## Architecture Overview

```mermaid
flowchart TB
    subgraph OnHandlerFrame [OnHandlerFrame Flow]
        A[Process Deferred Work] --> B[DoHandlerFrame]
        B --> C[Creature.LogicUpdate]
        C --> D[Queue new deferred work]
    end
    
    subgraph DeferredWorkManager [DeferredWorkManager]
        E[Effect Queue]
        F[Death Rendering Queue]
        G[Drops Queue]
    end
    
    C -->|enqueue| E
    C -->|enqueue| F
    C -->|enqueue| G
    A -->|process 2/frame| E
    A -->|process 1/frame| F
    A -->|process 3/frame| G
```



**Determinism boundary**: All HP changes, `IsDeath`, score, item data must remain immediate. Only visuals (effects, animations, UI drops) are deferred.

---

## Phase 1: DeferredWorkManager Skeleton

**New file**: `assets/Game/Scripts/UI/Battle/Managers/DeferredWorkManager.ts`

- Singleton pattern (matches existing managers like `CreatureManager`)
- Three queues: `effectQueue`, `deathRenderingQueue`, `dropsQueue`
- Config constants: `MAX_EFFECTS_PER_FRAME=2`, `MAX_DEATHS_PER_FRAME=1`, `MAX_DROPS_PER_FRAME=3`
- Methods: `enqueuePlayEffectBulletRealCheck()`, `enqueueDeathRendering()`, `enqueueShowDrops()`, `processDeferredWork()`, `clear()`
- Call `clear()` from [BattleManager.Clear()](assets/Game/Scripts/UI/Battle/Managers/BattleManager.ts) (line 147-157)

**Integration point**: In [BattleManager.OnHandlerFrame()](assets/Game/Scripts/UI/Battle/Managers/BattleManager.ts), call `DeferredWorkManager.Instance.processDeferredWork()` immediately after `BattleData.DoHandlerFrame()` (line 456) but only when `!isPrediction` (prediction frames skip creature logic and should not process deferred work).

---

## Phase 2: Bullet Effect Deferral (Highest Impact)

**Modify**: [Bullet.DelayCreate()](assets/Game/Scripts/UI/Battle/Models/Bullet.ts) (real-time path only, lines 128-135)

**Current code** (lines 128-135):

```typescript
this.skill.Owner.PlayEffectBulletRealCheck(EffectType.BulletRealCheck, this.skill.Define.BulletResource, this);
this.HitDamageEnemy();
```

**Change**: Replace direct call with:

```typescript
DeferredWorkManager.Instance.enqueuePlayEffectBulletRealCheck(this.skill.Owner, this.skill.Define.BulletResource, this);
this.HitDamageEnemy();
```

**EffectController dependency**: [EffectController.InitBulletRealCheck](assets/Game/Scripts/UI/Battle/Effects/EffectController.ts) (line 67) stores `this.bullet` and uses it every frame in `update()` to follow bullet position. The bullet reference remains valid when we process the queue next frame because the bullet is still alive. **Validation**: When processing, if `bullet.Stoped` is already true, skip creation (bullet ended before effect spawned).

**Queue item structure**: `{ owner: Creature, name: string, bullet: Bullet }` - pass full references; bullet is still in Skill.Bullets and valid.

---

## Phase 3: Death Rendering Split

**Modify**: [Creature.DoDeath()](assets/Game/Scripts/UI/Battle/Enities/Creature.ts) (lines 754-939)

**Split**:

- **Keep immediate** (deterministic): `IsDeath=true`, `AI.DoDeath`, `deathFrameId`, `surplusDieWaitFrame`, skill interrupt, deathReplaceNode, item/coin/exp via `AddAchievement`, score updates (`UpdateRedScore`/`UpdateBlueScore`), `renTou`/`zhenWang`, buff/tower/boss logic, `BuffMgr.RemoveBuff`, `RemoveCreature` (for IsPool)
- **Defer**: `deathRenderingHandle()` (line 934) - contains `SetAnim(Death)`, `UIDieInBattle.show`, `ShadowControl`, corpse sink

**Implementation**:

1. At line 934, replace `this.deathRenderingHandle()` with `DeferredWorkManager.Instance.enqueueDeathRendering(this)`
2. `deathRenderingHandle()` already exists as a private method - expose it or have DeferredWorkManager call a public `ExecuteDeathRendering()` that invokes the same logic
3. Queue item: `{ creature: Creature }` - validate `creature.IsDeath` before processing (sanity check)

**Note**: `ShowKillTips` (line 902) and `ShowDrops` (via AddAchievement) are handled separately. Death animation is the heaviest part of deathRenderingHandle.

---

## Phase 4: ShowDrops Separation

**Modify**: [Creature.AddAchievement()](assets/Game/Scripts/UI/Battle/Enities/Creature.ts) (lines 339-361)

**Current flow** (lines 356-359): After data update, immediately calls `UIWorldElementManager.Instance.ShowDrops(...)`.

**Change**:

1. Keep all data logic (AddItems, RefreshSportsItemsUI, achievementStrArr) immediate
2. Replace direct `ShowDrops` call with `DeferredWorkManager.Instance.enqueueShowDrops(deathCreature, itemId, count, this, isZhugongFlag)`
3. DeferredWorkManager will call `UIWorldElementManager.Instance.ShowDrops(...)` when processing

**Queue item**: `{ deathCreature, itemId, count, target, isZhugongFlag }`. Validate `deathCreature` and `target` are still valid (not destroyed) before processing. Capture creature world position if ShowDrops needs it - check [UIWorldElementManager.ShowDrops](assets/Game/Scripts/UI/Battle/UIWorldElementManager.ts).

---

## Phase 5: HitDamageEnemy Throttling (Optional / Later)

** complexity; recommend implementing after Phases 1-4 if time permits.**

**Modify**: [Bullet.HitDamageEnemy()](assets/Game/Scripts/UI/Battle/Models/Bullet.ts) (lines 336-374)

**Approach**: Add `hitProcessIndex` to Bullet, process max 2 creatures per LogicUpdate. Re-query `FindUnitsInRange()` each frame; use existing `hitMap` to skip already-hit creatures. On bullet `Stoped`, process any remaining hits immediately to preserve determinism.

**Edge cases**: Displacement bullets with `isStop`/`isTuiKai` have early-return logic; throttling must not break that. Consider only throttling the inner loop for non-displacement multi-hit bullets.

---

## Risk Mitigation


| Risk              | Mitigation                                                                                                  |
| ----------------- | ----------------------------------------------------------------------------------------------------------- |
| Visual desync     | EffectController needs live bullet ref - keep it; death/drops capture creature ref, validate before process |
| Queue overflow    | Add max queue size (e.g. 64), drop oldest when full for effects/drops; never drop deaths                    |
| Stale references  | Check `creature.IsValid` / `node.isValid` before processing; clear queues on BattleManager.Clear            |
| Determinism break | Only defer methods that do NOT touch HP, score, items data; AddAchievement data path stays sync             |


---

## Processing Order in processDeferredWork()

```typescript
processDeferredWork() {
  for (let i = 0; i < MAX_EFFECTS_PER_FRAME && effectQueue.length > 0; i++) { ... }
  for (let i = 0; i < MAX_DEATHS_PER_FRAME && deathRenderingQueue.length > 0; i++) { ... }
  for (let i = 0; i < MAX_DROPS_PER_FRAME && dropsQueue.length > 0; i++) { ... }
}
```

---

## Files to Create/Modify


| File                                   | Action                                                               |
| -------------------------------------- | -------------------------------------------------------------------- |
| `Managers/DeferredWorkManager.ts`      | Create (new)                                                         |
| `Managers/BattleManager.ts`            | Add processDeferredWork call, Clear integration                      |
| `Models/Bullet.ts`                     | Replace PlayEffectBulletRealCheck with enqueue                       |
| `Enities/Creature.ts`                  | DoDeath: defer deathRenderingHandle; AddAchievement: defer ShowDrops |
| `Managers/DeferredWorkManager.ts.meta` | Create (Cocos meta file if needed)                                   |


---

## Verification

- Replay/StateRecord: Existing [StateRecord](assets/Game/Scripts/UI/Battle/StateRecord/) and [IStateRollback](assets/Game/Scripts/UI/Battle/StateRecord/IStateRollback.ts) handle logic state; deferred queues are visual-only and not serialized
- Frame budget: Logic runs at 50ms/frame ([NetConfig.frameTime](assets/Game/Scripts/Network/NetConfig.ts)); render at 20fps (40ms) - deferral keeps render frame under budget
- Other callers: `PlayEffectBulletRealCheck` only from Bullet.DelayCreate; `DoDeath` from Creature.DoDamage and BattleGlobal (crystal); `ShowDrops` only from AddAchievement

