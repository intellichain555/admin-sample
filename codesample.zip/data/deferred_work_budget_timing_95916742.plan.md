---
name: Deferred work budget timing
overview: Reorder OnHandlerFrame to run logic first, measure its duration, and only call processDeferredWork when logic stays under DEFERRED_WORK_BUDGET_MS (15ms).
todos: []
isProject: false
---

# Deferred Work Budget Timing Plan

## Goal

Run logic update first in `OnHandlerFrame`, measure its duration, and call `processDeferredWork` only when logic stays under 15ms to avoid frame time spikes when both are heavy.

## File to Modify

`[assets/Game/Scripts/UI/Battle/Managers/BattleManager.ts](assets/Game/Scripts/UI/Battle/Managers/BattleManager.ts)`

## Changes

### 1. Add constant and timing variable

Add near other private fields (around line 68-70):

```typescript
private static readonly DEFERRED_WORK_BUDGET_MS = 15;  // Skip processDeferredWork if logic exceeded this
private logicPhaseStartMs: number = 0;
```

### 2. Reorder OnHandlerFrame logic (lines 462-492)

**Current order:** processDeferredWork -> birthPlaceWindHp -> creature loop -> SpawnMonManager.LogicUpdate

**New order:**

- Start timer
- birthPlaceWindHp
- creature LogicUpdate loop
- SpawnMonManager.LogicUpdate
- Measure duration
- Call processDeferredWork only if `logicDurationMs < DEFERRED_WORK_BUDGET_MS`

### 3. Specific edits

**Remove** the current `processDeferredWork()` call (line 464).

**Insert** timer start immediately after `DoHandlerFrame` / before birthPlaceWindHp:

```typescript
this.logicPhaseStartMs = performance.now();
```

**Insert** conditional processDeferredWork block immediately after `SpawnMonManager.Instance.LogicUpdate(frameId);`:

```typescript
const logicDurationMs = performance.now() - this.logicPhaseStartMs;
if (logicDurationMs < BattleManager.DEFERRED_WORK_BUDGET_MS) {
  DeferredWorkManager.Instance.processDeferredWork();
}
```

## Resulting Flow

```
DoHandlerFrame
  -> logicPhaseStartMs = performance.now()
  -> birthPlaceWindHp (x2)
  -> creature LogicUpdate loop
  -> SpawnMonManager.LogicUpdate
  -> if (logicDurationMs < 15) processDeferredWork()
  -> cache logic, PlayBattleCommonSound, handleFrameId
```

## Notes

- Deferred work (effects, death rendering, drops) is spread across frames; skipping when logic is heavy delays it by one or more frames, which is acceptable.
- No changes to battle logic determinism.

