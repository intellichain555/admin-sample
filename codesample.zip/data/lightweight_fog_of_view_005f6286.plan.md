---
name: Lightweight Fog of View
overview: Implement a lightweight fog of view system in Cocos Creator that efficiently determines visibility for game entities (champions, minions, etc.) and hides them if they are outside the player's sight range, focusing on performance and simplicity.
todos: []
isProject: false
---

## Plan: Lightweight Fog of View in Cocos Creator

### Overview
Implement a lightweight fog of view system in Cocos Creator that efficiently determines visibility for game entities (champions, minions, etc.) and hides them if they are outside the player's sight range. The focus will be on performance and simplicity, potentially using a combination of a simplified visibility grid and a basic masking or shader effect for the "fog" itself.

### Core Components

1.  **Visibility Grid/Data Structure**:
    *   **Purpose**: To efficiently store and update visibility information for different areas of the map.
    *   **Approach**: A 2D grid or quadtree that divides the game map into discrete cells. Each cell will have a visibility state (e.g., `visible`, `fogged`, `unexplored`).
    *   **Updates**: When a player unit moves, update the visibility of cells around it.
    *   **Key Files**: We'll likely need to create a new script or modify an existing map manager.

2.  **Entity Visibility Manager**:
    *   **Purpose**: To control the rendering and interaction of individual game entities based on the visibility grid.
    *   **Approach**: Each champion/minion will query the visibility manager to determine if its current position is visible to the player. If not, its rendering components (e.g., Sprite, MeshRenderer) will be disabled, effectively "hiding" it.
    *   **Optimization**: Implement events or dirty flags to only update entity visibility when necessary (e.g., player moves, entity moves into a new grid cell).

3.  **Fog Rendering (Simplified)**:
    *   **Purpose**: To visually represent the "fogged" or "unexplored" areas of the map.
    *   **Approach**:
        *   **Option 1 (Masking)**: A large texture or sprite that covers the entire map, with a mask that reveals visible areas. This can be efficient if the mask is updated dynamically.
        *   **Option 2 (Simple Shader)**: A basic shader that darkens or desaturates areas of the map that are not visible. This would be applied to the map's rendering.
        *   **User Preference**: Since you mentioned "just hide champions out of sight range" and looking for the "lightest way," we can start with simply hiding entities and add a subtle visual fog effect later if desired, or use a very basic masking approach.

### Todos

-   **`create-visibility-manager`**: Implement a `VisibilityManager` script to handle the 2D grid, updating cell visibility based on player unit positions. This will likely involve creating a new component or utility class.
-   **`integrate-entity-visibility`**: Modify champion and other unit scripts to query the `VisibilityManager` and toggle their rendering components (`Sprite`, `MeshRenderer`, etc.) based on the returned visibility state.
-   **`implement-fog-visual`**: Implement a basic visual representation of the fog. Given your preference for lightweight, we can start with a simple masking approach using a `cc.Mask` component or a custom sprite with a dynamically updated texture that represents the visible areas.
-   **`optimize-updates`**: Implement optimizations for updating visibility, such as only recalculating when a unit moves a significant distance or enters a new grid cell.

### Diagram: Fog of View System Flow

```mermaid
graph TD
    PlayerUnit[Player Unit Movement] --> UpdateVisibility[Update Visibility Grid]
    UpdateVisibility --> VisibilityGrid[Visibility Grid (Data)]
    VisibilityGrid --> QueryVisibility[Query Entity Visibility]
    QueryVisibility --> Entity[Champion/Minion Entity]
    Entity -- Visible --> Render[Enable Rendering]
    Entity -- Not Visible --> Hide[Disable Rendering]
    UpdateVisibility --> UpdateFogVisual[Update Fog Visual (Mask/Shader)]
    UpdateFogVisual --> FogVisual[Fog Layer (Rendering)]
```

I will start by exploring the existing project structure to understand where the game entities and map are defined to suggest specific file modifications.

Does this plan align with what you had in mind for a lightweight fog of view? Let me know if you'd like to adjust any of these approaches.