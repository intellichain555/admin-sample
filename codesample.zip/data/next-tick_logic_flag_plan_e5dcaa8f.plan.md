---
name: Next-tick logic flag plan
overview: Add a switchable next-tick scheduler for the 50ms battle logic so that on slow devices the game runs without overlapping callbacks, while keeping the current setInterval behavior available via a flag in Constant.ts.
todos: []
isProject: false
---

# Next-tick logic and Constant flag

## Goal

- Keep existing fixed-interval (setInterval 50ms) behavior as an option.
- Add a next-tick scheduler that runs the next logic tick only after the current one finishes (`delay = max(0, 50 - elapsed)`), avoiding overlapping callbacks on slow devices.
- Use a flag in [assets/Scripts/Utils/Constant.ts](assets/Scripts/Utils/Constant.ts) to choose between the two.

## Flow

```mermaid
flowchart LR
  subgraph init [Battle start]
    A[handleFrameWaitTime = 50ms]
    A --> B{Constant.USE_NEXT_TICK_LOGIC?}
    B -->|true| C[scheduleNextLogicTick 50ms delay]
    B -->|false| D[setInterval runLogicTick 50ms]
  end
  subgraph nextTick [Next-tick path]
    C --> E[setTimeout callback]
    E --> F[runLogicTick]
    F --> G[elapsed = now - start]
    G --> H[nextDelay = max 0 50 - elapsed]
    H --> I[scheduleNextLogicTick nextDelay]
    I --> E
  end
  subgraph intervalPath [Interval path]
    D --> J[every 50ms]
    J --> F
  end
```



Both paths call the same `runLogicTick(handleFrameWaitTime)` so logic (gapFrameCount, OnHandlerFrame, RepairFrameRequest, framePlaySpeed) is identical; only scheduling differs.

## File changes

### 1. [assets/Scripts/Utils/Constant.ts](assets/Scripts/Utils/Constant.ts)

- **Where:** After line 18 (`preLoadEnd`), before the "Permission types" comment.
- **Change:** Add one static flag:
  - `USE_NEXT_TICK_LOGIC: boolean = true` (or `false` if you prefer current behavior as default).
  - JSDoc: when true use next-tick scheduler for smoother behavior on slow devices; when false use fixed setInterval(50ms).

### 2. [assets/Game/Scripts/UI/Battle/Managers/BattleManager.ts](assets/Game/Scripts/UI/Battle/Managers/BattleManager.ts)

**A. New field (near line 70, with other timers)**

- Add: `private handleFrameTimeoutId: ReturnType<typeof setTimeout> = null;`
- Used only when `USE_NEXT_TICK_LOGIC` is true.

**B. Replace the "Handle logic frame timer" block (lines 292–314)**

- Keep `let handleFrameWaitTime = NetConfig.frameTime` and `let this_ = this`.
- Replace the single `setInterval(...)` with:
  - If `Constant.USE_NEXT_TICK_LOGIC`: call `this.scheduleNextLogicTick(handleFrameWaitTime, handleFrameWaitTime)` (first tick in 50ms).
  - Else: `this.handleFrameTimer = setInterval(async () => { await this_.runLogicTick(handleFrameWaitTime); }, handleFrameWaitTime);`

**C. New methods (e.g. after StartMonitorFrame, before OnHandlerFrame)**

1. `**runLogicTick(handleFrameWaitTime: number): Promise<void>**`
  Move the current setInterval callback body here (gapFrameCount, chase/normal branch, OnHandlerFrame, RepairFrameRequest, framePlaySpeed / isNormalPlay). No change to logic.
2. `**scheduleNextLogicTick(handleFrameWaitTime: number, delayMs: number): void**`
  - If `BattleGlobal.isGameEndFlag` return (do not schedule).
  - `this.handleFrameTimeoutId = setTimeout(async () => { ... }, delayMs)`.
  - In the callback: set `handleFrameTimeoutId = null`, record `start = performance.now()`, `await this.runLogicTick(handleFrameWaitTime)`, then `elapsed = performance.now() - start`, `nextDelay = Math.max(0, handleFrameWaitTime - elapsed)`, then call `this.scheduleNextLogicTick(handleFrameWaitTime, nextDelay)`.

**D. onDestroy (around line 697)**

- After `clearInterval(this.handleFrameTimer)`, add:
  - If `this.handleFrameTimeoutId != null`, call `clearTimeout(this.handleFrameTimeoutId)` and set `this.handleFrameTimeoutId = null`.

## Behavior summary


| Flag value | Scheduler                              | When a tick takes &gt; 50ms                                                      |
| ---------- | -------------------------------------- | -------------------------------------------------------------------------------- |
| `false`    | setInterval(50)                        | Next tick still fires at 50ms; callbacks can overlap.                            |
| `true`     | Next-tick (setTimeout after each tick) | Next tick runs after current finishes; delay = max(0, 50 - elapsed). No overlap. |


Logic (frame handling, repair, chase, framePlaySpeed) is unchanged; only the timer mechanism differs. The flag allows quick rollback or A/B testing.

## Testing

- Toggle `USE_NEXT_TICK_LOGIC` to `false` and run a battle: should match current behavior.
- Set to `true` and run on a low-end device or under load: no overlapping ticks; possible lower effective tick rate when frames exceed 50ms.

