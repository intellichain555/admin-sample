import { _decorator, Prefab, Node, instantiate, NodePool } from "cc";
import { ParticleOptimizer } from "../UI/Battle/Utils/ParticleOptimizer";
const { ccclass, property } = _decorator;

export interface PoolManagerOptions {
    /** When true, reduce particle count/emission on the node (for battle prefabs). */
    optimizeParticles?: boolean;
}

@ccclass("PoolManager")
export class PoolManager {
    private _dictPool: any = {}//Object pool dictionary
    private _dictPrefab: any = {}//Prefab dictionary

    static _instance: PoolManager;

    static get instance() {
        if (this._instance) {
            return this._instance;
        }

        this._instance = new PoolManager();
        return this._instance;
    }

    /**
     * Get corresponding node from object pool based on prefab
     * @param options.optimizeParticles When true, reduce particle count/emission (for battle prefabs)
     */
    public getNode(prefab: Node, parent?: Node, isShow:boolean = true, name?:string, options?: PoolManagerOptions): Node | undefined {
        if(!prefab){
            return;
        }
        if(!name){
            name = prefab.name;
            // //@ts-ignore
            // if (!prefab.position) {
            //     //@ts-ignore
            //     name = prefab.data.name;
            // }
        }else{
            prefab['name2'] = name;
        }

        this._dictPrefab[name] = prefab;
        let node: Node = null!;
        if (this._dictPool.hasOwnProperty(name)) {
            //Already has corresponding object pool
            let pool = this._dictPool[name] as NodePool;
            if (pool.size() > 0) {
                node = pool.get();
                // console.log('Got from object pool name='+name+', size='+pool.size())
            } else {
                node = instantiate(prefab);
                node['name2'] = name;
                // console.log('Created===='+name)
            }
        } else {
            //No corresponding object pool, create it!
            let pool = new NodePool();
            this._dictPool[name] = pool;

            node = instantiate(prefab);
            node['name2'] = name;
            // console.log('Created===='+name)
        }
        if (options?.optimizeParticles) {
            ParticleOptimizer.apply(node);
        }
        if(parent){
            parent.addChild(node);
            node.active = isShow;
        }
        return node;
    }

     /**
     *  Get corresponding node from object pool
     * @param options.optimizeParticles When true, reduce particle count/emission (for battle prefabs)
     */
    public getNode2(name:string, options?: PoolManagerOptions): Node | null {
        let node: Node | null = null;
        if (this._dictPool.hasOwnProperty(name)) {
            //Already has corresponding object pool
            let pool = this._dictPool[name] as NodePool;
            if (pool.size() > 0) {
                node = pool.get();
                // console.log('Got from object pool name='+name+', size='+pool.size())
            } else {
                let prefab = this._dictPrefab[name];
                if(prefab){
                    node = instantiate(prefab);
                    node['name2'] = name;
                    // console.log('Created===='+name)
                }
            }
        }
        if (node && options?.optimizeParticles) {
            ParticleOptimizer.apply(node);
        }
        return node;
    }

    /**
     * Put corresponding node back into object pool
     */
    public putNode(node: Node, name?:string) {
        if (!node) {
            return;
        }
        if(!name){
            name = node['name2'];
        }
        if(!name){
            name = node.name;
        }
        let pool:NodePool = null;
        if (this._dictPool.hasOwnProperty(name)) {
            //Already has corresponding object pool
            pool = this._dictPool[name];
        } else {
            //No corresponding object pool, create it!
            pool = new NodePool();
            this._dictPool[name] = pool;
        }

        pool.put(node);
    }

    /**
     * Clear corresponding object pool by name
     */
    public clearPool(name: string) {
        if (this._dictPool.hasOwnProperty(name)) {
            let pool = this._dictPool[name];
            pool.clear();
        }
    }

    /**
     * Clear all
     */
    public clearAll(){
        this._dictPool = {}//Object pool dictionary
        this._dictPrefab = {}//Prefab dictionary
    }
    
    /**
     * Pre-generate object pool
     *
     * @param {Prefab} prefab Prefab
     * @param {number} num Number of items to preload
     * @returns
     * @memberof PoolManager
     */
    public preloadPool (prefab: Prefab|Node, num: number, name?:string) {
        if(!prefab){
            return;
        }
        if(!name){
            name = prefab.name;
           // @ts-ignore
        //    if (!prefab.position) {
        //        // @ts-ignore
        //        name = prefab.data.name;
        //    }
        }else{
            prefab['name2'] = name;
        }
        this._dictPrefab[name] = prefab;
        let pool: NodePool = null;
        if (this._dictPool.hasOwnProperty(name)) {
            // Already has corresponding object pool
            pool = this._dictPool[name] as NodePool;
        } else {
            // No corresponding object pool, create it!
            pool = new NodePool();
            this._dictPool[name] = pool;
        }         
        // console.log('Pre-created===='+name+', count='+num)
        for (let i = 0; i < num; i++) {
            let node = instantiate(prefab) as Node;
            node['name2'] = name;
            pool.put(node);
        }
    }
}
