import { Creature } from "../Enities/Creature";
import { SkillDefine } from "../../../Data/SkillDefine";
import { SkillStatus } from "../enums/SkillStatus";
import { BattleContext } from "./BattleContext";
import { DataManager } from "../../../Managers/DataManager";
import { Bullet } from "./Bullet";
import { SkillResult } from "../enums/SkillResult";
import { TargetType } from "../enums/TargetType";
import { TriggerType } from "../enums/TriggerType";
import { NetConfig } from "../../../Network/NetConfig";
import { Node, Vec3 } from "cc";
import { DamageInfo } from "../Vo/DamageInfo";
import { RandomUtil } from "../Utils/RandomUtil";
import { CreatureManager } from "../Managers/CreatureManager";
import { CreatureType } from "../enums/CreatureType";
import { LogicRenderConvert } from "../Utils/LogicRenderConvert";
import { MathUtil } from "../../../Utils/MathUtil";
import { EffectType } from "../Effects/EffectType";
import { AniState } from "../enums/AniState";
import { BattleGlobal } from "../Utils/BattleGlobal";
import Decimal from "decimal.js";
import { ShapeType } from "../enums/ShapeType";
import { TeamType2 } from "../enums/TeamType2";
import { UIWorldElementManager } from "../UIWorldElementManager";
import { PopupType } from "../enums/PopupType";
import { BuffEffect } from "../enums/BuffEffect";
import { SkillType } from "../enums/SkillType";
import { BuffType } from "../enums/BuffType";
import { BattleManager } from "../Managers/BattleManager";
import { DeferredWorkManager } from "../Managers/DeferredWorkManager";
import { User } from "../../../Models/User";
import { IStateRollback } from "../StateRecord/IStateRollback";
import { SkillRecord } from "../StateRecord/Models/SkillRecord";
import { SkillTipsType } from "../enums/SkillTipsType";
import { SoundManager } from "../../../../../Scripts/Sound/SoundManager";
import { Constant } from "../../../../../Scripts/Utils/Constant";
import { PoolManager } from "../../../Managers/PoolManager";
/**
 * Skill
 */
export class Skill implements IStateRollback {
  public skillId: number;
  public Owner: Creature;
  public Define: SkillDefine;

  public Status: SkillStatus = SkillStatus.None;

  public cd: number = 0;

  public castingTime: number = 0;
  public skillTime: number = 0;
  public Hit: number = 0;
  public Context: BattleContext;
  public frameId: number;  // Current logic frame
  public actionTime: number = 0;  // Action time

  public Bullets = new Array<Bullet>();
  public isDurationEnd: boolean = false;  // Whether duration skill execution ended
  public isBreakingHiddenNormalSkillCrit = false;  // Whether breaking stealth normal attack guaranteed crit
  public CastTargetStr: string;  // Cast target string
  public effectNode: Node;  // Skill effect node
  public isStopCasting: boolean = false;  // Whether stop casting
  public lastSearchCreatureArr: Array<Creature> = null;  // Skill last searched target collection
  public peopleNum: number = 0;  // Damage count
  private typeStr:string;  // Type string
  private Target:Creature;
  private aoeEffectPosTemp: Vec3 = new Vec3();  // Reused for AOE effect position (avoids GC)


  public constructor(define: SkillDefine, owner: Creature) {
    this.skillId = define.ID;
    this.Owner = owner;
    this.Define = define;
    this.CastTargetStr = this.Define.CastTarget.toString();
    this.typeStr = this.Define.Type ? this.Define.Type.toString() : '';
  }

  public get Instant(): boolean {
    if (this.Define.CastTime > 0) return false;   // Pre-cast animation
    if (this.Define.Bullet) return false;   // Is bullet
    if (this.Define.Duration > 0) return false;  // Duration
    if (this.Define.HitTimes != null && this.Define.HitTimes.length > 0) return false;  // Hit times (rapid fire bullet launch delay)
    return true;
  }


  public CanCast(context: BattleContext): SkillResult {
    if (this.Owner.IsDeath) {
      return SkillResult.NotCast;
    }
    if (!context.isSubSkill) {  // Not sub skill
      if (!this.Owner.SkillMgr.ValidateSkillActionPlayEnd() || !this.Owner.isCanSkill || this.Owner.battleAttribute.CanSkillCount > 0) {  // Whether skill action finished playing, cannot cast
        return SkillResult.NotCast;
      }
    }

    if (this.Status != SkillStatus.None) {
      return SkillResult.Casting;
    }
    if (this.CastTargetStr == TargetType[TargetType.SelectedRange]) {  // Selected range
      if (this.Owner.Distance3(context.logicPositionX, context.logicPositionZ) > LogicRenderConvert.RenderToLogic_Value(this.Define.CastRange)) {
        // console.warn('Out of cast range SelectedRange')
        return SkillResult.OutOfRange;
      }
    } else if (this.CastTargetStr == TargetType[TargetType.Des] || this.CastTargetStr == TargetType[TargetType.RangeTarget]) {  // Specified target type
      if (context.logicPositionX && context.logicPositionZ) {  // No target, to specified position
        let dis = this.Owner.Distance3(context.logicPositionX, context.logicPositionZ);
        let renderCastRange = LogicRenderConvert.RenderToLogic_Value(this.Define.CastRange + 0.5);
        if (dis > renderCastRange) {
          // console.warn('Out of cast range no target, to specified position dis=' + dis + '，renderCastRange=' + renderCastRange)
          return SkillResult.OutOfRange;
        }
      } else if (context.Target) {  // Has target
        if (context.Target.IsDeath) {  // Target dead
          return SkillResult.OutOfRange;
        }
        let targetLogicPosition = context.Target.logicPosition;
        if (this.Owner.Distance3(targetLogicPosition.x, targetLogicPosition.z) > LogicRenderConvert.RenderToLogic_Value(this.Define.CastRange + context.Target.characterDefine.Radius + 0.5)) {
          // console.warn('Out of cast range has target')
          return SkillResult.OutOfRange;
        }
      }
    }    

    if (this.cd > 0) {
      return SkillResult.CoolDown;
    }
    return SkillResult.Ok;
  }

  /**
   * Get latest skill definition
   * @param isLog Whether print log (default false)
   * @param noSegmentsIsReturnOld No combo return old (default true)
   */
  public getNewDefine(isLog: boolean = false, noSegmentsIsReturnOld: boolean = true): SkillDefine {
    if (this.Define.SegmentsTime) {   // Combo skill
      let rangeTime = this.Define.SegmentsTime / 2;
      // console.log('Cast- rangeTime='+rangeTime)             
      if (this.cd > -rangeTime && this.cd < rangeTime) {  // Within combo time range
        let skillDefine = this.Owner.SkillMgr.GetSkillBySkillIdSegmentsNum(this.skillId, this.Define.SegmentsNum + 1);
        if (!skillDefine) {
          skillDefine = this.Owner.SkillMgr.GetSkillBySkillIdSegmentsNum(this.skillId, 1);
        }
        if (isLog) {
          // console.log('Combo skill cd='+this.cd+'，rangeTime='+rangeTime+'，description=', skillDefine.Description)
        }
        return skillDefine;
      } else if (this.cd <= -rangeTime) {  // Exceeded combo time, default use first segment skill
        if (isLog) {
          // console.log('Combo skill exceeded combo time, default use first segment skill')
        }
        let skillDefine = this.Owner.SkillMgr.GetSkillBySkillIdSegmentsNum(this.skillId, 1);
        return skillDefine;
      }
    }
    if (noSegmentsIsReturnOld) {
      return this.Define;
    } else {
      return null;
    }
  }

  /**
   * Skill replace
   */
  public skillReplace(skillDefine: SkillDefine) {
    this.Define = skillDefine;
  }

  /**
   * Get real CD
   */
  public getRealCD(): number {
    // return this.Define.CD - (this.Define.CD * this.Owner.attributes.CD / 100);
    return Decimal.sub(this.Define.CD, Decimal.mul(this.Define.CD, Decimal.add(this.Owner.attributes.CD, this.getAttackSpeed())).div(100)).toNumber();
  }

  /**
   * Get attack speed bonus
   */
  public getAttackSpeed(): number {
    if (this.typeStr == SkillType[SkillType.Normal]) { // Normal attack
      return this.Owner.attributes.AttackSpeed.toNumber();
    }
    return 0;
  }

  public Cast(context: BattleContext): SkillResult {
    let result = this.CanCast(context);
    if (result == SkillResult.Ok) {
      if (this.Define.SegmentsTime) {   // Combo skill                
        let skillDefine = this.getNewDefine(true, false);
        if (skillDefine) {
          this.skillReplace(skillDefine);
        }
      }
      if (this.Define.AOEEffect && this.CastTargetStr == TargetType[TargetType.RangeTarget]) {  // AOE skill and range damage skill            
        context.logicPositionX = this.Owner.logicPosition.x;
        context.logicPositionZ = this.Owner.logicPosition.z;
      }

      if (this.Define.isTowardTarget) {
        this.Owner.RotateHandle(context.dirDegree, undefined, undefined, context.isImmRotate);
      }

      if (this.Define.DisappearEffect) {   // Flash disappear pre-effect (deferred for safety)
        this.Owner.EntityEffectMgr.PlayEffect3(this.Define.DisappearEffect, undefined, undefined, true);
      }

      this.isStopCasting = false;
      this.isDurationEnd = false;
      this.castingTime = 0;
      this.skillTime = 0;
      this.peopleNum = 0;
      this.cd = this.getRealCD();

      this.Context = context;
      this.Hit = 0;
      this.Bullets = [];
      this.actionTime = this.Define.ActionTime - (this.Define.ActionTime * this.getAttackSpeed() / 100);
      // console.log('Cast- cd='+this.cd+'，actionTime='+this.actionTime)

      let isSkillExistStealth = this.AddBuff(TriggerType.SkillCast, this.Context.Target, BuffEffect.Stealth);  // Whether current skill has stealth
      this.isBreakingHiddenNormalSkillCrit = false;
      let isStealth = this.Owner.EffectMgr.HasEffect(BuffEffect.Stealth); // Stealth
      if (!isSkillExistStealth && isStealth) {  // Skill has no stealth and body has stealth effect, then break stealth
        let effect = this.Owner.EffectMgr.queryIsBreakingHiddenNormalSkillCrit();
        this.isBreakingHiddenNormalSkillCrit = (effect && this.typeStr == SkillType[SkillType.Normal]);
        this.Owner.EffectMgr.RemoveEffect(BuffEffect.Stealth, effect ? effect.buff : undefined);   // Break stealth, remove effect  
      }
      // Play action
      if (this.Define.SkillAnim && context.isPlaySkillAnim) {
        if (this.CastTargetStr == TargetType[TargetType.Des] && !this.Define.isDisplacement) {  // Specified target type, non-displacement
          if (context.Target) {  // Has target
            this.Owner.SetAnim(AniState[this.Define.SkillAnim], true); // Play action
          }
        } else {
          if (this.Owner.user && this.Owner.user.id == User.Instance.user.id) {
            // console.log('Play action =' + this.Define.SkillAnim)
          }
          this.Owner.SetAnim(AniState[this.Define.SkillAnim], true); // Play action
        }
      }

      if (this.Instant) {
        this.DoHit();
      }
      else {
        if (this.Define.CastTime > 0) {
          this.Status = SkillStatus.Casting;
        }
        else {
          this.StartSkill();
        }
      }
    }
    // console.log("Skill[{0}].Cast Result:[{1}] Status:{2}",this.Define.Name,result,this.Status);
    return result;
  }

/// <summary>
/// Skill execution start
/// </summary>
  private StartSkill() {
    this.Status = SkillStatus.Running;
    if (this.validateIsSkillInterrupt()) {   // Interrupt casting
      // console.log('Interrupted casting exit, ====Status=', this.Status)
      this.SkillInterruptHandle();
      return;
    }
    // console.log('Skill StartSkill')
    if (this.Define.AOEEffect) {
      if (this.CastTargetStr == TargetType[TargetType.SelectedRange] || this.CastTargetStr == TargetType[TargetType.RangeTarget])  // Selected range
      {
        this.aoeEffectPosTemp.set(LogicRenderConvert.LogicToRender_Value(this.Context.logicPositionX), 0, LogicRenderConvert.LogicToRender_Value(this.Context.logicPositionZ));
        DeferredWorkManager.Instance.enqueuePlayEffectPosition(this.Owner, EffectType.Position, this.Define.AOEEffect, this.aoeEffectPosTemp);
      }
      else if (this.CastTargetStr == TargetType[TargetType.Target])   // Target
      {
        DeferredWorkManager.Instance.enqueuePlayEffectTarget(this.Owner, EffectType.Position, this.Define.AOEEffect, this.Context.Target);
      }
      else if (this.CastTargetStr == TargetType[TargetType.Self])  // Self
      {
        DeferredWorkManager.Instance.enqueuePlayEffectTarget(this.Owner, EffectType.Position, this.Define.AOEEffect, this.Owner);
      }
    }

  }

  private AddBuff(trigger: TriggerType, target: Creature, queryBuffEffect?: BuffEffect): boolean {
    if (target && target.IsDeath) {  // Target already dead
      return;
    }
    let isExistBuffEffect: boolean = false;
    if (this.Define.Buff == null || this.Define.Buff.length == 0) {
      return false;
    } else if ((!this.Define.buffType || this.Define.buffType.toString() != BuffType[BuffType.MoveTreatmentFormation]) && target && (target.isImmunity || target.isRetreat)) {
      return false;
    }
    // console.log('Define.Buff='+this.Define.Buff);
    for (var buffId of this.Define.Buff) {
      let isExist = this.AddBuff2(buffId, trigger, target, queryBuffEffect);
      if (isExist) {
        isExistBuffEffect = true;
      }
    }
    return isExistBuffEffect;
  }

  public AddBuff2(buffId: number, trigger: TriggerType, target: Creature, queryBuffEffect?: BuffEffect): boolean {
    let isExistBuffEffect: boolean = false;
    if (!buffId) {
      return;
    }
    var buffDefine = DataManager.Instance.buffs[buffId];
    // console.log(buffId +'=='+ buffDefine);
    if (queryBuffEffect && buffDefine.Effect && buffDefine.Effect == BuffEffect[queryBuffEffect]) {  // Find specified buff effect
      isExistBuffEffect = true;
    }
    // console.log('AddBuff2 ===',buffDefine.Trigger.toString() ,TriggerType[trigger])
    if (buffDefine.Trigger.toString() != TriggerType[trigger]) return; // Trigger type inconsistent
    // console.log('buffDefine.Target='+buffDefine.Target.toString());

    // Buff probability trigger
    if (buffDefine.TriggerProbability) {
      let isBuffTrigger = this.IsBuffTrigger(buffDefine.TriggerProbability || 100);
      if (!isBuffTrigger) {   // Not triggered, execute otherwise buff
        if (buffDefine.OtherwiseBuff && buffDefine.OtherwiseBuff.length > 0) {
          for (var buffId of buffDefine.OtherwiseBuff) {
            let isExist = this.AddBuff2(buffId, trigger, target, queryBuffEffect);
            if (isExist) {
              isExistBuffEffect = true;
            }
          }
        }
        return;
      }
    }

    if (buffDefine.Target.toString() == TargetType[TargetType.Self]) {  // Self
      this.Owner.AddBuf(this.Context, buffDefine);
    } else if (buffDefine.Target.toString() == TargetType[TargetType.Target]) {  // Target
      if (!target) {
        return;
      }
      target.AddBuf(this.Context, buffDefine);
    } else if (buffDefine.Target.toString() == TargetType[TargetType.FriendlyHero]) {  // Friendly hero
      if (target && target.teamType2 == this.Owner.teamType2 && target.creatureType == CreatureType.Character) {
        target.AddBuf(this.Context, buffDefine);
      }
    }
    return isExistBuffEffect;
  }

  /**
   * Whether buff triggers
   * @param probability  Trigger probability
   */
  private IsBuffTrigger(probability: number): boolean {
    return RandomUtil.limitIntegerBattle(0, 100) < probability;
  }

  public LogicUpdate(frameId: number) {
    this.actionTime -= NetConfig.frameTime;
    this.frameId = frameId;
    this.UpdateCD();
    if (this.Status == SkillStatus.Casting)     // Pre-cast state
    {
      this.UpdateCasting();
    }
    else if (this.Status == SkillStatus.Running)  // Executing
    {
      this.UpdateSkill();
    }
  }

  /**
   * Update pre-cast time
   */
  private UpdateCasting() {
    if (this.castingTime < this.Define.CastTime) {
      this.castingTime += NetConfig.frameTime; //Time.deltaTime;
    }
    else {
      this.castingTime = 0;
      this.StartSkill();
      // console.log("Skill[{0}].UpdateCasting Finish", this.Define.Name);
    }
  }

  /**
   * Update CD time
   */
  private UpdateCD() {
    this.cd -= NetConfig.frameTime;
  }

  /**
   * Update skill
   */
  private UpdateSkill() {
    this.skillTime += NetConfig.frameTime;
    if (!this.isDurationEnd && this.Define.Duration > 0) {  // Duration skill, interval time damage
      // console.log('UpdateSkill skillTime：'+this.skillTime+'=='+(this.Define.Interval * (this.Hit + 1))+'=='+ this.Define.Interval)
      if (this.skillTime > this.Define.Interval * (this.Hit + 1)) {
        this.DoHit();
      }

      if (this.skillTime >= this.Define.Duration) {
        if (this.Define.HitTimes && this.Define.HitTimes.length > 0) {  // Has sub skills, execute sub skills
          this.Hit = 1;
          this.isDurationEnd = true;
        } else {
          this.Status = SkillStatus.None;
          // console.log("Skill[{0}].UpdateSkill Finish", this.Define.Name);
        }
      }
    } else if (this.Define.HitTimes && this.Define.HitTimes.length > 0) { // Specified time damage skill
      if (this.Hit < this.Define.HitTimes.length) {
        if (this.skillTime > this.Define.HitTimes[this.Hit]) {
          this.DoHit(true);
        }
      } else {
        if (!this.Define.Bullet) {
          this.Status = SkillStatus.None;
          // console.log("Skill[{0}].UpdateSkill Finish", this.Define.Name);
        }
      }
    }
    this.UpdateBullet();  // Update bullets
  }

  /**
   * Update bullets
   */
  private UpdateBullet() {
    if (this.Define.Bullet) {  // Update bullets
      let finish: boolean = true;
      for (let bullet of this.Bullets) {
        bullet.LogicUpdate();
        if (!bullet.Stoped) finish = false;
      }

      if (finish && this.Hit >= this.Define.HitTimes.length) {
        this.Status = SkillStatus.None;
        // console.log("Skill[{0}].UpdateSkill Finish", this.Define.Name);
      }
    }
  }

  /**
   * Damage judgment
   */
  private DoHit(isExecuteHitTimes: boolean = false) {
    // console.log("Skill[{0}].DoHit:[{1}]", this.Define.Name, this.Hit);
    let isSkillInterrupt = this.validateIsSkillInterrupt();  // Whether interrupt casting
    // Has sub skills, execute sub skill damage judgment
    let existSubSkill: boolean = false;
    if (isExecuteHitTimes && this.Hit > 0 && this.Define.SubSkillIds && this.Define.SubSkillIds.length >= this.Hit) {
      if (!isSkillInterrupt) {  // Not interrupted casting
        let subSkill = this.Owner.SkillMgr.GetSkill(this.Define.SubSkillIds[this.Hit - 1]);
        this.Context.isSubSkill = true;
        subSkill.Cast(this.Context);
        existSubSkill = true;
      }
    }

    this.Hit++;
    if (isSkillInterrupt) {   // Interrupt casting
      // console.error('Interrupted casting exit, executing===Status=', this.Status)
      this.SkillInterruptHandle();
      return;
    }

    if (existSubSkill) {
      return;
    }
    if (this.CastTargetStr == TargetType[TargetType.Des] && !this.Define.DamageShapeType && !this.Define.isDisplacement) {  // Specified target type, non-shape detection, non-displacement
      if (this.Context.Target) {  // Has target
        this.HitTarget(this.Context.Target);
      }
      return;
    }
    if (this.Define.isDisplacement) {  // Displacement
      if (this.Define.Bullet) { // Is bullet
        this.CastBullet();
      }
      this.AddBuff(TriggerType.SkillCastSwayAfter, null);
      return;
    } else if (this.Define.DamageShapeType) {  // Shape collision detection
      let creatureArr = this.GetRangeTargetList(undefined, this.Define.Bullet ? 1 : 2);
      if (this.Define.Bullet) {          // Is bullet, means range targets, bouncing ball
        creatureArr = creatureArr.sort(MathUtil.sortBy('dir', true));   // Sort by distance ascending
        let hitNum = this.Define.HitNum || -1;
        if (hitNum > 0) {  // Damage count
          for (let i = 0; i < creatureArr.length; i++) {
            if (i >= hitNum) {
              creatureArr.splice(i, 1);
              i--;
            }
          }
        }
        this.CastBullet(creatureArr);  // Create bullets
      } else {
        for (var target of creatureArr) {
          this.HitTarget(target, creatureArr.length);
        }
      }
      return;
    } else if (this.Define.Bullet) { // Is bullet
      if (this.CastTargetStr == TargetType[TargetType.RangeTarget] && !this.Define.RealDetection) { // Range target and non-real-time detection               
        // console.log('DoHit range target and is bullet')
        let creatureArr = this.GetRangeTargetList(this.Context.isPriorityHitTarget, 1);
        if (this.Define.isNoTargetCast && creatureArr.length < 1) {  // No target can cast and no target exists
          this.CastBullet(undefined, true);
        } else {
          if (creatureArr.length < 1) {  // No target cannot cast and no target exists, interrupt casting
            this.SkillInterruptHandle();
            return;
          }
          let targetArr: Array<Creature> = [];
          let index = 0;
          for (var target of creatureArr) {
            if (this.Define.isTowardTarget && index == 0) {  // Turn towards
              this.Target = target;
              let newDegree = Math.round(MathUtil.GetAngle(target.logicPosition.z - this.Owner.logicPosition.z, target.logicPosition.x - this.Owner.logicPosition.x));
              newDegree = BattleGlobal.AngleRangeHandle(newDegree);
              this.Owner.RotateHandle(newDegree, undefined, undefined, this.Context.isImmRotate);
            }
            targetArr = [];
            targetArr.push(target);
            this.CastBullet(targetArr);
            index++;
          }
        }
        return;
      } else {
        this.CastBullet(this.Context.Target ? [this.Context.Target] : undefined);
        return;
      }
    }
    this.DoHitHandle();
  }

  /**
   * Shape detection elimination
   * @param creatureArr 
   */
  private ShapeDetectionEliminate(creatureArr: Array<Creature>) {
    if (this.Define.DamageShapeType) {  // Shape collision detection
      let damageShapeTypeStr = this.Define.DamageShapeType.toString();
      if (damageShapeTypeStr == ShapeType[ShapeType.sector]) {  // Sector
        for (let i = 0; i < creatureArr.length; i++) {
          let target = creatureArr[i];
          // Enemy at my angle
          let enemyAngle = Math.round(MathUtil.GetAngle(target.logicPosition.z - this.Owner.logicPosition.z, target.logicPosition.x - this.Owner.logicPosition.x));
          enemyAngle = BattleGlobal.AngleRangeHandle(enemyAngle);
          // My angle
          let myAngle = this.Owner.logicRotation.y;
          // Enemy in my attack angle range
          let angleRange = this.Define.AngleRange / 2;
          let maxAngle = BattleGlobal.AngleRangeHandle(Math.round(myAngle + angleRange));
          let minAngle = BattleGlobal.AngleRangeHandle(Math.round(myAngle - angleRange));
          // Angle range 0 - 360                 
          // Max > Min  (< Max && > Min)
          // Max < Min  (< Max || > Min)                   
          if ((maxAngle > minAngle && (enemyAngle <= maxAngle && enemyAngle >= minAngle)) ||
            (maxAngle < minAngle && (enemyAngle <= maxAngle || enemyAngle >= minAngle))) { // In range
            //  console.log('Shape collision detection sector in range my angle='+myAngle+'，enemy at my angle='+enemyAngle+'，max angle='+maxAngle+'，min angle='+minAngle)                        
          } else {  // Not in range
            creatureArr.splice(i, 1);
            i--;
          }
        }
      }
    }
  }

  public DoHitHandle(isUpdatePeopleNum: boolean = false) {
    // console.log("Skill[{0}].DoHitHandle[{1}] IsBullet:{2}",this.Define.Name,this.Hit,this.Define.Bullet);
    if (isUpdatePeopleNum) {
      this.peopleNum++;
    }
    // Directional type, specified target range
    if (this.CastTargetStr == TargetType[TargetType.Target] ||
      this.CastTargetStr == TargetType[TargetType.StraightLine] ||
      this.Define.Bullet) {
      this.HitTarget(this.Context.Target, this.peopleNum);
    } else if ((this.CastTargetStr == TargetType[TargetType.RangeTarget] && !this.Define.Bullet) ||
      this.CastTargetStr == TargetType[TargetType.SelectedRange]) {  // Non-directional type, range target
      this.HitRange();
    }
    // if(isUpdatePeopleNum){
    //   this.Hit++;
    // }       
  }

  /**
   * Release bullets
   */
  private CastBullet(targetArr?: Array<Creature>, isRealDetection: boolean = false) {
    if (this.Define.DelayTimes && this.Define.DelayTimes.length > 0) {
      for (let i = 0; i < this.Define.DelayTimes.length; i++) {
        let times = this.Define.DelayTimes[i];
        for (let j = 0; j < times.length; j++) {
          let delay = times[j];
          let anglesOffest = this.Define.BulletAngles[i][j];
          let bullet = new Bullet(this, targetArr, anglesOffest, delay);
          bullet.isRealDetection = isRealDetection;
          this.Bullets.push(bullet);
        }
      }
    } else {
      let bullet = new Bullet(this, targetArr);
      bullet.isRealDetection = isRealDetection;
      this.Bullets.push(bullet);
    }
  }


  /**
   * Get range target collection
   * @param isPriorityHitTarget Whether prioritize finding targets
   * @param useTo Purpose 1, Find targets 2, Damage
   */
  public GetRangeTargetList(isPriorityHitTarget = false, useTo: number = 1): Array<Creature> {
    let logicPositionX: number;
    let logicPositionZ: number;
    let logicRadius: number;  // Radius
    let blowsNum: number = this.Define.BlowsNum || -1;;   // Count
    let width: number;  // Width
    let height: number;  // Length            
    let shapeType = ShapeType.circle;  // Shape
    let rectAngle: number;  // Rectangle angle

    if (this.CastTargetStr == TargetType[TargetType.RangeTarget] ||
      this.CastTargetStr == TargetType[TargetType.Sector] ||
      (this.Define.DamageShapeType && (this.Define.DamageShapeType.toString() == ShapeType[ShapeType.circle]
        || this.Define.DamageShapeType.toString() == ShapeType[ShapeType.sector]))) {   // Character range, sector, circle, sector
      logicPositionX = this.Owner.logicPosition.x;
      logicPositionZ = this.Owner.logicPosition.z;
      logicRadius = LogicRenderConvert.RenderToLogic_Value(this.Define.AOERange || this.Define.CastRange);  // AOERange exists means AOE area in character damage range
    } else if (this.CastTargetStr == TargetType[TargetType.SelectedRange]) { // Selected range
      logicPositionX = this.Context.logicPositionX;
      logicPositionZ = this.Context.logicPositionZ;
      logicRadius = LogicRenderConvert.RenderToLogic_Value(this.Define.AOERange);
    } else if (this.Define.DamageShapeType) {
      if (this.Define.DamageShapeType.toString() == ShapeType[ShapeType.rect]) {   // Rectangle
        // Rectangle defaults to character center, AngleRange controls rectangle offset angle, PositionOffset controls offset distance
        logicPositionX = this.Owner.logicPosition.x;
        logicPositionZ = this.Owner.logicPosition.z;
        width = LogicRenderConvert.RenderToLogic_Value(this.Define.BulletWidth);
        height = LogicRenderConvert.RenderToLogic_Value(this.Define.BulletHeight);
        shapeType = ShapeType.rect;
        rectAngle = this.Owner.logicRotation.y + (this.Define.AngleRange || 0);
      }
    }

    // Direction distance logic offset handling
    let positionOffset = this.Define.PositionOffset;  // Direction distance offset
    if (positionOffset) {
      // console.log('Direction distance logic offset handling positionOffset='+positionOffset)
      let rockerSpeedVo = DataManager.Instance.rockerSpeeds[this.Context.dirDegree];
      if (!rockerSpeedVo) {
        // console.log('rockerSpeedVo does not exist!' + this.Context.dirDegree)
        return;
      }
      let offsetX = positionOffset * 10 * rockerSpeedVo.x;
      let offsetZ = positionOffset * 10 * rockerSpeedVo.y;
      logicPositionX += offsetX;
      logicPositionZ += offsetZ;
    }
    let Class = this.Owner.characterDefine.Class;
    let isAggroOrder = (Class == Constant.CharacterClass.Fyt || Class == Constant.CharacterClass.ShuiJin);  // Tower, crystal sort by aggro
    let creatureArr = CreatureManager.Instance.FindUnitsInRange(logicPositionX, logicPositionZ, logicRadius, blowsNum, this.Owner.teamType2, true
      , shapeType, width, height, rectAngle, undefined, (this.Define.buffType ? BuffType[this.Define.buffType.toString()] : undefined), (isPriorityHitTarget ? this.Context.Target : undefined),
      isAggroOrder, useTo, this.Owner.characterDefine.IsAttackStealth);  // No buff type, search all
    // console.log('GetRangeTargetList creatureArr：'+creatureArr.length)


    // Logic range target test==============
    // if(this.Owner.user && this.Owner.user.id == User.Instance.user.id){
    //   BattleManager.Instance.LogicRangeTargetTestNode.active = true;
    //   BattleManager.Instance.LogicRangeTargetTestNode.setWorldPosition(LogicRenderConvert.LogicToRender_Value(logicPositionX), 0.1, LogicRenderConvert.LogicToRender_Value(logicPositionZ))
    //   if(shapeType == ShapeType.rect){
    //     BattleManager.Instance.LogicRangeTargetTestNode.setScale(LogicRenderConvert.LogicToRender_Value(width), 1, LogicRenderConvert.LogicToRender_Value(height));
    //     BattleManager.Instance.LogicRangeTargetTestNode.setRotationFromEuler(0, rectAngle, 0);
    //   }else if(shapeType == ShapeType.circle){
    //     BattleManager.Instance.LogicRangeTargetTestNode.setScale(LogicRenderConvert.LogicToRender_Value(logicRadius*2), 1, LogicRenderConvert.LogicToRender_Value(logicRadius*2));
    //   }
    // }
    this.ShapeDetectionEliminate(creatureArr);  // Shape detection elimination
    if(creatureArr.length > 0){  // Has targets
      this.Target = creatureArr[0];
    }
    this.lastSearchCreatureArr = creatureArr;
    return creatureArr;
  }

  /**
   * Face first target
   * @param creatureArr
   */
  private TowardTarget(creatureArr: Array<Creature>, isNewSearch = false) {
    if (creatureArr.length > 0 && isNewSearch) { // Re-search
      let target = creatureArr[0];
      let newDegree = Math.round(MathUtil.GetAngle(target.logicPosition.z - this.Owner.logicPosition.z, target.logicPosition.x - this.Owner.logicPosition.x));
      newDegree = BattleGlobal.AngleRangeHandle(newDegree);
      // Character rotation
      this.Owner.RotateHandle(newDegree, undefined, undefined, isNewSearch);
      if (isNewSearch) {
        // console.log('???GetRangeTargetList RotateHandle newDegree='+newDegree+',target entityId='+target.entityId)
        this.Context.dirDegree = newDegree;
      }
    }
  }

  private HitRange() {
    let creatureArr = this.GetRangeTargetList(undefined, 2);
    for (var target of creatureArr) {
      this.HitTarget(target, creatureArr.length);
    }
  }


  private HitTarget(target: Creature, peopleNum: number = 1) {
    if (!target) {
      return;
    }
    let isPlayHitEffect:boolean = !target.IsDeath;
    // console.log('HitTarget BuffIsFirstPerson='+this.Define.BuffIsFirstPerson+'，Hit='+this.Hit)
    if (this.Define.ATTFator) {   // Has attack factor
      if (this.CastTargetStr == TargetType[TargetType.Self] && (target != this.Context.Caster)) {
        return;
      } else if (target == this.Context.Caster) {
        return;
      } else if (target.isImmunity || target.isRetreat || target.EffectMgr.HasEffect(BuffEffect.Invincible)) {
        return;
      }

      if (this.Define.IsCanDodge) {  // Current skill can be dodged
        let isDodge = this.IsDodge(target.attributes.Dodge);
        if (isDodge) {  // Dodge 
          // console.log('Dodge===========')
          UIWorldElementManager.Instance.ShowPopupText(PopupType.EffectTips, target, 'Dodge!', undefined, 0.5);
          return;
        }
      }

      let damage = this.CalcSkillDamage(this.Context.Caster, target, peopleNum);
      // console.log('Skill hit' +'Current skill name='+this.Define.Name +'Target name='+target.characterDefine.Name
      // +'Damage='+damage.Damage +'Whether crit='+damage.Crit +'Crit rate='+this.Context.Caster.attributes.CRI
      // +'，Dodge rate='+target.attributes.Dodge+"，Stealth="+damage.isStealth);

      target.DoDamage(damage, this.Context.Caster);
    }
    if (!this.Define.BuffIsFirstPerson || (this.Define.BuffIsFirstPerson && this.Hit == 1)) {
      this.AddBuff(TriggerType.SkillHit, target);
    }

    // Play hit effect (deferred)
    let hitEffect = this.Define.HitEffect;
    if (hitEffect && this.Owner.user && this.Owner.user.id == User.Instance.user.id && isPlayHitEffect) {
      DeferredWorkManager.Instance.enqueuePlayEffectTarget(this.Owner, EffectType.Hit, hitEffect, target, undefined, this.Define.HitHeightScale, !this.Define.isNoUseGlobalEffect);
    }
  }



  /*
   * Battle calculation
   */
  private CalcSkillDamage(caster: Creature, target: Creature, peopleNum: number = 1): DamageInfo {
    let attFator = this.Define.ATTFator; // Skill attack factor
    let damageIncreasePercent = this.Define.DamageIncreasePercent ? this.Define.DamageIncreasePercent * peopleNum : 0;  // Damage increase percentage (damage follows count)
    // Calculate damage
    // let final = caster.attributes.ATT*attFator*(1 - target.attributes.DEF / (602 + target.attributes.DEF));
    let final = Decimal.mul(caster.attributes.ATT, attFator).mul(Decimal.sub(1, Decimal.div(target.attributes.DEF, Decimal.add(602, target.attributes.DEF))));
    final = final.add(final.mul(damageIncreasePercent).div(100));  // Damage = Damage + Damage * Damage increase factor percentage / 100
    final = final.sub(final.mul(target.attributes.ReduceInjury).div(100));  // Damage = Damage - Damage * Damage reduction percentage / 100
    let isCrit = this.IsCrit(caster.attributes.CRI) || this.isBreakingHiddenNormalSkillCrit;
    if (isCrit) {  // Probability crit or breaking stealth normal attack guaranteed crit
      final = final.mul(1.5);  // Crit damage 1.5x
    }

    let damage = new DamageInfo();
    damage.entityId = target.entityId;
    damage.Damage = Decimal.max(1, final.toFixed(1));
    damage.Crit = isCrit;
    damage.isStealth = target.EffectMgr.HasEffect(BuffEffect.Stealth)

    // Vampirism
    let vampirism = this.Owner.attributes.Vampirism;
    if (vampirism.gt(0)) {  // Vampirism probability greater than 0
      let vampirismValue = Math.max(1, Math.floor(Decimal.mul(final, vampirism).div(100).toNumber()));
      if (vampirismValue > 0) {
        this.Owner.attributes.RestoreHpValue(vampirismValue);
        if (caster.user && caster.user.id == User.Instance.user.id) {  // Caster is current user
          UIWorldElementManager.Instance.ShowPopupText(PopupType.Heal, caster, '+' + vampirismValue);
        }
      }
    }
    return damage;
  }

  /**
   * Whether crit
   * @param crit 
   */
  private IsCrit(crit: Decimal): boolean {
    return RandomUtil.limitIntegerBattle(0, 100) < crit.toNumber();
  }
  /**
   * Whether dodge
   * @param dodge 
   */
  private IsDodge(dodge: Decimal): boolean {
    return RandomUtil.limitIntegerBattle(0, 100) < dodge.toNumber();
  }


  /**
   * Sub skill re-search targets
   */
  public SubSkillNewSearch() {
    if (this.Hit > 0 && this.Define.SubSkillIds && this.Define.SubSkillIds.length >= this.Hit) {
      let subSkill = this.Owner.SkillMgr.GetSkill(this.Define.SubSkillIds[this.Hit - 1]);
      if (!subSkill.Define.isNewSearch) {
        return;
      }
      subSkill.Context = this.Context;
      // let creatureArr = subSkill.GetRangeTargetList();
      // subSkill.TowardTarget(creatureArr, true);  // Face target
      // subSkill.Context.isPlaySkillAnim = creatureArr.length > 0;  // No one then no animation
      subSkill.Context.isPlaySkillAnim = true;
    }
  }

  /**
   * Whether can interrupt skill casting
   * @returns 
   */
  public isCancelCasting() {
    if (this.Define.againClickIsCancelCasting && this.actionTime > 0) {  // Skill interrupt click
      return true;
    }
    return false;
  }

  /**
   * Cancel skill release
   */
  public CancelCastSkill() {
    // console.log('CancelCastSkill =============')
    if (this.isCancelCasting()) {  // Skill interrupt click
      this.isStopCasting = true;
      if (!this.IsCanInterrupt()) {  // Cannot interrupt
        return;
      }
      this.SkillInterruptHandle();
    }
  }

  /**
   * Whether can interrupt
   */
  private IsCanInterrupt(): boolean {
    if (!this.Define.RunningIsCanInterrupt && this.Status == SkillStatus.Running) { // Executing, skill cannot interrupt
      return false;
    }
    return true;
  }

  /**
   * Validate whether skill is interrupted
   */
  public validateIsSkillInterrupt(): boolean {
    if (this.isStopCasting || this.Owner.battleAttribute.CanInterruptSkillCount > 0) {   // Interrupt casting
      return this.IsCanInterrupt();
    }
    return false;
  }

  /**
   * Skill interrupt handling
   */
  public SkillInterruptHandle() {
    // console.log('Skill interrupt handling==========')
    this.isStopCasting = true;
    if (!this.Define.Bullet) {  // Not bullet
      this.Status = SkillStatus.None;
    }
    if (!this.Owner.IsDeath) {
      this.Owner.SetAnim(AniState.Idle, true);
    }
    this.actionTime = 0;
    if (this.effectNode) {
      this.effectNode.removeFromParent();
      PoolManager.instance.putNode(this.effectNode);
      this.effectNode = null;
    }
    if (this.Owner.entityId == BattleManager.Instance.currentCharacter.entityId) {
      // console.error('Stop playing sound effect')
      SoundManager.Instance.StopSound(true);  // Stop playing sound effect
    }
  }

  private targetSelectedNode:Node;  // Target selected circle
  private lastTargetEntityId:number;  // Last selected target id

  /**
   * Target selected update
   */
  private TargetSelectedUpdate(){
    let target = this.Target;
    if(!target || this.typeStr != SkillType[SkillType.Normal] || !this.Owner || !this.Owner.user || 
      this.Owner.user.id != User.Instance.user.id){ 
      if(this.targetSelectedNode){
        this.targetSelectedNode.removeFromParent();
        this.targetSelectedNode = null;
      }
      return; 
    }
    
    if(target && !target.IsDeath && !this.Owner.IsDeath){  // Has target, not dead
      if(!this.targetSelectedNode){
        this.targetSelectedNode = BattleGlobal.skillTipsMap.get(SkillTipsType[SkillTipsType.TargetSelected]) as Node;
      }
      if(!this.lastTargetEntityId || this.lastTargetEntityId != target.entityId){
        this.targetSelectedNode.parent = target.node.parent;
        this.lastTargetEntityId = target.entityId;
      }
   
      let logicDis = this.Owner.Distance(target);
      if(logicDis > LogicRenderConvert.RenderToLogic_Value(BattleGlobal.showSelectedQuanTargetRange)){  // Lost target, out of range
        this.Target = null;
      }
    }else{ // No target exists
      if(this.targetSelectedNode){
        this.targetSelectedNode.removeFromParent();
        this.targetSelectedNode = null;
      }
    }
  }

  update(){
    this.TargetSelectedUpdate();
  }

  /**
   * Rollback state
   */
  rollback(data: SkillRecord): void {
    if (data.Context) {
      let skill: Skill = null;
      if (data.Context.skillId) {
        skill = this.Owner.SkillMgr.GetSkill(data.Context.skillId);
      }
      if (!this.Context) {
        this.Context = new BattleContext(skill, this.Owner);
      }
      this.Context.skill = skill;
      this.Context.Caster = this.Owner;
      this.Context.rollback(data.Context);
    }
    this.skillId = data.skillId;
    this.Status = data.Status;
    this.cd = data.cd;
    this.castingTime = data.castingTime;
    this.skillTime = data.skillTime;
    this.Hit = data.Hit;
    this.frameId = data.frameId;
    this.actionTime = data.actionTime;

    let skill = this.Owner.SkillMgr.GetSkill(data.skillId);
    for (let bulletRecord of data.Bullets) {
      let bullet = new Bullet(skill, undefined, bulletRecord.anglesOffest, bulletRecord.delayTime);
      bullet.rollback(bulletRecord);
      this.Bullets.push(bullet);
    }

    this.isDurationEnd = data.isDurationEnd;
    this.isBreakingHiddenNormalSkillCrit = data.isBreakingHiddenNormalSkillCrit;
    this.isStopCasting = data.isStopCasting;

    // Skill last searched target collection
    if (data.lastSearchCreatureArr) {
      this.lastSearchCreatureArr = [];
      for (let entityId of data.lastSearchCreatureArr) {
        let targetCreature = CreatureManager.Instance.GetCreature(entityId);
        if (targetCreature) {
          this.lastSearchCreatureArr.push(targetCreature);
        }
      }
    }

    this.peopleNum = data.peopleNum;
  }

}