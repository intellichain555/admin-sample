import { Buff } from "./Buff";
import { BattleGlobal } from "../Utils/BattleGlobal";
import { BuffEffect } from "../enums/BuffEffect";
import { Creature } from "../Enities/Creature";
import { tween, Vec3, Node, SkinnedMeshRenderer, Color } from "cc";
import { UIWorldElementManager } from "../UIWorldElementManager";
import { MathUtil } from "../../../Utils/MathUtil";
import { GhostManager } from "../Effects/GhostManager";
import { DataManager } from "../../../Managers/DataManager";
import { CollisionCheckManager } from "../Managers/CollisionCheckManager";
import { LogicRenderConvert } from "../Utils/LogicRenderConvert";
import { FXManager } from "../Effects/FXManager";
import { PopupType } from "../enums/PopupType";
import { BattleManager } from "../Managers/BattleManager";
import { User } from "../../../Models/User";
import { EventManager } from "../../Common/Event/EventManager";
import { EventType } from "../../Common/Event/EventType";
import { IStateRollback } from "../StateRecord/IStateRollback";
import { EffectRecord } from "../StateRecord/Models/EffectRecord";
import { Constant } from "../../../../../Scripts/Utils/Constant";

/**
 * Effect
 */
export class Effect implements IStateRollback{

    private Owner:Creature;
    public buff:Buff;
    public buffEffect:BuffEffect;
    private shanBiEffectHolder = { node: null as Node | null };   // Dodge effect
    private jiasuEffectHolder = { node: null as Node | null };    // Speed boost effect
    private cureEffectHolder = { node: null as Node | null };   // Healing effect (reuse logic)
    private yunEffectHolder = { node: null as Node | null };      // Stun effect
    private frozenEffectHolder = { node: null as Node | null };   // Frozen effect
    private huichengEffectHolder = { node: null as Node | null }; // Recall effect
    private runSmokeEffectHolder = { node: null as Node | null }; // Movement effect
    private huoEffectNode: Node | null = null;  // Burning effect (unused)
    private jiansuEffectHolder = { node: null as Node | null };   // Slow effect

    private currentWorldPosition = new Vec3();
    private worldPositionTemp = new Vec3();
    private tween:any = null;


    public constructor(owner:Creature, buff:Buff, buffEffect:BuffEffect, num:number, isBuffTrigger = false, isOnAdd = true) {
        this.Owner = owner;
        this.buff = buff;
        this.buffEffect = buffEffect;
        if(isOnAdd){
          this.OnAdd(num, isBuffTrigger);
        }
    }

    /**
     * Add effect
     * @param this.buffEffect 
     * @param buff 
     */
    private OnAdd(num:number, isBuffTrigger = false) {
        // console.log("OnAdd", this.Owner.characterDefine.Name, num);
        // Add effect
        if(this.buffEffect == BuffEffect.Fly){ // Knockup          
          this.Owner.battleAttribute.CanMoveCount++;  // Update move count
          this.Owner.battleAttribute.CanSkillCount++;  // Update skill count
          this.Owner.battleAttribute.CanDisableSkillCount++;  // Update disable skill count
          this.Owner.battleAttribute.CanInterruptSkillCount++;  // Update interrupt skill count

          this.Owner.isUpdateRenderingPos = false; // Stop updating render position
          this.Owner.AnimEnableOrStop(false);  // Pause animation 

          let upDuration = this.buff.Define.Duration / 1000 * 0.35;  // Launch animation time
          let waitDuration = this.buff.Define.Duration / 1000 * 0.3;  // Airborne wait animation time
          let downDuration = this.buff.Define.Duration / 1000 * 0.35;  // Fall animation time

          let moveDis = this.buff.Define.MoveDis;  // Movement distance

          let parentNode = this.Owner.node.parent;
          parentNode.getWorldPosition(this.currentWorldPosition);
          this.worldPositionTemp.set(this.currentWorldPosition.x, this.currentWorldPosition.y + moveDis,this.currentWorldPosition.z);

          if(this.tween){
            this.tween.stop()
          }
          // console.log('Knockup animation start Name='+this.Owner.characterDefine.Name)       
          this.tween = tween(parentNode)
                 .to(upDuration, {worldPosition: this.worldPositionTemp}, { easing: "elasticInOut" })
                 .delay(waitDuration)
                 .to(downDuration, {worldPosition: this.currentWorldPosition}, { easing: 'elasticOut' })
                 .call(() => {
                  //  console.log('Knockup animation complete')
                }).start();
          UIWorldElementManager.Instance.ShowPopupText(PopupType.EffectTips, this.Owner, 'Knockup!', undefined, 1);
        }else if(this.buffEffect == BuffEffect.Repel){ // Knockback
          this.Owner.isRepeling = true;
          this.Owner.battleAttribute.CanMoveCount++;  // Update move count
          this.Owner.battleAttribute.CanSkillCount++;  // Update skill count
          this.Owner.battleAttribute.CanDisableSkillCount++;  // Update disable skill count
          this.Owner.EffectMgr.dispSpeed = Math.round(this.buff.Define.MoveDis * 10 / MathUtil.millisecondToFrame(this.buff.Define.Duration));  // Displacement speed per frame
          this.Owner.EffectMgr.dirDegree = Math.round(this.buff.Context.dirDegree);

        }else if(this.buffEffect == BuffEffect.Disp){ // Displacement
          let context = this.buff.Context;
          if(context.isDisplacementStop){ // Displacement stop
            return;
          }
          this.Owner.IsDisplacementing = true;
          this.Owner.battleAttribute.CanMoveCount++;  // Update move count
          this.Owner.battleAttribute.CanSkillCount++;  // Update skill count

          if(context.Target){  // Target exists, displace to target front
             // Displacement reverse offset distance: choose between self radius + target radius or configured displacement distance
             let positionOffset = this.buff.Define.PositionOffset;
             let offsetLen = 0;
             if(positionOffset){
               offsetLen = positionOffset * 10;
             }else{
               offsetLen = (this.Owner.characterDefine.Radius + context.Target.characterDefine.Radius) * 10;
             }
             let rockerSpeedVo = DataManager.Instance.rockerSpeeds[Math.round(context.dirDegree)];
             if(!rockerSpeedVo){
               console.log('rockerSpeedVo does not exist!'+context.dirDegree)
               return;
             }        
            let vx = context.Target.logicPosition.x + (-rockerSpeedVo.x*offsetLen);
            let vz = context.Target.logicPosition.z + (-rockerSpeedVo.y*offsetLen);       
            let renderDis = LogicRenderConvert.LogicToRender_Value(this.Owner.Distance3(vx, vz));
            this.Owner.EffectMgr.dispSpeed = Math.round(renderDis * 10 / MathUtil.millisecondToFrame(this.buff.Define.Duration));  // Displacement speed per frame
          }else if(context.logicPositionX && context.logicPositionZ){
            let renderDis = LogicRenderConvert.LogicToRender_Value(this.Owner.Distance3(context.logicPositionX, context.logicPositionZ));
            this.Owner.EffectMgr.dispSpeed = Math.round(renderDis * 10 / MathUtil.millisecondToFrame(this.buff.Define.Duration));  // Displacement speed per frame
          }else{
            this.Owner.EffectMgr.dispSpeed = Math.round(this.buff.Define.MoveDis * 10 / MathUtil.millisecondToFrame(this.buff.Define.Duration));  // Displacement speed per frame
          }
          this.Owner.EffectMgr.dirDegree = Math.round(context.dirDegree);
          //  console.error((this.Owner.user ? this.Owner.user.id : '')+'，Displacing OnAdd ，speed = ' + this.Owner.EffectMgr.dispSpeed+
          //  '，num='+num+'，isBuffTrigger='+isBuffTrigger+'，Effects2=', this.Owner.EffectMgr.Effects2)

           if(this.buff.Define.isShowGhost){
            //  let msSpeed = this.buff.Define.MoveDis  / this.buff.Define.Duration;   // Ghost movement speed per millisecond
             let context = this.buff.Context;
             GhostManager.Instance.ShowGhost(this.Owner, context.skill.Define.SkillAnim); // Show ghost
           }
           if(!this.buff.Define.isNoShowParticle){
             FXManager.Instance.PlayEffect3(BattleGlobal.runSmokeName, this.Owner.effectParentNode, true, this.runSmokeEffectHolder);
           }
        }else if(this.buffEffect == BuffEffect.Dodge){ // Dodge
         FXManager.Instance.PlayEffect3(BattleGlobal.shanbiName, this.Owner.effectParentNode, true, this.shanBiEffectHolder);

        }else if(this.buffEffect == BuffEffect.Flash){ // Flash
          let context = this.buff.Context;
          let skill = context.skill;
          if(context.Target){  // Target exists, flash to target front
            // Flash reverse offset distance: self radius + target radius
            let offsetLen = (this.Owner.characterDefine.Radius + context.Target.characterDefine.Radius) * 10;
            let rockerSpeedVo = DataManager.Instance.rockerSpeeds[Math.round(context.dirDegree)];
            if(!rockerSpeedVo){
              console.log('rockerSpeedVo does not exist!'+context.dirDegree)
              return;
            }        
            let vx = context.Target.logicPosition.x + (-rockerSpeedVo.x*offsetLen);
            let vz = context.Target.logicPosition.z + (-rockerSpeedVo.y*offsetLen);            
            this.Owner.LogicToRenderPosition(vx, this.Owner.logicPosition.y, vz, undefined, undefined, true);
          }else{  // Target does not exist, flash to specified position 
             // Position does not exist, calculate position on cast range circle
            if(!context.logicPositionX || !context.logicPositionZ){
              let rockerSpeedVo = DataManager.Instance.rockerSpeeds[Math.round(context.dirDegree)];
              if (!rockerSpeedVo) {
                  console.log('UISkillSlot OnTouchStart not rockerSpeedVo! dirDegree=' + context.dirDegree)
                  return;
              }

              let castRange = context.skill.Define.CastRange;
              context.logicPositionX = this.Owner.logicPosition.x + (castRange * 10 * rockerSpeedVo.x);
              context.logicPositionZ = this.Owner.logicPosition.z + (castRange * 10 * rockerSpeedVo.y);
            }

            if(context.logicPositionX && context.logicPositionZ){
              let isCollision = CollisionCheckManager.Instance.FlashCollisionCheckRectObstacles(this.Owner, Math.round(context.dirDegree), skill.Define.CastRange);
              console.log("Target does not exist, flash to specified position collision="+isCollision)
              if(!isCollision){ // No collision
                this.Owner.LogicToRenderPosition(context.logicPositionX, this.Owner.logicPosition.y, context.logicPositionZ, undefined, undefined, true);
              }
            }
          }
          if(skill.Define.AppearEffect){   // Flash appear effect (deferred for safety)
            this.Owner.EntityEffectMgr.PlayEffect3(skill.Define.AppearEffect, undefined, undefined, true);
          }
          this.Owner.MoveHandle();   // Collision correction after flash
        }else if(this.buffEffect == BuffEffect.Stun){ // Stun
          this.Owner.battleAttribute.CanMoveCount++;  // Update move count
          this.Owner.battleAttribute.CanSkillCount++;  // Update skill count
          this.Owner.battleAttribute.CanDisableSkillCount++;  // Update disable skill count
          this.Owner.battleAttribute.CanInterruptSkillCount++;  // Update interrupt skill count
          // UIWorldElementManager.Instance.ShowPopupText(PopupType.EffectTips, this.Owner, 'Stun!', undefined, 1);
          
            FXManager.Instance.PlayEffect3(BattleGlobal.yunName, this.Owner.effectParentNode, true, this.yunEffectHolder, { yValue: this.Owner.characterDefine.Height + 0.3 });
          

          this.Owner.isUpdateRenderingPos = false; // Stop updating render position

          this.Owner.AnimEnableOrStop(false);  // Pause animation 
         
        }else if(this.buffEffect == BuffEffect.TuiKai){ // Push away          
          this.Owner.isTuiKaiing = true;
          this.Owner.battleAttribute.CanMoveCount++;  // Update move count
          this.Owner.battleAttribute.CanSkillCount++;  // Update skill count
          this.Owner.battleAttribute.CanDisableSkillCount++;  // Update disable skill count
        }else if(this.buffEffect == BuffEffect.AddSpeed){ // Speed boost
            FXManager.Instance.PlayEffect3(BattleGlobal.jiasuName, this.Owner.effectParentNode, true, this.jiasuEffectHolder);
        }else if(this.buffEffect == BuffEffect.Stealth){ // Stealth
          this.Owner.battleAttribute.StealthCount++;  // Update stealth count
          let currentCharacter = BattleManager.Instance.currentCharacter;
          if(this.Owner.teamType2 == currentCharacter.teamType2){   // Self or teammate          
            this.Owner.SetTransparency(50);
          }else{
            this.Owner.IsShowHpNode = false;
            this.Owner.node.parent.active = false;
          }
        }else if(this.buffEffect == BuffEffect.Petrified){ // Petrified          
          this.Owner.battleAttribute.CanMoveCount++;  // Update move count
          this.Owner.battleAttribute.CanSkillCount++;  // Update skill count
          this.Owner.battleAttribute.CanDisableSkillCount++;  // Update disable skill count
          this.Owner.battleAttribute.CanInterruptSkillCount++;  // Update interrupt skill count
          this.Owner.AnimEnableOrStop(false);  // Pause animation 

          this.Owner.SetMainTexture(BattleManager.Instance.shihuaTexture2D);
          // Get all materials
          // let skinnedMeshRendererArr = this.Owner.node.getComponentsInChildren(SkinnedMeshRenderer);
          // if (skinnedMeshRendererArr) {
          //   for (let k = 0; k < skinnedMeshRendererArr.length; k++) {
          //     let meshRenderer = skinnedMeshRendererArr[k];
          //     for (let j = 0; j < meshRenderer.materials.length; j++) {
          //       // Replace material
          //       let shihuaMat = BattleGlobal.effectMaterialsMap.get(BattleGlobal.shihuaName);
          //       meshRenderer.setMaterial(shihuaMat, j);
          //     }
          //   }
          // }
        }else if(this.buffEffect == BuffEffect.Treatment){ // Healing
          if(!this.cureEffectHolder.node){
            FXManager.Instance.PlayEffect3(BattleGlobal.cureName, this.Owner.effectParentNode, true, this.cureEffectHolder);
          }else{
            this.cureEffectHolder.node.active = true;
          }
        }else if(this.buffEffect == BuffEffect.Frost){ // Frozen
          this.Owner.battleAttribute.CanMoveCount++;  // Update move count
          this.Owner.battleAttribute.CanSkillCount++;  // Update skill count
          this.Owner.battleAttribute.CanDisableSkillCount++;  // Update disable skill count
          this.Owner.battleAttribute.CanInterruptSkillCount++;  // Update interrupt skill count
          this.Owner.AnimEnableOrStop(false);  // Pause animation 
          const diameter = this.Owner.characterDefine.Radius * 2 * 14;
          const height = this.Owner.characterDefine.Height * 3;
          FXManager.Instance.PlayEffect3(BattleGlobal.frozenName, this.Owner.effectParentNode, true, this.frozenEffectHolder, { scale: new Vec3(diameter, diameter, height) });
        }else if(this.buffEffect == BuffEffect.HuiCheng){ // Recall
          FXManager.Instance.PlayEffect3(BattleGlobal.huichengName, this.Owner.effectParentNode, true, this.huichengEffectHolder);
          if(this.Owner.user && this.Owner.user.id == User.Instance.user.id){
            BattleManager.Instance.uiBattle.uiReturnCity.show(this.buff);
          }
        }else if(this.buffEffect == BuffEffect.ZiDong){ // AI auto
          console.log('ZiDong add================')
          this.Owner.isAiControlFlag = true;
          if(this.Owner.AI.ai){  // Set to pathfinding state
            this.Owner.AI.ai.aiState = Constant.AIState.pathWay;
          }
          if(this.Owner.user && this.Owner.user.id == User.Instance.user.id) {
            EventManager.Instance.dispatch(EventType.OnAiZiDong, 'add');
          }
        }else if(this.buffEffect == BuffEffect.Burning){ // Burning
          // this.huoEffectNode = FXManager.Instance.PlayEffect3(BattleGlobal.huoName, this.Owner.effectParentNode);
          // console.log('OnAdd burning huoEffectNode=', this.huoEffectNode)
        }else if(this.buffEffect == BuffEffect.Dece){ // Slow
          this.Owner.battleAttribute.DeceCount++;
          FXManager.Instance.PlayEffect3(BattleGlobal.jiansuName, this.Owner.effectParentNode, true, this.jiansuEffectHolder);
        }
    }

    /**
     * Remove effect
     * @param buffEffect 
     */
    public OnRemove(buffEffect:BuffEffect, num:number, isBuffTrigger = false) {
        // console.log("OnRemove", this.Owner.characterDefine.Name, num);
        // Stack count is 0, remove Buff
        if(num == 0 && this.buff){
          // console.log('Remove Buff num ='+num)
          this.Owner.BuffMgr.RemoveBuff(this.buff.Define.ID);
        }

        if(this.buffEffect == BuffEffect.Fly){ // Knockup end
          this.Owner.battleAttribute.CanMoveCount--;  // Update move count
          this.Owner.battleAttribute.CanSkillCount--;  // Update skill count
          this.Owner.battleAttribute.CanDisableSkillCount--;  // Update disable skill count
          this.Owner.battleAttribute.CanInterruptSkillCount--;  // Update interrupt skill count
          this.Owner.isUpdateRenderingPos = true; // Update render position
          this.Owner.AnimEnableOrStop(true);  // Enable animation 
          

        }else if(this.buffEffect == BuffEffect.Repel){ // Knockback end
          this.Owner.isRepeling = false;
          this.Owner.battleAttribute.CanMoveCount--;  // Update move count
          this.Owner.battleAttribute.CanSkillCount--;  // Update skill count
          this.Owner.battleAttribute.CanDisableSkillCount--;  // Update disable skill count

        }else if(this.buffEffect == BuffEffect.Disp){ // Displacementend
          let context = this.buff.Context;
          if(context.isDisplacementStop){ // Displacement stop
            return;
          }
          this.Owner.IsDisplacementing = false;
          this.Owner.battleAttribute.CanMoveCount--;  // Update move count
          this.Owner.battleAttribute.CanSkillCount--;  // Update skill count

          if(this.buff.Define.isShowGhost){
            GhostManager.Instance.HideGhost(this.Owner); // Hide ghost
          }
          // this.Owner.MoveHandle();   // Collision correction after displacement, avoid overlapping with other collision-enabled creatures
          context.skill.SubSkillNewSearch();

          if(!this.buff.Define.isNoShowParticle){
            FXManager.Instance.recoveryNode(this.runSmokeEffectHolder.node);
          }

        }else if(this.buffEffect == BuffEffect.Dodge){ // Dodgeend
          FXManager.Instance.recoveryNode(this.shanBiEffectHolder.node);
        }else if(this.buffEffect == BuffEffect.Stun){ // Stunend
          this.Owner.battleAttribute.CanMoveCount--;  // Update move count
          this.Owner.battleAttribute.CanSkillCount--;  // Update skill count
          this.Owner.battleAttribute.CanDisableSkillCount--;  // Update disable skill count          
          this.Owner.battleAttribute.CanInterruptSkillCount--;  // Update interrupt skill count
            FXManager.Instance.recoveryNode(this.yunEffectHolder.node);
          

          this.Owner.isUpdateRenderingPos = true; // Update render position
          this.Owner.AnimEnableOrStop(true);  // Enable animation 
          
        }else if(this.buffEffect == BuffEffect.TuiKai){ // Push awayend
          this.Owner.isTuiKaiing = false;
          this.Owner.battleAttribute.CanMoveCount--;  // Update move count
          this.Owner.battleAttribute.CanSkillCount--;  // Update skill count
          this.Owner.battleAttribute.CanDisableSkillCount--;  // Update disable skill count
        }else if(this.buffEffect == BuffEffect.AddSpeed){ // Speed boostend
          FXManager.Instance.recoveryNode(this.jiasuEffectHolder.node);
        }else if(this.buffEffect == BuffEffect.Stealth){ // Stealthend
          this.Owner.battleAttribute.StealthCount--;  // Update stealth count
          this.Owner.SetTransparency(255);
          if(!this.Owner.IsDeath){  // Show HP bar if not dead
            this.Owner.IsShowHpNode = true;
          }
          this.Owner.node.parent.active = true;         
        }else if(this.buffEffect == BuffEffect.Petrified){ // Petrifiedend
          this.Owner.battleAttribute.CanMoveCount--;  // Update move count
          this.Owner.battleAttribute.CanSkillCount--;  // Update skill count
          this.Owner.battleAttribute.CanDisableSkillCount--;  // Update disable skill count
          this.Owner.battleAttribute.CanInterruptSkillCount--;  // Update interrupt skill count
          this.Owner.AnimEnableOrStop(true);  // Enable animation 

          this.Owner.SetMainTexture();
          // Get all materials
          // let skinnedMeshRendererArr = this.Owner.node.getComponentsInChildren(SkinnedMeshRenderer);
          // if (skinnedMeshRendererArr) {
          //   let matIndex = 0;
          //   for (let k = 0; k < skinnedMeshRendererArr.length; k++) {
          //     let meshRenderer = skinnedMeshRendererArr[k];
          //     for (let j = 0; j < meshRenderer.materials.length; j++) {
          //       // Replace material
          //       let instanceMaterialArr = this.Owner.instanceMaterialArr;
          //       if(instanceMaterialArr && instanceMaterialArr.length > 0){
          //         let mat = instanceMaterialArr.length > matIndex ? instanceMaterialArr[matIndex] : instanceMaterialArr[instanceMaterialArr.length - 1];
          //         meshRenderer.setMaterial(mat, j);
          //       }
          //       matIndex++;
          //     }
          //   }
          // }
        }else if(this.buffEffect == BuffEffect.Treatment){ // Healingend
          if(this.cureEffectHolder.node){
            this.cureEffectHolder.node.active = false;
          }
        }else if(this.buffEffect == BuffEffect.Frost){ // Frozenend
          this.Owner.battleAttribute.CanMoveCount--;  // Update move count
          this.Owner.battleAttribute.CanSkillCount--;  // Update skill count
          this.Owner.battleAttribute.CanDisableSkillCount--;  // Update disable skill count
          this.Owner.battleAttribute.CanInterruptSkillCount--;  // Update interrupt skill count
          this.Owner.AnimEnableOrStop(true);  // Enable animation 
          FXManager.Instance.recoveryNode(this.frozenEffectHolder.node);
        }else if(this.buffEffect == BuffEffect.HuiCheng){ // Recallend
          FXManager.Instance.recoveryNode(this.huichengEffectHolder.node);
          if(this.Owner.user && this.Owner.user.id == User.Instance.user.id){
            BattleManager.Instance.uiBattle.uiReturnCity.hide();
          }
          if(isBuffTrigger){  // Buff trigger end, return to spawn point
            this.Owner.initBirthPosRot();
          }
        }else if(this.buffEffect == BuffEffect.ZiDong){ // AI autoend
          // console.log('ZiDong remove================')
          this.Owner.isAiControlFlag = false;
          if(this.Owner.user && this.Owner.user.id == User.Instance.user.id) {
            EventManager.Instance.dispatch(EventType.OnAiZiDong, 'remove');
          }
        }else if(this.buffEffect == BuffEffect.Burning){ // Burning
          // FXManager.Instance.recoveryNode(this.huoEffectNode);
        }else if(this.buffEffect == BuffEffect.Dece){ // Slow
          this.Owner.battleAttribute.DeceCount--;
          FXManager.Instance.recoveryNode(this.jiansuEffectHolder.node);
        }
        
    }

     /**
     * Logic update
     */
    public LogicUpdate(frameId: number) {
        if(this.buffEffect == BuffEffect.Disp && this.Owner.IsDisplacementing){  // Displacing
          let effectMgr = this.Owner.EffectMgr;
          this.Owner.Move(effectMgr.dirDegree, effectMgr.dispSpeed);  // Rapidly move character in specified direction
          // if(effectMgr.hitArr && effectMgr.hitArr.length > 0){  // Damage list exists indicating displacement push, decelerate
          //   effectMgr.dispSpeed -= effectMgr.hitArr.length / 5;
          //   for(let tuiKaiCreature of effectMgr.hitArr){
          //     tuiKaiCreature.EffectMgr.dispSpeed = effectMgr.dispSpeed;
          //   }
          // }
          // console.log(this.Owner.user.id + '，time='+(this.buff ? this.buff.time : '')+'，Displacing dirDegree='+effectMgr.dirDegree+'，dispSpeed='+effectMgr.dispSpeed)
        }else if(this.buffEffect == BuffEffect.TuiKai && this.Owner.isTuiKaiing){ // Being pushed away
          let effectMgr = this.Owner.EffectMgr;
          // console.log('Being pushed away name='+this.Owner.characterDefine.Name+'，speed='+(effectMgr.dispSpeed)+'，dirDegree='+effectMgr.dirDegree)
          this.Owner.Move(effectMgr.dirDegree, effectMgr.dispSpeed);  // Rapidly move character in specified direction 
        }else if(this.buffEffect == BuffEffect.Repel && this.Owner.isRepeling){  // Being knocked back
          let effectMgr = this.Owner.EffectMgr;
          // If within caster's attack range, no decay, otherwise decay
          let isRangeInFlag:boolean = false;
          if(this.buff){
            let context = this.buff.Context;
            if(this.Owner.Distance(context.Caster) < LogicRenderConvert.RenderToLogic_Value(context.skill.Define.CastRange)){
              isRangeInFlag = true;
            }
          }
          if(!isRangeInFlag){  // Not in range
            effectMgr.dispSpeed -= 0.02;
          }
          this.Owner.Move(effectMgr.dirDegree, effectMgr.dispSpeed);  // Rapidly move character in specified direction           
        }
  
      }
  

   /**
     * Rollback state
    */
    rollback(data:EffectRecord):void{
      data.buffEffect = this.buffEffect;
    }
       
}