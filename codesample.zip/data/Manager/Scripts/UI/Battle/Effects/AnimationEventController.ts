import { _decorator, instantiate, Node, Component, Vec3, AnimationComponent, Prefab, UITransform } from 'cc';
import { EntityEffectManager } from './EntityEffectManager';
import { TeamType2 } from '../enums/TeamType2';
import { CreatureManager } from '../Managers/CreatureManager';
import { BattleManager } from '../Managers/BattleManager';
import { BattleGlobal } from '../Utils/BattleGlobal';
import { SoundManager } from '../../../../../Scripts/Sound/SoundManager';
const { ccclass, property } = _decorator;

@ccclass('AnimationEventController')
export class AnimationEventController extends Component{
    
    private path: string = "Battle/";

    @property(EntityEffectManager)
    public EffectMgr:EntityEffectManager;

    public isGhost:boolean = false;  // Whether is ghost

    /**
     * Play effect
     * @param name Effect prefab name
     * @param isEffectFollowHero Whether effect follows hero when casting
     * @param teamType2 Team type  0、Blue team  1、Red team  2、Neutral
     */
    public PlayEffect(name:string, isEffectFollowHero?:boolean, teamType2?:TeamType2) {
        if(this.isGhost || BattleManager.Instance.uiBattle.isOpenUIEnterGameLoad()) {
            return;
        }
        // console.log("AnimationEventController:PlayEffect:", name, isEffectFollowHero, teamType2);
        this.EffectMgr.PlayEffect3(name, isEffectFollowHero, teamType2, true);  // Deferred for safety (parent may be destroyed)

    }

    /**
     * Play sound
     * @param name Sound name
     */
    public PlaySound(name:string) {
        if(this.isGhost || BattleManager.Instance.uiBattle.isOpenUIEnterGameLoad() || BattleGlobal.isGameEndFlag) {
            return;
        }
       
        let entityId = this.node['entityId'];
        let creature = CreatureManager.Instance.GetCreature(entityId);
        // Already interrupted casting
        if(BattleGlobal.validateIsSkillInterrupt(creature)){
            // console.error('Interrupted casting, exit playing sound='+(name))
            return;
        }
        let currentCharacter = BattleManager.Instance?.currentCharacter;
        if(currentCharacter && entityId == currentCharacter.entityId){   // Current character
          SoundManager.Instance.PlaySound(this.path + name, true);
        }else{  // Non-current character, volume attenuates by distance
          let volumeScale = BattleGlobal.getVolumeByDist(this.node.worldPosition, BattleManager.Instance.camera.worldPosition);
          SoundManager.Instance.playOneShot(this.path + name, volumeScale);
        }
    }
    
}