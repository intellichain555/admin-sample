import { _decorator, instantiate, Node, Component, Vec3, AnimationComponent, Prefab, UITransform, Vec2, isValid, NodePool, CCFloat, CCInteger } from 'cc';
import { EffectType } from './EffectType';
import { Bullet } from '../Models/Bullet';
import { MathUtil } from '../../../Utils/MathUtil';
import { NetConfig } from '../../../Network/NetConfig';
import { LogicRenderConvert } from "../Utils/LogicRenderConvert";
import { BattleGlobal } from '../Utils/BattleGlobal';
import { PoolManager } from '../../../Managers/PoolManager';
import { RandomUtil } from '../Utils/RandomUtil';
import { Creature } from '../Enities/Creature';
const { ccclass, property } = _decorator;

@ccclass('EffectController')
export class EffectController extends Component{

    @property(CCFloat)
    public lifeTime:number = 1;
    @property(CCInteger)
    public preloadCount:number = 1;  // Preload count
   
    
    private time:number = 0;

    private type:EffectType=EffectType.None;
    private target:Node;

    private targetPos:Vec3=new Vec3();
    private startPos:Vec3;
    private offset:Vec3;
    private bullet:Bullet;

    onEnable() {
        if(this.type != EffectType.Bullet && this.type != EffectType.BulletRealCheck) {
            let this_ = this;
            setTimeout(function(){
                // console.log('setTimeout recycle')
              this_.recoveryThisNode();  
            },BattleGlobal.isNormalPlay ? this.lifeTime * 1000 : this.lifeTime * 1000 / BattleGlobal.framePlaySpeed / 1.5) 
        }
    }

    public Init(type:EffectType, source:Node, target:Node, offset:Vec3, duration:number=0, bullet?:Bullet) {
        this.type = type;
        this.target = target;
        if(duration > 0){
            this.lifeTime = duration;
        }
        this.time = 0;
        if (type == EffectType.Bullet) {
            this.bullet = bullet;
            this.startPos = this.node.worldPosition;
            // Set rotation angle
           this.node.worldRotation.getEulerAngles(this.worldRotation_);
           this.node.setWorldRotationFromEuler(this.worldRotation_.x, this.bullet.dirDegree, this.worldRotation_.z);
            // this.offset = offset;
            // this.targetPos.set(target.worldPosition.x + offset.x, target.worldPosition.y + offset.y, target.worldPosition.z + offset.z);
            // console.log('EffectController Init targetPos='+this.targetPos)
        } else if(type==EffectType.Hit) {
            this.targetPos.set(target.worldPosition.x + offset.x, target.worldPosition.y + offset.y, target.worldPosition.z + offset.z);
            this.node.worldPosition = this.targetPos;
        } else if(type==EffectType.Position) {
            // this.targetPos.set(offset.x, offset.y, offset.z);
            this.node.worldPosition = offset;
        }
    }

    private worldRotation_ = new Vec3();
    public InitBulletRealCheck(type:EffectType, bullet:Bullet){
        // console.log("InitBulletRealCheck")
        this.type = type;
        this.bullet = bullet;
        // Set rotation angle
        this.node.worldRotation.getEulerAngles(this.worldRotation_);
        // this.worldRotation_.y = this.bullet.skill.Owner.logicRotation.y;  // Y-axis set to character logic Y position, avoid character tween rotation causing bullet position deviation
        // let y = BattleGlobal.AngleRangeHandle(this.worldRotation_.y + this.bullet.anglesOffest);
        this.node.setWorldRotationFromEuler(this.worldRotation_.x, this.bullet.dirDegree, this.worldRotation_.z);
    }

    private tempVec3 = new Vec3();
    private dir = Vec3.UP;  // Direction
    private targetCreature:Creature;
    private posTemp:Vec3 = new Vec3();

    update(dt:number) {
        if (this.type == EffectType.Bullet) {
            let dtms = dt * 1000;
            this.time += dtms;
            let targetCreature = this.bullet.target_;
            if(!targetCreature){
                this.recoveryThisNode();
                return;
            }
            if(!this.targetCreature || this.targetCreature.entityId != targetCreature.entityId){
                this.targetCreature = targetCreature;
                this.time = 0;
            }
            this.target = targetCreature.node.parent;
            this.offset = targetCreature.GetHitOffset(0.4);
            this.targetPos.set(this.target.worldPosition.x + this.offset.x, this.target.worldPosition.y + this.offset.y, this.target.worldPosition.z + this.offset.z);                 
            this.node.lookAt(this.targetPos, this.dir);
            this.node.setScale(this.node.scale.x, this.node.scale.y, -1);
            // if(MathUtil.GetDistance(this.targetPos.x, this.targetPos.z, this.node.worldPosition.x, this.node.worldPosition.z) < targetCreature.characterDefine.Radius) {
            //     this.recoveryThisNode();
            //     return;
            // }
            if(this.lifeTime > 0 && this.time >= this.lifeTime) {
                // if(this.bullet.skill.Owner.characterDefine.ID == 8){  // Fire Nana
                //     console.log('Bullet stop lifeTime='+this.lifeTime+'，time='+this.time+'，duration='+this.bullet.duration)
                // }
                this.recoveryThisNode();
                return;
            }
            Vec3.lerp(this.posTemp, this.node.worldPosition, this.targetPos, dtms / (this.bullet.duration - this.time));
            this.node.setWorldPosition(this.posTemp);
            // this.node.setWorldPosition(this.node.worldPosition.lerp(this.targetPos, 0.1));

        } else if (this.type == EffectType.BulletRealCheck) {  // Bullet real-time detection
            this.tempVec3.set(LogicRenderConvert.LogicToRender_Value(this.bullet.positionX), this.node.worldPosition.y, LogicRenderConvert.LogicToRender_Value(this.bullet.positionZ));
            Vec3.lerp(this.posTemp, this.node.worldPosition, this.tempVec3, 0.25)
            this.node.setWorldPosition(this.posTemp);
            // this.node.setWorldPosition(this.tempVec3.lerp(this.node.worldPosition, BattleGlobal.bulletChaZhi));
            this.node.setWorldRotationFromEuler(this.worldRotation_.x, this.bullet.dirDegree, this.worldRotation_.z);
            
            if(this.bullet.Stoped){
              this.recoveryThisNode();  
              //console.log('EffectController BulletRealCheck Stoped destroy')
              return;
            }
        }
    }

    /**
     * Recycle current node
     */
    private recoveryThisNode(){
        // console.log('EffectController recoveryThisNode recycle')
        if(!isValid(this.node)){
            return;
        }
        this.node.active = false;
        this.node.removeFromParent();  // Remove node from parent node
        PoolManager.instance.putNode(this.node);
    } 

    onDestroy(){
        // console.log('EffectController onDestroy')
    }


}