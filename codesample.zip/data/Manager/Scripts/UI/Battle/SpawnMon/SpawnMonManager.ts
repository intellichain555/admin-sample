import { _decorator, Component, Node, Vec3, instantiate } from 'cc';
import { CharacterDefine } from '../../../Data/CharacterDefine';
import { Creature } from '../Enities/Creature';
import { CreatureType } from '../enums/CreatureType';
import { TeamType2 } from '../enums/TeamType2';
import { CreatureManager } from '../Managers/CreatureManager';
import { IStateRollback } from '../StateRecord/IStateRollback';
import { SpawnMonManagerRecord } from '../StateRecord/SpawnMon/SpawnMonManagerRecord';
import { Spawn } from './Spawn';
const { ccclass, property } = _decorator;
/**
 * Spawn monster manager
 */
/** Pending spawn request (one monster per frame) */
export interface PendingSpawn {
    spawn: Spawn;
    idx?: number;
}

export class SpawnMonManager implements IStateRollback{

    public static Instance: SpawnMonManager = new SpawnMonManager();

    public spawns:Array<Spawn> = [];
    private idx:number=0;

    /** Queue of spawns to process one per frame */
    private pendingSpawnQueue: PendingSpawn[] = [];

    public Clear(){
        this.spawns = [];
        this.pendingSpawnQueue = [];
        this.idx=0;
    }

    /** Enqueue a monster spawn; will be created one per frame by ProcessOneSpawn */
    public EnqueueSpawn(spawn: Spawn, idx?: number): void {
        this.pendingSpawnQueue.push({ spawn, idx });
    }

    /** Process at most one pending spawn (call once per frame) */
    public ProcessOneSpawn(): void {
        if (this.pendingSpawnQueue.length === 0) return;
        const item = this.pendingSpawnQueue.shift();
        if (item && item.spawn) item.spawn.DoCreateMonster(item.idx);
    }

    public AddSpawn(spawn:Spawn){
      this.idx++;
        console.warn('AddSpawn='+spawn.node.name+', idx='+this.idx)
        spawn.idx = this.idx;
        this.spawns.push(spawn);
    }

    public getSpawn(idx:number):Spawn{
      for(let spawn of this.spawns){
        if(spawn.idx == idx){
            return spawn;
        }
      }
      return null;
    }


    /** 
     * Logic update
     * @param frameId 
     */
    public LogicUpdate(frameId: number) {
       // Process at most one monster creation per frame to avoid spikes
       this.ProcessOneSpawn();
       for(let spawn of this.spawns){
         spawn.LogicUpdate(frameId);
       }
    }

  /**
     * Rollback state
     */
 rollback(data: SpawnMonManagerRecord): void {
  for(let spawnRecord of data.spawns){
      let spawn = this.getSpawn(spawnRecord.idx);
      if(spawn){
        spawn.rollback(spawnRecord);
      }
     }
}
 
    
}


