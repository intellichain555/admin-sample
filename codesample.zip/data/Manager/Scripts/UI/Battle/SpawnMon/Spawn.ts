import { _decorator, Component, Node, Enum, CCBoolean, Prefab, instantiate, CCInteger, Vec3 } from 'cc';
import proto from '../../../../Proto/proto.js';
import { CharacterDefine } from '../../../Data/CharacterDefine';
import { DataManager } from '../../../Managers/DataManager';
import { PoolManager } from '../../../Managers/PoolManager';
import { MathUtil } from '../../../Utils/MathUtil';
import { EventManager } from '../../Common/Event/EventManager';
import { EventType } from '../../Common/Event/EventType';
import { Creature } from '../Enities/Creature';
import { CreatureType } from '../enums/CreatureType';
import { TeamType2 } from '../enums/TeamType2';
import { UIMinimapManager } from '../Minimap/UIMinimapManager';
import { BattleGlobal } from '../Utils/BattleGlobal';
import { SpawnMonManager } from './SpawnMonManager';
import { IStateRollback } from '../StateRecord/IStateRollback';
import { SpawnRecord } from '../StateRecord/SpawnMon/SpawnRecord';
import { DeseTypeConve } from '../Utils/DeseTypeConve';
import { Constant } from '../../../../../Scripts/Utils/Constant';
const { ccclass, property } = _decorator;
/**
 * Spawn monster configuration script
 */
@ccclass('Spawn')
export class Spawn extends Component implements IStateRollback{

    @property({
        type: CCInteger,
        range: [0, 999999999, 1],
        tooltip: 'Creature configuration ID'
    })
    public characterId:number;

    @property({
        type: Enum(TeamType2),
        tooltip: 'Team type'
    })
    public teamType2:TeamType2;

    @property({
        type: Node,
        tooltip: 'Spawn point creature node'
    })
    public spawnPointCreatureNode:Node;

    @property({
        type: CCBoolean,
        tooltip: 'Whether periodic spawning'
    })
    public isSpawnPeriod:boolean;

    @property({
        type: CCInteger,
        range: [0, 999999999, 1],
        tooltip: 'Start monster spawn time (seconds)'
    })
    public startTime:number;

    @property({
        type: CCInteger,
        range: [0, 999999999, 1],
        tooltip: 'Wave count'
    })
    public waveNum:number;

    @property({
        type: CCInteger,
        range: [0, 999999999, 1],
        tooltip: 'Monster spawn cycle (seconds)'
    })
    public spawnPeriod:number;

    @property({
        type: [Node],
        tooltip: 'Pathfinding point node collection'
    })
    public moveWayNodeArr:Array<Node> = [];

    @property({
      type: Prefab,
      tooltip: 'Node after death'
  })
  public deathPrefab:Prefab;

    public idx:number=0;
    public isStartRefreshMon:boolean;  // Whether to start spawning monsters
    public lastFrameId:number;  // Last spawn frame count
    public lastWaveNum:number;  // Last spawn wave count
    // public templateMonster:Creature = null;  // Template creature object
    public templateMonsterBirthPosition: Vec3 = null;  // Template creature birth position
    public templateMonsterBirthRotation: Vec3 = null;  // Template creature birth direction
    public characterDefine:CharacterDefine;
    private characterClass:string;

    start() {
      SpawnMonManager.Instance.AddSpawn(this);
      this.characterDefine = DataManager.Instance.characters[this.characterId];
      this.characterClass = this.characterDefine.Class;
      EventManager.Instance.addListener(EventType.OnSpawnInit, this.OnSpawnInit,this);
      if(this.characterClass == Constant.CharacterClass.Soldier){  // Minion
        this.node.active = false;
      }
    }

    /**
     * Game enter
     */
    private OnSpawnInit(){
      if(!this.isSpawnPeriod){ // Non-periodic spawning
        this.RefreshMon();
      }else{
        if(this.characterDefine.IsPool){  // Object pool storage
          //musa manually set as size 1 to avoid frame overflow.
          PoolManager.instance.preloadPool(this.node, 1, this.node.name);
        }
        this.node.active = false;
      }
    }

    /**
     * Spawn monsters (enqueue; one monster created per frame by SpawnMonManager)
     */
    public RefreshMon(idx: number = undefined): Creature {
      SpawnMonManager.Instance.EnqueueSpawn(this, idx);
      return null;
    }

    /**
     * Actually create one monster (called by SpawnMonManager.ProcessOneSpawn, one per frame)
     */
    public DoCreateMonster(idx: number = undefined): Creature {
      let monster: Creature = null;
      if (!this.isSpawnPeriod) {
        this.node.active = true;
        monster = BattleGlobal.CreateCreature(this.characterDefine, this.teamType2, CreatureType.Monster, this.spawnPointCreatureNode,
          undefined, undefined, idx);
      } else {
        this.node.active = false;
        let node: Node = null;
        if (this.characterDefine.IsPool) {
          node = PoolManager.instance.getNode(this.node, this.node.parent, false, undefined, { optimizeParticles: true });
        } else {
          node = this.node;
        }
        let spawn = node.getComponent(Spawn);
        if (spawn) {
          let spawnPointCreatureNode = spawn.spawnPointCreatureNode;
          spawn.enabled = false;
          monster = BattleGlobal.CreateCreature(this.characterDefine, this.teamType2, CreatureType.Monster, spawnPointCreatureNode,
            undefined, undefined, idx, this.templateMonsterBirthPosition ? this.templateMonsterBirthPosition : undefined,
            this.templateMonsterBirthRotation ? this.templateMonsterBirthRotation : undefined);
          node.active = true;
          this.templateMonsterBirthPosition = monster.birthPosition;
          this.templateMonsterBirthRotation = monster.birthRotation;
        }
      }
      if (monster) {
        monster.SpawnId = this.idx;
        if (this.deathPrefab) {
          monster.deathReplaceNode = instantiate(this.deathPrefab);
        }
        if (this.characterClass == Constant.CharacterClass.Soldier) {
          UIMinimapManager.Instance.soldierCreate(monster);
        } else if (this.characterClass == Constant.CharacterClass.Fyt) {
          UIMinimapManager.Instance.FytCreate(monster);
        } else if (this.characterClass == Constant.CharacterClass.ShuiJin) {
          UIMinimapManager.Instance.ShuiJinCreate(monster);
        } else if (this.characterClass == Constant.CharacterClass.Boss) {
          UIMinimapManager.Instance.greatMonsterCreate(monster);
          BattleGlobal.bossCreature = monster;
        }
      }
      return monster;
    }

    /**
     * Logic update
     * @param frameId 
     */
    public LogicUpdate(frameId: number) {
        if(!this.isSpawnPeriod || this.lastWaveNum == this.waveNum){ // Non-periodic spawning or reached max wave count
            return;
        }
        let startFrame = MathUtil.secondToFrame(this.startTime);  
        if(this.characterClass == Constant.CharacterClass.Boss){  //boss
          // Large monster update time
          UIMinimapManager.Instance.greatMonsterUpdateTime(frameId, startFrame, this.node);
        }
       if(startFrame == frameId){  // Start spawning
         this.isStartRefreshMon = true;
         this.lastFrameId = frameId;
         this.lastWaveNum = 1;
          this.RefreshMon();
       } else if(this.isStartRefreshMon){  // Periodic spawning
         let currentFrame = this.lastFrameId + MathUtil.secondToFrame(this.spawnPeriod);  
         if(currentFrame == frameId){
            this.lastFrameId = frameId;
            this.lastWaveNum++;
             this.RefreshMon();
         }
       }
    }

    public onDestroy() {
      EventManager.Instance.removeAll(this);
    }

   /**
    * Rollback state
    */
    rollback(data:SpawnRecord):void{
      this.isStartRefreshMon = data.isStartRefreshMon;
      this.lastFrameId = data.lastFrameId;
      this.lastWaveNum = data.lastWaveNum;
      this.templateMonsterBirthPosition = DeseTypeConve.conveVec3(this.templateMonsterBirthPosition, data.templateMonsterBirthPosition);
      this.templateMonsterBirthRotation = DeseTypeConve.conveVec3(this.templateMonsterBirthRotation, data.templateMonsterBirthRotation);
    }
 
}


