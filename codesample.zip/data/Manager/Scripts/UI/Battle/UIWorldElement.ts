
import { _decorator, Component, Node, Camera, v3, Vec3, CameraComponent, game, Sprite, Size, view, UITransform } from 'cc';
import { BattleManager } from './Managers/BattleManager';
import { UIPopupText } from './UIPopupText';
import { EventManager } from '../Common/Event/EventManager';
import { EventType } from '../Common/Event/EventType';
import { MathUtil } from '../../Utils/MathUtil';
import { NetConfig } from '../../Network/NetConfig';
import { Creature } from './Enities/Creature';
import { CreatureType } from './enums/CreatureType';
import { User } from '../../Models/User';
import { Constant } from '../../../../Scripts/Utils/Constant';
import { TweenPosition } from './Utils/Tween/TweenPosition';
import { BattleGlobal } from './Utils/BattleGlobal';
const { ccclass, property } = _decorator;
/**
 * World element
 */
@ccclass('UIWorldElement')
export class UIWorldElement extends Component {

    public id:number = 0;
    private owner:Creature=null;
    public height:number=2.3;
    @property(Node)
    public camera:Node=null;
    public uiVec3:Vec3=new Vec3();  // UI coordinates
    private worldVec3:Vec3=new Vec3();  // World coordinates

    public cameraComponent:CameraComponent=null;
    public isExecuteOnce:boolean = false; // Whether execute only once
    public isExecute:boolean = false; // Whether already executed
    public type:number = 1; // 1. HP bar  2. Popup text  3. Drop
    private currentSize:Size = new Size();
    

    onLoad () {
      this.currentSize = view.getVisibleSize();
      this.cameraComponent=this.camera.getComponent(CameraComponent);
    }

    public set Owner(owner:Creature){
      this.owner = owner;
    }

    public get Owner(): Creature {
      return this.owner;
    }

    updateRendering(){
        if(this.owner && this.cameraComponent){
           // Early-out: dead owners skip expensive convertToUINode
           if (this.owner.IsDeath) {
             this.node.active = false;
             return;
           }
           // Execute-once elements skip full update after first run, but we must still
           // restore visibility when they come back within CULL_DISTANCE (manager set active=false when far).
           if (this.isExecuteOnce && this.isExecute && this.node.active) {
             return;
           }
            this.isExecute = true;
            this.owner.node.parent.getWorldPosition(this.worldVec3);
           let pos = this.worldVec3.add3f(0, this.height, 0);

           
          this.cameraComponent.convertToUINode(pos, this.node.parent, this.uiVec3);
          // this.cameraComponent.camera.update();
          

          if(this.type == 1){  // HP bar
              // Minion: sync show-flag from HP here (HP bar node may be inactive so UIHpBar.update() doesn't run)
              let isMinion = this.owner.creatureType === CreatureType.Monster && this.owner.characterDefine.Class === Constant.CharacterClass.Soldier;
              if (isMinion) {
                let HP = this.owner.attributes.HP.toNumber();
                let MaxHP = this.owner.attributes.MaxHP.toNumber();
                this.owner.IsShowHpNode = HP < MaxHP;
              }
              this.node.position=this.uiVec3;
              if(!this.owner.IsShowHpNode || this.currentSize.width / 2 < Math.abs(this.uiVec3.x)){
                this.node.active = false;
              }else{
                this.node.active = true;
              }
          }else if(this.type == 2 || this.type == 3){  // Popup text, drop
            this.node.position=this.uiVec3;
            if(this.currentSize.width / 2 < Math.abs(this.uiVec3.x)){
              this.node.active = false;
            }else{
              this.node.active = true;
            }
          }
          
           // Calculate element size
           let len = Vec3.distance(pos, this.camera.worldPosition);
           let scale=BattleManager.Instance.camCharDis / len ;
           scale=scale > 0.9 ? 0.9 : scale;
           this.node.setScale(scale, scale, scale);
          
          //  if(this.isExecuteOnce){  // Execute only once   
          //   // Dispatch event
          //   EventManager.Instance.dispatchObj(EventType.OnWorldElementExecuteOnceSuccess, this);
          // }
        }
    }
}

