import { TeamType2 } from "../enums/TeamType2";
import { Node, Vec3, lerp, AnimationComponent, animation, director, Material, SkinnedMeshRenderer, Quat, tween, Tween, Canvas, Color, Texture2D, Vec2, instantiate } from "cc";
import { LogicRenderConvert } from "../Utils/LogicRenderConvert";
import { MathUtil } from "../../../Utils/MathUtil";
import { NetConfig } from "../../../Network/NetConfig";
import { UIHpBar } from "../UIHpBar";
import { SkillManager } from "../Managers/SkillManager";
import { BattleContext } from "../Models/BattleContext";
import { BuffDefine } from "../../../Data/BuffDefine";
import { BuffManager } from "../Managers/BuffManager";
import { CharacterDefine } from "../../../Data/CharacterDefine";
import { DataManager } from "../../../Managers/DataManager";
import { DamageInfo } from "../Vo/DamageInfo";
import { SkillResult } from "../enums/SkillResult";
import { BattleState } from "../enums/BattleState";
import { EffectManager } from "../Managers/EffectManager";
import proto from "../../../../Proto/proto.js";
import { CreatureType } from "../enums/CreatureType";
import { BattleManager } from "../Managers/BattleManager";
import { DeferredWorkManager } from "../Managers/DeferredWorkManager";
import { SpawnRuleDefine } from "../../../Data/SpawnRuleDefine";
import { UIWorldElementManager } from "../UIWorldElementManager";
import { CollisionCheckManager } from "../Managers/CollisionCheckManager";
import { Skill } from "../Models/Skill";
import { Attributes } from "../Attribute/Attributes";
import { EffectType } from "../Effects/EffectType";
import { FXManager } from "../Effects/FXManager";
import { EntityEffectManager } from "../Effects/EntityEffectManager";
import { AnimationEventController } from "../Effects/AnimationEventController";
import { AniState } from "../enums/AniState";
import { Bullet } from "../Models/Bullet";
import { PopupType } from "../enums/PopupType";
import { User } from "../../../Models/User";
import { BattleGlobal } from "../Utils/BattleGlobal";
import { AchievementVo } from "../Vo/AchievementVo";
import { NetClientBattle } from "../../../Network/Battle/NetClientBattle";
import { BattleService } from "../../../Services/BattleService";
import { RoomService } from "../../../Services/RoomService";
import { LocalStorageUtil } from "../../../Utils/LocalStorageUtil";
import { EventManager } from "../../Common/Event/EventManager";
import { EventType } from "../../Common/Event/EventType";
import { SettlementRewardsDefine } from "../../../Data/SettlementRewardsDefine";
import { DataUtil } from "../../../Utils/DataUtil";
import { Buff } from "../Models/Buff";
import { Util } from "../../../Utils/Util";
import { RandomUtil } from "../Utils/RandomUtil";
import { TipsManager } from "../../TipsManager";
import { BattleData } from "../Utils/BattleData";
import { AttackerManager } from "../Managers/AttackerManager";
import { CharacterManager } from "../Managers/CharacterManager";
import { CreatureManager } from "../Managers/CreatureManager";
import Decimal from "decimal.js";
import { BuffEffect } from "../enums/BuffEffect";
import { GhostManager } from "../Effects/GhostManager";
import { BattleAttribute } from "../Attribute/BattleAttribute";
import { TweenPosition } from "../Utils/Tween/TweenPosition";
import { AIAgent } from "../AI/AIAgent";
import { PoolManager } from "../../../Managers/PoolManager";
import { GameStaticBatch } from "../../BatchRendering/GameStaticBatch";
import { UIMinimapManager } from "../Minimap/UIMinimapManager";
import { ShapeType } from "../enums/ShapeType";
import { BattleSoundTipsManager } from "../Managers/BattleSoundTipsManager";
import { IStateRecord } from "../StateRecord/IStateRecord";
import { CreatureRecord } from "../StateRecord/Enities/CreatureRecord";
import { IStateRollback } from "../StateRecord/IStateRollback";
import { DeseTypeConve } from "../Utils/DeseTypeConve";
import { OptType } from "../enums/OptType";
import { SoundDefine } from "../../../../../Scripts/Sound/SoundDefine";
import { Constant } from "../../../../../Scripts/Utils/Constant";
import { AIHeroSkillMoveTarget } from "../AI/AIHeroSkillMoveTarget";

export class Creature implements IStateRollback {
  private static readonly RESU_HP = new Decimal(50);  // Cached for resurrection (avoids GC)

  public entityId: number;  // Entity ID
  public characterDefine: CharacterDefine;  // Character configuration
  public teamType2: TeamType2; // Team type
  public node: Node;  // Node object
  public logicPosition: Vec3 = new Vec3();   // Logic position
  public renderPosition: Vec3 = new Vec3();   // Render position
  public SkillMgr: SkillManager;
  public BuffMgr: BuffManager;
  public BattleState: BattleState = BattleState.Idle;
  public EffectMgr: EffectManager;
  public AttackerMgr: AttackerManager;
  public IsDeath: boolean = false;  // Whether dead
  public deathTime: Date;  // Death time
  public deathFrameId: number = -1; // Death logic frame number
  public birthPosition: Vec3 = new Vec3();  // Birth position
  public birthRotation: Vec3 = new Vec3();  // Birth direction
  public logicRotation: Vec3 = new Vec3();   // Logic direction
  
  public creatureType: CreatureType;   // Creature type
  public hpBarNode: Node;  // HP bar node
  public _amend: Vec3 = new Vec3();  // Correction value 
  private collisionTempVec3: Vec3 = new Vec3();  // Collision temporary coordinates
  public aniState: AniState;  // Animation state
  public surplusDieWaitFrame: number = 0;  // Remaining death wait frames
  public attributes = new Attributes();
  public materialArr: Array<Material> = null;   // Shared material list
  public materialMainTextureArr: Array<Texture2D> = null;  // Material textures

  public settlementRewardsDefine: SettlementRewardsDefine;   // Settlement rewards configuration

  public deathReplaceNode: Node; // Node to replace after death
  public effectParentNode: Node;  // Effect parent node
  /** Components */
  // public animationComponent: AnimationComponent; // Animation component
  public EntityEffectMgr: EntityEffectManager;  // Effect manager component
  public animationController: animation.AnimationController;  // Animation controller

  /** Character attributes */
  public user: proto.Message.NUser = null;
  public notHandleFrameCount: number = 0;  // No operation frame count

  public achievementList = new Array<AchievementVo>();  // Achievement data
  public allSportsItemList = new Array<AchievementVo>();  // All sports items list
  public useSportsItemList = new Array<AchievementVo>();  // Used sports items list
  public renTou: number = 0;  // Kills
  public zhenWang: number = 0;  // Deaths
  public zhuGong: number = 0;  // Assists
  public score: number = 0;  // Score
  public isMvp: boolean = false;  // Whether MVP

  public lianXuRenTou: number = 0;  // Consecutive kills
  public lianXuRenTouMax: number = 0;  // Maximum consecutive kills
  public lastJiShaTime: number = 0; // Last kill time
  public lianXuJiShaJianGe: number = 0;  // Consecutive kill interval time

  public startBirthPlaceNeedWindHpFrameId: number = -1;  // Starting birth place needs heal frame
  public resuFlag: boolean = false;  // Whether resurrection kill
  public resuFrameId: number = -1; // Resurrection frame number
  public newExistOptFrameId: number = -1;  // Latest existing operation frame

  public minimapCharacterNode: Node;  // Minimap character node
  public isAiControlFlag: boolean = false; // Whether AI controlled
  public aiRoadType: number = Constant.AIRoadType.up;  // AI top/bottom lane type
  public resuCoinCount: number = 0;  // Resurrection coin count
  public resuCoinUseCount: number = 0;  // Resurrection coin usage count
  public aiHeroSkillMoveTarget:AIHeroSkillMoveTarget;  // AI hero skill move to target

  /** Monster attributes */
  public SpawnId: number;  // Spawn ID
  public AI: AIAgent;  // AI agent
  public dir: number = 0;  // Distance


  /** Battle attributes */
  public isCanMove: boolean = true; // Whether can move
  public isCanSkill: boolean = true; // Whether can cast skills
  public isImmunity: boolean = false; // Whether immune (other players' skills can find but cannot deal damage)
  public isRetreat: boolean = false; // Whether retreated (other players' skills cannot find, cannot deal damage)
  public isShowHpNode_: boolean = true;  // Whether show HP bar node
  public isVisibleToLocalPlayer: boolean = true;  // Fog of view: visible to local player (enemy/neutral hidden when false)
  public isUpdateRenderingPos: boolean = true; // Whether update rendering position
  private isDisplacementing: boolean = false; // Whether displacing
  public isTuiKaiing: boolean = false; // Whether being pushed away
  public isRepeling: boolean = false; // Whether being repelled
  public battleAttribute = new BattleAttribute(this);  // Battle attributes
  public aggro: number = 0;     // Aggro value
  public dropsAngle: number = 0;  // Drop angle
  public noInBattleFrame: number = 0;  // Lost battle frame
  private corpseSinkTimer: any;
  private corpseSinkTween: Tween<Node>;

  public lastSkillRotateAngle: number = -1;  // Last skill rotation angle
  public lastLogicPosition = new Vec3();  // Last logic position 
  public lastMoveAngle: number = 0;  // Last move angle

  constructor(teamType2: TeamType2, node: Node, define: CharacterDefine, user: proto.Message.NUser, creatureType: CreatureType, birthPosition: Vec3 = null, birthRotation: Vec3 = null) {
    // Initialize basic attributes
    this.attributes.InitBasicAttributes(define, user, creatureType);

    this.user = user;
    this.creatureType = creatureType;
    this.teamType2 = teamType2;
    this.node = node;
    this.characterDefine = define;
    // this.animationComponent = node.getComponent(AnimationComponent);
    this.EntityEffectMgr = node.getComponent(EntityEffectManager);
    this.animationController = node.getComponent(animation.AnimationController);
    if (this.node.parent.active) {
      // Play idle animation
      this.SetAnim(AniState.Idle, true);
    }
    // Settlement rewards configuration
    this.settlementRewardsDefine = DataManager.Instance.settlementRewardss[define.RewardId];
    // Get all materials
    this.getAllMaterials();

    this.node.active = true;

    // Birth position
    if (birthPosition) {
      this.birthPosition = birthPosition;
      this.node.parent.setWorldPosition(birthPosition.x, birthPosition.y, birthPosition.z);
    } else {
      this.node.parent.getWorldPosition(this.birthPosition);
    }
    // Initialize logic position and direction
    node.parent.getWorldPosition(this.renderPosition);
    LogicRenderConvert.RenderToLogic_TwoVec3(this.logicPosition, this.renderPosition);
    this.lastLogicPosition.set(this.logicPosition.x, this.logicPosition.y, this.logicPosition.z);  // Last moved logic position
    node.parent.rotation.getEulerAngles(this.logicRotation);

    // Birth direction
    if (birthRotation) {
      this.birthRotation = birthRotation;
      node.parent.setRotationFromEuler(birthRotation.x, birthRotation.y, birthRotation.z);
    } else {
      this.birthRotation.set(this.logicRotation.x, this.logicRotation.y, this.logicRotation.z);
    }

    this.SkillMgr = new SkillManager(this);
    this.BuffMgr = new BuffManager(this);
    this.EffectMgr = new EffectManager(this);
    this.AttackerMgr = new AttackerManager(this);


    this.AI = new AIAgent(this);
    if(this.creatureType == CreatureType.Character){
      this.aiHeroSkillMoveTarget = new AIHeroSkillMoveTarget(this);
    }
    
    this.IsDeath = false;
    this.node.active = true;
    // Create ghost
    if (this.SkillMgr.IsExistShowGhostSkill()) {  // Has show ghost skill
      GhostManager.Instance.CreateGhost(this);
    }
    this.AnimEnableOrStop(true);  // Enable animation component
    this.CreateEffectParentNode(); // Create effect parent node
    this.effectParentNode.removeAllChildren();
    this.BattleState = BattleState.Idle;
    // Fog of view: enemy/neutral start hidden until first visibility update
    const bm = BattleManager.Instance;
    if (bm?.currentCharacter && this.teamType2 !== bm.currentCharacter.teamType2) {
      this.SetFogVisibility(false);
    }
    // Below is test creature range size code =================================
    // let testPrefab =  BattleManager.Instance.LogicRangeTargetTestNode;
    // let testNode = instantiate(testPrefab);
    // testNode.active = true;
    // this.node.parent.addChild(testNode);
    // if(this.characterDefine.Shape.toString() == ShapeType[ShapeType.rect]){
    //   testNode.setScale(this.characterDefine.Width, 1, this.characterDefine.Height);
    //   testNode.setRotationFromEuler(0, this.logicRotation.y, 0);
    // }else if(this.characterDefine.Shape.toString() == ShapeType[ShapeType.circle]){
    //   testNode.setScale(this.characterDefine.Radius*2, 1, this.characterDefine.Radius*2);
    // }  
  }

  /**
   * Get all materials
   */
  public getAllMaterials() {
    let skinnedMeshRendererArr = this.node.getComponentsInChildren(SkinnedMeshRenderer);
    if (skinnedMeshRendererArr) {
      if (!this.materialArr) {
        this.materialArr = [];
        this.materialMainTextureArr = [];
        for (let i = 0; i < skinnedMeshRendererArr.length; i++) {
          let meshRenderer = skinnedMeshRendererArr[i];
          for (let j = 0; j < meshRenderer.materials.length; j++) {
            let mat = meshRenderer.materials[j];  // Material                
            let mainTexture = mat.getProperty('mainTexture') as Texture2D;
            this.materialMainTextureArr.push(mainTexture);
            //  console.log('getAllMaterials mainTexture =',mainTexture)
            this.materialArr.push(mat);
          }
        }
      }
    }
  }

  /**
   * Set displacement state
   */
  public set IsDisplacementing(value: boolean) {
    this.isDisplacementing = value;
    this.animationController.setValue(AniState[AniState.IsDisplacementing], value);  // Set displacement state
  }
  public get IsDisplacementing() {
    return this.isDisplacementing;
  }

  public get IsShowHpNode() {
    return this.isShowHpNode_;
  }
  public set IsShowHpNode(value: boolean) {
    this.isShowHpNode_ = value;
    if (!value && this.hpBarNode) { // Hide (guard: hpBarNode may not exist yet when deferred for minions)
      // Set HP bar position far away to avoid interpolation when showing
      let pos = this.hpBarNode.position;
      this.hpBarNode.setPosition(pos.x + 1500, pos.y, pos.z);
    }
  }

  /**
   * Add item
   * @param itemId Item ID
   * @param count Count
   * @param Array Collection
   */
  private AddItems(itemId: number, count: number, arr: Array<AchievementVo>) {
    if (!itemId || !count || !arr) {
      return;
    }
    let achievementVo: AchievementVo = null;
    for (let i = 0; i < arr.length; i++) {
      let av = arr[i];
      if (av.itemId == itemId) {
        achievementVo = av;
        break;
      }
    }

    if (achievementVo) {  // Exists
      achievementVo.count += count;
    } else {
      achievementVo = new AchievementVo(itemId, count);
      arr.push(achievementVo);
    }
  }

  /**
   * Add sports items
   * @param sportsItems Sports items list
   */
  public AddSportsItems(sportsItems: Array<proto.Message.INItem>) {
    if (sportsItems) {
      for (let i = 0; i < sportsItems.length; i++) {
        let item = sportsItems[i];
        this.AddItems(item.itemId, item.count, this.allSportsItemList);
      }

      this.RefreshSportsItemsUI();
    }
  }

  /**
   * Add battle rewards
   * @param itemId Item ID
   * @param count Count
   */
  public AddAchievement(itemId: number, count: number, achievementStrArr: Array<string>, deathCreature?: Creature, isZhugongFlag: boolean = false): string {
    if (!itemId || !count) {
      return;
    }
    this.AddItems(itemId, count, this.achievementList);

    let itemDefine = DataManager.Instance.items[itemId];
    if (itemDefine.Type == Constant.ItemType.SPORTS) {  // Sports item
      this.AddItems(itemId, count, this.allSportsItemList); // Add to sports items
      // console.log('Sports items refresh='+JSON.stringify(this.allSportsItemList))
      this.RefreshSportsItemsUI();
    }
    let str = itemDefine.Name + '+' + count;
    if (achievementStrArr) {
      achievementStrArr.push(str);
    }

    // Show drops (deferred to spread across frames)
    if (deathCreature && this.creatureType == CreatureType.Character && this.user && this.user.id == User.Instance.user.id) {
      DeferredWorkManager.Instance.enqueueShowDrops(deathCreature, itemId, count, this, isZhugongFlag);
    }
    return str;
  }

  /**
   * Use sports item
   * @param itemId Item ID
   */
  public UseSportsItem(itemId: number) {
    for (let i = 0; i < this.allSportsItemList.length; i++) {
      let sportsItem = this.allSportsItemList[i];
      if (sportsItem.itemId == itemId) {
        // Add buff
        let isUseSuccess = Util.UseItemGetBuff(itemId, this, false);
        if (!isUseSuccess) {  // Not used successfully
          if (this.user && this.user.id == User.Instance.user.id && !BattleManager.Instance.uiBattle.isOpenUIEnterGameLoad()) {
            TipsManager.Instance.showTips('This item is currently in use!');
          }
          continue;
        }
        // Add used item
        if (sportsItem.count > 1) {
          sportsItem.count--;
        } else {
          this.allSportsItemList.splice(i, 1);
        }
        this.AddItems(itemId, 1, this.useSportsItemList);
        this.RefreshSportsItemsUI();
        break;
      }
    }

  }

  /**
   * Refresh sports items UI
   */
  public RefreshSportsItemsUI() {
    if (this.user && this.user.id == User.Instance.user.id) {
      EventManager.Instance.dispatch(EventType.OnSportsItemsChange, this.allSportsItemList);
    }
  }

  /**
   * Get collision temporary coordinates to avoid affecting original coordinates
   */
  public get CollisionTempVec3(): Vec3 {
    this.collisionTempVec3.set(this.logicPosition.x, this.logicPosition.y, this.logicPosition.z);
    return this.collisionTempVec3;
  }

   /**
   * Get collision temporary coordinates to avoid affecting original coordinates
   */
   public get CollisionTempVec3_2(): Vec3 {
    LogicRenderConvert.RenderToLogic_TwoVec3(this.collisionTempVec3, this.renderPosition);
    return this.collisionTempVec3;
  }

  private renderRotation_: Vec3 = new Vec3();   // Render direction
  public get RenderRotation(): Vec3{
    this.node.parent.rotation.getEulerAngles(this.renderRotation_);
    return this.renderRotation_;
  }

  /**
   * Logic to render position
   * @param isPrediction Whether prediction
   * @param isUpdateRendering Whether update rendering
   * @param isFlash Whether flash
   * @param isAiMove Whether AI caused movement (default false)
   */
  public LogicToRenderPosition(logicX: number, logicY: number, logicZ: number, isPrediction = false, isUpdateRendering = true, isFlash = false, isAiMove = false): boolean {
    if (this.battleAttribute.CanMoveCount > 0 && (isAiMove || (!this.IsDisplacementing && !this.isTuiKaiing && !this.isRepeling))) {  // Cannot move and not displacing
      return false;
    }
    if (!isPrediction) {  // Not prediction
      this.logicPosition.set(logicX, logicY, logicZ);
    }
    if (isUpdateRendering) {
      if (isPrediction) {  // Prediction, update rendering
        LogicRenderConvert.LogicToRender_TwoVec3_3f(this.renderPosition, logicX, logicY, logicZ);
        // console.log('Prediction, update rendering=', this.renderPosition)
      } else { // Not prediction, update rendering
        LogicRenderConvert.LogicToRender_TwoVec3(this.logicPosition, this.renderPosition)
      }

      if (isFlash) {  // Flash
        this.node.parent.setWorldPosition(this.renderPosition.x, this.renderPosition.y, this.renderPosition.z);
      }
    }
    // console.log('logicPosition='+this.logicPosition+'，renderPosition='+this.renderPosition)
    return true;
  }

  private updateIndex:number = 0;
  private posTemp:Vec3 = new Vec3();
  public update() {
    const isMinion = this.creatureType === CreatureType.Monster && this.characterDefine.Class === Constant.CharacterClass.Soldier;
    const isStaticBuilding = this.characterDefine.Class === Constant.CharacterClass.Fyt || this.characterDefine.Class === Constant.CharacterClass.ShuiJin;
    // Skip position update for towers/crystal (they don't move) - reduces cost when many towers
    const doPositionUpdate = !isStaticBuilding && (!isMinion || (this.updateIndex + this.entityId) % 2 === 0);
    if (doPositionUpdate) {
      let nodeParent = this.node.parent;
      if (nodeParent && this.isUpdateRenderingPos) {
        let isLerp:boolean = true; // Whether interpolate
        const validateInterval = isMinion ? 10 : 5;  // Minions: validate distance less often
        if(this.updateIndex % validateInterval == 0){
          let currentPos = nodeParent.worldPosition;
          let dis = MathUtil.GetDistance(currentPos.x, currentPos.z, this.renderPosition.x, this.renderPosition.z);
          if(dis > 10){
            isLerp = false;
          }
        }
        if(isLerp){  // Interpolate position       
          Vec3.lerp(this.posTemp, nodeParent.worldPosition, this.renderPosition, (this.isDisplacementing || this.isTuiKaiing || this.isRepeling) ? 0.3 : 
          ((!BattleGlobal.isStandaloneFlag && (!this.user || this.user.id != User.Instance.user.id)) ? BattleGlobal.creatureChaZhi2 : BattleGlobal.creatureChaZhi)); 
          nodeParent.setWorldPosition(this.posTemp);
        }else{
          nodeParent.setWorldPosition(this.renderPosition.x, this.renderPosition.y, this.renderPosition.z);
        }
      }
    }
    // Towers/crystal: throttle skill update (target selection UI) - every 3 frames to reduce cost when many towers
    if (!isStaticBuilding || (this.updateIndex % 3 === 0)) {
      this.SkillMgr.update();
    }
    this.updateIndex++;
  }

  public CastSkill(context: BattleContext, skill: Skill) {
    context.Result = skill.Cast(context);
    if (context.Result == SkillResult.Ok) {
      this.BattleState = BattleState.InBattle;
      this.noInBattleFrame = BattleData.executeFrameId + BattleGlobal.noInBattleFrameCount;
    }
  }

  /**
   * Whether resurrect
   * @param resu Resurrection rate
   */
  private IsResu(resu: Decimal): boolean {
    return RandomUtil.limitIntegerBattle(0, 100) < resu.toNumber();
  }

  /**
   * Take damage
   * @param damage 
   * @param caster 
   */
  public DoDamage(damage: DamageInfo, caster: Creature) {
    if (this.IsDeath) {  // Already dead
      return;
    }

    this.BattleState = BattleState.InBattle;
    this.noInBattleFrame = BattleData.executeFrameId + BattleGlobal.noInBattleFrameCount;

    let isShowDamageText:boolean = true;  // Whether show damage text
    this.attributes.HP = this.attributes.HP.sub(damage.Damage);
    // Minion: show HP bar as soon as damage is applied
    if (this.creatureType === CreatureType.Monster && this.characterDefine.Class === Constant.CharacterClass.Soldier && this.attributes.HP.lt(this.attributes.MaxHP)) {
      this.IsShowHpNode = true;
    }
    if (this.attributes.HP.lte(0)) {
      let isResu = this.IsResu(this.attributes.RESU);
      if (isResu || caster.resuFlag) {  // Resurrect
        console.log('You are resurrected!')
        caster.resuFlag = false;
        this.SetAnim(AniState.Death, true);
        this.resuFrameId = BattleData.executeFrameId + BattleGlobal.resuWaitFrameCount;
        this.IsShowHpNode = false;
        this.SetBattleState(false, false, false, true);
      } else { // Death
        // Monster last kill credit goes to last attacking hero
        if (this.creatureType == CreatureType.Character && caster.creatureType == CreatureType.Monster) {
          if (this.AttackerMgr.lastAttackHero) {
            caster = this.AttackerMgr.lastAttackHero;
            isShowDamageText = false;
          }
        }
        this.deathTime = new Date();
        damage.WillDead = true;
      }
    }
    this.AI.DoDamage(damage, caster);
    // Add to attacker manager
    this.AttackerMgr.AddAttacker(caster, damage.Damage, damage.WillDead);

    if (damage.WillDead) {   // Current character death
      this.DoDeath(caster);
    }

    if (caster.creatureType == CreatureType.Character) {  // Attacker is hero
      if (this.creatureType == CreatureType.Character) {  // Attacking hero
        caster.aggro++;
      }
      if (caster.user && caster.user.id == User.Instance.user.id && !damage.isStealth && isShowDamageText) { // Attacker is current user and target not stealthed then show damage text
        UIWorldElementManager.Instance.ShowPopupText(PopupType.Damage, this, Math.floor(-damage.Damage) + '', damage.Crit);
      }
    }
    if (this.creatureType == CreatureType.Character) {
      // Cancel recall buff
      if (this.EffectMgr.HasEffect(BuffEffect.HuiCheng)) {   // Has recall buff
        this.EffectMgr.RemoveEffect(BuffEffect.HuiCheng);
      }
      if (this.user && this.user.id == User.Instance.user.id) {  // Self takes damage text
        UIWorldElementManager.Instance.ShowPopupText(PopupType.Hit, this, Math.floor(-damage.Damage) + '', damage.Crit, undefined, caster);
      }
    }

    // Our crystal is being attacked
    if (this.characterDefine.Class == Constant.CharacterClass.ShuiJin &&
      this.teamType2 == BattleManager.Instance.currentCharacter.teamType2) { // Crystal
      if (BattleData.executeFrameId > BattleGlobal.myShuiJinSoundFrame) {
        BattleSoundTipsManager.Instance.PlaySound(SoundDefine.Our_crystal_is_under_attack);
        BattleGlobal.myShuiJinSoundFrame = BattleData.executeFrameId + BattleGlobal.myShuiJinSoundTipsJgFrame;
      }
    }
  }

  /**
   * Logic update
   */
  public LogicUpdate(frameId: number) {
    // Start game character add auto AI (3v3 or 5v5)
    if(frameId == BattleGlobal.start_game_character_addAi_frame 
      && this.creatureType == CreatureType.Character
      && (BattleGlobal.playingMethod == Constant.PlayingMethod.ThreeVsThree || 
          BattleGlobal.playingMethod == Constant.PlayingMethod.FiveVsFive)){
      if(frameId - this.newExistOptFrameId > BattleGlobal.start_game_character_addAi_frame){
        this.EffectMgr.AddEffect(BuffEffect.ZiDong);
      }
    }
    
    this.EffectMgr.LogicUpdate(frameId);
    this.SkillMgr.LogicUpdate(frameId);
    this.BuffMgr.LogicUpdate();
    // this.AiMgr.LogicUpdate();
    this.AI.LogicUpdate(frameId);
    if(this.aiHeroSkillMoveTarget){
      this.aiHeroSkillMoveTarget.LogicUpdate(frameId);
    }
    this.AttackerMgr.LogicUpdate(frameId);

    this.attributes.LogicUpdate(frameId);
    this.ResuCharacter();
    this.noDeathResu(frameId);

    if (frameId == this.noInBattleFrame) {  // Lose battle state
      this.BattleState = BattleState.Idle;
    }
  }

  /**
   * Non-death resurrection
   * @param frameId 
   */
  public noDeathResu(frameId: number) {
    if (this.resuFrameId == frameId) {
      console.log('Non-death resurrection========================')
      this.attributes.SetHp(Creature.RESU_HP);  // Restore 50% health (cached to avoid GC)          
      this.IsShowHpNode = true;
      this.SetBattleState(true, true, false, false);
      // Play resurrection effect
      this.PlayEffect2(EffectType.Normal, BattleGlobal.resuPlaceEffectsName, this.renderPosition, 2);
      UIWorldElementManager.Instance.ShowPopupText(PopupType.EffectTips, this, 'Resurrected');
      this.SetAnim(AniState.Idle, true);
    }
  }



  /**
   * Resurrect character
   */
  private ResuCharacter() {
    if (this.IsDeath && this.creatureType == CreatureType.Character) {  // Already dead and is character
      this.surplusDieWaitFrame--;
      if (this.surplusDieWaitFrame < 1) {  // Resurrect
        this.ResuCharacterHandle();
      }
    }
  }

  /**
   * Resurrect character handling
   */
  public ResuCharacterHandle() {
    // Close death popup first
    if (this.user && this.user.id == User.Instance.user.id) {  // Death is self
      BattleManager.Instance.uiDieInBattle.hide();
      BattleManager.Instance.uiBattle.isEndFlag = true;
      UIMinimapManager.Instance.hideKuang();  // Hide frame
      BattleManager.Instance.MyBattleItemNode.removeAllChildren();
    }
    // Resurrect (restores state, sets node.active = true)
    this.resu();
    // Set idle pose after node is active so AnimationController receives the call
    this.SetAnim(AniState.Idle, true);
    // Clear leftover damage/popup labels for this creature
    UIWorldElementManager.Instance.RemovePopupTextsForCreature(this);
  }

  /**
   * Get remaining death wait time
   */
  public getSurplusDieWaitTime() {
    return MathUtil.frameToSecond(this.surplusDieWaitFrame);
  }

  public Distance(target: Creature): number {
    let dis = Math.floor(MathUtil.GetDistance(this.logicPosition.x, this.logicPosition.z, target.logicPosition.x, target.logicPosition.z));
    return dis;
  }

  public Distance2(position: Vec3): number {
    let dis = Math.floor(MathUtil.GetDistance(this.logicPosition.x, this.logicPosition.z, position.x, position.z));
    return dis;
  }

  public Distance3(positionX: number, positionZ: number): number {
    let dis = Math.floor(MathUtil.GetDistance(this.logicPosition.x, this.logicPosition.z, positionX, positionZ));
    return dis;
  }

  public AddBuf(context: BattleContext, buffDefine: BuffDefine) {
    this.BuffMgr.AddBuf(context, buffDefine);
  }

  /**
   * Resurrect
   */
  private resu() {
    this.IsDeath = false;
    // Stop corpse animation
    clearTimeout(this.corpseSinkTimer);
    if (this.corpseSinkTween) {
      this.corpseSinkTween.stop();
    }

    // Clear all buffs and their visual effects (from before death)
    this.BuffMgr.RemoveBuff(-1, true);
    this.EffectMgr.RemoveAllEffect();

    // Clear attacker manager
    this.AttackerMgr.Clear();

    // Initialize basic attributes
    this.attributes.HP=this.attributes.Basic.MaxHP;
    // this.attributes.InitBasicAttributes(this.characterDefine, this.user, this.creatureType);
    // Initialize position and direction
    this.initBirthPosRot();
    // Add HP bar
    this.IsShowHpNode = true;

    this.node.active = true;
    // Show shadow
    this.ShadowControl(true);

    // Self resurrect
    if (this.user && this.user.id == User.Instance.user.id) {
      BattleGlobal.isMyDeath = false;
    }
    // Enemy team all dead
    BattleGlobal.isEnemyTemyAllDeath = CharacterManager.Instance.validateTemyAllDeath(BattleManager.Instance.currentCharacter.teamType2 == TeamType2.Blue ? TeamType2.Red : TeamType2.Blue);

  }

  /**
   * Initialize to birth position and direction
   */
  public initBirthPosRot() {
    this.node.parent.setWorldPosition(this.birthPosition.x, this.birthPosition.y, this.birthPosition.z);
    this.renderPosition.set(this.birthPosition.x, this.birthPosition.y, this.birthPosition.z);
    LogicRenderConvert.RenderToLogic_TwoVec3(this.logicPosition, this.renderPosition);

    this.node.parent.setRotationFromEuler(this.birthRotation);
    this.logicRotation.set(this.birthRotation.x, this.birthRotation.y, this.birthRotation.z);
  }

  /**
   * Shadow control
   */
  private ShadowControl(isShow: boolean) {
    if (this.characterDefine.ShadowName) {
      let childrenList = this.node.parent.children;
      for (let n of childrenList) {
        if (n.name == this.characterDefine.ShadowName) {
          n.active = isShow;
          break;
        }
      }
    }
  }

  /**
   * Set fog-of-view visibility (model, shadow, and flag). Used by FogOfViewManager.
   */
  public SetFogVisibility(visible: boolean) {
    this.isVisibleToLocalPlayer = visible;
    if (this.node && this.node.isValid) {
      this.node.active = visible;
      this.ShadowControl(visible);
    }
  }


  /**
   * Death
   */
  public DoDeath(caster: Creature) {
    // console.log('DoDeath')
    this.dropsAngle = BattleGlobal.dropsInitAngle;
    this.IsDeath = true;
    this.AI.DoDeath(caster);
    this.AnimEnableOrStop(true);  // Enable animation component
    // Has death replacement node
    if (this.deathReplaceNode) {
      this.node.parent.addChild(this.deathReplaceNode);
      this.node.removeFromParent();
      this.deathReplaceNode['entityId'] = this.node['entityId'];
      this.node = this.deathReplaceNode;
      this.animationController = this.node.getComponent(animation.AnimationController);
    }

    // Death skill interrupt
    this.SkillMgr.deathSkillInterrupt();

    this.deathFrameId = BattleData.executeFrameId;


    let gameSecond = Math.ceil(BattleData.executeFrameId / (1000 / NetConfig.frameTime)); // Game process time
    let dieDelayedSecond = gameSecond / 60 + this.zhenWang * 5;// Death 1 time adds 5 seconds death delay seconds game process 1 minute = 1 second death delay
    this.surplusDieWaitFrame = MathUtil.secondToFrame(DataManager.Instance.gameConfig.dieWaitTime + dieDelayedSecond);  // Remaining death wait frames

    if (caster) {
      // let achievementStrArr:Array<string> = [];  // Killer rewards collection
      // Add battle rewards----------------
      // Add items
      if (this.settlementRewardsDefine.Items) {
        let ProbabilityGetItem = this.settlementRewardsDefine.ProbabilityGetItem;
        let RandomGetItemCount = this.settlementRewardsDefine.RandomGetItemCount;
        if (RandomGetItemCount) { // Has random item count
          for (let i = 0; i < RandomGetItemCount; i++) {
            let itemId = RandomUtil.randomArraySeed(this.settlementRewardsDefine.Items);
            if (ProbabilityGetItem) {  // Probability get
              let isGet = RandomUtil.limitIntegerBattle(0, 100) < ProbabilityGetItem;
              if (!isGet || gameSecond > BattleGlobal.limitDropTime) { // Not obtained
                continue;
              }
            }
            caster.AddAchievement(itemId, 1, undefined, this);
          }
        } else {
          for (let i = 0; i < this.settlementRewardsDefine.Items.length; i++) {
            let itemId = this.settlementRewardsDefine.Items[i];
            if (ProbabilityGetItem) {  // Probability get
              let isGet = RandomUtil.limitIntegerBattle(0, 100) < ProbabilityGetItem;
              if (!isGet || gameSecond > BattleGlobal.limitDropTime) { // Not obtained
                continue;
              }
            }
            caster.AddAchievement(itemId, 1, undefined, this);
          }
        }
      }
      // Gold amount
      let coinId = DataUtil.queryItemByType(Constant.ItemType.COIN)?.ID;
      let coin = this.settlementRewardsDefine.Coin;
  

      // Experience amount
      let expeId = DataUtil.queryItemByType(Constant.ItemType.EXPE)?.ID;
      let exp = this.settlementRewardsDefine.Exp;
      if (gameSecond > BattleGlobal.limitDropTime) {
        coin = 1;
        exp = 1;
      }

      // Add killer gold and experience rewards
      caster.AddAchievement(coinId, Math.floor(coin + (coin * BattleGlobal.killExtraGetScale)), undefined, this);
      caster.AddAchievement(expeId, Math.floor(exp + (exp * BattleGlobal.killExtraGetScale)), undefined, this)
      // caster.AddAchievement(coinId, Math.floor(coin), undefined, this);
      // caster.AddAchievement(expeId, Math.floor(exp), undefined, this)

      // Add assist gold and experience rewards
      let attackerVoList = this.AttackerMgr.attackerVoList;
      for (let j = 0; j < attackerVoList.length; j++) {
        let attackerVo = attackerVoList[j];
        let zhuGongCreature = attackerVo.zhuGongCreature;
        if (zhuGongCreature.entityId != caster.entityId) {  // Not killer
          let zb = attackerVo.zhanBi / 100;
          let c = Math.floor(coin * zb);
          zhuGongCreature.AddAchievement(coinId, c < 1 ? 1 : c, undefined, this, true);
          let e = Math.floor(exp * zb);
          zhuGongCreature.AddAchievement(expeId, e < 1 ? 1 : e, undefined, this, true)
        }
      }



      // Update page rewards
      // if(caster.user && caster.user.id == User.Instance.user.id){
      //     if(achievementStrArr.length > 0){
      //         let achievementStr = 'Obtained: ' + achievementStrArr.join(',');
      //         // console.log('achievementStr='+achievementStr)
      //         // EventManager.Instance.dispatch(EventType.OnAchievementStrChange, achievementStr);
      //     }
      // }

      // Death is tower, dragon, attacker team attack increased by 10%
      if (this.characterDefine.Class == Constant.CharacterClass.Fyt || this.characterDefine.Class == Constant.CharacterClass.Boss) {
        let creatureList = CreatureManager.Instance.GetCreatureByTeamType2(caster.teamType2);
        for (let creature of creatureList) {
          if (creature.IsDeath ||
            creature.characterDefine.Class == Constant.CharacterClass.Fyt ||
            creature.characterDefine.Class == Constant.CharacterClass.ShuiJin) {    // Dead, tower, crystal no buff
            continue;
          }
          creature.BuffMgr.AddBuf(undefined, DataManager.Instance.buffs[BattleGlobal.addAttBuffDefineId])
        }

        // Death is boss dragon, team summon dragon
        if(this.characterDefine.Class == Constant.CharacterClass.Boss){
          let tips:string = (caster.teamType2 == TeamType2.Blue ? 'Blue team summons dragon to attack!' : 'Red team summons dragon to attack!');
          BattleManager.Instance.uiBattle.ShowKillBossTips(tips);
          BattleManager.Instance.callMonster.create(caster.teamType2);
        }
      }
    }
    // Remove attack buff from dead person
    this.BuffMgr.RemoveBuff(BattleGlobal.addAttBuffDefineId, true);

    // Update score
    if (this.creatureType == CreatureType.Character) {
      this.BuffMgr.RemoveBuff(-1, true, true);
      caster.renTou++;
      this.zhenWang++;
      if (this.teamType2 == TeamType2.Blue) {
        BattleGlobal.UpdateRedScore();
      } else if (this.teamType2 == TeamType2.Red) {
        BattleGlobal.UpdateBlueScore();
      }
      // Dead person
      this.lianXuRenTou = 0;
      this.lastJiShaTime = 0;
      this.lianXuJiShaJianGe = 0;
      // Attacker
      if (caster.lianXuRenTou > 0) {  // Kill interval
        caster.lianXuJiShaJianGe = new Date().getTime() - caster.lastJiShaTime;
      }
      caster.lianXuRenTou++;  // Consecutive kills
      if(caster.lianXuRenTou > caster.lianXuRenTouMax){
        caster.lianXuRenTouMax = caster.lianXuRenTou;
      }
      caster.lastJiShaTime = new Date().getTime();  // Last kill time        

      // Show kill tips
      BattleManager.Instance.uiBattle.ShowKillTips(caster, this);

      // Self death
      if (this.user && this.user.id == User.Instance.user.id) {
        BattleGlobal.isMyDeath = true;
        EventManager.Instance.dispatch(EventType.OnMyDeathUI);
      }
      // Enemy team all dead
      BattleGlobal.isEnemyTemyAllDeath = CharacterManager.Instance.validateTemyAllDeath(BattleManager.Instance.currentCharacter.teamType2 == TeamType2.Blue ? TeamType2.Red : TeamType2.Blue);

    } else if (this.creatureType == CreatureType.Monster) {  // Monster
      if (this.characterDefine.Class == Constant.CharacterClass.Fyt ||
        this.characterDefine.Class == Constant.CharacterClass.ShuiJin) {  // Tower, crystal
        // Tower show kill tips
        if (this.characterDefine.Class == Constant.CharacterClass.Fyt) {
          BattleManager.Instance.uiBattle.ShowKillTips(caster, this);
        }
        //this.RemoveCreature();  
      }
      // Has attacker and crystal destroyed
      if (caster && this.characterDefine.Class == Constant.CharacterClass.ShuiJin) {
        if (BattleGlobal.isStandaloneFlag) {  // Standalone
          BattleGlobal.GameOver(this.teamType2 == TeamType2.Red, this);
        } else { // Online
          BattleGlobal.GameOver(this.teamType2 == TeamType2.Red, this);
          BattleData.frameHandle.opt = OptType.handGameOver;
          BattleData.frameHandle.optValue1 = User.Instance.user.id;
          BattleData.frameHandle.optValue2 = (this.teamType2 == TeamType2.Red ? TeamType2.Blue : TeamType2.Red);
        }
      }
    }

    DeferredWorkManager.Instance.enqueueDeathRendering(this);
    if (this.characterDefine.IsPool) {  // Object pool management
      this.RemoveCreature();
    }

  }

  /**
   * Execute death rendering (called by DeferredWorkManager when processing queue)
   */
  public ExecuteDeathRendering(): void {
    this.deathRenderingHandle();
  }

  /**
   * Death rendering handling
   */
  private deathRenderingHandle() {
    this.SetAnim(AniState.Death, true);
    if (this.creatureType == CreatureType.Character && this.user && this.user.id == User.Instance.user.id
      && !BattleManager.Instance.uiGameLoadIn.isShow()) {
      // console.log('DoDeath show death info');
      BattleManager.Instance.uiDieInBattle.show(this);
    }
    // Hide HP bar
    this.IsShowHpNode = false;
    // Hide shadow
    this.ShadowControl(false);
    if (this.characterDefine.Class != Constant.CharacterClass.Fyt && this.characterDefine.Class != Constant.CharacterClass.ShuiJin) {  // Not crystal and tower
      let this_ = this;
      let corpseSinkTime = (this.creatureType == CreatureType.Character ? BattleGlobal.characterCorpseSinkTime * 1000 : BattleGlobal.monsterCorpseSinkTime * 1000);
      let tweenTime = 3;  // Animation time
      // Corpse sink
      if (BattleGlobal.isNormalPlay) {  // Normal play
        this.corpseSinkTimer = setTimeout(function () {
          if (!this_.IsDeath) {  // Not dead
            return;
          }
          if (BattleGlobal.isNormalPlay) {  // Normal play
            this_.corpseSinkTween = tween(this_.node.parent).by(tweenTime, { worldPosition: BattleGlobal.corpseSinkVec3 }, { easing: "smooth" }).call(function () {
              this_.CorpseSinkCompleteHandel();
            }).start();
          } else {  // Fast play
            this_.CorpseSinkCompleteHandel();
          }
        }, corpseSinkTime)
      } else {
        this_.CorpseSinkCompleteHandel();
      }
    }
  }

  /**
   * Corpse sink complete handling
   * @returns 
   */
  private CorpseSinkCompleteHandel() {
    try {
      if (!this.IsDeath) {  // Not dead
        return;
      }

      this.node.active = false;
      if (this.characterDefine.IsPool) { // Return to object pool
        PoolManager.instance.putNode(this.node.parent);
      }
    } catch (e) {
      console.log(e)
    }
  }

  /**
   * Remove creature
   */
  private RemoveCreature() {
    this.BuffMgr.RemoveBuff(-1, true); // Remove all buffs
    this.EffectMgr.RemoveAllEffect();  // Remove all effects
    CreatureManager.Instance.RemoveCreature(this.entityId);
  }

  /**
   * Move handling
   */
  public MoveHandle(isPrediction = false, isUpdateRendering = true, isReadRenderValue = false) {
    CollisionCheckManager.Instance.CollisionCheck(this, isPrediction, isUpdateRendering, isReadRenderValue);
  }

  private forwardTween: any = null;
  private newPos: Vec3 = new Vec3();
  private tagertPos: Vec3 = new Vec3();
  /**
   * Rotation handling
   * @param angle Angle
   * @param isPrediction Whether prediction
   * @param isUpdateRendering Whether update rendering
   * @param isImmRotate  Whether immediate rotation
   */
  public RotateHandle(angle: number, isPrediction = false, isUpdateRendering = true, isImmRotate = false) {
    // if(!this.node.parent){
    //    console.log('RotateHandle: character id='+this.characterDefine.ID+'，node id='+this.node.uuid+'，teamType2='+this.teamType2)
    // }
    // console.log('RotateHandle angle='+angle)
    this.lastSkillRotateAngle = angle;
    if (!isPrediction) {
      // Update logic direction
      this.logicRotation.y = angle;
    }
    // Update render direction
    if (isUpdateRendering) {
      let rockerSpeedVo = DataManager.Instance.rockerSpeeds[angle];
      if (!rockerSpeedVo) {
        console.log('RotateHandle rockerSpeedVo does not exist! ID=' + this.characterDefine.ID + '，angle=' + angle)
        this.node.parent.setRotationFromEuler(0, angle, 0);
        return;
      }

      if (this.forwardTween) {
        this.forwardTween.stop()
      }
      let parentNode = this.node.parent;
      if (!parentNode) {
        return;
      }
      if (isImmRotate || BattleGlobal.isChasingFrameFlag) {  // Immediate rotation
        parentNode.setRotationFromEuler(0, angle, 0);
        return;
      }

      // Quat.lerp(parentNode.rotation,)
      // Interpolate direction
      this.newPos.set(-rockerSpeedVo.x / 100, 0, -rockerSpeedVo.y / 100);
      let this_ = this;
      this.forwardTween = tween({ forward: parentNode.forward }).to(BattleGlobal.rotateChaZhi, { forward: this.newPos }, {
        onUpdate: (v: any) => {
          try {
            if (v.forward) {
              this_.tagertPos.set(v.forward);
              parentNode.forward = this_.tagertPos;
            }
          } catch (e) {
            console.error(e)
            // parentNode.forward =  newPos;
            parentNode.setRotationFromEuler(0, angle, 0);
            if (this_.forwardTween) {
              this_.forwardTween.stop()
            }
          }
        }
      }).start()
    }
  }

  private popupOffset: Vec3 = new Vec3();
  public GetPopupOffset(): Vec3 {
    this.popupOffset.set(0, this.characterDefine.Height * 0.7, 0);
    return this.popupOffset;
  }

  private popup2Offset: Vec3 = new Vec3();
  public GetPopup2Offset(): Vec3 {
    this.popup2Offset.set(0, this.characterDefine.Height * 0.1, 0);
    return this.popup2Offset;
  }

  private hitOffset: Vec3 = new Vec3();
  public GetHitOffset(HitHeightScale: number = 0.8): Vec3 {
    this.hitOffset.set(0, this.characterDefine.Height * HitHeightScale, 0);
    return this.hitOffset;
  }

  public PlayEffect(type: EffectType, name: string, target: Creature, duration: number = 0, HitHeightScale?: number, bullet?: Bullet, isUseGlobalEffect?: boolean) {
    // console.log('EntityEffectMgr='+this.EntityEffectMgr+'，type='+type+'，name='+name+
    // '，duration='+duration)

    if (type == EffectType.Normal) {
      FXManager.Instance.PlayEffect(type, name, target.node, target.GetHitOffset(HitHeightScale || 0), duration);
    }
    else {
      let node = this.EntityEffectMgr.PlayEffect2(type, name, target ? target.node : null,
        target ? target.GetHitOffset(HitHeightScale || 0) : null, duration, bullet,
        isUseGlobalEffect, target ? target.characterDefine.HitEffectScale : undefined);

      // if(this.user && this.user.id == User.Instance.user.id){  // Self
      //   if(node){
      //     console.log('PlayEffect node=', node.worldPosition, node.active, node.parent)
      //   }
      // }
    }
  }

  public PlayEffect2(type: EffectType, name: string, position: Vec3, duration: number = 0) {
    if (type == EffectType.Normal)
      FXManager.Instance.PlayEffect(type, name, null, position, duration);
    else
      this.EntityEffectMgr.PlayEffect2(type, name, null, position, duration);
  }

  public PlayEffectBulletRealCheck(type: EffectType, name: string, bullet: Bullet) {
    if (!name) {
      return;
    }
    this.EntityEffectMgr.PlayEffectBulletRealCheck(type, name, bullet);
  }

  /**
   * Set animation state
   * @param entityState  Animation state 
   * @param value  Value
   */
  public SetAnim(aniState: AniState, value: any) {
    if (!aniState) {
      return;
    }
    // musa: remove this check to allow animation for all creatures.
    // // Buildings are static - no animation
    // if (this.characterDefine.Class === Constant.CharacterClass.Fyt || this.characterDefine.Class === Constant.CharacterClass.ShuiJin) {
    //   return;
    // }
    // if(this.user && this.user.id == User.Instance.user.id){
    //   console.log('Set animation state =', aniState ,value)
    // }
    if (value) {
      this.aniState = aniState;
    }
    // When node is inactive (fog of view), skip driving AnimationController to avoid assertion (invalid refs)
    if (!this.node.active) {
      return;
    }
    BattleGlobal.SetAnim(aniState, value, this.animationController);
  }

  public DoAddBuff(buff: Buff) {
    EventManager.Instance.dispatchObj(EventType.DoAddBuff, this, buff);
  }

  public DoRemoveBuff(buff: Buff) {
    EventManager.Instance.dispatchObj(EventType.DoRemoveBuff, this, buff);
  }


  /**
   * Set battle state
   * @param isCanMove Whether can move
   * @param isCanSkill Whether can cast skills
   * @param isImmunity Whether immune (other players' skills can find but cannot deal damage)
   * @param isRetreat Whether retreated (other players' skills cannot find, cannot deal damage)
   */
  public SetBattleState(isCanMove: boolean, isCanSkill: boolean, isImmunity: boolean, isRetreat: boolean) {
    this.isCanMove = isCanMove;
    this.isCanSkill = isCanSkill;
    this.isImmunity = isImmunity;
    this.isRetreat = isRetreat;
  }

  /**
   * Move
   * @param angle Angle
   * @param speed Speed
   * @param isPrediction Whether prediction (default false)
   * @param isUpdateRendering Whether update rendering (default true)
   * @param isAiMove Whether AI caused movement (default false)
   */
  public Move(angle: number, speed: number, isPrediction = false, isUpdateRendering = true, isAiMove = false,
     logicX?: number, logicY?: number, logicZ?: number, isReadStateValueFlag?:boolean, isCalculationPredictionStateFlag?:boolean): boolean {
    this.lastMoveAngle = angle;
    let rockerSpeedVo = DataManager.Instance.rockerSpeeds[angle];
    if (!rockerSpeedVo) {
      console.log('rockerSpeedVo does not exist!' + angle + '==' + (angle))
      return false;
    } else if (speed <= 0) {
      return false;
    }

    // let bs: number = 1; // Multiplier
    // if (isPrediction) { // Prediction, set slow multiplier
    //   bs = Math.floor(NetConfig.frameTime / BattleGlobal.fastestWaitTime);
    // }
    if(isCalculationPredictionStateFlag){  // Calculate prediction state      
      logicX = LogicRenderConvert.RenderToLogic_Value(this.renderPosition.x) + (rockerSpeedVo.x * speed * NetConfig.speedFactor);
      logicY = this.logicPosition.y;
      logicZ = LogicRenderConvert.RenderToLogic_Value(this.renderPosition.z) + (rockerSpeedVo.y * speed * NetConfig.speedFactor);
    }else if(!isReadStateValueFlag){  // Not reading state value
      logicX = this.logicPosition.x + (rockerSpeedVo.x * speed * NetConfig.speedFactor);
      logicY = this.logicPosition.y;
      logicZ = this.logicPosition.z + (rockerSpeedVo.y * speed * NetConfig.speedFactor);
    }

    let flag = this.LogicToRenderPosition(logicX || 0, logicY || 0, logicZ || 0, isPrediction, isUpdateRendering, undefined, isAiMove);
    if (!flag) {
      return false;
    }

    // if(isAiMove){
    //     this.lastLogicPosition.set(this.logicPosition.x, this.logicPosition.y, this.logicPosition.z);
    // }
    // Prediction movement handling, afraid of wall penetration, still add
    // if(!isAiMove){  // Not AI movement
    this.MoveHandle(isPrediction, isUpdateRendering, isCalculationPredictionStateFlag);  // Move handling
    // }
    this.lastLogicPosition.set(this.logicPosition.x, this.logicPosition.y, this.logicPosition.z);
    return true;
  }


  private mainColor = new Color(255, 255, 255, 255);
  /**
   * Set transparency
   * @param a Transparency
   */
  public SetTransparency(a: number) {
    if (!this.materialArr || this.materialArr.length < 1) {
      return;
    }
    //   console.log('SetTransparency a='+a)
    this.mainColor.a = a;

    for (let mat of this.materialArr) {
      mat.setProperty('mainColor', this.mainColor); // Modify material transparency
    }
  }

  /**
   * Set texture
   */
  public SetMainTexture(texture?: Texture2D) {
    // console.log('SetMainTexture=====')
    this.mainColor.a = 255;
    let matIndex = 0;
    for (let mat of this.materialArr) {
      if (!texture) {
        texture = this.materialMainTextureArr.length > matIndex ? this.materialMainTextureArr[matIndex] : this.materialMainTextureArr[this.materialMainTextureArr.length - 1];
      }
      mat.setProperty('mainTexture', texture); // Modify material texture
      mat.setProperty('mainColor', this.mainColor); // Modify material transparency
      matIndex++;
    }
  }


  /**
   * Animation enable or stop
   * @param isEnable Whether enable
   */
  public AnimEnableOrStop(isEnable: boolean) {
    let animationController = this.animationController;
    if (animationController) {
      animationController.enabled = isEnable;
    }
  }

  /**
   * Create effect parent node
   */
  private CreateEffectParentNode() {
    let parentNode = this.node.parent;
    // Get effect node under parent node
    let effectNode = parentNode.getChildByName('Effect');
    if (!effectNode) {
      effectNode = new Node('Effect');
      parentNode.addChild(effectNode);
    }
    this.effectParentNode = effectNode;
  }

  /**
     * Rollback state
     */
  rollback(data: CreatureRecord): void {
    this.entityId = data.entityId;
    this.teamType2 = data.teamType2;

    this.logicPosition = DeseTypeConve.conveVec3(this.logicPosition, data.logicPosition);
    LogicRenderConvert.LogicToRender_TwoVec3(this.logicPosition, this.renderPosition);
    this.node.parent.setWorldPosition(this.renderPosition.x, this.renderPosition.y, this.renderPosition.z);

    if (data.SkillMgr && this.SkillMgr) {
      this.SkillMgr.rollback(data.SkillMgr);
    }
    if (data.BuffMgr && this.BuffMgr) {
      this.BuffMgr.rollback(data.BuffMgr);
    }
    if (data.EffectMgr && this.EffectMgr) {
      this.EffectMgr.rollback(data.EffectMgr);
    }
    // ✅ ALWAYS rollback AttackerMgr to clear old attackers, even if no saved data
    if (this.AttackerMgr) {
      if (data.AttackerMgr) {
        this.AttackerMgr.rollback(data.AttackerMgr);
      } else {
        // No saved attackers, clear any existing ones
        console.log('[ASSIST ROLLBACK] No saved attackers for ' + this.characterDefine.Name + ', clearing existing');
        this.AttackerMgr.Attackers.length = 0;
      }
    }
    this.IsDeath = data.IsDeath;
    this.deathTime = DeseTypeConve.conveDate(data.deathTime);
    this.deathFrameId = data.deathFrameId;
    this.birthPosition = DeseTypeConve.conveVec3(this.birthPosition, data.birthPosition);
    this.birthRotation = DeseTypeConve.conveVec3(this.birthRotation, data.birthRotation);
    this.logicRotation = DeseTypeConve.conveVec3(this.logicRotation, data.logicRotation);
    this.creatureType = data.creatureType;
    this.aniState = data.aniState;


    if (this.characterDefine.Class == Constant.CharacterClass.Fyt) {  // Tower
      console.log('Tower===', this.IsDeath, this.aniState)
    }

    if (this.IsDeath) {
      this.deathRenderingHandle();  // Death rendering handling
    } else {
      this.SetAnim(this.aniState, true);
    }

    this.surplusDieWaitFrame = data.surplusDieWaitFrame;

    this.attributes.rollback(data.attributes);

    this.notHandleFrameCount = data.notHandleFrameCount;
    this.achievementList = data.achievementList;
    this.allSportsItemList = data.allSportsItemList;
    this.useSportsItemList = data.useSportsItemList;
    this.renTou = data.renTou;
    this.zhenWang = data.zhenWang;
    this.zhuGong = data.zhuGong;
    this.score = data.score;
    this.isMvp = data.isMvp;
    this.lianXuRenTou = data.lianXuRenTou;
    this.lianXuRenTouMax = data.lianXuRenTouMax;
    this.lastJiShaTime = data.lastJiShaTime;
    this.lianXuJiShaJianGe = data.lianXuJiShaJianGe;
    this.startBirthPlaceNeedWindHpFrameId = data.startBirthPlaceNeedWindHpFrameId;
    this.resuFlag = data.resuFlag;
    this.resuFrameId = data.resuFrameId;
    this.newExistOptFrameId = data.newExistOptFrameId;
    this.isAiControlFlag = data.isAiControlFlag;
    this.aiRoadType = data.aiRoadType;
    this.resuCoinCount = data.resuCoinCount;
    this.resuCoinUseCount = data.resuCoinUseCount;
    this.SpawnId = data.SpawnId;
    if (data.AI && this.AI) {
      this.AI.rollback(data.AI);
    }

    this.dir = data.dir;
    this.isCanMove = data.isCanMove;
    this.isCanSkill = data.isCanSkill;
    this.isImmunity = data.isImmunity;
    this.isRetreat = data.isRetreat;
    this.isShowHpNode_ = data.isShowHpNode_;
    this.isUpdateRenderingPos = data.isUpdateRenderingPos;
    this.IsDisplacementing = data.isDisplacementing;
    this.isTuiKaiing = data.isTuiKaiing;
    this.isRepeling = data.isRepeling;

    this.battleAttribute.rollback(data.battleAttribute);

    this.aggro = data.aggro;
    this.noInBattleFrame = data.noInBattleFrame;
    this.lastSkillRotateAngle = data.lastSkillRotateAngle;
    this.lastLogicPosition = DeseTypeConve.conveVec3(this.lastLogicPosition, data.lastLogicPosition);
    this.lastMoveAngle = data.lastMoveAngle;
    
    if (data.aiHeroSkillMoveTargetRecord && this.aiHeroSkillMoveTarget) {
      this.aiHeroSkillMoveTarget.rollback(data.aiHeroSkillMoveTargetRecord);
    }

  }
}