import { Node, ParticleSystem, Color, animation, SkinnedMeshRenderer, Material, instantiate, Vec3, Vec2 } from "cc";
import { Creature } from "../Enities/Creature";
import { BattleMode } from "../enums/BattleMode";
import { DataManager } from "../../../Managers/DataManager";
import { User } from "../../../Models/User";
import proto from '../../../../Proto/proto.js';
import { BattleService } from "../../../Services/BattleService";
import { Util } from "../../../Utils/Util";
import { TeamType2 } from "../enums/TeamType2";
import { UserInfoVo } from "../../../Vo/UserInfoVo";
import { UserInfoVo2 } from "../../../Vo/UserInfoVo2";
import { TeamInfoVo } from "../../../Vo/TeamInfoVo";
import { CharacterManager } from "../Managers/CharacterManager";
import { MathUtil } from "../../../Utils/MathUtil";
import { Decimal } from "decimal.js";
import { EventManager } from "../../Common/Event/EventManager";
import { EventType } from "../../Common/Event/EventType";
import { BattleManager } from "../Managers/BattleManager";
import { AniState } from "../enums/AniState";
import { CharacterDefine } from "../../../Data/CharacterDefine";
import { CreatureType } from "../enums/CreatureType";
import { CreatureManager } from "../Managers/CreatureManager";
import { PoolManager } from "../../../Managers/PoolManager";
import { UIBattle } from "../UIBattle";
import { UIWorldElementManager } from "../UIWorldElementManager";
import { OptType } from "../enums/OptType";
import { BattleData } from "./BattleData";
import { LocalStorageUtil } from "../../../Utils/LocalStorageUtil";
import { Skill } from "../Models/Skill";
import { BattleSoundTipsManager } from "../Managers/BattleSoundTipsManager";
import { ChatManager } from "../../../Managers/ChatManager";
import { DateUtil } from "../../../Utils/DateUtil";
import { NetConfig } from "../../../Network/NetConfig";
import { Attributes } from "../Attribute/Attributes";
import { SoundDefine } from "../../../../../Scripts/Sound/SoundDefine";
import { Constant } from "../../../../../Scripts/Utils/Constant";
import { HashMap } from "../../../../../Scripts/Utils/HashMap";
import { LoadResUtil } from "../../../../../Scripts/Utils/LoadResUtil";
import { SpawnMonManager } from "../SpawnMon/SpawnMonManager";

/**
 * Battle variables
 */
export class BattleGlobal{   

    //Some properties that need state recording
    public static blueGameIsVictory:boolean = false; //Blue team game victory
    public static isGameEndFlag:boolean = false; //Game is over
    private static blueScore:number=0;   //Blue team score
    private static redScore:number=0;   //Red team score

    
    public static battleMode:BattleMode;  //Battle mode
    public static skillTipsMap=new HashMap();  //Skill tips model key: skill tips type name string value: skill model
    public static shadowsMap=new HashMap();  //Shadow node
    public static targetLiveUserId:number;  //Target live user id
    public static isExistBattleFlag:boolean = false;   //Battle exists

    public static logStr:string='';
    public static teamCount:number = 0;  //Team count
    public static accountExpQuota:number = 0 ;  //Game end settlement experience quota
    public static battleRecordData:Array<any> = [];  //Battle data
    public static myColor = '#00FF00';  //My color
    public static friendColor = '#001FFF';  //Friend team color
    public static enemyColor = '#FF0000';  //Enemy team color
    
    public static myColor2 = new Color().fromHEX(BattleGlobal.myColor);  //My color
    public static friendColor2 = new Color().fromHEX(BattleGlobal.friendColor);  //Friend team color
    public static enemyColor2 = new Color().fromHEX(BattleGlobal.enemyColor);  //Enemy team color

    public static cameraOffsetAngle:number = 0;  //Camera offset angle
    
    //Battle global effects
    public static birthPlaceEffectsName:string='EFX_HealField';   //Birth place effect name
    public static resuPlaceEffectsName:string='EFX_ActivateLife';   //Revive effect name
    public static shanbiName:string='shanbi';   //Dodge effect name
    public static jiasuName:string='runSmoke';   //Speed up effect name
    public static jiansuName:string='jiansu';   //Slow down effect name
    public static cureName:string='cure';   //Heal effect name
    public static yunName:string='yun';   //Stun effect name
    public static frozenName:string='frozen';   //Frozen effect name
    public static huichengName:string='huicheng';   //Recall effect name
    public static runSmokeName:string='runSmoke';   //Move effect name
    public static huoName:string='huo';   //Burning effect name
    

    public static birthPlaceEffectsDiameter:number=8.6;  //Birth place effect diameter
    public static birthPlaceWindHpFrameCount:number = MathUtil.millisecondToFrame(450); //Birth place heal frame count
    public static birthPlaceWindHpPercent:Decimal = new Decimal(10); //Birth place heal percentage
    public static huiHpFrameNum:number = MathUtil.secondToFrame(5); //Restore HP frame count
    public static resuWaitFrameCount:number = MathUtil.secondToFrame(1); //Revive wait frame count
    public static greatMonsterTipsFrameCount:number = MathUtil.secondToFrame(30); //Great monster tips frame count
    public static minimapTakeEffectFrameCount:number = MathUtil.secondToFrame(3); //Minimap effect frame count
    public static desCircleRadius:number = 0.65; //Specified type circle diameter
    public static flashObstacleSuffix = '_chuan';  //Flash passable obstacle suffix
    public static addAttBuffDefineId:number = 39;  //Death is tower/dragon, attacker team attack +10%, buff config id
    public static creatureChaZhi:number = 0.2;  //Creature move interpolation
    public static creatureChaZhi2:number = 0.17;  //Online non-self creature interpolation
    public static bulletChaZhi:number = 0.016;  //Bullet move interpolation
    // public static hpChaZhi:number = 0.15; //HP bar interpolation
    public static isTouchSkillBtnFlag:boolean = false; //Touch skill button
    public static isChasingFrameFlag:boolean = false;  //Chasing frames
    public static framePlaySpeed:number = 1;  //Frame play speed
    public static isStandaloneFlag:boolean = false;  //Is standalone
    public static preperformanceFrameCount = 3; //Player move prediction frame count
    public static aniPredictionFrameCount = 3; //Animation prediction frame count
    public static aniPredictionFrameCount2 = 3; //Online non-self creature animation prediction frame count
    public static rotateChaZhi:number = 0.15;  //Rotation interpolation
    public static rotateFrameMoveMaxAngle:number = 3;  //Joystick rotation release skill max rotation angle per frame
    public static dropLastRandomNum:number = -99;  //Drop last generated random number
    public static characterCorpseSinkTime:number = 7;  //Hero corpse sink time from death (seconds)
    public static monsterCorpseSinkTime:number = 3;  //Monster corpse sink time from death (seconds)
    public static corpseSinkVec3 = new Vec3(0, -2, 0);  //Corpse sink position vector
    public static dropsInitAngle:number = 180;  //Drop initial angle
    public static battleSoundTipsTime:number = 15 * 1000;//Battle sound tips interval time (milliseconds)
    public static continuousKillTime:number = 30;  //Continuous kill judgment time (seconds)
    public static isNormalPlay:boolean = false;  //Is normal play
    public static The_enemy_has_five_seconds_sound_frame:number = 2*15; //Enemy has 5 seconds to reach battlefield sound (play frame count)
    public static The_whole_army_launched_an_attack_sound_frame:number = 7*15; //Whole army attack sound (play frame count)
    public static myShuiJinSoundTipsJgFrame:number = 4*15;  //My crystal sound tips interval frame count
    public static myShuiJinSoundFrame:number = 0;  //My crystal sound tips frame count
    public static noInBattleFrameCount:number = MathUtil.secondToFrame(5); //Lost battle state frame count
    public static piaoZiChaZhi:number = 0.05;  //Floating text interpolation
    public static fastestWaitTime:number = 16;   //Fastest timer time ms
    public static showSelectedQuanTargetRange:number = 7; //Show selected circle target range
    public static killExtraGetScale:number = 0.5; //Kill extra gain ratio
    public static limitDropTime:number = 900; //Limit drop time 900 seconds
    public static start_game_character_addAi_frame:number = 5*15; //Game start player auto AI time
    public static noOperateSeconds:number = 10;   //10 seconds no operation AI auto operation
    public static bossCreature:Creature = null;
    
    // Playing method - initialized from localStorage if available
    private static _playingMethod: number = -1; // -1 means not initialized
    public static get playingMethod(): number {
        if (this._playingMethod === -1) {
            // Load from localStorage, default to 0 (3v3) if not set
            const saved = LocalStorageUtil.GetItem('selectedPlayingMode');
            this._playingMethod = saved ? parseInt(saved) : 0;
            console.log(`[BattleGlobal GETTER] First access - loaded from storage: "${saved}" -> ${this._playingMethod}`);
        } else {
            console.log(`[BattleGlobal GETTER] Returning cached value: ${this._playingMethod}`);
        }
        return this._playingMethod;
    }
    public static set playingMethod(value: number) {
        console.log(`[BattleGlobal SETTER] Setting playingMethod: ${this._playingMethod} -> ${value}`);
        this._playingMethod = value;
        // Save to localStorage for persistence across scene loads
        LocalStorageUtil.SetItem('selectedPlayingMode', value.toString());
        console.log(`[BattleGlobal SETTER] Saved to storage: ${value}`);
    }

    //Some variables for recording state
    public static isMyDeath:boolean = false; //Am I dead
    public static isEnemyTemyAllDeath:boolean = false; //Enemy team all dead
    public static isHpBloodSpring:boolean = false;  //Am I in blood spring
    public static noOptTime:number = 3;  //No operation time (seconds)
    public static cacheStateJgTime:number = 10; //Cache state interval time (seconds)
    public static nextCacheStateFrameId:number = -1;  //Next cache state frame
    public static sameScreenRangeRadius:number = 14;  //Same screen range radius (3D code unit render value)
    public static visionRadius:number = 18;  //Fog of view: vision radius in render units (enemies visible within this distance)

    public static init(){
        this.isGameEndFlag = false;
        this.blueGameIsVictory = false;
        this.isStandaloneFlag = false;
        this.isNormalPlay = false;
        this.myShuiJinSoundFrame = 0;
        //Settlement experience calculation
        let accountExpQuota = DataManager.Instance.gameConfig.accountExpQuota;
        BattleGlobal.accountExpQuota = accountExpQuota;
        this.dropLastRandomNum = 0;
        this.isMyDeath = false;
        this.isEnemyTemyAllDeath = false;
        this.isHpBloodSpring = false;
        this.nextCacheStateFrameId = 5*15;  //(Start caching state after 5 seconds of game start)
        this.bossCreature = null;
        const cfg = DataManager.Instance?.gameConfig as Record<string, unknown>;
        if (cfg && typeof cfg.VisionRadius === 'number') {
            this.visionRadius = cfg.VisionRadius;
        }
    }


    /** Blue team score */
    public static get BlueScore():number{
        return this.blueScore;
    }
    public static set BlueScore(value:number){
        this.blueScore = value;
    }
    
    /**
     * Update blue team score
     */
    public static UpdateBlueScore(){
        this.blueScore++;
        if (BattleData.executeFrameId + 1 < BattleData.newFrameId) {  //Not executed to latest frame
          return;
        }
        BattleService.Instance.SendUploadBiFen(this.blueScore+':'+this.redScore); //Upload score
    }

    /** Red team score */
    public static get RedScore():number{
        return this.redScore;
    }
    public static set RedScore(value:number){
        this.redScore = value;
    }
    /**
     * Update red team score
     */
    public static UpdateRedScore(){
        this.redScore++;
        if (BattleData.executeFrameId + 1 < BattleData.newFrameId) {  //Not executed to latest frame
          return;
        }
        BattleService.Instance.SendUploadBiFen(this.blueScore+':'+this.redScore); //Upload score
    }

    public static clear(){
        this.blueScore = 0;
        this.redScore = 0;
        this.skillTipsMap.clear();
    }

     /**
     * Get battle message text content
     * @param chatMessage Message object
     * @param enterFontCount Line break character count -1 means no manual line break
     * @param index 0, Our side 1, Live stream fans
     */
    public static getBattleMsgContent(chatMessage:proto.Message.IChatMessage, enterFontCount:number, index:number):string{
        let characterDefine = DataManager.Instance.characters[chatMessage.fromCCharacterId];
        let name = '';
        let nameStr = '';
        if((BattleGlobal.battleMode == BattleMode.Battle && User.Instance.user.id == chatMessage.fromId) || 
           (BattleGlobal.battleMode == BattleMode.Live && chatMessage.fromId == chatMessage.enterLiveUserId)) {  // Own player or followed user
            name = chatMessage.fromName+'('+characterDefine.Name+'):';
            nameStr = '<color=#36DA3B>'+name+'</color>';
        }else if(index == 0){  // Our side player
            name = chatMessage.fromName+'('+characterDefine.Name+'):';
            nameStr = '<color=#4169E1>'+name+'</color>';
        }else if(index == 1 && BattleGlobal.battleMode == BattleMode.Battle){  // Fans
            name = '(Fans)'+chatMessage.fromName+':';  
            nameStr = '<color=#4169E1>'+name+'</color>';          
        }else if(index == 1 && BattleGlobal.battleMode == BattleMode.Live){  // Visitors
            name = '(Visitor)'+chatMessage.fromName+':';  
            nameStr = '<color=#4169E1>'+name+'</color>';       
        }
        
        let contentStr='';
      if(enterFontCount < 0){
        contentStr = chatMessage.msg;
      } else {
        let i=name.length;
        for(let char of chatMessage.msg){
            i++;
            if(i%enterFontCount==0){  // Line break
                char += '\n';
            }
            contentStr += char;
        }
      }
       // console.log('contentStr='+contentStr)
        return nameStr+'<color=#ffffff>'+contentStr+'</color>';
    }
  
    /**
     * Play particle effect
     */
    public static playParticleEffect(node : Node, isOneCall:boolean = true, scale:number = 1){
      if(isOneCall){
        node.active = true;
      }      
      if(!scale){
        scale = 1;
      }
      let scaleX:number = node['scaleX'];
      let scaleY:number = node['scaleY'];
      let scaleZ:number = node['scaleZ'];
      if(!scaleX || !scaleY || !scaleZ){
        node['scaleX'] = scaleX = node.scale.x;
        node['scaleY'] = scaleY = node.scale.y;
        node['scaleZ'] = scaleZ = node.scale.z;
      }

      node.setScale(scaleX * scale, scaleY * scale, scaleZ * scale);      
      try{
        let particleSystem = node.getComponent(ParticleSystem);
        if(particleSystem){
            particleSystem.stop();
            particleSystem.clear();
            particleSystem.play();
            // particleSystem.stop();
            // particleSystem.play();
        }
      }catch(e){       
      }
        // console.log('playParticleEffect name='+node.name)

        // let particleSystem = node.getComponent(ParticleSystem);
        // if(particleSystem){
        //   particleSystem.play();
        // }
        let childrenList = node.children;
        for(let i=0; i < childrenList.length; i++){
            this.playParticleEffect(childrenList[i], false, scale);
        }


    }
    

     /**
     * Calculate score (kills + assists) / deaths + (battle record data item score * quantity)   
     * @param creature 
     */
    public static calculationScore(creature:Creature){
        if(creature.renTou + creature.zhuGong == 0){
          creature.score = 0;
        }else if(creature.zhenWang == 0){
          creature.score = creature.renTou + creature.zhuGong;
        }else{
          creature.score = (creature.renTou + creature.zhuGong) / creature.zhenWang;
        }
        for(let i=0; i < creature.achievementList.length; i++){
          let achievementVo = creature.achievementList[i];
          let itemDefine = DataManager.Instance.items[achievementVo.itemId];
          creature.score += itemDefine.Score * achievementVo.count;
        }
        creature.score = Util.toFixed(creature.score, 1);
    }

    

    /**
     * Get battle record data
     * @param type Type 1, Battle record 2, Game settlement
     */
    public static getRecordData(type:number) {
        let characterList = CharacterManager.Instance.characterList;
        if(type == 2){  // Game settlement
          // Calculate player score
          let blueMaxScoreCreature:Creature = null;  // Blue team highest scoring player
          let redMaxScoreCreature:Creature = null;  // Red team highest scoring player
          for(let i = 0; i < characterList.length; i++){
            let creature = characterList[i];
            creature.isMvp = false;
            BattleGlobal.calculationScore(creature);  // Calculate score
            if(creature.teamType2 == TeamType2.Blue && (!blueMaxScoreCreature || creature.score > blueMaxScoreCreature.score)){
              blueMaxScoreCreature = creature;
            }
            if(creature.teamType2 == TeamType2.Red && (!redMaxScoreCreature || creature.score > redMaxScoreCreature.score)){
              redMaxScoreCreature = creature;
            }
          }
          if(blueMaxScoreCreature){
            blueMaxScoreCreature.isMvp = true;
          }
          if(redMaxScoreCreature){
            redMaxScoreCreature.isMvp = true;
        }
        }

        let userInfoOtherDataMap = new HashMap();  // User other data
        let userList:Array<UserInfoVo> = [];
        for(let j = 0; j < characterList.length; j++){
          let creature = characterList[j];
          let isVictory:boolean = (creature.teamType2 == TeamType2.Blue ? this.blueGameIsVictory : !this.blueGameIsVictory);  // Whether victorious          
          let character = creature.user.character;
          userList.push(new UserInfoVo(creature.user.id, creature.renTou, creature.lianXuRenTouMax, creature.zhenWang, creature.zhuGong, creature.score,
             creature.isMvp, creature.achievementList, creature.useSportsItemList, isVictory, creature.teamType2, creature.resuCoinUseCount));
          
          userInfoOtherDataMap.put(creature.user.id, new UserInfoVo2(character.cid, character.level, creature.user.nickname, 
            0/*creature.user.fenSiCount*/, 0,//creature.user.barrageCount, 
            (type == 1 ? creature.attributes.ATT.toFixed(1) : character?.att),
             (type == 1 ? creature.attributes.DEF.toFixed(1) : character?.def), 
             (type == 1 ? character?.cPower : character?.cPower), 
             (type == 1 ? creature.attributes.HP.toFixed(0) : character?.hp), character.hp));
        }

        // Main data
        let costTime = DateUtil.convertSecondsToMS(BattleData.newFrameId * NetConfig.frameTime / 1000);
        let teamInfoVo = new TeamInfoVo(User.Instance.user.id, BattleGlobal.BlueScore, BattleGlobal.RedScore, BattleGlobal.accountExpQuota, costTime, userList);   
        this.battleRecordData = [teamInfoVo, userInfoOtherDataMap];
    }

    /**
     * Get current combat power
     * Power formula: att*15 + def*10 + hp*15 + cri*5 + resu*3 + speed*3 + cd*3 + huiHp*3
     */
    private static getCurrentPower(attributes:Attributes, hp:number):Decimal{
      return Decimal.mul(attributes.ATT, 15).add(Decimal.mul(attributes.DEF, 10)).add(Decimal.mul(hp, 15))
      .add(Decimal.mul(attributes.CRI, 5)).add(Decimal.mul(attributes.RESU, 3))
      .add(Decimal.mul(attributes.Speed, 3)).add(Decimal.mul(attributes.CD, 3)).add(Decimal.mul(attributes.HUIHP, 3));
    }


    /**
     * Angle processing (including camera angle offset)
     * @param angle 
     */
    public static AngleHandle(angle:number):number{
      angle = Math.round(angle + BattleGlobal.cameraOffsetAngle);
      if (angle < 0) {
        angle = angle + 360;
      } else if (angle > 360) {
        angle = angle - 360;
      }
      return angle;
    }

    /**
     * Angle processing
     * @param angle 
     */
    public static AngleRangeHandle(angle:number):number{
      if (angle < 0) {
        angle = angle + 360;
      } else if (angle > 360) {
        angle = angle - 360;
      }
      return angle;
    }


    /**
     * King version game end
     * @param blueGameIsVictory Whether blue team is victorious
     * @param deathShuiJin Destroyed crystal
     */
    public static GameOver(blueGameIsVictory:boolean, deathShuiJin?:Creature){
      if(BattleGlobal.isGameEndFlag){
        return;
      }
      // Hide UI
      BattleManager.Instance.uiBattle.battleUI.active = false;
      UIWorldElementManager.Instance.node.active = false;
      
      this.blueGameIsVictory = blueGameIsVictory;
      BattleGlobal.isGameEndFlag = true;
      ChatManager.Instance.gameMessages = [];
      ChatManager.Instance.liveMessages = [];
      // Manual destruction
      if(!deathShuiJin){  
        deathShuiJin = CreatureManager.Instance.GetCreatureByClassTeamType2(Constant.CharacterClass.ShuiJin, blueGameIsVictory ? TeamType2.Red : TeamType2.Blue);
        deathShuiJin.DoDeath(null);
      }
      BattleManager.Instance.deathShuiJin = deathShuiJin; 
      // Start ending game
      setTimeout(function(){
        if(BattleManager.Instance){
          BattleManager.Instance.LookBattleTeamInfo(2); 
        }
      }, 500)      
    }

    /**
     * Set animation
     * @param aniState 
     * @param value 
     * @param animationController 
     */
    public static SetAnim(aniState:AniState, value:any, animationController:animation.AnimationController){
      if(!animationController){
          return;
      }
      if (!animationController.node.active) {
          return;
      }
      for (let key in AniState) {
          if(key == AniState[aniState] || key == AniState[AniState.IsGhost]){ 
              continue; 
          }
          animationController.setValue(key, false);
      }

      animationController.setValue(AniState[aniState], value);
  }

  /**
   * Replace material
   * @param mat 
   * @param meshRenderer 
   * @param index 
   */
  public static ReplaceMaterial(mat:Material, meshRenderer:SkinnedMeshRenderer, index:number):Material{
    // Copy material
    let material = new Material();
    material.initialize({
      effectAsset: mat.effectAsset,
      effectName: mat.effectName,
      technique: mat.technique
    })
    material.copy(mat);
    meshRenderer.setMaterial(material, index);
    return material;
  }

  /**
   * Create creature
   * @param characterDefine 
   * @param teamType2 
   */
  public static CreateCreature(characterDefine: CharacterDefine, teamType2: TeamType2, creatureType:CreatureType, node?: Node, parentNode?: Node, user?: any, idx: number = undefined
    , birthPosition: Vec3 = null, birthRotation: Vec3 = null): Creature {
    let isFromPool = false;
    if(!node){
        let resource = (teamType2==TeamType2.Red ? characterDefine.RedResource : characterDefine.Resource) || characterDefine.Resource;
        // Minions: reuse node from pool when available
        if (creatureType === CreatureType.Monster) {
          node = PoolManager.instance.getNode2(resource) as Node;
          if (node) {
            isFromPool = true;
            node.setPosition(0, 0, 0);
            node.setRotationFromEuler(0, 0, 0);
            node.setScale(1, 1, 1);
            // Keep node active to avoid re-running activateNode/AnimationGraphEval on reuse
          }
        }
        if (!node) {
          let prefab = LoadResUtil.loadPrefab(resource);
          node = instantiate(prefab) as Node;
          if (creatureType === CreatureType.Monster) {
            PoolManager.instance.preloadPool(prefab, 0, resource);
            node['name2'] = resource;
          }
        }
    }
    if(parentNode){
       // Minions (new only): add inactive then activate next frame to avoid blocking; pooled nodes skip to avoid activateNode cascade
       if (creatureType === CreatureType.Monster && !isFromPool) {
         node.active = false;
       }
       parentNode.addChild(node);
       if (creatureType === CreatureType.Monster && !isFromPool) {
         setTimeout(() => {
           if (node && node.isValid) node.active = true;
         }, 0);
       }
    }

    // Show shadow (defer for minions to avoid blocking spawn)
    if(characterDefine.ShadowName) {
      const doShadow = (n: Node, def: CharacterDefine) => {
        if (!n || !n.isValid || !n.parent) return;
        let shadowScale = def.ShadowScale ? def.ShadowScale : 1;
        let shadowNode: Node = null;
        let childrenList = n.parent.children;
        for (let i = 0; i < childrenList.length; i++) {
          if (childrenList[i].name === def.ShadowName) {
            shadowNode = childrenList[i];
            break;
          }
        }
        if (!shadowNode) {
          let prefab = BattleGlobal.shadowsMap.get(def.ShadowName);
          shadowNode = instantiate(prefab) as Node;
          let scale = def.Radius * 2 * shadowScale;
          shadowNode.setScale(scale, scale, scale);
          if (def.ShadowOffset && def.ShadowOffset.length > 1) {
            let offsetX = def.ShadowOffset[0];
            let offsetZ = def.ShadowOffset[1];
            shadowNode.setPosition(shadowNode.position.x + offsetX, shadowNode.position.y, shadowNode.position.z + offsetZ);
          }
        }
        shadowNode.active = true;
        n.parent.addChild(shadowNode);
      };
      if (creatureType === CreatureType.Monster) {
        setTimeout(() => doShadow(node, characterDefine), 0);
      } else {
        doShadow(node, characterDefine);
      }
    }

    let creature: Creature = new Creature(teamType2, node, characterDefine, user, creatureType, birthPosition, birthRotation);
    if(creatureType == CreatureType.Character){
      CharacterManager.Instance.AddCharacter(creature);
    }
    CreatureManager.Instance.AddCreature(creature.node, creature, idx);
    return creature;
  }

  /**
   * Pre-warm minion prefabs so shaders/materials compile at load instead of on first spawn.
   * Call after Spawn components have registered (e.g. setTimeout 300ms after battle start).
   * @param parentNode Parent to attach minion nodes to briefly (e.g. spawnMonsterNode)
   * @param onComplete Optional callback when pre-warm is done
   */
  public static preWarmMinionPrefabs(parentNode: Node, onComplete?: () => void): void {
    if (!parentNode) {
      onComplete?.();
      return;
    }
    const spawns = SpawnMonManager.Instance.spawns;
    if (!spawns || spawns.length === 0) {
      onComplete?.();
      return;
    }
    const resourceSet = new Set<string>();
    for (let i = 0; i < spawns.length; i++) {
      const def = spawns[i].characterDefine;
      if (!def) continue;
      const res = def.Resource;
      if (res) resourceSet.add(res);
      const redRes = def.RedResource;
      if (redRes && redRes !== res) resourceSet.add(redRes);
    }
    const warmedNodes: Node[] = [];
    const resources = Array.from(resourceSet);
    for (let j = 0; j < resources.length; j++) {
      try {
        const prefab = LoadResUtil.loadPrefab(resources[j]);
        if (!prefab) continue;
        const node = instantiate(prefab) as Node;
        parentNode.addChild(node);
        node.setPosition(0, -1000, 0);
        node.active = true;
        warmedNodes.push(node);
      } catch (e) {
        // Skip invalid or missing prefabs
      }
    }
    setTimeout(() => {
      for (let k = 0; k < warmedNodes.length; k++) {
        const n = warmedNodes[k];
        if (n && n.isValid) n.destroy();
      }
      onComplete?.();
    }, 0.15);
  }

  /**
   * Get creature color
   * @param creature 
   * @returns 
   */
  public static getCreatureColor(creature: Creature) : Color{
    if (creature.teamType2 == BattleManager.Instance.currentCharacter.teamType2) {  // Friendly team
      if(creature.user && creature.user.id == User.Instance.user.id) {  // Self
        return BattleGlobal.myColor2;
      }else{
        return BattleGlobal.friendColor2;
      }
    }else{  // Enemy team
      return BattleGlobal.enemyColor2;
    }
  }
  
  /**
   * Validate if skill is interrupted (including manual cancel release and skill interruption due to stun, freeze, etc.)
   * @param creature 
   */
  public static validateIsSkillInterrupt(creature: Creature, skill?: Skill):boolean{
    if(creature){
      if(!skill){
        skill = creature.SkillMgr.getSkillByAniState(creature.aniState);
      }
      if(skill && skill.isStopCasting){
        return true;
      }
    }
    return false;
  }

  /**
   * Modify angle on x, y components
   * @param x 
   * @param y 
   * @param angle 
   * @returns 
   */
  public static changeXYAngle(x:number, y:number, angle:number){
    let tha = Math.PI / (180 / angle);
    var value = Math.sqrt(x*x + y*y);
 
		var cos1 = x / value;
		var sin1 = y / value;
 
		var cos2 = Math.cos(tha);
		var sin2 = Math.sin(tha);
 
		var cos3 = cos1*cos2 - sin1*sin2;
		var sin3 = sin1*cos2 + cos1*sin2;
    return new Vec2(Number((value * cos3).toFixed(2)), Number((value * sin3).toFixed(2)));
  }

  /**
   * Get sound effect playback coefficient based on distance
   * @param soundPos Current position
   * @param earPos  Target position
   * @param maxDist Maximum sound distance range  
   * @returns 
   */
  public static getVolumeByDist(soundPos: { x: number, y: number, z: number }, earPos: { x: number, y: number, z: number }, maxDist: number = 2) {
    let dx = Math.abs(soundPos.x - earPos.x);
    let dz = Math.abs(soundPos.z - earPos.z);
    let dist = Math.sqrt(dx * dx + dz * dz);
    if(dist < 1.0){
        return 1.0;
    }
    let factor = 1.0 / (dist / maxDist);
    if (factor > 1.0) {
        factor = 1.0;
    }
    if(factor < 0.1){
      factor = 0;
    }
    return factor
  }

  /**
   * Play battle common sound effect
   */
  public static async PlayBattleCommonSound(frameId:number){
    if(frameId == this.The_enemy_has_five_seconds_sound_frame){
      BattleSoundTipsManager.Instance.PlaySound(SoundDefine.The_enemy_has_five_seconds);
    }else if(frameId == this.The_whole_army_launched_an_attack_sound_frame){
      BattleSoundTipsManager.Instance.PlaySound(SoundDefine.The_whole_army_launched_an_attack);
    }
  }

}