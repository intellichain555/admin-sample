import { Node, ParticleSystem, ParticleSystem2D } from 'cc';

/**
 * Centralized particle optimization for battle prefabs.
 * When particleOptimize is true, reduces particle count and emission rate on all
 * ParticleSystem / ParticleSystem2D under the given node (recursively), and
 * disables expensive modules (trail, collision, texture animation, noise, GPU renderer).
 * Set particleOptimize once (e.g. from GameConfig or settings) to enable/disable.
 */
export class ParticleOptimizer {
    /** When true, apply reduced particle settings to battle prefabs. Set from config or settings. */
    public static particleOptimize: boolean = false;

    /** Multiplier for particle count and emission when optimized (0.5 = 50%). */
    public static readonly optimizeFactor: number = 0.1;

    /**
     * Disable expensive modules on a 3D ParticleSystem (trail, collision, texture animation, noise, GPU).
     */
    private static disableExpensiveModules(ps: ParticleSystem): void {
        try {
            const a = ps as any;
            // Trail module – expensive (extra geometry)
            if (a.trailModule && typeof a.trailModule.enabled === 'boolean') {
                a.trailModule.enabled = false;
            }
            // Collision module – expensive (physics)
            if (a.collisionModule && typeof a.collisionModule.enabled === 'boolean') {
                a.collisionModule.enabled = false;
            }
            // Texture sheet animation – extra sampling
            if (a.textureAnimationModule && typeof a.textureAnimationModule.enabled === 'boolean') {
                a.textureAnimationModule.enabled = false;
            }
            // Noise module – extra per-particle math
            if (a.noiseModule && typeof a.noiseModule.enabled === 'boolean') {
                a.noiseModule.enabled = false;
            }
            // GPU particles can be slower on some low-end devices; use CPU
            const renderer = a.renderer;
            if (renderer && typeof renderer.useGPU === 'boolean') {
                renderer.useGPU = false;
            }
            if (renderer && (renderer._useGPU !== undefined)) {
                renderer._useGPU = false;
            }
        } catch (_) {
            // Skip if API differs
        }
    }

    /**
     * Apply particle optimization to a node and all its descendants.
     * No-op if particleOptimize is false.
     */
    public static apply(root: Node | null): void {
        if (!root || !this.particleOptimize) return;
        const queue: Node[] = [root];
        while (queue.length > 0) {
            const n = queue.shift()!;
            try {
                const ps2d = n.getComponent(ParticleSystem2D);
                if (ps2d) {
                    const total = (ps2d as any).totalParticles ?? (ps2d as any)._totalParticles;
                    if (typeof total === 'number' && total > 0) {
                        (ps2d as any).totalParticles = Math.max(2, Math.floor(total * this.optimizeFactor));
                        if ((ps2d as any)._totalParticles !== undefined) {
                            (ps2d as any)._totalParticles = Math.max(2, Math.floor(total * this.optimizeFactor));
                        }
                    }
                    const rate = (ps2d as any).emissionRate;
                    if (typeof rate === 'number' && rate > 0) {
                        (ps2d as any).emissionRate = Math.max(0.5, rate * this.optimizeFactor);
                    }
                }
                const ps = n.getComponent(ParticleSystem);
                if (ps) {
                    const cap = (ps as any).capacity;
                    if (typeof cap === 'number' && cap > 0) {
                        (ps as any).capacity = Math.max(2, Math.floor(cap * this.optimizeFactor));
                    }
                    const emission = (ps as any).emissionModule;
                    if (emission && emission.rateOverTime !== undefined) {
                        const rt = emission.rateOverTime;
                        if (rt && typeof rt.constant === 'number') {
                            rt.constant = Math.max(0.5, rt.constant * this.optimizeFactor);
                        }
                    }
                    this.disableExpensiveModules(ps);
                }
            } catch (_) {
                // Skip if API differs
            }
            for (let i = 0; i < n.children.length; i++) {
                queue.push(n.children[i]);
            }
        }
    }
}
