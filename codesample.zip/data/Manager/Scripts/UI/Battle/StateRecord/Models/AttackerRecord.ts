import Decimal from "decimal.js";
import { Attacker } from "../../Models/Attacker";
import { IStateRecord } from "../IStateRecord";

export class AttackerRecord implements IStateRecord{
    
    public zhuGongCreatureId:number;  // Attacker ID
    public damage:Decimal;  // Damage
    public isZhuGongFlag:boolean; // Whether assist
    public time:Date;  // Time (wall-clock)
    public timeFrame:number;  // ✅ Frame when attacker was added

    /**
     * Record state
     */
     record(data:Attacker):void{
        if(data.zhuGongCreature){
            this.zhuGongCreatureId = data.zhuGongCreature.entityId;
        }
        this.damage = data.damage;
        this.isZhuGongFlag = data.isZhuGongFlag;
        this.time = data.time;
        this.timeFrame = data.timeFrame;  // ✅ Save frame time
    }

}