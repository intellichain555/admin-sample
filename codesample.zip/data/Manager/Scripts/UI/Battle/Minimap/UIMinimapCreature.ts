
import { _decorator, Component, Node, Rect, Sprite, Vec3, Color, Label, EventTouch, UITransform } from 'cc';
import { DataManager } from '../../../Managers/DataManager';
import { User } from '../../../Models/User';
import { TeamType2 } from '../enums/TeamType2';
import { BattleManager } from '../Managers/BattleManager';
import { MinimapBoxVo } from '../../../Vo/MinimapBoxVo';
import { Creature } from '../Enities/Creature';
import { BattleGlobal } from '../Utils/BattleGlobal';
import { CreatureType } from '../enums/CreatureType';
import proto from '../../../../Proto/proto.js';
import { BattleService } from '../../../Services/BattleService';
import { Constant } from '../../../../../Scripts/Utils/Constant';
import { LoadResUtil } from '../../../../../Scripts/Utils/LoadResUtil';
const { ccclass, property } = _decorator;

@ccclass('UIMinimapCreature')
export class UIMinimapCreature extends Component {

    @property(Sprite)
    private avatarImgSprite: Sprite = null;// Friendly use
    @property(Sprite)
    private avatarImgSprite2: Sprite = null;// Enemy use
    @property(Sprite)
    private avatarBgSprite: Sprite = null;
    @property(Label)
    private time: Label = null;


    public creature: Creature = null;
    public minimapBoxVo: MinimapBoxVo = null;

    public lastX: number = -1; // Last X
    public lastZ: number = -1; // Last Z

    onLoad() {
        this.hide();
    }

    /**
     * Set information
     * @param creature 
     * @param minimapBoxVo 
     */
    public async SetItemInfo(creature: Creature, minimapBoxVo: MinimapBoxVo) {
        this.creature = creature;
        this.minimapBoxVo = minimapBoxVo;
        if (this.creature.creatureType == CreatureType.Character) {   // Character
            // Change background color
            if (creature.user.id == User.Instance.user.id) {  // Self
                this.avatarBgSprite.color = new Color().fromHEX(BattleGlobal.myColor);
                // Set my layer cannot be occluded
                let uiTransform = this.node.getComponent(UITransform);  
                uiTransform.priority = 999;
            } else if (creature.teamType2 == BattleManager.Instance.currentCharacter.teamType2) {  // Friendly team
                this.avatarBgSprite.color = new Color().fromHEX(BattleGlobal.friendColor);
            } else {  // Enemy team
                this.avatarBgSprite.color = new Color().fromHEX(BattleGlobal.enemyColor);
            }
            // Load avatar
            this.avatarImgSprite.spriteFrame = LoadResUtil.getPictures(DataManager.Instance.characters[creature.user.character.cid].Avatar);
        } else { // Monster
            let characterClass = creature.characterDefine.Class;
            if (characterClass == Constant.CharacterClass.Soldier ||
                characterClass == Constant.CharacterClass.ShuiJin ||
                characterClass == Constant.CharacterClass.Fyt ||
                characterClass == Constant.CharacterClass.CallMonster) { // Escort cart, minions, crystal, defense tower, summoned monsters
                if (creature.teamType2 == BattleManager.Instance.currentCharacter.teamType2) {  // Friendly team
                    if (this.avatarBgSprite) {
                        this.avatarBgSprite.color = new Color().fromHEX(BattleGlobal.friendColor);
                    } 

                } else {  // Enemy team
                    if (this.avatarBgSprite) {
                        this.avatarBgSprite.color = new Color().fromHEX(BattleGlobal.enemyColor);
                    } else {
                        this.avatarImgSprite2.spriteFrame = this.avatarImgSprite.spriteFrame;
                    }
                }
            }
        }
    }

    update() {
        if (this.creature && this.minimapBoxVo) {
            if (this.creature.IsDeath) {  // Death
                this.hide();
            } else {
                const currentCharacter = BattleManager.Instance?.currentCharacter;
                const isEnemyOrNeutral = currentCharacter && this.creature.teamType2 !== currentCharacter.teamType2;
                if (isEnemyOrNeutral && !this.creature.isVisibleToLocalPlayer) {
                    this.hide();
                } else {
                    this.show();
                }
            }
            let currentX = this.creature.renderPosition.x;
            let currentZ = this.creature.renderPosition.z;
            let zAngle = this.creature.creatureType == CreatureType.Character ? (this.creature.logicRotation.y + 90) : undefined;
            this.updatePos(currentX, currentZ, zAngle);  // Update position
        }
    }

    /**
     * Update monster appearance time
     * @param time 
     */
    public updateTime(time: number, minimapBoxVo: MinimapBoxVo) {
        this.minimapBoxVo = minimapBoxVo;
        let color = this.avatarImgSprite.color;
        if (time == 0) {
            this.time.enabled = false;
            this.avatarImgSprite.color = new Color(color.r, color.g, color.b, 255);
        } else {
            this.time.enabled = true;
            this.time.string = time + '';
            this.avatarImgSprite.color = new Color(color.r, color.g, color.b, 140);
        }
    }

    /**
     * Update position
     */
    public updatePos(currentX: number, currentZ: number, zAngle?: number) {
        // Position unchanged, no need to update
        if (currentX == this.lastX && currentZ == this.lastZ) {
            return;
        }

        // Get character x, y position in bounding box
        let relaX = -(currentX - this.minimapBoxVo.x) + this.minimapBoxVo.width / 2;
        let relaY = -(currentZ - this.minimapBoxVo.z) + this.minimapBoxVo.height / 2;

        // Get character x, y ratio in bounding box
        let pivoX = relaX / this.minimapBoxVo.width;
        let pivoY = relaY / this.minimapBoxVo.height;

        this.node.setPosition(this.minimapBoxVo.minimapWidth * pivoY - this.minimapBoxVo.minimapWidth / 2,
            this.minimapBoxVo.minimapHeight * pivoX - this.minimapBoxVo.minimapHeight / 2, this.node.position.z)
        if (zAngle) {
            if (this.avatarBgSprite) {
                this.avatarBgSprite.node.setRotationFromEuler(0, 0, zAngle);
            }
        }
        this.lastX = currentX;
        this.lastZ = currentZ;
    }

    /**
     * Show
     */
    public show() {
        for (let node of this.node.children) {
            node.active = true;
        }
    }

    /**
     * Hide
     */
    public hide() {
        for (let node of this.node.children) {
            node.active = false;
        }
    }

    /**
    * Creature click
    * @param param 
    */
    public OnCreatureClick(param: EventTouch) {
        let targetNode = param.target as Node;
        let targetUIMinimapCreature = targetNode.getComponent(UIMinimapCreature);
        if (targetUIMinimapCreature.creature) {
            BattleService.Instance.SendCreatureClick(targetUIMinimapCreature.creature.entityId);
        }
    }

}
