import { EventManager } from '../../Common/Event/EventManager';
import { OptType } from './../enums/OptType';
import { BattleService } from '../../../Services/BattleService';
import { NetConfig } from '../../../Network/NetConfig';
import { EventType } from '../../Common/Event/EventType';
import { LogUtil } from '../../../Log/LogUtil';
import { User } from '../../../Models/User';
import { DataManager } from '../../../Managers/DataManager';
import { CreatureManager } from './../Managers/CreatureManager';
import { TeamType2 } from './../enums/TeamType2';
import { MathUtil } from '../../../Utils/MathUtil';
import { _decorator, instantiate, Node, Component, Vec3, AnimationComponent, Prefab, UITransform, game, director, CameraComponent, Material, Texture2D, sys } from 'cc';
const { ccclass, property } = _decorator;
import { GameStatus } from '../enums/GameStatus';
import { CharacterManager } from './CharacterManager';
import { LogicRenderConvert } from '../Utils/LogicRenderConvert';
import { LocalStorageUtil } from '../../../Utils/LocalStorageUtil';
import { UIMinimapManager } from '../Minimap/UIMinimapManager';
import { Creature } from '../Enities/Creature';
import { BattleContext } from '../Models/BattleContext';
import { CollisionCheckManager } from './CollisionCheckManager';
import { BattleGlobal } from '../Utils/BattleGlobal';
import { SkillTipsType } from '../enums/SkillTipsType';
import { SkillTipsSize } from '../Vo/SkillTipsSize';
import { TargetType } from '../enums/TargetType';
import { AniState } from '../enums/AniState';
import { BattleMode } from '../enums/BattleMode';
import { HandlerFrameResult } from '../enums/HandlerFrameResult';
import { CreatureType } from '../enums/CreatureType';
import { UIBattle } from '../UIBattle';
import { UIGameLoadIn } from '../UI/UIGameLoadIn';
import { UIDieInBattle } from '../UI/UIDieInBattle';
import { UIGameProgressRecovery } from '../UI/UIGameProgressRecovery';
import { UserInfoVo } from '../../../Vo/UserInfoVo';
import { TeamInfoVo } from '../../../Vo/TeamInfoVo';
import { EncryptUtil } from '../../../Utils/EncryptUtil';
import { RoomService } from '../../../Services/RoomService';
import { NetClientBattle } from '../../../Network/Battle/NetClientBattle';
import { CharacterStateBackupsVo } from '../Vo/CharacterStateBackupsVo';
import { Util } from '../../../Utils/Util';
import { NetClient } from '../../../Network/NetClient';
import { BattleData } from '../Utils/BattleData';
import { UIPlayerIcons } from '../UI/UIPlayerIcons';
import { UserInfoVo2 } from '../../../Vo/UserInfoVo2';
import { UIGameOver } from '../UIGameOver';
import { LookRecordType } from '../enums/LookRecordType';
import { UIWorldElementManager } from '../UIWorldElementManager';
import { FXManager } from '../Effects/FXManager';
import { PoolManager } from '../../../Managers/PoolManager';
import { SpawnMonManager } from '../SpawnMon/SpawnMonManager';
import { DataUtil } from '../../../Utils/DataUtil';
import { BattleSoundTipsManager } from './BattleSoundTipsManager';
import { DeferredWorkManager } from './DeferredWorkManager';
import { StateHandleManager } from '../StateRecord/StateHandleManager';
import { CallMonster } from '../SpawnMon/CallMonster';
import { SoundDefine } from '../../../../../Scripts/Sound/SoundDefine';
import { SoundManager } from '../../../../../Scripts/Sound/SoundManager';
import AdManager from '../../../../../Scripts/Platform/Sdk/AdManager';
import { CustomAdType } from '../../../../../Scripts/Platform/Sdk/WeChatAd';
import { Constant } from '../../../../../Scripts/Utils/Constant';
import { FogOfViewManager } from './FogOfViewManager';

@ccclass('BattleManager')
export class BattleManager extends Component {

  public static Instance: BattleManager = null;

  private timer = null;
  private recProTimer = null;
  private handleFrameTimer = null;
  private handleFrameTimeoutId: ReturnType<typeof setTimeout> = null;  // Used when USE_NEXT_TICK_LOGIC is true
  private fastestTimer = null;
  private static readonly DEFERRED_WORK_BUDGET_MS = 15;  // Skip processDeferredWork if logic exceeded this
  private logicPhaseStartMs: number = 0;
  public gameStatus = GameStatus.None;  // Game status

  // Friendly and enemy positions, friendly => blue team, enemy => red team
  @property([Node])
  public MyTeam = [];
  @property([Node])
  public EnemyTeam = [];
  @property(Node)
  public camera: Node = null;
  @property(Node)
  public spawnMonsterNode: Node = null;   // Monster node
  @property(Node)
  public npcMoveWayNode: Node = null;   // NPC path node
  @property([Prefab])
  public skillTipsPrefabs = [];   // Skill tips prefab
  @property(Texture2D)
  public shihuaTexture2D: Texture2D = null;   // Petrification texture
  @property(Node)
  public MyBattleItemNode: Node = null;  // My battle item storage node
  @property(Node)
  public AllBattleEffectsNode: Node = null;  // All battle effects storage node
  @property(UIBattle)
  public uiBattle: UIBattle = null;

  @property(UIGameLoadIn)
  public uiGameLoadIn: UIGameLoadIn = null;

  @property([Prefab])
  public shadowPrefabs: Array<Prefab> = [];   // Shadow prefab

  @property(UIGameProgressRecovery)
  public uiGameProgressRecovery: UIGameProgressRecovery = null;


  @property(UIDieInBattle)
  public uiDieInBattle: UIDieInBattle = null;
  @property(UIPlayerIcons)
  public uiPlayerIcons: UIPlayerIcons = null;

  @property(Node)
  public RectObstaclesNode: Node = null;  // Rectangle obstacle node

  @property(Node)
  public BlueBirthPlaceEffectsNode: Node = null;  // Blue team birthplace effects node
  @property(Node)
  public RedBirthPlaceEffectsNode: Node = null;  // Red team birthplace effects node
  @property(Node)
  public LogicRangeTargetTestNode: Node;  // Logic range target test
  @property([Node])
  public BlueHeroMoveWayNodeArr: Array<Node> = [];  // Blue team hero pathfinding collection - bottom lane
  @property([Node])
  public RedHeroMoveWayNodeArr: Array<Node> = [];  // Red team hero pathfinding collection - bottom lane
  @property(CallMonster)
  public callMonster:CallMonster;

  public BlueHeroMoveWayNodeArrUp: Array<Node> = null;  // Blue team hero pathfinding collection - top lane
  public RedHeroMoveWayNodeArrUp: Array<Node> = null;  // Red team hero pathfinding collection - top lane

  public currentCharacter: Creature = null;  // Current character
  public deathShuiJin: Creature = null;  // Destroyed crystal
  public camCharDis: number = 0;  // Camera to protagonist distance

  // public isRecProFlag:boolean = true; // Whether in progress recovery
  private recordUserTimer = null;

  public isLookAtCharacterFlag: boolean = true; // Whether to follow protagonist
  private onSpawnInit: boolean = true;// Whether need to spawn monsters

  public isAddListener: boolean = false; // Whether to start listening to events
  private startBattleTimer = null;
  public percent_: number = 0;   // Loading progress percentage
  public cameraDisOffset: Vec3 = new Vec3();  // Camera distance offset
  private cameraAngleOffset: Vec3 = new Vec3();  // Camera angle offset
  public cameraComponent: CameraComponent = null;
  private fastestWaitTime:number = BattleGlobal.fastestWaitTime;


  Clear() {
    game.frameRate = 30;  // Reduced from 60/30 for better Android performance (25 fps = 40ms budget)
    FogOfViewManager.Instance?.setAllCreaturesVisible();
    DeferredWorkManager.Instance.clear();
    CharacterManager.Instance.Clear();
    CreatureManager.Instance.Clear();
    CollisionCheckManager.Instance.Clear();
    BattleGlobal.clear(); // Clear battle data
    SpawnMonManager.Instance.Clear();
    PoolManager.instance.clearAll();
    BattleSoundTipsManager.Instance.Clear();  // Battle sound tips manager cleanup
    console.log('BattleManager Clear')
  }

  onLoad(){
    BattleManager.Instance = this;
    this.Clear();
    console.log('Gameplay type======================'+BattleGlobal.playingMethod)
  }

  async start() {
    this.isAddListener = false;
    SoundManager.Instance.PlayMusic(SoundDefine.Music_Battle);
    this.cameraComponent = this.camera.getComponent(CameraComponent);

    this.percent_ = 5;
    BattleGlobal.init();  // Battle data initialization
    if (!this.getComponent(FogOfViewManager)) {
      this.addComponent(FogOfViewManager);
    }
    // Pre-warm effects so shaders/materials compile at load instead of during combat (reduces frame hitches)
    if (FXManager.Instance && this.AllBattleEffectsNode) {
      FXManager.Instance.preWarmEffects(this.AllBattleEffectsNode);
    }
    // Pre-warm minion prefabs after spawns are registered (reduces first-spawn hitches)
    setTimeout(() => {
      if (this.spawnMonsterNode) {
        BattleGlobal.preWarmMinionPrefabs(this.spawnMonsterNode);
      }
    }, 400);
    // Check if we need to recover frame data (skip clearing frames if recovering)
    let hasStateRecordStr = LocalStorageUtil.GetItem(LocalStorageUtil.stateRecordKey + User.Instance.user.id);
    BattleData.init(!!hasStateRecordStr);  // Skip clearing frames if we have saved state
    // Initialize hero pathfinding top lane position
    this.BlueHeroMoveWayNodeArrUp = [];
    for (let n of this.BlueHeroMoveWayNodeArr) {
      let node = instantiate(n);
      node.setPosition(-node.position.x, node.position.y, node.position.z);
      n.parent.addChild(node);
      this.BlueHeroMoveWayNodeArrUp.push(node);
    }
    this.RedHeroMoveWayNodeArrUp = [];
    for (let n of this.RedHeroMoveWayNodeArr) {
      let node = instantiate(n);
      node.setPosition(-node.position.x, node.position.y, node.position.z);
      n.parent.addChild(node);
      this.RedHeroMoveWayNodeArrUp.push(node);
    }
    this.percent_ = 10;
    // Get camera initial position
    this.camera.getPosition(this.cameraDisOffset);
    this.camera.rotation.getEulerAngles(this.cameraAngleOffset);

    // Initialize shadow
    for (let i = 0; i < this.shadowPrefabs.length; i++) {
      let prefab = this.shadowPrefabs[i];
      BattleGlobal.shadowsMap.put(prefab.name, prefab);
    }

    // console.log('BattleManager start creatureMap len：'+CreatureManager.Instance.creatureMap.values().length)
    console.log('Create character start')
    CharacterManager.Instance.noRobotCount = 0;
    // Create character
    CharacterManager.Instance.CreateCharacter(TeamType2.Blue);  // Blue team
    this.percent_ = 40;
    CharacterManager.Instance.CreateCharacter(TeamType2.Red);  // Red team

    if (this.currentCharacter && this.currentCharacter.teamType2 == TeamType2.Red) {
      this.cameraDisOffset.z *= -1;
      this.cameraAngleOffset.y += 90;
    }

   // 3v3 and 5v5 use the same logic
   if(BattleGlobal.playingMethod == Constant.PlayingMethod.ThreeVsThree || 
      BattleGlobal.playingMethod == Constant.PlayingMethod.FiveVsFive){   //3v3 or 5v5
     if (CharacterManager.Instance.noRobotCount <= 1) {
       BattleGlobal.isStandaloneFlag = true;
       console.warn(User.Instance.room.roomId + ', Standalone mode====================================================================')
     } else {
       console.warn(User.Instance.room.roomId + ', Online mode====================================================================')
     }
   }else if(BattleGlobal.playingMethod == Constant.PlayingMethod.OnlineBattle){     // Battle royale, test set to standalone first
     BattleGlobal.isStandaloneFlag = true;
   } 

    this.percent_ = 70;
    console.log('uiPlayerIcons start================')
    await this.uiPlayerIcons.init();
    this.percent_ = 80;
    console.log('Minimap initialization start')
    // Minimap initialization
    UIMinimapManager.Instance.Init();
    // this.percent_ = 85;
    // // Create birthplace effects
    // let birthPlaceEffectsName = BattleGlobal.birthPlaceEffectsName;
    this.BlueBirthPlaceEffectsNode.active = false;
    this.RedBirthPlaceEffectsNode.active = false;
    // let BlueEffectNode = FXManager.Instance.PlayEffect2(birthPlaceEffectsName, this.BlueBirthPlaceEffectsNode.worldPosition, this.BlueBirthPlaceEffectsNode);
    // let RedEffectNode = FXManager.Instance.PlayEffect2(birthPlaceEffectsName, this.RedBirthPlaceEffectsNode.worldPosition, this.RedBirthPlaceEffectsNode);
    // console.log('Create birthplace effects complete BlueEffectNode=' + BlueEffectNode + ',RedEffectNode=' + RedEffectNode)

    this.percent_ = 90;

    console.log('Initialize skill tips model start')
    // Initialize skill tips model
    for (let i = 0; i < this.skillTipsPrefabs.length; i++) {
      let node = instantiate(this.skillTipsPrefabs[i]) as Node;
      BattleGlobal.skillTipsMap.put(node.name, node);
    }

    this.gameStatus = GameStatus.GameIn;

    EventManager.Instance.dispatch(EventType.OnBattleGameIn);

    // Read cached state and frame data
    let stateRecordStr = LocalStorageUtil.GetItem(LocalStorageUtil.stateRecordKey + User.Instance.user.id);
    if (stateRecordStr) {  // Cached state exists, rollback all states
      this.onSpawnInit = false;
      // Restore frame data BEFORE rolling back state
      BattleData.recoverFrameData();  
      StateHandleManager.Instance.rollbackAllState(stateRecordStr);
      console.log('Recovered state and frame data from LocalStorage');
    } else {
      this.onSpawnInit = true;
      // EventManager.Instance.dispatch(EventType.OnSpawnInit);
    }

    this.percent_ = 95;

    let this_ = this;

    // Handle logic frame timer
    let handleFrameWaitTime: number = NetConfig.frameTime;
    if (Constant.USE_NEXT_TICK_LOGIC) {
      this.scheduleNextLogicTick(handleFrameWaitTime, handleFrameWaitTime);
    } else {
      this.handleFrameTimer = setInterval(async function () {
        await this_.runLogicTick(handleFrameWaitTime);
      }, handleFrameWaitTime);
    }
    // Fastest timer
    // let isIos = (sys.os == 'iOS');
    // console.log("Is iOS=" + isIos)
    // let fastestWaitTime:number = BattleGlobal.fastestWaitTime;
    // this.fastestTimer = setInterval(async function () {
    //   await this_.ChasingFrame(fastestWaitTime);
    // }, fastestWaitTime);

    if (BattleGlobal.battleMode == BattleMode.Battle) {    // Battle mode
      if (BattleGlobal.isExistBattleFlag) {  // Battle exists, chase frames
        // this.uiGameLoadIn.hide();
      } else {  // Start synchronization from first frame
        // Periodically send battle ready request
        if (!BattleGlobal.isStandaloneFlag) {  // Not standalone
          BattleService.Instance.SendStartBattle();
          this.startBattleTimer = setInterval(function () {
            if (BattleData.handleFrameId >= 0) {
              this_.OnStartBattle();
              return;
            }
            BattleService.Instance.SendStartBattle();

          }, 2000)
        }
      }
      setTimeout(function () {
        // Create birthplace effects
        if(!this_.BlueBirthPlaceEffectsNode || !this_.RedBirthPlaceEffectsNode){
          return;
        }
        let birthPlaceEffectsName = BattleGlobal.birthPlaceEffectsName;
        let BlueEffectNode = FXManager.Instance.PlayEffect2(birthPlaceEffectsName, this_.BlueBirthPlaceEffectsNode.worldPosition, this_.BlueBirthPlaceEffectsNode);
        let RedEffectNode = FXManager.Instance.PlayEffect2(birthPlaceEffectsName, this_.RedBirthPlaceEffectsNode.worldPosition, this_.RedBirthPlaceEffectsNode);
        console.log('Create birthplace effects complete FXManager BlueEffectNode=' + BlueEffectNode + ',RedEffectNode=' + RedEffectNode)
        if (this_.onSpawnInit) {
          EventManager.Instance.dispatch(EventType.OnSpawnInit);
        }
        AdManager.Instance.ShowCustomAd(CustomAdType.One);
      }, 2000)

    } else if (BattleGlobal.battleMode == BattleMode.Live) {  // Live mode, chase frames
      // this.uiGameLoadIn.hide();
    }
    this.percent_ = 100;
    this.StartMonitorFrame();
    BattleSoundTipsManager.Instance.Init();  // Battle sound tips manager initialization
  }

  /**
   * Chase frames
   */
  private async ChasingFrame(fastestWaitTime: number) {
    if (BattleGlobal.isGameEndFlag) {  // Game end
      return;
    }
    this.fastestWaitTime = fastestWaitTime;
    // Handle frame operations
    if (BattleGlobal.isChasingFrameFlag) {
      let handlerFrameResult = await this.OnHandlerFrame();
      BattleData.RepairFrameRequest(handlerFrameResult, fastestWaitTime);
    }

    // Pre-rendering
    // BattleData.DoPrediction();
    BattleData.DoPredictionMyRotate();

    // Update world UI
    // let uiWorldElementManager = UIWorldElementManager.Instance;
    // if (uiWorldElementManager) {
    //   uiWorldElementManager.updateRendering();
    // }
  }


  /**
   * Battle ready response
   */
  public OnStartBattle() {
    console.log('OnStartBattle')
    clearInterval(this.startBattleTimer);
    // this.uiGameLoadIn.hide();
  }

  /**
   * Start monitoring frame events
   */
  private StartMonitorFrame() {
    console.log('StartMonitorFrame')
    this.isAddListener = true;
    let this_ = this;
    if (BattleGlobal.battleMode == BattleMode.Battle) {
      this.timer = setInterval(function () {
        BattleData.CapturePlayerOpts();
      }, NetConfig.frameTime)
      EventManager.Instance.addListener(EventType.OnTeamInfoLook_UI, this.OnTeamInfoLook_UI, this);
      EventManager.Instance.addListener(EventType.OnMyDeathUI, this.OnMyDeathUI, this)
    }
    // Record user requests
    this.recordUserTimer = setInterval(function () {
      if (BattleData.handleFrameId >= 0) {
        clearInterval(this_.recordUserTimer)
        return;
      }
      BattleService.Instance.SendRecordUser();
    }, 1000)

  }

  /**
   * Run one logic tick (shared by setInterval and next-tick paths).
   */
  private async runLogicTick(handleFrameWaitTime: number): Promise<void> {
    let gapFrameCount = BattleData.newFrameId - BattleData.executeFrameId;
    if ((BattleGlobal.battleMode == BattleMode.Battle && gapFrameCount <= BattleData.redundantFrameCount)) {
      BattleGlobal.isChasingFrameFlag = false;
      let handlerFrameResult = await this.OnHandlerFrame();
      BattleData.RepairFrameRequest(handlerFrameResult, handleFrameWaitTime);
    } else {
      BattleGlobal.isChasingFrameFlag = true;
    }
    if (gapFrameCount < 50) {
      BattleGlobal.framePlaySpeed = 1;
      BattleGlobal.isNormalPlay = true;
    } else {
      BattleGlobal.framePlaySpeed = NetConfig.frameTime / this.fastestWaitTime;
      BattleGlobal.isNormalPlay = false;
    }
  }

  /**
   * Schedule the next logic tick after a delay (next-tick scheduler).
   */
  private scheduleNextLogicTick(handleFrameWaitTime: number, delayMs: number): void {
    if (BattleGlobal.isGameEndFlag) return;
    this.handleFrameTimeoutId = setTimeout(async () => {
      this.handleFrameTimeoutId = null;
      const start = performance.now();
      await this.runLogicTick(handleFrameWaitTime);
      const elapsed = performance.now() - start;
      const nextDelay = Math.max(0, handleFrameWaitTime - elapsed);
      this.scheduleNextLogicTick(handleFrameWaitTime, nextDelay);
    }, delayMs);
  }

  /**
   * Handle frame operations
   */
  private async OnHandlerFrame(): Promise<HandlerFrameResult> {
    let frameId = BattleData.handleFrameId + 1;
    // if(frameId % 50 == 0){
    //   console.log('OnHandlerFrame frameId='+frameId)
    // }
    let isPrediction: boolean = false;  // Whether predicting
    let isNoServerFrameData: boolean = false;  // Whether no server frame data

    // Get frame operation collection
    let userFrameHandleMap = BattleData.getFrameData(frameId);
    // console.log('OnHandlerFrame userFrameHandleMap=', userFrameHandleMap)
    if (!userFrameHandleMap) {  // No server frame data
      isNoServerFrameData = true;
      // During catch-up, do NOT use prediction - wait for server frames
      if (BattleGlobal.isChasingFrameFlag) {
        console.log('Catch-up mode: waiting for frame ' + frameId + ' from server (no prediction)');
        return HandlerFrameResult.NoFrameData;
      }
      userFrameHandleMap = BattleData.clientPredictionFrameHandles.get(frameId);  // Get from client prediction map
      if (!userFrameHandleMap) {  // No client prediction frame data
        return HandlerFrameResult.NoFrameData;
      }else{
        isPrediction = true;
      }
    }
    if(!isPrediction){
      if (BattleData.executeFrameId >= frameId) {
        console.log('Cannot repeat execution, already executed frame: ' + BattleData.executeFrameId)
        return HandlerFrameResult.NotRepeatFrame;
      }
      BattleData.executeFrameId = frameId;
    }else{
      if (BattleData.predictionExecuteFrameId >= frameId) {
        // console.log('Prediction cannot repeat execution, already executed frame: ' + BattleData.predictionExecuteFrameId)
        return isNoServerFrameData ? HandlerFrameResult.NoFrameData : HandlerFrameResult.NotRepeatFrame;
      }
      BattleData.predictionExecuteFrameId = frameId;
    }
    // console.log(frameId+' frame execution, '+(isPrediction ? 'prediction' : 'non-prediction'))
    // Execute frame operations
    BattleData.DoHandlerFrame(userFrameHandleMap, undefined, isPrediction);

    if(isPrediction){      
      return isNoServerFrameData ? HandlerFrameResult.NoFrameData : HandlerFrameResult.Success;
    }
    this.logicPhaseStartMs = performance.now();
    // Player birthplace healing
    CharacterManager.Instance.birthPlaceWindHp(frameId, TeamType2.Blue);
    CharacterManager.Instance.birthPlaceWindHp(frameId, TeamType2.Red);

    // Synchronize creature logic (characters every frame, towers/crystal every 10 frames, others every 5 frames)
    CreatureManager.Instance.creatureMap.valuesInto(this.creatureListForUpdate);
    for (let i = 0; i < this.creatureListForUpdate.length; i++) {
      let creature = this.creatureListForUpdate[i] as Creature;
      if (creature.creatureType === CreatureType.Character) {
        creature.LogicUpdate(frameId);
      } else if (creature.characterDefine.Class === Constant.CharacterClass.Fyt || creature.characterDefine.Class === Constant.CharacterClass.ShuiJin) {
        // Towers/crystal: run LogicUpdate every 10 frames (reduces SearchTarget cost when many towers)
        if (frameId % 10 === (creature.entityId % 10)) {
          creature.LogicUpdate(frameId);
        } else {
          creature.attributes.LogicUpdate(frameId);
        }
      } else {
        if (frameId % 5 === (creature.entityId % 5)) {
          creature.LogicUpdate(frameId);
        } else {
          creature.attributes.LogicUpdate(frameId);
        }
      }
    }
    // Synchronize spawn monster manager
    SpawnMonManager.Instance.LogicUpdate(frameId);

    const logicDurationMs = performance.now() - this.logicPhaseStartMs;
    if (logicDurationMs < BattleManager.DEFERRED_WORK_BUDGET_MS) {
      DeferredWorkManager.Instance.processDeferredWork();
    }

    // 3v3 and 5v5 use the same caching logic
    if(BattleGlobal.playingMethod == Constant.PlayingMethod.ThreeVsThree || 
       BattleGlobal.playingMethod == Constant.PlayingMethod.FiveVsFive){   //3v3 or 5v5
      // Cache frame data
      // BattleData.cacheFrame(frameId);
      // (Self death/in blood spring interval 15 seconds/same screen only self), cache state data
      let isToEndCacheFrame = (frameId >= BattleGlobal.nextCacheStateFrameId);  // Whether reached cache state frame
      if(isToEndCacheFrame){
        // let isCacheState = (BattleGlobal.isMyDeath || BattleGlobal.isEnemyTemyAllDeath || BattleGlobal.isHpBloodSpring);  // Whether cache state
        let isCacheState = (BattleGlobal.isHpBloodSpring || !NetClient.Instance.connected);  // Whether cache state
        if(!isCacheState){  // Check if same screen only has self
          let count = CharacterManager.Instance.getSameScreenHeroCount(this.currentCharacter);
          isCacheState = count < 2;
        }
        if (isCacheState) {
          BattleGlobal.nextCacheStateFrameId = frameId + MathUtil.secondToFrame(BattleGlobal.cacheStateJgTime); 
          BattleData.cacheStateDate(frameId);
        }
      }
    }

    // Play battle common sound effects
    BattleGlobal.PlayBattleCommonSound(frameId);

    BattleData.handleFrameId = frameId;   // Update synchronized frame
    BattleData.clientPredictionFrameHandles.remove(frameId);  // Remove prediction frame
    return HandlerFrameResult.Success;
  }

  private creatureWorldPosition: Vec3 = new Vec3();
  private creatureListForUpdate: Creature[] = [];  // Reused for LogicUpdate iteration (avoids values() allocation each frame)

  /**
   * Camera follow protagonist
   */
  public CameraLookAtCharacter() {
    // Camera follow self
    if (this.currentCharacter && !this.currentCharacter.IsDeath) {
      BattleGlobal.cameraOffsetAngle = this.cameraAngleOffset.y;
      // Y-axis rotation
      this.camera.setRotationFromEuler(this.cameraAngleOffset.x, this.cameraAngleOffset.y, this.cameraAngleOffset.z);

      this.currentCharacter.node.parent.getWorldPosition(this.creatureWorldPosition);
      this.creatureWorldPosition.set(this.creatureWorldPosition.x + this.cameraDisOffset.x, this.creatureWorldPosition.y + this.cameraDisOffset.y, this.creatureWorldPosition.z + this.cameraDisOffset.z);
      // Camera position     
      this.camera.setWorldPosition(this.creatureWorldPosition);
      this.cameraComponent.camera.update();
      // this.camera.setWorldPosition(this.camera.worldPosition.lerp(this.creatureWorldPosition, 0.2));

      // Distance between camera and protagonist
      this.camCharDis = Vec3.distance(this.currentCharacter.node.worldPosition, this.camera.worldPosition);
    }
  }

  private cameraPosTemp:Vec3 = new Vec3();
  /**
   * Camera follow crystal
   */
  public GameOverCameraLookAtShuiJin() {
    // Camera follow crystal
    if (this.deathShuiJin) {
      BattleGlobal.cameraOffsetAngle = this.cameraAngleOffset.y;
      // Y-axis rotation
      this.camera.setRotationFromEuler(this.cameraAngleOffset.x, this.cameraAngleOffset.y, this.cameraAngleOffset.z);

      this.deathShuiJin.node.parent.getWorldPosition(this.creatureWorldPosition);
      this.creatureWorldPosition.set(this.creatureWorldPosition.x + this.cameraDisOffset.x, this.creatureWorldPosition.y + this.cameraDisOffset.y, this.creatureWorldPosition.z + this.cameraDisOffset.z);
      // Camera position => interpolation      
      this.camera.getWorldPosition(this.cameraPosTemp);
      this.cameraPosTemp.lerp(this.creatureWorldPosition, 0.02)
      this.camera.setWorldPosition(this.cameraPosTemp);

    }
  }

  private myBattleItemTemp:Vec3 = new Vec3();
  update(dt: number) {
    this.ChasingFrame(dt * 1000);  // Chase frames
    // Update battle item storage node
    if (this.currentCharacter) {     
      // this.MyBattleItemNode.setWorldPosition(this.MyBattleItemNode.worldPosition.lerp(this.currentCharacter.renderPosition, 0.1));
      Vec3.lerp(this.myBattleItemTemp, this.MyBattleItemNode.worldPosition, this.currentCharacter.renderPosition, 0.2);
      this.MyBattleItemNode.setWorldPosition(this.myBattleItemTemp);      
    }
    // Creature manager update
    CreatureManager.Instance.update();
  }

  lateUpdate(dt: number) {
    FogOfViewManager.Instance?.updateFog(dt);
    if (BattleGlobal.isGameEndFlag) {  // Game end, camera follow crystal
      this.GameOverCameraLookAtShuiJin();
    } else if (BattleGlobal.battleMode == BattleMode.Battle && this.isLookAtCharacterFlag) {    // Battle mode, camera follow protagonist
      this.CameraLookAtCharacter();
    }

    // Update world UI
    let uiWorldElementManager = UIWorldElementManager.Instance;
    if (uiWorldElementManager) {
      uiWorldElementManager.updateRendering();
    }
  }

  private lookBattleTeamInfoType: number;  // View battle info type 1, record 2, game settlement
  /**
   * View game battle
   * @param type Type 1, record 2, game settlement
   */
  public LookBattleTeamInfo(type: number) {
    this.lookBattleTeamInfoType = type;
    if (this.lookBattleTeamInfoType == 2) {  // Game settlement
      // NetClient.Instance.Connect(); // Connect to lobby server
    }
    BattleService.Instance.SendTeamInfoLook();   // View team info
  }

  /**
   * View team info response
   */
  private OnTeamInfoLook_UI() {
    this.GameOverHandle();
  }

  /**
  * Game end handling
  */
  private async GameOverHandle() {
    if (this.lookBattleTeamInfoType == 1) {  // 1, record
      BattleGlobal.getRecordData(1);
      this.uiBattle.uiGameAchievements.show(LookRecordType.LookRecord, User.Instance.user.id);
    } else {   // 2, game settlement        
      BattleGlobal.getRecordData(2);  // Get record data         
      let teamInfoVo = BattleGlobal.battleRecordData[0];
      let userInfoOtherDataMap = BattleGlobal.battleRecordData[1];

      let data = JSON.stringify(teamInfoVo);
      // RSA encryption
      // data = EncryptUtil.RsaEncrypt(data);
      // AES encryption
      data = EncryptUtil.AesEncrypt(data);

      // Other data
      let otherData = JSON.stringify(userInfoOtherDataMap);
      // RSA encryption
      // otherData = EncryptUtil.RsaEncrypt(otherData);
      // AES encryption
      otherData = EncryptUtil.AesEncrypt(otherData);

      if (BattleGlobal.battleMode == BattleMode.Battle) {
        BattleService.Instance.SendGameOver();
        setTimeout(function () {
          RoomService.Instance.SendGameOver2(data, otherData);
        }, 200)
      }
      LocalStorageUtil.RemoveItem(LocalStorageUtil.allFrameHandlesKey + User.Instance.user.id);  // Clear previous frame operation cache  
      LocalStorageUtil.RemoveItem(LocalStorageUtil.stateRecordKey + User.Instance.user.id);

      NetClientBattle.Instance.closeCurrentSocket();  // Disconnect battle server    
      console.log('Game settlement, disconnect battle server=====')

      setTimeout(function(){
        if(BattleManager.Instance && BattleManager.Instance.uiBattle){
          BattleManager.Instance.uiBattle.uiGameEnd.open();
        }
      }, 3000)
    }
  }

  /**
   * Show 3D camera
   */
  public show3DCamera() {
    this.camera.active = true;
  }

  /**
   * Hide 3D camera
   */
  public hide3DCamera() {
    this.camera.active = false;
  }

  private OnMyDeathUI(){
    this.MyBattleItemNode.removeAllChildren();
  }

  public onDestroy() {
    console.log('BattleManager onDestroy')
    EventManager.Instance.removeAll(this);
    clearInterval(this.timer);
    clearInterval(this.recProTimer);
    clearInterval(this.recordUserTimer);
    clearInterval(this.fastestTimer);
    clearInterval(this.handleFrameTimer);
    if (this.handleFrameTimeoutId != null) {
      clearTimeout(this.handleFrameTimeoutId);
      this.handleFrameTimeoutId = null;
    }
    this.Clear();
    BattleManager.Instance = null;
  }
}