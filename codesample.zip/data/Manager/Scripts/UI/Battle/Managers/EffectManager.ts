import { Creature } from "../Enities/Creature";
import { BuffEffect } from "../enums/BuffEffect";
import { Buff } from "../Models/Buff";
import { tween, Vec3, easing, instantiate, Node } from "cc";
import { Effect } from "../Models/Effect";
import { BuffManager } from "./BuffManager";
import { IStateRollback } from "../StateRecord/IStateRollback";
import { CreatureManager } from "./CreatureManager";
import { EffectManagerRecord } from "../StateRecord/Managers/EffectManagerRecord";
import { DeseTypeConve } from "../Utils/DeseTypeConve";
import { HashMap } from "../../../../../Scripts/Utils/HashMap";


/**
 * Effect manager
 */
export class EffectManager implements IStateRollback{
  public Owner: Creature;

  //key：BuffEffect  value：number
  public Effects = new HashMap();
  public Effects2 = new Array<Effect>();

  public dispSpeed: number = 0;  // Logic frame displacement speed
  public dirDegree: number = 0; // Angle
  // Targets that have already caused damage key=>entintyId  value=>1
  public hitArr: Array<Creature>;
  

  public constructor(owner: Creature) {
    this.Owner = owner;
  }


  public HasEffect(effect: BuffEffect): boolean {
    let val = this.Effects.get(effect);
    if (val) {
      return val > 0;
    }
    return false;
  }



  /**
   * Add effect
   * @param buffEffect 
   * @param buff 
   */
  public AddEffect(buffEffect: BuffEffect, buff?: Buff, dispSpeed?: number, dirDegree?: number, isBuffTrigger = false) {
    // console.log("[{0}].AddEffect{1}", this.Owner.characterDefine.Name, buffEffect);
    let val = this.Effects.get(buffEffect);
    if (!val) {
      this.Effects.put(buffEffect, 1);
      val = 1;
    } else {
      this.Effects.put(buffEffect, ++val);
    }
    this.dispSpeed = dispSpeed;
    this.dirDegree = Math.round(dirDegree);
    let effect = new Effect(this.Owner, buff, buffEffect, val, isBuffTrigger);
    this.Effects2.push(effect);

  }

  /**
   * Remove effect
   * @param effect 
   */
  public RemoveEffect(buffEffect: BuffEffect, buff?: Buff, isBuffTrigger = false) {
    // console.log("[{0}].RemoveEffect{1}", this.Owner.characterDefine.Name, buffEffect);
    let val = this.Effects.get(buffEffect);
    if (typeof val === 'number' && val > 0) {
      this.Effects.put(buffEffect, --val);
    } else {
      val = 0;
    }

    for (let i = 0; i < this.Effects2.length; i++) {
      let effect = this.Effects2[i];
      if (buff) {  // Buff exists, delete by BuffID
        if (effect.buff && buff.BuffID == effect.buff.BuffID) {
          effect.OnRemove(buffEffect, val, isBuffTrigger);
          this.Effects2.splice(i, 1);
          i--;
        }
      } else if (effect.buffEffect == buffEffect) {  // Delete by buffEffect
        effect.OnRemove(buffEffect, val, isBuffTrigger);
        this.Effects2.splice(i, 1);
        i--;
      }
    }
  }

  /**
   * Query effect
   * @param buffEffect 
   * @returns 
   */
  public queryEffect(buffEffect: BuffEffect):Effect{
    for (let i = 0; i < this.Effects2.length; i++) {
      let effect = this.Effects2[i];
      if (effect.buffEffect == buffEffect) {
        return effect;
      }
    }
    return null;
  }

  /**
   * Remove all effects
   */
  public RemoveAllEffect() {
    for (let i = 0; i < this.Effects2.length; i++) {
      let effect = this.Effects2[i];
      effect.OnRemove(effect.buffEffect, 0);
      this.Effects2.splice(i, 1);
      i--;
    }
    // Reset all effect counts so HasEffect() returns false (avoid clear() in case it causes side effects)
    const keys = this.Effects.keys();
    for (let i = 0; i < keys.length; i++) {
      this.Effects.put(keys[i], 0);
    }
  }

  /**
   * Query stealth-breaking guaranteed crit skill effect
   */
  public queryIsBreakingHiddenNormalSkillCrit(): Effect {
    for (let effect of this.Effects2) {
      if (effect.buffEffect == BuffEffect.Stealth && effect.buff && effect.buff.Define.isBreakingHiddenNormalSkillCrit) {  // Stealth-breaking normal attack guaranteed crit exists
        return effect;
      }
    }
    return null;
  }

  /**
   * Logic update
   */
  public LogicUpdate(frameId: number) {
    for (let effect of this.Effects2) {
      effect.LogicUpdate(frameId);
    }
  }

  /**
   * Rollback state
   */
 rollback(data: EffectManagerRecord): void {
  // console.log('EffectManager rollback state',this.Effects , data.Effects)
  this.Effects = DeseTypeConve.conveHashMap(data.Effects);
  for(let effectRecord of data.Effects2){
      let buff:Buff = null;
      if(effectRecord.buffID){
        buff = this.Owner.BuffMgr.getBuff(effectRecord.buffID);
      }
      let effects2 = new Effect(this.Owner, buff, effectRecord.buffEffect, undefined, undefined, false);
      effects2.rollback(effectRecord);
      this.Effects2.push(effects2);
  }
  this.dispSpeed = data.dispSpeed;
  this.dirDegree = data.dirDegree;
  if(data.hitArr){
      this.hitArr = [];
      for(let entintyId of data.hitArr){
          let targetCreature = CreatureManager.Instance.GetCreature(entintyId);
          if(targetCreature){
              this.hitArr.push(targetCreature);
          }
      }
  }
}
 

}