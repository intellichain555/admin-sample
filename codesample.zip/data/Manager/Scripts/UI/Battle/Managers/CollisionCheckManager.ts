import proto from "../../../../Proto/proto.js";
import { CreatureManager } from "./CreatureManager";
import { Creature } from "../Enities/Creature";
import { ShapeType } from "../enums/ShapeType";
import { MathUtil } from "../../../Utils/MathUtil";
import { LogicRenderConvert } from "../Utils/LogicRenderConvert";
import { TeamType2 } from "../enums/TeamType2";
import { BattleManager } from "./BattleManager";
import { Node, Vec3, Vec2 } from "cc";
import { DataManager } from "../../../Managers/DataManager";
import { BattleGlobal } from "../Utils/BattleGlobal";
import { Constant } from "../../../../../Scripts/Utils/Constant";

/**
 * Collision manager 
 */
export class CollisionCheckManager{
    public static Instance: CollisionCheckManager = new CollisionCheckManager();
    public creatureList:Array<Creature>=[];  // Collision creature collection

     /**
     * Clear
     */
    public Clear() {
      this.creatureList=[];
    }


    private rectObstaclesRenderPosition: Vec3 = new Vec3();  // Rectangle obstacle render position
    private rectObstaclesLogicPosition: Vec3 = new Vec3();  // Rectangle obstacle logic position
    private rectObstaclesLogicRotation: Vec3 = new Vec3();  // Rectangle obstacle logic rotation
    /**
     * Collision detection
     * @param creature 
     */
    public CollisionCheck(creature:Creature, isPrediction=false, isUpdateRendering = true, isReadRenderValue = false){
        // Buildings (tower/crystal) do not move - skip collision check
        if (creature.characterDefine.Class === Constant.CharacterClass.Fyt || creature.characterDefine.Class === Constant.CharacterClass.ShuiJin) {
            return;
        }
        let myLogicRotation = isReadRenderValue ? creature.RenderRotation : creature.logicRotation;
        // Soldiers (minions) do not collide with other creatures - skip creature loop to save cost when many minions
        const isSoldier = creature.characterDefine.Class === Constant.CharacterClass.Soldier;
        if (!isSoldier) {
        // Collision detection with other creatures
        for(let creature2 of this.creatureList){
            if ((!creature.characterDefine.IsCollision && !creature2.characterDefine.IsCollision) 
                //|| (creature.characterDefine.IsCollision && (creature.isTuiKaiing || creature.IsDisplacementing)) || (creature2.characterDefine.IsCollision && (creature2.isTuiKaiing || creature2.IsDisplacementing)) 
               || creature.IsDeath || creature2.IsDeath || creature.entityId == creature2.entityId  // Death or self
               || creature.characterDefine.Class === Constant.CharacterClass.Soldier || creature2.characterDefine.Class === Constant.CharacterClass.Soldier
            ){  // No collision: soldier vs character, soldier vs soldier
                continue;
            }
            // if(creature.IsDisplacementing){
            //     console.log('Displacement test collision detection executed=======')
            // }
            let myLogicPosition = isReadRenderValue ? creature.CollisionTempVec3_2 : creature.CollisionTempVec3; // Our position coordinates
            let enemyLogicPosition = creature2.CollisionTempVec3; // Enemy position coordinates
            // Collision detection start
            let isCollision:boolean=false;  // Whether collision
            let isReviseMyFlag:boolean=true; // Whether correct self
            let creatureShape = creature.characterDefine.Shape.toString();
            let creature2Shape = creature2.characterDefine.Shape.toString();
            if(creatureShape==ShapeType[ShapeType.circle] && creature2Shape==ShapeType[ShapeType.circle]){  // Both circles
                isCollision=MathUtil.CollideCircleAndCircleRevise(myLogicPosition, enemyLogicPosition, LogicRenderConvert.RenderToLogic_Value(creature.characterDefine.Radius), LogicRenderConvert.RenderToLogic_Value(creature2.characterDefine.Radius), creature._amend);
            }else if(creatureShape==ShapeType[ShapeType.circle] && creature2Shape==ShapeType[ShapeType.rect]){  // Self is circle, enemy is rectangle
                isCollision=MathUtil.CollideCircleAndRectRotateRevise(myLogicPosition, LogicRenderConvert.RenderToLogic_Value(creature.characterDefine.Radius), enemyLogicPosition, LogicRenderConvert.RenderToLogic_Value(creature2.characterDefine.Width), LogicRenderConvert.RenderToLogic_Value(creature2.characterDefine.Long_), creature._amend, 360-creature2.logicRotation.y);
                // if(creature.teamType2==TeamType2.Blue){
                //     creature._amend.x = -creature._amend.x;
                //     creature._amend.z = -creature._amend.z;
                // }
                // console.log('Self is circle, enemy is rectangle, enemy y rotation='+creature2.logicRotation.y)
            }else if(creatureShape==ShapeType[ShapeType.rect] && creature2Shape==ShapeType[ShapeType.circle]){  // Self is rectangle, enemy is circle                
                isCollision=MathUtil.CollideCircleAndRectRotateRevise(enemyLogicPosition, LogicRenderConvert.RenderToLogic_Value(creature2.characterDefine.Radius), myLogicPosition, LogicRenderConvert.RenderToLogic_Value(creature.characterDefine.Width), LogicRenderConvert.RenderToLogic_Value(creature.characterDefine.Long_), isReviseMyFlag ? creature._amend : creature2._amend, 360-myLogicRotation.y);
                // if(creature.teamType2==TeamType2.Blue){
                //     console.log('Escort cart angle='+(creature.logicRotation.y))
                // }
                // if(creature.teamType2==TeamType2.Blue){
                //     if(isReviseMyFlag){  // Correct self
                //         creature._amend.x = -creature._amend.x;
                //         creature._amend.z = -creature._amend.z;
                //     }else{
                //         creature2._amend.x = -creature2._amend.x;
                //         creature2._amend.z = -creature2._amend.z;
                //     } 
                // }
            }
            if(isCollision){  // Collision occurred
                // console.log('Collision occurred, correct position: isReviseMyFlag='+isReviseMyFlag+'，'+(isReviseMyFlag ? creature._amend : creature2._amend));
                if(isReviseMyFlag){  // Correct self
                    let creatureLogicPosition = isReadRenderValue ? creature.CollisionTempVec3_2 : creature.CollisionTempVec3;
                    creature.LogicToRenderPosition(creatureLogicPosition.x + creature._amend.x, creatureLogicPosition.y, creatureLogicPosition.z + creature._amend.z, isPrediction, isUpdateRendering, undefined, undefined); 
                }else{  // Correct enemy
                    creature2.LogicToRenderPosition(creature2.logicPosition.x + creature2._amend.x, creature2.logicPosition.y, creature2.logicPosition.z + creature2._amend.z, isPrediction, isUpdateRendering, undefined, undefined); 
                } 
            }
        } 
        }

        // Collision detection with rectangle obstacles (runs for all: heroes, soldiers, bosses)
        let rectObstaclesNodeArr = BattleManager.Instance.RectObstaclesNode.children;
        for (let i = 0; i < rectObstaclesNodeArr.length; i++) {
            // if ((!creature.characterDefine.IsCollision && !creature.isTuiKaiing && !creature.isRepeling) || creature.IsDeath){  // Death or collision not enabled
            //     continue;
            // }
            let rectObstaclesNode = rectObstaclesNodeArr[i];
            let creatureLogicPosition = isReadRenderValue ? creature.CollisionTempVec3_2 : creature.CollisionTempVec3;
            this.CreatureObstacleCollisionCheck(creature, creatureLogicPosition, rectObstaclesNode, myLogicRotation, isPrediction, isUpdateRendering);
        }
    }

    /**
     * Creature and obstacle collision detection
     * @param creatures  Creature object
     * @param creatureLogicPosition Creature logic position
     * @param rectObstaclesNode Obstacle node
     */
    public CreatureObstacleCollisionCheck(creature:Creature, creatureLogicPosition:Vec3, rectObstaclesNode:Node, myLogicRotation:Vec3, isPrediction=false, isUpdateRendering = true, isFlash = false):boolean{
        let width = LogicRenderConvert.RenderToLogic_Value(rectObstaclesNode.scale.x);  
        let long_ = LogicRenderConvert.RenderToLogic_Value(rectObstaclesNode.scale.z);
        let logicX = creatureLogicPosition.x;
        let logicY = creatureLogicPosition.y;
        let logicZ = creatureLogicPosition.z;

        let isCollision:boolean=false;  // Whether collision
        rectObstaclesNode.getWorldPosition(this.rectObstaclesRenderPosition);
        LogicRenderConvert.RenderToLogic_TwoVec3(this.rectObstaclesLogicPosition, this.rectObstaclesRenderPosition);
        rectObstaclesNode.getRotation().getEulerAngles(this.rectObstaclesLogicRotation);
        
        let creatureShape = creature.characterDefine.Shape.toString();
        if(creatureShape==ShapeType[ShapeType.circle]){  // Self is circle
            isCollision=MathUtil.CollideCircleAndRectRotateRevise(creatureLogicPosition, LogicRenderConvert.RenderToLogic_Value(creature.characterDefine.Radius), 
            this.rectObstaclesLogicPosition, width, long_, creature._amend, 360-this.rectObstaclesLogicRotation.y);
            // if(this.rectObstaclesLogicRotation.y == 90 && creature.teamType2==TeamType2.Blue){
            //     creature._amend.x = -creature._amend.x;
            //     creature._amend.z = -creature._amend.z;
            // }
            if(isCollision){  // Collision occurred
                // console.log('Collision occurred, correct position: ' + creature._amend);
                creature.LogicToRenderPosition(logicX + creature._amend.x, logicY, logicZ + creature._amend.z, isPrediction, isUpdateRendering, isFlash, undefined); 
            }   
        }else if(creatureShape==ShapeType[ShapeType.rect]){  // Self is rectangle
            creature._amend.set(0, 0, 0);
            isCollision=MathUtil.rectInRect(logicX, logicZ, LogicRenderConvert.RenderToLogic_Value(creature.characterDefine.Width), LogicRenderConvert.RenderToLogic_Value(creature.characterDefine.Long_), 360-myLogicRotation.y,
            this.rectObstaclesLogicPosition.x, this.rectObstaclesLogicPosition.z, width, long_, 360-this.rectObstaclesLogicRotation.y);
            if(isCollision){  // Collision occurred
              creature.LogicToRenderPosition(creature.lastLogicPosition.x, creature.lastLogicPosition.y, creature.lastLogicPosition.z, isPrediction, isUpdateRendering, isFlash);
            }
        }
        
        return isCollision; 
    }

    private newCreatureLogicPosition: Vec3 = new Vec3();  // New creature logic position
    /**
     * Flash and rectangle obstacle collision detection (avoid going out of map)
     * @param creature Creature object
     * @param dirDegree Direction angle
     * @param CastRange Cast range radius
     * @return Returns whether collision, if collision then correct within map
     */
    public FlashCollisionCheckRectObstacles(creature:Creature, dirDegree:number, CastRange:number):boolean{
        let rockerSpeedVo = DataManager.Instance.rockerSpeeds[dirDegree];
        if(!rockerSpeedVo){
          console.log('rockerSpeedVo does not exist!'+dirDegree)
          return;
        }   
        let centerPointX:number = creature.logicPosition.x + (rockerSpeedVo.x * (CastRange*10/2));   // Rectangle center x position (logic value)
        let centerPointY:number = creature.logicPosition.z + (rockerSpeedVo.y * (CastRange*10/2));  // Rectangle center y position (logic value)
        let width:number = LogicRenderConvert.RenderToLogic_Value(creature.characterDefine.Radius * 2);   // Rectangle width (logic value)
        let height:number = LogicRenderConvert.RenderToLogic_Value(CastRange);  // Rectangle height (logic value)
        let rotation:number = dirDegree;   // Rotation angle

        let myLogicRotation = creature.logicRotation;
        // Collision detection with rectangle obstacles
      let rectObstaclesNodeArr = BattleManager.Instance.RectObstaclesNode.children;
      for (let i = 0; i < rectObstaclesNodeArr.length; i++) {
        let rectObstaclesNode = rectObstaclesNodeArr[i];
        let flashChuanFlag:boolean = false;
        if(rectObstaclesNode.name.lastIndexOf(BattleGlobal.flashObstacleSuffix) != -1){  // Flash passable obstacle
            flashChuanFlag = true;
        }
        // Obstacle data
        let logicWidth:number = LogicRenderConvert.RenderToLogic_Value(rectObstaclesNode.scale.x);  
        let logicHeight:number = LogicRenderConvert.RenderToLogic_Value(rectObstaclesNode.scale.z);
        rectObstaclesNode.getWorldPosition(this.rectObstaclesRenderPosition);
        LogicRenderConvert.RenderToLogic_TwoVec3(this.rectObstaclesLogicPosition, this.rectObstaclesRenderPosition);
        rectObstaclesNode.getRotation().getEulerAngles(this.rectObstaclesLogicRotation);
        
        let isCollision = MathUtil.rectInRect(centerPointX, centerPointY, width, height, 360-rotation,
            this.rectObstaclesLogicPosition.x, this.rectObstaclesLogicPosition.z, logicWidth, logicHeight, 360-this.rectObstaclesLogicRotation.y);
        if(isCollision && !flashChuanFlag){  // Collision occurred, non-flash passable obstacle
            // Simulate collision with character body positions within cast range radius
            let count =  Math.ceil(CastRange / (creature.characterDefine.Radius * 2)); // Determine how many character body positions within cast range radius
            for(let n = 0; n <= count; n++){
                let offsetLen = creature.characterDefine.Radius * 2 * 10 * n;  // Offset n character body positions each time
                // Removed debug log - was costly when many minions/flash checks
                let creatureLogicPosition = creature.logicPosition;  // Creature logic position
                let vx = creatureLogicPosition.x + (rockerSpeedVo.x*offsetLen);
                let vz = creatureLogicPosition.z + (rockerSpeedVo.y*offsetLen);   
                this.newCreatureLogicPosition.set(vx, creatureLogicPosition.y, vz);
                let isCollision2 = this.CreatureObstacleCollisionCheck(creature, this.newCreatureLogicPosition , rectObstaclesNode, myLogicRotation, undefined, undefined, true);
                if(isCollision2){
                    return true;
                }
            }
            return false;
        }    
      }
      return false;
    }
     
}