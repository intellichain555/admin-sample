import { Node, Vec3 } from "cc";
import { Creature } from "../Enities/Creature";
import { Bullet } from "../Models/Bullet";
import { EffectType } from "../Effects/EffectType";
import { EntityEffectManager } from "../Effects/EntityEffectManager";
import { UIWorldElementManager } from "../UIWorldElementManager";
import { BattleData } from "../Utils/BattleData";
import { BattleGlobal } from "../Utils/BattleGlobal";
import { BattleManager } from "../Managers/BattleManager";
import { CreatureManager } from "./CreatureManager";
import { PoolManager } from "../../../Managers/PoolManager";
import { PopupType } from "../enums/PopupType";
import { BuffEffect } from "../enums/BuffEffect";

type DeferredPlayEffectTargetItem = { kind: 'target'; owner: Creature; type: EffectType; name: string; target: Creature; duration?: number; hitHeightScale?: number; isUseGlobalEffect?: boolean };
type DeferredPlayEffectPositionItem = { kind: 'position'; owner: Creature; type: EffectType; name: string; position: Vec3; duration?: number };
type DeferredPlayEffectBulletItem = { kind: 'bullet'; owner: Creature; name: string; duration: number; bullet: Bullet };
type DeferredSkillEffectItem = DeferredPlayEffectTargetItem | DeferredPlayEffectPositionItem | DeferredPlayEffectBulletItem;

/** Safe deferred FX PlayEffect3 - parent may be destroyed before processing */
type DeferredPlayEffect3FXItem = {
    name: string;
    parentNode: Node;  // Strong ref; validated with isValid at process time
    worldPos: Vec3;
    resultHolder?: { node: Node | null };
    yValue?: number;  // Set world Y (e.g. stun stars above head)
    scale?: Vec3;
};

/** Safe deferred Entity PlayEffect3 - creature may be destroyed before processing */
type DeferredPlayEffect3EntityItem = {
    entityMgr: EntityEffectManager;  // Strong ref; validated with node.isValid at process time
    name: string;
    isEffectFollowHero?: boolean;
    teamType2?: number;
};

/** Deferred popup text - spreads getNode/addChild/InitPopup cost across frames to avoid spikes */
type DeferredPopupTextItem = {
    type: PopupType;
    creature: Creature;
    text: string;
    isCrit: boolean;
    costTime: number;
    caster?: Creature;
};

/**
 * Deferred Work Manager - spreads expensive visual/UI work across frames
 * to avoid frame time spikes. Only defers visuals; logic remains immediate for determinism.
 */
export class DeferredWorkManager {

    public static Instance: DeferredWorkManager = new DeferredWorkManager();

    private static readonly MAX_EFFECTS_PER_FRAME = 1;
    private static readonly MAX_SKILL_EFFECTS_PER_FRAME = 1;
    private static readonly MAX_PARTICLE_ACTIVATIONS_PER_FRAME = 1;
    private static readonly MAX_PLAY_EFFECT3_FX_PER_FRAME = 1;
    private static readonly MAX_PLAY_EFFECT3_ENTITY_PER_FRAME = 1;
    private static readonly MAX_DEATHS_PER_FRAME = 1;
    private static readonly MAX_DROPS_PER_FRAME = 3;
    private static readonly MAX_POPUPS_PER_FRAME = 3;
    private static readonly MAX_QUEUE_SIZE = 64;
    /** Frames to wait before recycling FX nodes that have no resultHolder (~10s at 60 fps) */
    private static readonly RECYCLE_DELAY_FRAMES = 600;

    private effectQueue: Array<{ owner: Creature; name: string; bullet: Bullet }> = [];
    private pendingFXRecycle: Array<{ node: Node; recycleAtFrame: number }> = [];
    private skillEffectQueue: DeferredSkillEffectItem[] = [];
    private particleActivationQueue: Node[] = [];
    private playEffect3FXQueue: DeferredPlayEffect3FXItem[] = [];
    private playEffect3EntityQueue: DeferredPlayEffect3EntityItem[] = [];
    private deathRenderingQueue: Array<Creature> = [];
    private dropsQueue: Array<{ deathCreature: Creature; itemId: number; count: number; target: Creature; isZhugongFlag: boolean }> = [];
    private popupTextQueue: DeferredPopupTextItem[] = [];

    /**
     * Enqueue bullet effect creation (deferred from Bullet.DelayCreate)
     */
    public enqueuePlayEffectBulletRealCheck(owner: Creature, name: string, bullet: Bullet): void {
        if (this.effectQueue.length >= DeferredWorkManager.MAX_QUEUE_SIZE) {
            this.effectQueue.shift(); // Drop oldest when full
        }
        this.effectQueue.push({ owner, name, bullet });
    }

    /**
     * Enqueue death rendering (deferred from Creature.DoDeath)
     */
    public enqueueDeathRendering(creature: Creature): void {
        this.deathRenderingQueue.push(creature);
    }

    /**
     * Enqueue drop display (deferred from Creature.AddAchievement)
     */
    public enqueueShowDrops(deathCreature: Creature, itemId: number, count: number, target: Creature, isZhugongFlag: boolean): void {
        if (this.dropsQueue.length >= DeferredWorkManager.MAX_QUEUE_SIZE) {
            this.dropsQueue.shift(); // Drop oldest when full
        }
        this.dropsQueue.push({ deathCreature, itemId, count, target, isZhugongFlag });
    }

    /**
     * Enqueue popup text (damage/hit/heal/tips) - spreads getNode/addChild/InitPopup across frames to avoid spikes.
     */
    public enqueueShowPopupText(type: PopupType, creature: Creature, text: string, isCrit: boolean = false, costTime: number = 1.5, caster?: Creature): void {
        if (this.popupTextQueue.length >= DeferredWorkManager.MAX_QUEUE_SIZE) {
            this.popupTextQueue.shift();
        }
        this.popupTextQueue.push({ type, creature, text, isCrit, costTime, caster });
    }

    /**
     * Enqueue PlayEffect with target (hit effect, AOE target/self) - deferred from Skill
     */
    public enqueuePlayEffectTarget(owner: Creature, type: EffectType, name: string, target: Creature, duration?: number, hitHeightScale?: number, isUseGlobalEffect?: boolean): void {
        if (this.skillEffectQueue.length >= DeferredWorkManager.MAX_QUEUE_SIZE) {
            this.skillEffectQueue.shift();
        }
        this.skillEffectQueue.push({ kind: 'target', owner, type, name, target, duration, hitHeightScale, isUseGlobalEffect });
    }

    /**
     * Enqueue PlayEffect2 with position (AOE position) - deferred from Skill
     */
    public enqueuePlayEffectPosition(owner: Creature, type: EffectType, name: string, position: Vec3, duration?: number): void {
        if (this.skillEffectQueue.length >= DeferredWorkManager.MAX_QUEUE_SIZE) {
            this.skillEffectQueue.shift();
        }
        this.skillEffectQueue.push({ kind: 'position', owner, type, name, position: position.clone(), duration });
    }

    /**
     * Enqueue PlayEffect for bullet (non-real-time) - deferred from Bullet.DelayCreate
     */
    public enqueuePlayEffectBullet(owner: Creature, name: string, duration: number, bullet: Bullet): void {
        if (this.skillEffectQueue.length >= DeferredWorkManager.MAX_QUEUE_SIZE) {
            this.skillEffectQueue.shift();
        }
        this.skillEffectQueue.push({ kind: 'bullet', owner, name, duration, bullet });
    }

    /**
     * Enqueue particle node activation (deferred from PlayEffectBulletRealCheck to spread activateNode cost)
     */
    public enqueueParticleActivation(node: Node): void {
        if (node && node.isValid && this.particleActivationQueue.length < DeferredWorkManager.MAX_QUEUE_SIZE) {
            this.particleActivationQueue.push(node);
        }
    }

    /**
     * Enqueue FXManager PlayEffect3 - safe when parentNode may be destroyed before processing.
     * Validates parent at process time. If parent destroyed, effect plays at saved world position.
     * @param resultHolder If provided and parent valid, set resultHolder.node for caller to recover.
     * @param opts Optional yValue (set world Y, e.g. stun) or scale (e.g. frozen) applied after attach.
     */
    public enqueuePlayEffect3FX(name: string, parentNode: Node, resultHolder?: { node: Node | null }, opts?: { yValue?: number; scale?: Vec3 }): void {
        if (this.playEffect3FXQueue.length >= DeferredWorkManager.MAX_QUEUE_SIZE) {
            this.playEffect3FXQueue.shift();
        }
        const item: DeferredPlayEffect3FXItem = {
            name,
            parentNode,
            worldPos: parentNode.worldPosition.clone(),
            resultHolder,
            yValue: opts?.yValue,
            scale: opts?.scale ? opts.scale.clone() : undefined,
        };
        this.playEffect3FXQueue.push(item);
    }

    /**
     * Enqueue EntityEffectManager PlayEffect3 - safe when creature may be destroyed before processing.
     */
    public enqueuePlayEffect3Entity(entityMgr: EntityEffectManager, name: string, isEffectFollowHero?: boolean, teamType2?: number): void {
        if (this.playEffect3EntityQueue.length >= DeferredWorkManager.MAX_QUEUE_SIZE) {
            this.playEffect3EntityQueue.shift();
        }
        this.playEffect3EntityQueue.push({
            entityMgr,
            name,
            isEffectFollowHero,
            teamType2,
        });
    }

    /**
     * Process deferred work - call at start of each logic frame (full frames only)
     */
    public processDeferredWork(): void {
        let didPlayEffect = false;

        // Recycle FX nodes that had no resultHolder (parent was invalid)
        const nowFrame = BattleData.executeFrameId;
        for (let i = this.pendingFXRecycle.length - 1; i >= 0; i--) {
            const entry = this.pendingFXRecycle[i];
            if (nowFrame >= entry.recycleAtFrame && entry.node && entry.node.isValid) {
                entry.node.active = false;
                entry.node.removeFromParent();
                PoolManager.instance.putNode(entry.node);
                this.pendingFXRecycle.splice(i, 1);
            }
        }

        // Process one effect queue per frame (avoid activateNode spikes)
        // effectQueue (highest priority)
        if (!didPlayEffect && this.effectQueue.length > 0) {
            const item = this.effectQueue.shift();
            if (item && !item.bullet.Stoped) {
                item.owner.PlayEffectBulletRealCheck(EffectType.BulletRealCheck, item.name, item.bullet);
                didPlayEffect = true;
            }
        }

        // particleActivationQueue
        if (!didPlayEffect && this.particleActivationQueue.length > 0) {
            const node = this.particleActivationQueue.shift();
            if (node && node.isValid && node.parent) {
                BattleGlobal.playParticleEffect(node);
                //didPlayEffect = true;
            }
        }

        // skillEffectQueue
        if (!didPlayEffect && this.skillEffectQueue.length > 0) {
            const item = this.skillEffectQueue.shift();
            if (item && item.owner?.node?.isValid) {
                if (item.kind === 'target' && item.target?.node?.isValid && !item.target.IsDeath) {
                    item.owner.PlayEffect(item.type, item.name, item.target, item.duration, item.hitHeightScale, undefined, item.isUseGlobalEffect);
                    
                } else if (item.kind === 'position') {
                    item.owner.PlayEffect2(item.type, item.name, item.position, item.duration);
                    
                } else if (item.kind === 'bullet' && !item.bullet.Stoped) {
                    item.owner.PlayEffect(EffectType.Bullet, item.name, null, item.duration, undefined, item.bullet);
                    
                }
                didPlayEffect = true;
            }
        }

        // playEffect3FXQueue
        if (!didPlayEffect && this.playEffect3FXQueue.length > 0) {
            const item = this.playEffect3FXQueue.shift();
            if (item) {
                const effectNode = PoolManager.instance.getNode2(item.name, { optimizeParticles: true });
                if (effectNode) {
                    const parentNode = item.parentNode;
                    if (parentNode && parentNode.isValid) {
                        let shouldAttach = true;
                        if (item.resultHolder) {
                            const creature = DeferredWorkManager.getCreatureFromEffectParent(parentNode);
                            if (creature) {
                                const stale = (item.name === BattleGlobal.jiansuName && !creature.EffectMgr.queryEffect(BuffEffect.Dece));
                                    // || (item.name === BattleGlobal.frozenName && !creature.EffectMgr.queryEffect(BuffEffect.Frost));
                                if (stale) {
                                    PoolManager.instance.putNode(effectNode);
                                    didPlayEffect = true;
                                    shouldAttach = false;
                                }
                            }
                        }
                        if (shouldAttach) {
                            parentNode.addChild(effectNode);
                            if (item.yValue !== undefined) {
                                effectNode.setWorldPosition(effectNode.worldPosition.x, item.yValue, effectNode.worldPosition.z);
                            }
                            if (item.scale) {
                                effectNode.setScale(item.scale);
                            }
                            if (item.resultHolder) {
                                item.resultHolder.node = effectNode;
                            }
                            BattleGlobal.playParticleEffect(effectNode);
                            didPlayEffect = true;
                        }
                    } else {
                        const allNode = BattleManager.Instance?.AllBattleEffectsNode;
                        if (allNode && allNode.isValid) {
                            allNode.addChild(effectNode);
                            const pos = item.worldPos.clone();
                            if (item.yValue !== undefined) pos.y = item.yValue;
                            effectNode.setWorldPosition(pos);
                            if (item.scale) {
                                effectNode.setScale(item.scale);
                            }
                            this.pendingFXRecycle.push({
                                node: effectNode,
                                recycleAtFrame: BattleData.executeFrameId + DeferredWorkManager.RECYCLE_DELAY_FRAMES,
                            });
                        }
                        BattleGlobal.playParticleEffect(effectNode);
                        didPlayEffect = true;
                    }
                }
            }
        }

        // playEffect3EntityQueue
        if (!didPlayEffect && this.playEffect3EntityQueue.length > 0) {
            const item = this.playEffect3EntityQueue.shift();
            if (item) {
                const entityMgr = item.entityMgr;
                if (entityMgr && entityMgr.node?.isValid) {
                    entityMgr.executeDeferredPlayEffect3(item.name, item.isEffectFollowHero, item.teamType2);
                }
            }
        }

        // Process death rendering
        for (let i = 0; i < DeferredWorkManager.MAX_DEATHS_PER_FRAME && this.deathRenderingQueue.length > 0; i++) {
            const creature = this.deathRenderingQueue.shift();
            if (creature && creature.IsDeath && creature.node && creature.node.isValid) {
                creature.ExecuteDeathRendering();
            }
        }

        // Process drop displays
        for (let i = 0; i < DeferredWorkManager.MAX_DROPS_PER_FRAME && this.dropsQueue.length > 0; i++) {
            const item = this.dropsQueue.shift();
            if (item && item.deathCreature && item.deathCreature.node && item.deathCreature.node.isValid
                && item.target && item.target.node && item.target.node.isValid) {
                UIWorldElementManager.Instance.ShowDrops(item.deathCreature, item.itemId, item.count, item.target, item.isZhugongFlag);
            }
        }

        // Process popup text (damage/hit/heal/tips) - spread across frames to avoid LogicUpdate spike
        if (UIWorldElementManager.Instance) {
            for (let i = 0; i < DeferredWorkManager.MAX_POPUPS_PER_FRAME && this.popupTextQueue.length > 0; i++) {
                const item = this.popupTextQueue.shift();
                if (item && item.creature && item.creature.node && item.creature.node.isValid) {
                    UIWorldElementManager.Instance.ShowPopupText(item.type, item.creature, item.text, item.isCrit, item.costTime, item.caster);
                }
            }
        }
    }

    /**
     * Get creature that owns this effect parent node (Effect node under character container).
     * Used to validate slow effect is still active before attaching deferred jiansu node.
     */
    private static getCreatureFromEffectParent(effectParentNode: Node): Creature | null {
        const container = effectParentNode.parent;
        if (!container) return null;
        for (const child of container.children) {
            const entityId = (child as Node & { entityId?: number }).entityId;
            if (entityId != null) {
                return CreatureManager.Instance.GetCreature(entityId);
            }
        }
        return null;
    }

    /**
     * Clear all queues (call on battle end/reset)
     */
    public clear(): void {
        this.effectQueue.length = 0;
        this.skillEffectQueue.length = 0;
        this.particleActivationQueue.length = 0;
        this.playEffect3FXQueue.length = 0;
        this.playEffect3EntityQueue.length = 0;
        this.deathRenderingQueue.length = 0;
        this.dropsQueue.length = 0;
        this.popupTextQueue.length = 0;
        for (const entry of this.pendingFXRecycle) {
            if (entry.node && entry.node.isValid) {
                entry.node.active = false;
                entry.node.removeFromParent();
                PoolManager.instance.putNode(entry.node);
            }
        }
        this.pendingFXRecycle.length = 0;
    }
}
