import { Creature } from "../Enities/Creature";
import { Skill } from "../Models/Skill";
import { DataManager } from "../../../Managers/DataManager";
import { SkillType } from "../enums/SkillType";
import { SkillStatus } from "../enums/SkillStatus";
import { SkillDefine } from "../../../Data/SkillDefine";
import { CreatureType } from "../enums/CreatureType";
import { BattleContext } from "../Models/BattleContext";
import { SkillResult } from "../enums/SkillResult";
import { LogicRenderConvert } from "../Utils/LogicRenderConvert";
import { AniState } from "../enums/AniState";
import { Node } from "cc";
import { PoolManager } from "../../../Managers/PoolManager";
import { IStateRollback } from "../StateRecord/IStateRollback";
import { SkillManagerRecord } from "../StateRecord/Managers/SkillManagerRecord";

export class SkillManager implements IStateRollback{
    public Owner: Creature;
    public NormalSkill: Skill;

    public Skills: Array<Skill> = [];

    // public Infos:Array<number> = [];

    public constructor(owner: Creature) {
        this.Owner = owner;
        this.InitSkills();
    }

    private InitSkills() {
        this.Skills = [];
        // this.Infos = [];

        // Creature has skills
        let skillMap = DataManager.Instance.skills[this.Owner.characterDefine.ID];
        for (var skillId in skillMap) {
            let define = skillMap[skillId];
            if (define.SegmentsNum && define.SegmentsNum > 1) {
                continue;
            }
            // console.log(JSON.stringify(define))

            // this.Infos.push(define.ID);
            let skill = new Skill(define, this.Owner);
            if (define.Type && define.Type.toString() == SkillType[SkillType.Normal] && (!skill.Define.SegmentsNum || skill.Define.SegmentsNum == 1))  // Normal skill, no segments or segment count is 1
            {
                this.NormalSkill = skill;
            }
            this.AddSkill(skill);
        }

        // Character common skills
        if (this.Owner.creatureType == CreatureType.Character) {
            // Recall
            let commonSkillMap = DataManager.Instance.skills[0];
            // console.log('commonSkillMap=', commonSkillMap)
            for (var skillId in commonSkillMap) {
                let define = commonSkillMap[skillId];
                let skill = new Skill(define, this.Owner);
                this.AddSkill(skill);
            }

            // AI auto
            let aiCommonSkillMap = DataManager.Instance.skills[-1];
            for (var skillId in aiCommonSkillMap) {
                let define = aiCommonSkillMap[skillId];
                let skill = new Skill(define, this.Owner);
                this.AddSkill(skill);
            }
        }

    }

    private AddSkill(skill: Skill) {
        this.Skills.push(skill);
    }

    public GetSkill(skillId: number): Skill {
        for (let i = 0; i < this.Skills.length; i++) {
            if (this.Skills[i].skillId == skillId)
                return this.Skills[i];
        }
        return null;
    }

    /**
     * Validate if skill action has finished playing
     */
    public ValidateSkillActionPlayEnd(isValidateMove: boolean = false): boolean {
        for (let i = 0; i < this.Skills.length; i++) {
            let skill = this.Skills[i];
            if ((!isValidateMove && skill.actionTime > 0) || (isValidateMove && skill.actionTime > 0 && !skill.Define.isCanMove && !skill.Define.isCanRotate)) {  // Not finished playing, cannot move
                return false;
            }
        }
        return true;
    }


    /**
     * Get skills that can only rotate while casting
     */
    public GetSkillCastIsOnlyRotate(): Skill {
        for (let i = 0; i < this.Skills.length; i++) {
            let skill = this.Skills[i];
            if (skill.actionTime > 0 && !skill.Define.isCanMove && skill.Define.isCanRotate) {  // Skill casting, cannot move but can rotate
                return skill;
            }
        }
        return null;
    }

    /**
     * Get skills that can move while casting
     */
    public GetSkillPlayingCanMoveNoChangeAni(): Skill {
        for (let i = 0; i < this.Skills.length; i++) {
            let skill = this.Skills[i];
            if (skill.actionTime > 0 && skill.Define.isCanMove) {  // Not finished playing, can move
                return skill;
            }
        }
        return null;
    }

    public LogicUpdate(frameId: number) {
        for (let i = 0; i < this.Skills.length; i++) {
            this.Skills[i].LogicUpdate(frameId);
        }
    }

    public update() {
        for (let i = 0; i < this.Skills.length; i++) {
            this.Skills[i].update();
        }
    }

    /**
     * Get skill by skill ID and segment count
     * @param skillId Skill ID
     * @param SegmentsNum Segment count
     */
    public GetSkillBySkillIdSegmentsNum(skillId: number, SegmentsNum: number): SkillDefine {
        let skillMap = DataManager.Instance.skills[this.Owner.characterDefine.ID];
        for (let key in skillMap) {
            let skillDefine = skillMap[key];
            if (skillDefine.ParentSkillId == skillId && skillDefine.SegmentsNum == SegmentsNum) {
                return skillDefine;
            }
        }
        return null;
    }

    /**
     * Validate if ghost display skill exists
     */
    public IsExistShowGhostSkill(): boolean {
        for (let i = 0; i < this.Skills.length; i++) {
            let skill = this.Skills[i];
            let buffArr = skill.Define.Buff;
            if (buffArr && buffArr.length > 0) {
                for (let j = 0; j < buffArr.length; j++) {
                    let buffId = buffArr[j];
                    let buffDefine = DataManager.Instance.buffs[buffId];
                    if (buffDefine.isShowGhost) { // Ghost display exists
                        return true;
                    }
                }
            }
        }
        return false;
    }

    /**
     * AI query cast distance within skill range
     * @param logicDis 
     */
     public isExistCastRangeInSkill(context: BattleContext, logicDis:number, targetCreature: Creature):Skill{
        let skillResult:Skill = null;
        for (var skill of this.Skills) {
            if(logicDis <= LogicRenderConvert.RenderToLogic_Value(skill.Define.CastRange + targetCreature.characterDefine.Radius)){  // Within cast range
                skillResult = skill;
                var result = skill.CanCast(context);
                if (result == SkillResult.Ok){  // Priority return castable skill
                    return skill;
                }
            }
        }
        return skillResult;
    }

    /**
     * AI query cast distance within skill range
     * @param logicDis 
     */
    public heroUseIsExistCastRangeInSkill(context: BattleContext, logicDis:number, targetCreature: Creature, isNormalFlag:boolean = false):Skill{
        let skillResult:Skill = null;
        for (var skill of this.Skills) {
            if(!skill.Define.Type || skill.Define.Type.toString() == SkillType[SkillType.HuiCheng]
              || skill.Define.Type.toString() == SkillType[SkillType.ZiDong]
              || skill.Define.aiAttackIsNoCast){  // Sub-skill or recall skill or no cast when attacking
              continue;
            }
            if(isNormalFlag && skill.skillId != this.NormalSkill.skillId){  // Only check normal attack
                continue;
            }
            if(!skill.Define.CastRange || logicDis <= LogicRenderConvert.RenderToLogic_Value(skill.Define.CastRange + targetCreature.characterDefine.Radius)){  // Within cast range
                // skillResult = skill;
              context.skill = skill;
              context.Target = targetCreature;
              context.logicPositionX = targetCreature.logicPosition.x;
              context.logicPositionZ = targetCreature.logicPosition.z;
                var result = skill.CanCast(context);
                if (result == SkillResult.Ok){  // Priority return castable skill
                    if(!isNormalFlag && skill.Define.Type.toString() == SkillType[SkillType.Normal]){
                        skillResult = skill;
                        continue;
                    }
                    return skill;
                }
            }
        }
        return skillResult;
    }

    /**
     * AI query max cast range
     */
    public queryMaxCastRange():number{
      let maxCastRange: number;  // Max cast distance
      for (var skill of this.Skills) {
        if(!skill.Define.Type || skill.Define.Type.toString() == SkillType[SkillType.HuiCheng]
          || skill.Define.Type.toString() == SkillType[SkillType.ZiDong]
          || skill.Define.aiAttackIsNoCast){  // Sub-skill or recall skill or no cast when attacking
            continue;
        }
        let castRange = skill.Define.CastRange;
        if (!maxCastRange || (castRange && castRange > maxCastRange)) {
            maxCastRange = castRange;
        }
      }
      return maxCastRange;  
    }

    /**
     * Query castable skills when escaping
     */
     public queryAiEscapeCastSkill():Skill{
        for (var skill of this.Skills) {
          if(skill.Define.aiEscapeIsCast){  // Cast when AI escaping
            return skill;
          }
        }
        return null;
    }

    /**
     * Get first skill
     * @returns 
     */
    public getOneSkill():Skill{
        if(this.Skills.length > 0) {
            return this.Skills[0];
        }
        return null;
    }


    /**
     * Query skill by animation name
     * @param aniState 
     * @returns 
     */
    public getSkillByAniState(aniState:AniState):Skill{
        let skillResult:Skill = null;
        for (let skill of this.Skills) {
            if(skill.Define.SkillAnim && aniState && skill.Define.SkillAnim == AniState[aniState]){
                skillResult = skill;
                break;
            }
        }
        return skillResult;
    }

    /**
     * Set skill effect node
     * @param aniState 
     * @param effectNode 
     */
    public setSkillEffectNode(aniState:AniState, effectNode:Node){
        let skill = this.getSkillByAniState(aniState);
        if(skill){
            if(skill.effectNode && skill.effectNode.isValid){
                skill.effectNode.removeFromParent();
                PoolManager.instance.putNode(skill.effectNode);
            }
            skill.effectNode = effectNode;
        }
    }

    /**
     * Death skill interrupt
     */
    public deathSkillInterrupt(){
        for (let skill of this.Skills) {
            if(skill.Define.DeathIsInterrupt){  
                skill.SkillInterruptHandle();
            }
        }
    }


   /**
    * Rollback state
    */
    rollback(data:SkillManagerRecord):void{
       for(let skillRecord of data.Skills){
         let skill = this.GetSkill(skillRecord.skillId);
         if(skill){
            skill.rollback(skillRecord);
         }
       }
    }
 
}