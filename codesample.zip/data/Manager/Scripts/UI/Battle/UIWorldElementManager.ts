
import { _decorator, Component, Node, instantiate, Vec3 } from 'cc';
import { UIWorldElement } from './UIWorldElement';
import { UIHpBar } from './UIHpBar';
import { BattleManager } from './Managers/BattleManager';
import proto from '../../../Proto/proto.js';
import { Creature } from './Enities/Creature';
import { DataManager } from '../../Managers/DataManager';
import { PopupType } from './enums/PopupType';
import { UIPopupText } from './UIPopupText';
import { EventManager } from '../Common/Event/EventManager';
import { EventType } from '../Common/Event/EventType';
import { PoolManager } from '../../Managers/PoolManager';
import { UIDrops } from './UI/Drop/UIDrops';
import { HashMap } from '../../../../Scripts/Utils/HashMap';
import { Constant } from '../../../../Scripts/Utils/Constant';
import { TeamType2 } from './enums/TeamType2';
const { ccclass, property } = _decorator;

/**
 * World element manager
 */
@ccclass('UIWorldElementManager')
export class UIWorldElementManager extends Component {
    
    public static Instance:UIWorldElementManager=null;

    @property(Node)
    public hpBarNode:Node;
    @property(Node)
    public popupTextNode:Node;
    @property(Node)
    public dropNode:Node;

    public uiWorldElementMap=new HashMap();

    private componentCache = new Map<Node, { popup?: UIPopupText, element?: UIWorldElement }>();

    private idx:number = 1;
    private get ID()
    {
        return this.idx++; 
    }

    private Clear(){
        this.uiWorldElementMap.clear();
        this.componentCache.clear();
    }


    onLoad () {
        UIWorldElementManager.Instance=this;
        this.Clear();
        
    }

    start(){
        this.preloadCreated();
    }

    /**
     * Preload object pool
     */
    private preloadCreated(){
        // Create HP bar object pool
        PoolManager.instance.preloadPool(this.hpBarNode, 20, this.hpBarNode.name);
        // Create popup text object pool
        PoolManager.instance.preloadPool(this.popupTextNode, 50, this.popupTextNode.name);
        // Create drop object pool
        PoolManager.instance.preloadPool(this.dropNode, 8, this.dropNode.name);        
    }

    /**
     * Add creature HP bar
     * @param owner Creature node
     * @param creature  Creature object
     */
    public AddCharacterHpBar(owner:Node, creature:Creature){
        // console.log('AddCharacterHpBar hpBarNode='+this.hpBarNode);
        // Create HP bar node
        let hpBarNode2 = PoolManager.instance.getNode(this.hpBarNode, this.node);
        creature.hpBarNode=hpBarNode2;
        // Get HP bar node UIWorldElement, UIHpBar components
        let uiWorldElement=hpBarNode2.getComponent(UIWorldElement);
        let uiHpBar=hpBarNode2.getComponent(UIHpBar);
        uiWorldElement.Owner=creature;
        uiWorldElement.height=creature.characterDefine.Height; 
        uiWorldElement.type = 1;
        uiHpBar.Owner=creature;

        uiWorldElement.id = this.ID;
        this.uiWorldElementMap.put(uiWorldElement.id, uiWorldElement);

    }

    /**
     * Remove creature HP bar
     * @param creature  Creature object
     */
    public RemoveCharacterHpBar(creature:Creature){
        if(creature.hpBarNode){
            let uiWorldElement = creature.hpBarNode.getComponent(UIWorldElement);
            this.uiWorldElementMap.remove(uiWorldElement.id);

            // creature.hpBarNode.destroy();
            // creature.hpBarNode=null;
            creature.hpBarNode.removeFromParent();  // Remove node from parent
            PoolManager.instance.putNode(creature.hpBarNode);  // Return to object pool
        }
    }


    /**
     * Show popup text
     * @param type 
     * @param creature 
     * @param damage 
     * @param isCrit 
     * @param costTime
     */
    public ShowPopupText(type:PopupType, creature:Creature, text: string, isCrit:boolean = false, costTime:number=1.5, caster?: Creature)
    {
        if (!Constant.SHOW_POPUP_TEXT) return;

        let goPopup = PoolManager.instance.getNode(this.popupTextNode, this.node, false);
        if (!goPopup) return;

        let cache = this.componentCache.get(goPopup);
        let uiPopupText: UIPopupText;
        let uiWorldElement: UIWorldElement;

        if (cache) {
            uiPopupText = cache.popup!;
            uiWorldElement = cache.element!;
        } else {
            uiPopupText = goPopup.getComponent(UIPopupText);
            uiWorldElement = goPopup.getComponent(UIWorldElement);
            this.componentCache.set(goPopup, { popup: uiPopupText, element: uiWorldElement });
        }

        uiWorldElement.Owner = creature;
        uiWorldElement.isExecute = false;
        uiWorldElement.isExecuteOnce = true;
        uiWorldElement.type = 2;
        uiWorldElement.id = this.ID;
        this.uiWorldElementMap.put(uiWorldElement.id, uiWorldElement);

        uiPopupText.InitPopup(type, text, isCrit, creature, costTime, caster);
        uiWorldElement.height = uiPopupText.height;

        goPopup.active = true;
    }

    /**
     * Remove popup text
     */
    public RemovePopupText(uiPopupText:UIPopupText){
        if(uiPopupText){
            let uiWorldElement = uiPopupText.node.getComponent(UIWorldElement);
            this.uiWorldElementMap.remove(uiWorldElement.id);

            uiPopupText.node.removeFromParent();  // Remove node from parent
            EventManager.Instance.removeAll(uiWorldElement);
            PoolManager.instance.putNode(uiPopupText.node);  // Return to object pool
            // uiPopupText.node.destroy();
        }
    }

    /**
     * Remove all popup texts (damage labels, etc.) for a creature. Use on respawn to clear stale labels.
     */
    public RemovePopupTextsForCreature(creature: Creature) {
        const toRemove: UIPopupText[] = [];
        const data = this.uiWorldElementMap.data;
        for (const id in data) {
            const el = this.uiWorldElementMap.get(id) as UIWorldElement;
            if (el && el.type === 2 && el.Owner === creature) {
                const popup = el.node.getComponent(UIPopupText);
                if (popup) toRemove.push(popup);
            }
        }
        for (const popup of toRemove) {
            this.RemovePopupText(popup);
        }
    }

    /**
     * Show drops
     * @param creature 
     * @param text 
     */
     public ShowDrops(creature:Creature, itemId:number, count:number, target:Creature, isZhugongFlag:boolean = false):UIDrops
     {
         let dropsNode = PoolManager.instance.getNode(this.dropNode, this.node);

         let uiDrops = dropsNode.getComponent(UIDrops);
         uiDrops.init(creature, itemId, count, target, isZhugongFlag);

         let uiWorldElement=dropsNode.getComponent(UIWorldElement);
         uiWorldElement.Owner = creature;
         uiWorldElement.height = uiDrops.height; 
         uiWorldElement.isExecute = false;
         uiWorldElement.isExecuteOnce=true;
         uiWorldElement.type = 3;
 
         uiWorldElement.id = this.ID;
         this.uiWorldElementMap.put(uiWorldElement.id, uiWorldElement);
  
         return uiDrops;
     }

    /**
     * Remove drops
     */
    public RemoveDrops(uiDrops:UIDrops){
      try{
        if(uiDrops){
          let uiWorldElement = uiDrops.node.getComponent(UIWorldElement);
          this.uiWorldElementMap.remove(uiWorldElement.id);
  
          uiDrops.node.removeFromParent();  // Remove node from parent
          EventManager.Instance.removeAll(uiWorldElement);
          PoolManager.instance.putNode(uiDrops.node);  // Return to object pool
        }
      } catch(e) {
        console.error(e)
      }
    }


    /** Max distance from camera to update world UI (render units); beyond this we cull to save CPU */
    private static readonly CULL_DISTANCE = 20;

    public updateRendering(){
        if(!this.uiWorldElementMap){
            return;
        }
        let cameraWorldPos: Vec3 | null = null;
        if (BattleManager.Instance && BattleManager.Instance.camera) {
            cameraWorldPos = BattleManager.Instance.camera.worldPosition;
        }
        let uiWorldElementData = this.uiWorldElementMap.data;
        for(let id in uiWorldElementData){
            let uiWorldElement = this.uiWorldElementMap.get(id) as UIWorldElement;
            let owner = uiWorldElement.Owner;
            // Skip dead or invalid owners
            if (!owner || owner.IsDeath) {
                if (uiWorldElement.node) uiWorldElement.node.active = false;
                continue;
            }
            // Fog of view: hide world UI for enemy/neutral when not visible to local player
            const currentCharacter = BattleManager.Instance?.currentCharacter;
            if (currentCharacter && owner.teamType2 !== currentCharacter.teamType2 && !owner.isVisibleToLocalPlayer) {
                uiWorldElement.node.active = false;
                continue;
            }
            // Cull off-screen: skip expensive convertToUINode for distant elements
            if (cameraWorldPos) {
                let ownerWorldPos = owner.node.worldPosition;
                let dist = Vec3.distance(ownerWorldPos, cameraWorldPos);
                if (dist > UIWorldElementManager.CULL_DISTANCE) {
                    uiWorldElement.node.active = false;
                    continue;
                }
            }
            uiWorldElement.updateRendering();
        }
    }

    onDestroy(){
        this.Clear();
    }
}

