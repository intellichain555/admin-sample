
import { view, macro, UITransform, _decorator, Component, Node, Label, Sprite, SpriteFrame, loader, resources, director, sys, __private, EventTouch, Event, Input, SceneAsset, assetManager, ImageAsset, Button, RichText, Prefab, Animation, UIOpacity } from 'cc';
import { MessageBox } from './Common/MessageBox';
import { UISystemConfig } from './UISystemConfig';
import { User } from '../Models/User';
import { DataManager } from '../Managers/DataManager';
import { UIBag } from './Bag/UIBag';
import { UIShop } from './Shop/UIShop';
import { EventManager } from './Common/Event/EventManager';
import { EventType } from './Common/Event/EventType';
import { UIAuction } from './Auction/UIAuction';
import { InputBox } from './Common/InputBox';
import { Validate } from '../Utils/Validate';
import { RoomService } from '../Services/RoomService';
import { UIChat } from './Chat/UIChat';
import { ChatManager } from '../Managers/ChatManager';
import { MatchService } from '../Services/MatchService';
import { UICharacterDetail } from './UICharacterDetail/UICharacterDetail';
import { NetConfig } from '../Network/NetConfig';
import { Util } from '../Utils/Util';
import { WxGame } from '../Platform/WxGame';
import { LoadingManager } from '../LoadingManager';
import { TipsManager } from './TipsManager';
import { UILogin } from './UILogin';
import { DataUtil } from '../Utils/DataUtil';
import { UserService } from '../Services/UserService';
import { UIInputBox } from './Common/UIInputBox';
import { NetClient } from '../Network/NetClient';
import { NetClientBattle } from '../Network/Battle/NetClientBattle';
import { UIHistoryRecord } from './HistoryRecord/UIHistoryRecord';
import List from './Common/ScrollView/List';
import { ListView } from './Common/ListView/ListView';
import { UIHomeRankItem } from './Rank/UIHomeRankItem';
import { ListViewItem } from './Common/ListView/ListViewItem';
import { UIRank } from './Rank/UIRank';
import { UICharacter } from './UICharacterDetail/UICharacter';
import { UICharacterShop } from './UICharacterShop/UICharacterShop';
import { UIPromote } from './UIPromote/UIPromote';
import proto from '../../Proto/proto.js';
import { DouYingGame } from '../Platform/DouYinGame';
import { UIFollow } from './Follow/UIFollow';
import { UIRoom } from './Room/UIRoom';
import { qqGame } from '../Platform/qqGame';
import { FollowManager } from '../Managers/FollowManager';
import { LocalStorageUtil } from '../Utils/LocalStorageUtil';
import { UINewGuide } from './Guild/UINewGuide';
import { UICharacterSelect } from './UICharacterDetail/UICharacterSelect';
import { SoundDefine } from '../../../Scripts/Sound/SoundDefine';
import { SoundManager } from '../../../Scripts/Sound/SoundManager';
import { UIManager } from '../../../Scripts/UI/Common/UIManager';
import { Constant } from '../../../Scripts/Utils/Constant';
import { LoadResUtil } from '../../../Scripts/Utils/LoadResUtil';
import AdManager from '../../../Scripts/Platform/Sdk/AdManager';
import { CustomAdType } from '../../../Scripts/Platform/Sdk/WeChatAd';
import { BattleGlobal } from './Battle/Utils/BattleGlobal';
import { BattleMode } from './Battle/enums/BattleMode';
import { RandomUtil } from './Battle/Utils/RandomUtil';
const { ccclass, property } = _decorator;

@ccclass('UIMain')
export class UIMain extends Component {

  @property(Label)
  public levelText: Label = null as unknown as Label;
  @property(Label)
  public expText: Label = null as unknown as Label;

  @property(Sprite)
  public expProcessBar: Sprite;

  @property(Label)
  public nicknameText: Label = null as unknown as Label;
  @property(Label)
  public coinText: Label = null as unknown as Label;
  @property(Sprite)
  public avatarSprite: Sprite = null as unknown as Sprite;
  @property(Sprite)
  public selectSprite: Sprite = null as unknown as Sprite;
  @property(Node)
  public taskRedPoint: Node; //Task red dot
  @property(Node)
  public privateChatRedPoint: Node; //Private chat red dot
  @property(Node)
  public chatRedPoint: Node; //Chat red dot
  @property(RichText)
  public chatLabel: RichText = null; //Chat content
  @property(Label)
  public tiLiText: Label = null;  //Stamina content

  @property(Node)
  public douyinSidebarButton: Node; //Douyin sidebar entry reward button

  @property(Node)
  public chatButton: Node; //Chat button
  @property(Node)
  public selectHeroButton: Node; //Hero button
  @property(Node)
  public matchButton: Node; //Match button
  @property(Node)
  public zuduiButton: Node; //Team button

  // Match Settings Panel (6 buttons for different prices and modes)
  @property(Node)
  public matchSettingsPanel: Node = null; //Match settings container
  
  // Mode selector (3v3 / 5v5)
  @property(Button)
  public btn3v3Mode: Button = null; //3v3 mode button
  @property(Button)
  public btn5v5Mode: Button = null; //5v5 mode button
  
  @property(Button)
  public btnQuick10: Button = null; //Quick Match - 10 gold
  @property(Button)
  public btnQuick50: Button = null; //Quick Match - 50 gold
  @property(Button)
  public btnQuick100: Button = null; //Quick Match - 100 gold
  
  @property(Button)
  public btnInvite10: Button = null; //Invite Mode - 10 gold
  @property(Button)
  public btnInvite50: Button = null; //Invite Mode - 50 gold
  @property(Button)
  public btnInvite100: Button = null; //Invite Mode - 100 gold

  // Removed selectedPlayingMode - we'll use BattleGlobal.playingMethod directly

  @property(List)
  private rankingList = null as unknown as List;//Top 10 active ranking
  @property(ListView)
  public rankListMain: ListView = null as unknown as ListView;

  @property(Node)
  public tiLiNode: Node
  @property(Node)
  public clubNode: Node //Game circle window
  @property(Node)
  public clubRedPointNode: Node
  @property(Node)
  public clubContent: Node
  @property(Node)
  public clubContent2: Node
  @property(Node)
  public clubButton: Node
  @property(Label)
  public wsyCountLabel: Label;  //Remaining count
  @property(Label)
  public tiLiGetLabel: Label;  //Stamina acquisition amount
  @property(Label)
  public gifiTiLiLabel: Label;  //Lunch dinner time acquisition

  @property(Node)
  public pro_progress: Node
  @property(Label)
  public proLabel: Label;  //Scene loading percentage
  @property(Label)
  public proText: Label;  //Scene loading description
  @property(Node)
  public proValueNode: Node //Scene loading progress bar

  @property(Node)
  public fuliNode: Node;

  @property(Node)
  public ValueNode: Node

  @property(Node)
  public fankuiNode: Node

  @property(Node)
  public UIMainLoad: Node = null;

  @property(UILogin)
  public uiLogin: UILogin = null;

  private mainLoadCurrent: number = 0.3; // Login progress

  onLoad() {
    this.mainLoadCurrent = 0.3;
    this.OnUIMainLoadShow();
    let isQQ = window['isQQ'];
    Constant.isQQ = isQQ;
    let qihu360 = window["qihu360"];
    if (qihu360) {
      if (qihu360 == '1') {
        TipsManager.Instance.showTips('360 account login failed, please refresh browser!');
        return;
      }
      Constant.qihu360Web = true;
    }
    this.rankListMain.owner = this;
    this.rankListMain.isAddScene = false;
    this.douyinSidebarButton.active = false;
    this.clubButton.active = false;
    if (sys.platform == Constant.BYTEDANCE_MINI_GAME) {
      this.douyinSidebarButton.active = true;
    } else if (sys.platform == Constant.WECHAT_GAME) {
      this.clubButton.active = true;
    }
    EventManager.Instance.addListener(EventType.OnUserLoginRefresh, this.OnUserLoginRefresh, this);
    EventManager.Instance.addListener(EventType.OnUIMainLoadShow, this.OnUIMainLoadShow, this);
    EventManager.Instance.addListener(EventType.OnUpdateNicknameSuccess_UI, this.OnUpdateNicknameSuccess_UI, this);
    EventManager.Instance.addListener(EventType.ListView_OnItemSelected, this.OnItemSelected, this);
    EventManager.Instance.addListener(EventType.OnChat_UI, this.OnChat_UI, this);
    EventManager.Instance.addListener(EventType.OnSidebar_UI, this.OnHideSidebar, this);
    EventManager.Instance.addListener(EventType.TiLiGetChange, this.TiLiGetChange, this);
    EventManager.Instance.addListener(EventType.OnChangeRedNum, this.OnChangeRedNum, this);
    EventManager.Instance.addListener(EventType.OnChangeTaskRedNum, this.OnChangeTaskRedNum, this);

    // Setup mode selector button click events
    console.log('[UIMain] onLoad - Setting up mode selector buttons...');
    console.log('[UIMain] btn3v3Mode:', this.btn3v3Mode);
    console.log('[UIMain] btn5v5Mode:', this.btn5v5Mode);
    
    if (this.btn3v3Mode) {
      this.btn3v3Mode.clickEvents.push(
        EventManager.Instance.createButtonClickEvent(this.node, "UIMain", "OnClick3v3Mode")
      );
      console.log('[UIMain] btn3v3Mode click event added');
    } else {
      console.error('[UIMain] btn3v3Mode is NULL - not bound in Inspector!');
    }
    
    if (this.btn5v5Mode) {
      this.btn5v5Mode.clickEvents.push(
        EventManager.Instance.createButtonClickEvent(this.node, "UIMain", "OnClick5v5Mode")
      );
      console.log('[UIMain] btn5v5Mode click event added');
    } else {
      console.error('[UIMain] btn5v5Mode is NULL - not bound in Inspector!');
    }

    // Setup match settings button click events programmatically
    if (this.btnQuick10) {
      this.btnQuick10.clickEvents.push(
        EventManager.Instance.createButtonClickEvent(this.node, "UIMain", "OnClickQuick10")
      );
    }
    if (this.btnQuick50) {
      this.btnQuick50.clickEvents.push(
        EventManager.Instance.createButtonClickEvent(this.node, "UIMain", "OnClickQuick50")
      );
    }
    if (this.btnQuick100) {
      this.btnQuick100.clickEvents.push(
        EventManager.Instance.createButtonClickEvent(this.node, "UIMain", "OnClickQuick100")
      );
    }
    if (this.btnInvite10) {
      this.btnInvite10.clickEvents.push(
        EventManager.Instance.createButtonClickEvent(this.node, "UIMain", "OnClickInvite10")
      );
    }
    if (this.btnInvite50) {
      this.btnInvite50.clickEvents.push(
        EventManager.Instance.createButtonClickEvent(this.node, "UIMain", "OnClickInvite50")
      );
    }
    if (this.btnInvite100) {
      this.btnInvite100.clickEvents.push(
        EventManager.Instance.createButtonClickEvent(this.node, "UIMain", "OnClickInvite100")
      );
    }

    // Initialize mode selector visual state (3v3 selected by default)
    this.updateModeSelector();

    this.OnUserLoginRefresh();
    AdManager.Instance.HideCustomAd(CustomAdType.One);
    AdManager.Instance.HideBannerAd();
  }

  private OnUIMainLoadShow() {
    this.uiLogin.node.active = false;
    this.UIMainLoad.active = true;
    this.ValueNode.setScale(this.mainLoadCurrent, 1, 1);
  }

  private OnUserLoginRefresh() {
    console.log('OnUserLoginRefresh sys.platform=' + sys.platform);
    this.ValueNode.setScale(this.mainLoadCurrent, 1, 1);
    if (Util.IsLogin) {  //Already logged in
      this.preLoad();//Preload battle server resources
      if (!NetClient.Instance.connected) {
        NetClient.Instance.Connect(); //Connect to lobby server
      }
      NetClientBattle.Instance.closeCurrentSocket();  //Disconnect battle server
      this.OnUserLoginSuccess();
      MatchService.Instance.CheckExistMatch();
    } else {
      User.Instance.room = null;
      //Initialize loading
      LoadingManager.Init();

      if (Constant.isQQ) {   //QQ platform
        qqGame.Login();
      } else if (sys.platform == Constant.WECHAT_GAME) {   //WeChat platform
        WxGame.Login();
      } else if (sys.platform == Constant.BYTEDANCE_MINI_GAME) {   //Douyin mini game
        DouYingGame.Login();
      } else if (Constant.qihu360Web) {   //360 web game
        let openId360 = window["qihu360"];
        UserService.Instance.SendLoginByOpenId(openId360, '', '', 3);
      } else {
        this.UIMainLoad.active = false;
        this.uiLogin.node.active = true;
      }
    }
  }



  private async OnUserLoginSuccess() {
    console.log('OnUserLoginSuccess');
    let _this = this;
    let timer = setInterval(function () {
      if (_this.mainLoadCurrent < 1) {
        _this.mainLoadCurrent += 0.01;
        let value = _this.mainLoadCurrent > 1 ? 1 : _this.mainLoadCurrent;
        _this.ValueNode.setScale(value, 1, 1)
      }
    }, 20)
    setTimeout(function () {
      clearInterval(timer);
      _this.UIMainLoad.active = false;
      if (User.Instance.user.newGuild == 0) {
        _this.OnClickNickname();
      }
    }, 2000)
    this.levelText.string = 'Lv.' + (User.Instance.user.character?.level || 0);
    this.expText.string = (User.Instance.user.character?.exp || 0) + '/' + (User.Instance.user.character?.levelExp || 0);
    if ((User.Instance.user.character?.exp || 0) == 0) {
      this.expProcessBar.fillRange = 0;
    } else {
      this.expProcessBar.fillRange = User.Instance.user.character?.exp / User.Instance.user.character?.levelExp;
    }
    this.nicknameText.string = User.Instance.user.nickname;
    this.coinText.string = '' + (User.Instance.user.coin || 0);
    let cid = User.Instance.user.character?.cid as number;  //Character config id
    this.OnTiLiChange();  //Stamina display
    this.selectSprite.spriteFrame = LoadResUtil.getPictures(DataManager.Instance.characters[cid].AvatarSelect);

    if (User.Instance.user.avatar) {
      this.avatarSprite.spriteFrame = LoadResUtil.getPictures(DataManager.Instance.characters[cid].Avatar);
      LoadResUtil.getAndSetRemoteImage(User.Instance.user.avatar, this.avatarSprite);
    } else {
      this.avatarSprite.spriteFrame = LoadResUtil.getPictures(DataManager.Instance.characters[cid].Avatar);
    }

    this.rankingList.numItems = User.Instance.rankList.length;
    this.rankingList.scrollTo(0);

    let flag = LocalStorageUtil.GetItem(User.Instance.user.id + LocalStorageUtil.taskRedPoint);
    if (flag == '1' || flag == null) {
      this.taskRedPoint.active = true;
    }
    //  console.log(this.avatarSprite.spriteFrame)
    EventManager.Instance.addListener(EventType.UserCoinChange, this.OnUserCoinChange, this);
    EventManager.Instance.addListener(EventType.CharacterExpChange, this.OnCharacterExpChange, this);
    EventManager.Instance.addListener(EventType.CharacterLevelChange, this.OnCharacterLevelChange, this);
    EventManager.Instance.addListener(EventType.CharacterLevelUpExpChange, this.OnCharacterExpChange, this);
    EventManager.Instance.addListener(EventType.TiLiChange, this.OnTiLiChange, this);
    EventManager.Instance.addListener(EventType.PreLoadShow, this.OnPreLoadShow, this);
    ChatManager.Instance.roomMessages = [];  //Clear messages when no room
    //Sync friend power ranking
    // this.OnSysnZhanLiRank();
    this.passivityShare();
    this.UdpateChatMsg(); //Update messages

    this.tiLiInit();  //Update stamina
    //Get task list
    UserService.Instance.SendGetTaskInfo();
    if (User.Instance.loginDays > 1) {
      this.clubButton.active = true;
    }
  }

  private nicknameInputObj: UIInputBox;
  /**
 * Click nickname
 */
  public async OnClickNickname() {
    let tips = 'Please set a nickname for your character';
    this.nicknameInputObj = await InputBox.Show(tips, "Set Nickname", undefined, undefined, undefined, true);
    // this.nicknameInputObj.input.string = User.Instance.user.nickname; //Default value
    EventManager.Instance.addListener(EventType.UIInputBox_OnClickYes, function (param: any): string {
      let nickname = param[0];
      if (!nickname) {
        return 'Nickname cannot be empty';
      }

      if (sys.platform == Constant.WECHAT_GAME) {
        let callback = (nickname) => {
          UserService.Instance.SendUpdateNickName(nickname, '');
        }
        WxGame.wxMsgCheck(User.Instance.user.id, nickname, callback);
        return '';
      }

      console.log('nickname=' + nickname)
      UserService.Instance.SendUpdateNickName(nickname, '');
      return 'close';
    }, this.nicknameInputObj);
  }

  private OnItemSelected(param: any) {
    let uIHomeRankItem = param[0] as UIHomeRankItem;
    console.log('OnItemSelected=')
  }

  private async preLoad(): Promise<void> {
    try {
      //Run swing animation
      this.schedule(() => {
        this.fuliNode.getComponent(Animation).play('anim_baidong');
      }, 2, macro.REPEAT_FOREVER, 0);

      this.pro_progress.active = false;
      if (Constant.preLoadEnd) {
        console.log('preLoad ResBattleBundleList already load-----------------');
        return;
      }
      Constant.preLoadEnd = false;

      const loadedAssets: any[] = [];
      let len = Constant.ResBattleBundleList.length;
      let _this = this;
      //Simulate progress bar
      setTimeout(function () {
        if (!Constant.preLoadEnd) {
          _this.proValueNode.setScale(0.1, 1, 1);
          _this.proLabel.string = '10%';
        }
      }, 500)
      setTimeout(function () {
        if (!Constant.preLoadEnd) {
          _this.proValueNode.setScale(0.35, 1, 1);
          _this.proLabel.string = '35%';
        }
      }, 2000)
      setTimeout(function () {
        if (!Constant.preLoadEnd) {
          if (_this.proLabel.string !== '100%' && _this.proLabel.string !== '') {
            _this.proValueNode.setScale(0.75, 1, 1);
            _this.proLabel.string = '75%';
          }
        }
      }, 5000)
      for (let i = 0; i < len; i++) {
        const data = await LoadResUtil.loadDir(Constant.ResBattleBundleList[i]);
        loadedAssets.push(...data); // Add files loaded from current directory to array
        let per = ((i + 1) / len);
        this.proValueNode.setScale(per, 1, 1);
        this.proLabel.string = `${Math.round(per * 100)}%`;
      }
      LoadResUtil.setLoadedAssets(loadedAssets);
      console.log('preLoad ResBattleBundleList end-----------------');
      setTimeout(function () {
        if (!Constant.preLoadEnd) {
          _this.proText.string = 'Scene is initializing...';
          _this.proLabel.string = '';
        }
      }, 1000)
      //Preload battle scene resources
      //2026-01-31-altmusa added for Map01 to Map02, test stress
      //director.preloadScene('Map01',
      director.preloadScene('Map03',
        function (completedCount: number, totalCount: number, item: any) {
          // let loadPraent = Math.round(completedCount / totalCount * 100);
          // console.log('Preload battle scene resources progress=' + loadPraent)
        },
        function (error: Error, sceneAsset?: SceneAsset) {
          console.log('Preload battle scene resources completed---------------------------')
          _this.proText.string = 'Scene initialization completed...';
          _this.proLabel.string = '';
          setTimeout(function () {
            _this.pro_progress.active = false;
            Constant.preLoadEnd = true;
          }, 1000)
        });
    } catch (error) {

    }

  }


  /**
  * Loading interface display
  * @param param 
  */
  private OnPreLoadShow() {
    console.log('OnPreLoadShow -----------', Constant.preLoadEnd)
    if (!Constant.preLoadEnd) {
      this.pro_progress.active = true;
    } else {
      this.pro_progress.active = false;
    }
  }

  /**
    * Ranking list rendering
    * @param node
    * @param index 
    */
  public OnRankingListRender(node: Node, index: number) {
    let uiHomeRankItem = node.getComponent(UIHomeRankItem);
    console.log('OnRankingListRender -----------')
    this.rankListMain.AddItem(node, uiHomeRankItem as ListViewItem);
    uiHomeRankItem?.SetItemInfo(User.Instance.rankList[index]);
  }

  private GameClubButton = null;

  /** 
   * Top right three dots passive share button
   */
  public passivityShare(callBack?: any) {
    if (sys.platform != Constant.WECHAT_GAME) {
      return;
    }
    const wx = window['wx'];

    // Authorize display menu
    wx.showShareMenu({
      withShareTicket: false,
      // Show menu
      menus: ['shareAppMessage', 'shareTimeline'],
      success: (res) => {
        console.log("Start passive forwarding shareMenu success");
      },
      fail: () => {
        console.log("Start passive forwarding shareMenu failed");
      }
    });

    // Friend click callback
    wx.onShareAppMessage(() => {
      return {
        // Forward title, if not provided, use mini game nickname by default
        title: "Hot Battle",
        imageUrl: "https://leme-1256681783.file.myqcloud.com/cdn/game/img/share1.png",
      };
    });
    // Moments click callback
    wx.onShareTimeline(() => {
      return {
        title: 'Hot Battle',
        imageUrl: "https://leme-1256681783.file.myqcloud.com/cdn/game/img/share4.png",
      };
    });

    // Create game circle button
    var rect = this.getWxRect();
    this.GameClubButton = wx.createGameClubButton({
      icon: 'green',
      style: {
        left: rect.left,
        top: rect.top,
        width: 40,
        height: 40
      },
      openlink: 'L7NT2g7geKOE6tlXImIlShBpXQeEoVvpybMjbKVIrkIvPPhwpQK-7o3FLq81imeT2am70Ux8hr7dCtRYUerbpziBUWMNnA3-fWLX7bSQeaoTWiZzyBJyOWgdwcBBZzWER'
    })
    this.GameClubButton.hide();

  }

  /**
   * Get WeChat Rect through Node
   */
  private getWxRect() {
    const wx = window['wx'];
    let sysInfo = wx.getSystemInfoSync()
    // console.log('getWxGetSystemInfoSync==========:', sysInfo.screenWidth, sysInfo.screenHeight);
    var left = sysInfo.screenWidth / 2 - 20;
    var top = sysInfo.windowHeight / 2 + 30;
    // console.log('getWxRect==========:', left, top);
    return { left: left, top: top };
  }

  private isOpenedClub: boolean = false;

  /**
   * Game circle button
   */
  public OnGameClubWindow() {
    this.isOpenedClub = true;
    this.clubRedPointNode.active = false;
    if (sys.platform == Constant.WECHAT_GAME) {
      this.clubContent.active = true;
      this.clubContent2.active = false;
      if (this.clubNode.active) {
        this.clubNode.active = false;
        this.GameClubButton.hide();
      } else {
        this.clubNode.active = true;
        this.GameClubButton.show();
      }
    } else {
      this.clubContent.active = false;
      this.clubContent2.active = true;
      if (this.clubNode.active) {
        this.clubNode.active = false;
      } else {
        this.clubNode.active = true;
      }
    }
  }

  /**
   * Coin amount changed
   * @param param 
   */
  private OnUserCoinChange(param: any) {
    let coin = param[0] as number;
    this.coinText.string = '' + (User.Instance.user.coin || 0);
  }

  /**
   * Stamina changed
   * @param param 
   */
  private OnTiLiChange() {
    this.tiLiText.string = (User.Instance.user.tiLi || 0) + '/' + DataManager.Instance.gameConfig.TiLiSum;
  }

  /**
   * Experience, level up experience changed
   * @param param 
   */
  private OnCharacterExpChange(param: any) {
    let exp = param[0] as number;
    this.expText.string = (User.Instance.user.character?.exp || 0) + '/' + (User.Instance.user.character?.levelExp || 0);
    this.expProcessBar.fillRange = User.Instance.user.character?.exp / User.Instance.user.character?.levelExp;
    if ((User.Instance.user.character?.exp || 0) == 0) {
      this.expProcessBar.fillRange = 0.01;
    } else {
      this.expProcessBar.fillRange = User.Instance.user.character?.exp / User.Instance.user.character?.levelExp;
    }
  }

  /**
   * Level changed
   * @param param 
   */
  private OnCharacterLevelChange(param: any) {
    this.levelText.string = 'Lv.' + (User.Instance.user.character?.level || 0);
  }

  /**
   * Settings
   */
  SetUpClick() {
    let obj = UIManager.Instance.show("UISystemConfig");
    //    console.log('obj='+obj)
  }

  /**
   * Click avatar
   */
  public async OnClickAvatar() {
    let uiCharacterDetail = await UIManager.Instance.show("UICharacterDetail") as UICharacterDetail;
    if (uiCharacterDetail) {
      uiCharacterDetail.SendCharacterDetail(User.Instance.user.id, User.Instance.user.character?.tid as number);
    }
  }

  /**
   * Select hero
   */
  public async OnClickSelectHeroButton() {
    let uiCharacter = await UIManager.Instance.show("UICharacterSelect") as UICharacterSelect;
    if (uiCharacter) {
      uiCharacter.SendCharacter(User.Instance.user.character?.cid);
    }
  }

  /**
   * Click hero shop button
   */
  public async OnClickHeroButton() {
    await UIManager.Instance.show("UICharacterShop") as UICharacterShop;
  }

  /**
   * Click enhance button
   */
  public async OnClickPromoteButton() {
    let uiPromote = await UIManager.Instance.show("UIPromote") as UIPromote;
    if (uiPromote) {
      uiPromote.InitAttrPromote();
    }
  }


  /**
   * Click bag
   */
  public async OnClickBag() {
    let uiBag = await UIManager.Instance.show("UIBag") as UIBag;
    if (uiBag) {
      uiBag.SetUpOpenMode(1);
    }
  }

  /**
    * Click shop
    */
  public async OnClickShop() {
    let uiShop = await UIManager.Instance.show("UIShop") as UIShop;
  }

  /**
   * Click power ranking
   */
  public async OnClickRank() {
    if (!User.Instance.user.avatar) {
      if (sys.platform == Constant.WECHAT_GAME) {
        WxGame.getWxNameAvatar();
      } else if (sys.platform == Constant.BYTEDANCE_MINI_GAME) {
        DouYingGame.getDouyingNameAvatar();
      }
    }
    let uiRank = await UIManager.Instance.show("UIRank") as UIRank;
  }

  /**
   * Click sign in
   */
  public async OnClickLoginSignIn() {
    await UIManager.Instance.show("UILoginSignIn");
  }

  /**
   * Daily draw
   */
  public async OnClickDraw() {
    await UIManager.Instance.show("UIDraw");
  }


  /**
   * Click create room
   */
  OnClickOpenRoom() {
    RoomService.Instance.SendValidateOpenRoom();
  }

  /**
  * Click join room
  */
  async OnClickJoinRoom() {
    let inputBox = await InputBox.Show('Please enter room id', "Join");
    let this_ = this;
    EventManager.Instance.addListener(EventType.UIInputBox_OnClickYes, function (param: any): string {
      let roomId = param[0];
      if (!Validate.isIntegerLarge0(roomId)) {
        return 'Room id must be greater than 0';
      }
      RoomService.Instance.SendAddRoomRequest(roomId);
      return '';
    }, inputBox);
  }

  /**
   * Click general chat
   */
  public async OnClickChat() {
    let uiChat = await UIManager.Instance.show("UIChat") as UIChat;
    if (uiChat) {
      if (this.chatRedPoint.active) {
        uiChat.ChangeChatChannel(0);
        this.chatRedPoint.active = false;
      } else {
        uiChat.ChangeChatChannel(uiChat.index);
      }
    }
  }

  /**
   * Click match battle - match now waits up to 5 seconds, if not enough people, match with bots, 1v1
   */
  public async OnClickStartMatch() {
    MatchService.Instance.SendStartMatch(0);
  }

  /** 
   * Click team match battle
   */
  public async OnClickTeamStart() {
    // MatchService.Instance.SendStartMatch(1);
    await UIManager.Instance.show("UIRoom") as UIRoom;
  }

  /**
   * Match Settings - Click handlers for 6 buttons
   */
  private onMatchClick(matchType: number, goldCost: number) {
    console.log(`[UIMain] ===== onMatchClick START =====`);
    console.log(`[UIMain] BattleGlobal.playingMethod BEFORE any checks: ${BattleGlobal.playingMethod}`);
    console.log(`[UIMain] typeof BattleGlobal.playingMethod: ${typeof BattleGlobal.playingMethod}`);
    console.log(`[UIMain] BattleGlobal.playingMethod === 0: ${BattleGlobal.playingMethod === 0}`);
    console.log(`[UIMain] BattleGlobal.playingMethod === undefined: ${BattleGlobal.playingMethod === undefined}`);
    console.log(`[UIMain] BattleGlobal.playingMethod === null: ${BattleGlobal.playingMethod === null}`);
    
    const userGold = User.Instance.user.coin;
    
    // Validate user has enough gold
    if (userGold < goldCost) {
      TipsManager.Instance.showTips(`金币不足！需要 ${goldCost} 金币，当前拥有 ${userGold} 金币`);
      return;
    }

    // BattleGlobal.playingMethod is already set by mode buttons
    // If not set, default to 3v3
    if (BattleGlobal.playingMethod === undefined || BattleGlobal.playingMethod === null) {
      console.log(`[UIMain] playingMethod was undefined/null, defaulting to ThreeVsThree`);
      BattleGlobal.playingMethod = Constant.PlayingMethod.ThreeVsThree;
    }
    
    console.log(`[UIMain] BattleGlobal.playingMethod AFTER default check = ${BattleGlobal.playingMethod} (${BattleGlobal.playingMethod === 0 ? '3v3' : BattleGlobal.playingMethod === 2 ? '5v5' : 'unknown'})`);

    // Log for debugging
    const modeText = matchType === 0 ? "快速匹配" : "邀请模式";
    const playingModeText = BattleGlobal.playingMethod === Constant.PlayingMethod.ThreeVsThree ? "3v3" : "5v5";
    console.log(`[UIMain] Starting ${modeText} ${playingModeText} with ${goldCost} gold cost`);
    TipsManager.Instance.showTips(`开始${modeText} ${playingModeText} - 消耗${goldCost}金币`);

    // Send match request with custom gold cost
    this.sendStartMatchWithCost(matchType, goldCost);
  }

  /**
   * Send match request with custom gold cost
   */
  private sendStartMatchWithCost(matchType: number, goldCost: number) {
    const message = new proto.Message.NetMessage();
    message.Request = new proto.Message.NetMessageRequest();
    message.Request.startMatchReq = new proto.Message.StartMatchRequest();
    message.Request.startMatchReq.matchType = matchType;
    message.Request.startMatchReq.battleGoldCost = goldCost;
    message.Request.startMatchReq.playingMode = BattleGlobal.playingMethod;
    message.Request.startMatchReq.checkExistMatch = false;

    const playingModeText = BattleGlobal.playingMethod === Constant.PlayingMethod.ThreeVsThree ? "3v3" : "5v5";
    console.log(`[UIMain] === MATCH REQUEST DEBUG ===`);
    console.log(`[UIMain] BattleGlobal.playingMethod = ${BattleGlobal.playingMethod}`);
    console.log(`[UIMain] Constant.PlayingMethod.ThreeVsThree = ${Constant.PlayingMethod.ThreeVsThree}`);
    console.log(`[UIMain] Constant.PlayingMethod.FiveVsFive = ${Constant.PlayingMethod.FiveVsFive}`);
    console.log(`[UIMain] message.Request.startMatchReq.playingMode = ${message.Request.startMatchReq.playingMode}`);
    console.log(`[UIMain] Match request sent - Type: ${matchType}, Cost: ${goldCost}, playingMode: ${BattleGlobal.playingMethod} (${playingModeText})`);
    console.log(`[UIMain] Full request object:`, message.Request.startMatchReq);
    
    NetClient.Instance.SendMessage(message);
  }

  /**
   * Mode Selector Handlers - Switch between 3v3 and 5v5
   */
  public OnClick3v3Mode() {
    BattleGlobal.playingMethod = Constant.PlayingMethod.ThreeVsThree;
    this.updateModeSelector();
    console.log(`[UIMain] Mode selected: 3v3`);
    console.log(`[UIMain] BattleGlobal.playingMethod set to: ${BattleGlobal.playingMethod}`);
    TipsManager.Instance.showTips("切换到 3v3 模式");
  }

  public OnClick5v5Mode() {
    console.log("🔥🔥🔥 OnClick5v5Mode CALLED!!! 🔥🔥🔥");
    BattleGlobal.playingMethod = Constant.PlayingMethod.FiveVsFive;
    this.updateModeSelector();
    console.log(`[UIMain] Mode selected: 5v5`);
    console.log(`[UIMain] BattleGlobal.playingMethod set to: ${BattleGlobal.playingMethod}`);
    console.log(`[UIMain] Constant.PlayingMethod.FiveVsFive = ${Constant.PlayingMethod.FiveVsFive}`);
    TipsManager.Instance.showTips("切换到 5v5 模式");
  }

  /**
   * Update mode selector visual state (highlight selected mode)
   */
  private updateModeSelector() {
    if (!this.btn3v3Mode || !this.btn5v5Mode) return;

    const is3v3 = BattleGlobal.playingMethod === Constant.PlayingMethod.ThreeVsThree;
    
    // Update button opacity to show selection (255 = selected, 150 = unselected)
    const opacity3v3 = this.btn3v3Mode.node.getComponent(UIOpacity);
    const opacity5v5 = this.btn5v5Mode.node.getComponent(UIOpacity);
    
    if (opacity3v3) opacity3v3.opacity = is3v3 ? 255 : 150;
    if (opacity5v5) opacity5v5.opacity = is3v3 ? 150 : 255;
  }

  // Quick Match Handlers - Direct match with gold cost
  public OnClickQuick10() { this.onMatchClick(0, 10); }
  public OnClickQuick50() { this.onMatchClick(0, 50); }
  public OnClickQuick100() { this.onMatchClick(0, 100); }

  // Invite/Team Mode Handlers - Open room UI to collect players first
  public async OnClickInvite10() { await this.onInviteModeClick(10); }
  public async OnClickInvite50() { await this.onInviteModeClick(50); }
  public async OnClickInvite100() { await this.onInviteModeClick(100); }

  /**
   * Handle invite mode button clicks - Opens room UI for player collection
   */
  private async onInviteModeClick(goldCost: number) {
    const userGold = User.Instance.user.coin;
    
    // Validate user has enough gold
    if (userGold < goldCost) {
      TipsManager.Instance.showTips(`金币不足！需要 ${goldCost} 金币，当前拥有 ${userGold} 金币`);
      return;
    }

    // Store the gold cost for this invite mode session
    // BattleGlobal.playingMethod is already set by mode buttons
    // If not set, default to 3v3
    if (BattleGlobal.playingMethod === undefined || BattleGlobal.playingMethod === null) {
      BattleGlobal.playingMethod = Constant.PlayingMethod.ThreeVsThree;
    }
    
    User.Instance.user['inviteModeGoldCost'] = goldCost;
    
    const playingModeText = BattleGlobal.playingMethod === Constant.PlayingMethod.ThreeVsThree ? "3v3" : "5v5";
    console.log(`[UIMain] Opening invite mode room with ${goldCost} gold cost, ${playingModeText} mode`);
    TipsManager.Instance.showTips(`邀请模式 ${playingModeText} - 消耗${goldCost}金币`);

    // Open the room UI where users can invite/collect players
    await UIManager.Instance.show("UIRoom") as UIRoom;
  }

  /**
   * Click friends
   */
  public async OnClickFriend() {
    await UIManager.Instance.show("UIFollow") as UIFollow;

    if (this.privateChatRedPoint.active) {
      let uiChat = await UIManager.Instance.show("UIChat") as UIChat;
      if (uiChat) {
        uiChat.ChangeChatChannel(1);
      }
      this.privateChatRedPoint.active = false;
    }
  }

  /**
   * Click auction
   */
  public async OnClickAuctionHall() {
    let uiAuction = await UIManager.Instance.show("UIAuction") as UIAuction;
    // await UIManager.Instance.show("UILoginSignIn");
  }

  /**
   * Click task
   */
  public async OnClickTask() {
    this.taskRedPoint.active = false;
    LocalStorageUtil.SetItem(User.Instance.user.id + LocalStorageUtil.taskRedPoint, '0');
    await UIManager.Instance.show("UITask");
  }

  /**
   * Click sidebar entry reward
   */
  public async OnClickSidebar() {
    await UIManager.Instance.show("UISidebar");
  }

  /**
   * Hide sidebar entry
   */
  public async OnHideSidebar() {
    this.douyinSidebarButton.active = false;
  }

  /**
   * Stamina changed
   */
  private async TiLiGetChange() {
    console.log('TiLiGetChange=' + (User.Instance.user?.tiLiUseCount || 0))
    this.tiLiInit();
    TipsManager.Instance.showTips('Get stamina+' + DataManager.Instance.gameConfig.TiLiAdGetCount);
  }

  private tiLiInit() {
    this.wsyCountLabel.string = 'Today remaining count: ' + (DataManager.Instance.gameConfig.TiLiGetCount - (User.Instance.user?.tiLiUseCount || 0));
    let tiLiAdGetCount = DataManager.Instance.gameConfig.TiLiAdGetCount;
    this.tiLiGetLabel.string = 'x' + tiLiAdGetCount;
  }

  /**
  * Stamina ad acquisition click count
  */
  public OnADTiLiClick() {
    let leftCount = (DataManager.Instance.gameConfig.TiLiGetCount - (User.Instance.user?.tiLiUseCount || 0));
    if (leftCount <= 0) {
      TipsManager.Instance.showTips("Insufficient remaining count!");
      return;
    }
    AdManager.Instance.ShowRewardedVideoAd(() => {
      UserService.Instance.SendTiLiResuCoinGet(1);
      if (!AdManager.Instance.isdebug) {
        if (sys.platform == Constant.BYTEDANCE_MINI_GAME) {
          SoundManager.Instance.PlayMusic(SoundDefine.Music_Douyin);
        } else {
          SoundManager.Instance.PlayMusic(SoundDefine.Music_Game);
        }
      }
    }, () => { });
  }

  /**
  * Lunch/dinner stamina acquisition
  */
  public OnTiLiClick() {
    // Get current time  
    const now = new Date();
    // Extract current hour  
    const hour = now.getHours();
    if ((hour >= 11 && hour <= 13) || (hour >= 18 && hour <= 20)) {
      UserService.Instance.SendTiLiResuCoinGet(3);
    } else {
      TipsManager.Instance.showTips("Please wait for the time to come, then claim again!");
    }
  }

  /**
  * Stamina ad window
  */
  public OnTiLiWindow() {
    if (this.tiLiNode.active) {
      this.tiLiNode.active = false;
    } else {
      this.tiLiNode.active = true;
    }
    // Get current time  
    const now = new Date();
    // Extract current hour  
    const hour = now.getHours();
    if (hour >= 0 && hour < 18) {
      this.gifiTiLiLabel.string = '11:00-13:59 acquisition';
    } else {
      this.gifiTiLiLabel.string = '18:00-20:59 acquisition';
    }
  }

  /**
  * Feedback suggestion window
  */
  public OnFankuiWindow() {
    if (this.fankuiNode.active) {
      this.fankuiNode.active = false;
    } else {
      this.fankuiNode.active = true;
    }
  }

  /**
   * Click follow/live - first show battle record
   */
  public async OnClickFollowLive() {
    // director.loadScene('FollowLive');
    let uiHistoryRecord = await UIManager.Instance.show("UIHistoryRecord") as UIHistoryRecord;
    UserService.Instance.SendQueryHistoryRecordList(User.Instance.user.id);
  }


  /**
   * Avatar nickname modification success response
   */
  private OnUpdateNicknameSuccess_UI() {
    this.nicknameText.string = User.Instance.user.nickname;
    this.selectSprite.spriteFrame = LoadResUtil.getPictures(DataManager.Instance.characters[User.Instance.user.character.cid].AvatarSelect);
    if (User.Instance.user.avatar) {
      this.avatarSprite.spriteFrame = LoadResUtil.getPictures(DataManager.Instance.characters[User.Instance.user.character.cid].Avatar);
      LoadResUtil.getAndSetRemoteImage(User.Instance.user.avatar, this.avatarSprite);
    } else {
      this.avatarSprite.spriteFrame = LoadResUtil.getPictures(DataManager.Instance.characters[User.Instance.user.character.cid].Avatar);
    }
  }

  private isFirstTime: boolean = false;

  /**
   * Modify chat display
   */
  private OnChat_UI(param: any) {
    let channel = param[0] as proto.Message.ChatChannel;
    let messages = param[1] as Array<proto.Message.ChatMessage>;
    if (channel == proto.Message.ChatChannel.Comp) {  //General
      if (messages && messages.length > 0) {
        let lastChatMessage = messages[messages.length - 1];
        console.log('UIMain OnChat_UI isOpenChatUI=' + (!ChatManager.Instance.isOpenChatUI))
        if (this.isFirstTime && lastChatMessage.roomId > 0 && lastChatMessage.roomId != User.Instance.room?.roomId) {
          this.chatRedPoint.active = true;
        }
        this.isFirstTime = true;
        let msg = lastChatMessage.fromName + ':' + lastChatMessage.msg;
        let content = Util.getChatContent(msg.length > 18 ? msg.substring(0, 18) + '...' : msg, -1);
        this.chatLabel.string = content;
        return;
      }
    }
  }

  /**
   * Update messages
   * @returns 
   */
  private UdpateChatMsg() {
    let messages = ChatManager.Instance.compMessages;
    console.log('UdpateChatMsg messages=' + messages.length)
    if (messages && messages.length > 0) {
      let lastChatMessage = messages[messages.length - 1];
      let msg = lastChatMessage.fromName + '：' + lastChatMessage.msg;
      let content = Util.getChatContent(msg.length > 18 ? msg.substring(0, 18) + '...' : msg, -1);
      this.chatLabel.string = content;
      return;
    }
  }

  /**
    * Message count changed
    */
  private async OnChangeRedNum() {
    let privateNum = ChatManager.Instance.GetPrivateChatMsgNum();
    console.log('UIChat OnChangeRedNum:privateNum=' + privateNum)
    if (privateNum > 0) {
      this.privateChatRedPoint.active = true;
      //When follow list is open, red dot opens chat window
      if (FollowManager.Instance.isOpenFollowUI && !ChatManager.Instance.isOpenChatUI) {
        let uiChat = await UIManager.Instance.show("UIChat") as UIChat;
        if (uiChat) {
          uiChat.ChangeChatChannel(1);
        }
      }
    } else {
      this.privateChatRedPoint.active = false;
    }
  }

  private async OnChangeTaskRedNum(param: any) {
    if (!User.Instance.user) {
      return;
    }
    if (param[0]) {
      this.taskRedPoint.active = true;
      LocalStorageUtil.SetItem(User.Instance.user.id + LocalStorageUtil.taskRedPoint, '1');
    } else {
      this.taskRedPoint.active = false;
      LocalStorageUtil.SetItem(User.Instance.user.id + LocalStorageUtil.taskRedPoint, '0');
    }
    if (User.Instance.taskInfo.todayActiveValue > 20) {
      this.clubRedPointNode.active = false;
    } else if (!this.isOpenedClub) {
      this.clubRedPointNode.active = true;
    }
  }

  /**
   * Free gold
   */
  public async GetFreegold() {
    let obj = UIManager.Instance.show("UIFreeGold");
  }

  /**
  * Click battle record
  */
  public async OnClickHistoryRecord() {
    let uiHistoryRecord = await UIManager.Instance.show("UIHistoryRecord") as UIHistoryRecord;
  }

  /**
   * Welfare
   */
  public async OnClickFuLi() {
    let obj = UIManager.Instance.show("UIFreeGold");
  }

  private timer = null;
  private isCompleteLoad:boolean = false;  //Whether loading is complete
  /**
   * Battle royale
   */
  public OnClickOnlineBattle(){
    //Create test room
    let user = User.Instance.user;
    let room = new proto.Message.NRoom({roomId:1, userId:user.id, 
      my:[new proto.Message.NRoomUser({userId:user.id, nickName:user.nickname, user:user})],
      enemy:[], randomSeed:45, ipPortStr: 'www.gryxzx.top:9889:9002:10002'}); 

    User.Instance.room = room;
    BattleGlobal.battleMode = BattleMode.Battle;  //Set to battle mode
    RandomUtil.seed = room.randomSeed;   //Set battle random seed
    //Set game mode type
    BattleGlobal.playingMethod = Constant.PlayingMethod.OnlineBattle; 
    
    if (!Constant.preLoadEnd) {
      EventManager.Instance.dispatch(EventType.PreLoadShow);
    }
    this.isCompleteLoad = false;  //Whether loading is complete
    let this_ = this;
    this.timer = setInterval(function () {
        if (Constant.preLoadEnd && !this_.isCompleteLoad) {
            clearInterval(this_.timer);
            this_.isCompleteLoad = true;
            Util.ToBattleScene(); //Jump to battle server
        }
    }, 1000);
  }

  onDestroy() {
    console.log('onDestroy')
    EventManager.Instance.removeAll(this);
  }
}
