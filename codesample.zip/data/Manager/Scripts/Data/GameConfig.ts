export class GameConfig{
    public BagMaxGridCount:number=null as unknown as number;  //Max bag grid count
    public MaxTranCount:number=null as unknown as number;  //Max transaction count
    public MaxMatchTime:number=null as unknown as number;  //Max match time (s)

    public LiveIntervalForwardTime:number=null;  //Live interval forward time (seconds)
    public accountExpQuota:number=null; //Settlement experience quota
    public dieWaitTime:number=null;  //Death wait time (seconds) 
    public zhenWangTongJiTime:number=null;   //Death assist statistics time (seconds)
    public ResuCoinGetCount:number=null; //Revive coin total obtainable count
    public TiLiGetCount:number=null;        //Stamina ad total obtainable count
    public TiLiSum:number=null;             //Total stamina count
    public BattleXhTiLiCount:number=null;   //Battle stamina consumption count
    public TiLiAdGetCount:number=null;      //Single video stamina obtain count
    public TiLiRecoveryGetCount:number=null;    //Stamina recovery per 10 minutes
    public BattleGetDoubleRewardCount:number;  //Daily double reward count for battle
    /** When true, reduce particle count/emission on battle prefabs (e.g. for mobile). */
    public ParticleOptimize: boolean = true;

}