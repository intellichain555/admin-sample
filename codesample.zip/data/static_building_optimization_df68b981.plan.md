---
name: Static building optimization
overview: Treat towers (Fyt) and crystal (ShuiJin) as static objects by disabling animation updates, ensuring position update skip, and extending collision-check skip to both building types.
todos: []
isProject: false
---

# Static Building (Fyt / ShuiJin) Optimization Plan

## Current State

- **Position update**: Already skipped in `[Creature.update()](assets/Game/Scripts/UI/Battle/Enities/Creature.ts)` via `isStaticBuilding` (lines 459-461)
- **Collision check**: Only Fyt is skipped in `[CollisionCheckManager.CollisionCheck()](assets/Game/Scripts/UI/Battle/Managers/CollisionCheckManager.ts)` (lines 37-39). ShuiJin is not excluded
- **Animation**: Buildings still receive `SetAnim` from constructor, skill casting, death, etc.

## Changes

### 1. Skip animation for buildings

In `[Creature.SetAnim()](assets/Game/Scripts/UI/Battle/Enities/Creature.ts)` (around line 1144), add an early return for Fyt and ShuiJin:

```typescript
public SetAnim(aniState: AniState, value: any) {
  if (!aniState) return;
  // Buildings are static - no animation
  if (this.characterDefine.Class === Constant.CharacterClass.Fyt || 
      this.characterDefine.Class === Constant.CharacterClass.ShuiJin) {
    return;
  }
  // ... existing logic
}
```

This stops all animation updates for buildings from every caller (constructor, Skill.Cast, DoDeath, AIBase, BattleAttribute).

### 2. Position update (already done)

Position update is already skipped in `Creature.update()` for `isStaticBuilding` (Fyt and ShuiJin). No code changes.

### 3. Collision check skip for both building types

In `[CollisionCheckManager.CollisionCheck()](assets/Game/Scripts/UI/Battle/Managers/CollisionCheckManager.ts)` (lines 37-39), include ShuiJin in the early return:

```typescript
// Buildings (tower/crystal) do not move - skip collision check
if (creature.characterDefine.Class === Constant.CharacterClass.Fyt || 
    creature.characterDefine.Class === Constant.CharacterClass.ShuiJin) {
  return;
}
```

## Summary


| Item               | File                     | Action                                      |
| ------------------ | ------------------------ | ------------------------------------------- |
| No animation       | Creature.ts              | Early return in `SetAnim()` for Fyt/ShuiJin |
| No position update | Creature.ts              | Already implemented                         |
| No collision check | CollisionCheckManager.ts | Add ShuiJin to existing Fyt early return    |


## Notes

- Buildings remain in `creatureList` so heroes/minions can still collide with them
- The early return in `CollisionCheck` runs when the moving creature is a building (rare in normal flow)
- Prefabs are unchanged; logic-only changes

