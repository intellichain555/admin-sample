---
name: Fog of View Implementation
overview: "Implement entity-based fog of view: enemy and neutral units are only visible when within vision radius of the local player's allied vision providers. Includes a new FogOfViewManager, Creature visibility flag, integration with HP bars and minimap, config, risks, and test cases."
todos: []
isProject: false
---

# Fog of View Implementation Plan

## Scope

- **Entity-only fog**: Hide enemy and neutral creatures (and their HP bars, minimap icons) when they are not within vision radius of any allied vision provider. No terrain/mask rendering in this phase.
- **Vision providers (v1)**: Local player's hero only (`BattleManager.Instance.currentCharacter`). Optional later: allied heroes, towers, crystal.
- **Who is hidden**: Any creature where `teamType2 !== currentCharacter.teamType2` (i.e. enemy and neutral). Allies always visible.

## Architecture

```mermaid
flowchart LR
  subgraph update [BattleManager.update]
    CM[CreatureManager.update]
  end
  subgraph lateUpdate [BattleManager.lateUpdate]
    FOV[FogOfViewManager.update]
    CAM[Camera]
    UIWM[UIWorldElementManager.updateRendering]
  end
  CM --> FOV
  FOV --> CAM
  FOV --> UIWM
  FOV --> Creature[Creature.node / isVisibleToLocalPlayer]
  Creature --> UIWM
  Creature --> Minimap[Minimap icons]
```



- **FogOfViewManager** runs once per frame in `lateUpdate` (before `updateRendering()`). It computes visibility for all "hideable" creatures and sets `Creature.isVisibleToLocalPlayer` and `Creature.node.active`.
- **UIWorldElementManager** and minimap use the same flag so HP bars and minimap icons stay in sync with 3D visibility.

## Implementation Tasks

### 1. Config and global vision radius

- **File**: [assets/Game/Data/GameConfig.txt](assets/Game/Data/GameConfig.txt)  
Add optional key, e.g. `"VisionRadius": 16` (render/world units).
- **File**: [assets/Game/Scripts/UI/Battle/Utils/BattleGlobal.ts](assets/Game/Scripts/UI/Battle/Utils/BattleGlobal.ts)  
Add `public static visionRadius: number = 16` and in `init()` read from `DataManager.Instance.gameConfig` if present (fallback 16). Use same scale as existing `sameScreenRangeRadius` (render units).

### 2. Creature visibility flag

- **File**: [assets/Game/Scripts/UI/Battle/Enities/Creature.ts](assets/Game/Scripts/UI/Battle/Enities/Creature.ts)  
Add `public isVisibleToLocalPlayer: boolean = true` (default true preserves current behavior when fog is disabled).  
Ensure **ShadowControl** is driven by visibility: when hiding in fog, call existing `ShadowControl(false)`; when revealing, `ShadowControl(true)` (or tie to `node.active` so shadow follows model).

### 3. FogOfViewManager (new component)

- **New file**: `assets/Game/Scripts/UI/Battle/Managers/FogOfViewManager.ts`
  - Singleton-style access (e.g. `FogOfViewManager.Instance`) and optional `enabled` so fog can be toggled (e.g. via config or debug).
  - **Vision providers**: List of creatures that grant vision. v1: only `BattleManager.Instance.currentCharacter` (if non-null and not dead). Use `CharacterManager.Instance.characterList` filtered by `teamType2 === currentCharacter.teamType2` if you extend to all allies.
  - **Hideable creatures**: Iterate `CreatureManager.Instance.creatureMap`; for each creature skip if same team as `currentCharacter`, dead, or invalid. For the rest (enemy + neutral), compute min distance to any provider using **render positions** (e.g. `creature.node.worldPosition` vs `provider.node.worldPosition`) and squared distance to avoid sqrt.
  - **Visibility logic**: If `minDistSq <= visionRadius * visionRadius` then in vision: set `creature.isVisibleToLocalPlayer = true`, `creature.node.active = true`, and shadow on. Else in fog: `isVisibleToLocalPlayer = false`, `creature.node.active = false`, shadow off.
  - **Edge cases**: If `currentCharacter` is null or dead, treat as no vision (all hideable creatures in fog) or optionally show all (configurable). Game-over / camera-on-crystal case: keep using current character's team for vision so behavior stays consistent.
  - **Performance**: Run once per frame; use a reused array for providers and avoid per-creature allocations. Consider updating visibility every 2–3 frames if needed (visibility changes can be slightly delayed).

### 4. BattleManager integration

- **File**: [assets/Game/Scripts/UI/Battle/Managers/BattleManager.ts](assets/Game/Scripts/UI/Battle/Managers/BattleManager.ts)  
In `lateUpdate(dt)`, **before** camera and before `uiWorldElementManager.updateRendering()`, call `FogOfViewManager.Instance?.update(dt)` (or equivalent). Ensure the component is on the same scene node as BattleManager or referenced so it exists when battle is active.

### 5. UIWorldElementManager (HP bars)

- **File**: [assets/Game/Scripts/UI/Battle/UIWorldElementManager.ts](assets/Game/Scripts/UI/Battle/UIWorldElementManager.ts)  
In `updateRendering()`, after the existing "Skip dead or invalid owners" block, add: for each world element whose `Owner` is a creature that should be subject to fog (enemy/neutral), if `!Owner.isVisibleToLocalPlayer`, set `uiWorldElement.node.active = false` and `continue`. So HP bars and other world UI for that creature are hidden when in fog, without changing culling logic for allies.

### 6. Minimap visibility

- **Heroes**: Each hero has [Creature.minimapCharacterNode](assets/Game/Scripts/UI/Battle/Enities/Creature.ts) with [UIMinimapCreature](assets/Game/Scripts/UI/Battle/Minimap/UIMinimapCreature.ts). In `UIMinimapCreature.update()`, when the creature is not the local player and not same team, call `this.hide()` when `!this.creature.isVisibleToLocalPlayer` and `this.show()` when visible (mirror the existing `IsDeath` show/hide pattern).
- **Other minimap icons** (soldiers, towers, crystal, great monster, call monster): These are created per creature and hold a reference to `Creature` in `UIMinimapCreature.creature`. Apply the same rule in their update path. If there is no central `update()` for these (they may be updated elsewhere), add a single place that iterates minimap creature nodes and sets `node.active = creature.isVisibleToLocalPlayer` for enemy/neutral, or ensure each UIMinimapCreature that has an enemy/neutral creature gets updated (e.g. from UIMinimapManager or from a shared tick) and hide/show based on `creature.isVisibleToLocalPlayer`.

### 7. Initial state and cleanup

- When a creature is **spawned**, set `isVisibleToLocalPlayer` to a safe default (e.g. false for enemy/neutral so they start hidden until first visibility tick).
- When **FogOfViewManager** is disabled or battle ends, ensure all creatures are visible again (e.g. set all to `isVisibleToLocalPlayer = true` and `node.active = true` in Clear/onDisable) to avoid leaving units hidden after battle.

## Risks and Mitigations


| Risk                                                        | Mitigation                                                                                                                                                                                                                                       |
| ----------------------------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| **Performance** (extra loop over all creatures every frame) | Use squared distance; reuse arrays; optional throttle (every 2–3 frames). Creature count is bounded (heroes + minions + towers + monsters).                                                                                                      |
| **Replay / rollback**                                       | Fog is view-only. If you have state rollback (e.g. [CreatureManager rollback](assets/Game/Scripts/UI/Battle/Managers/CreatureManager.ts)), do not persist `isVisibleToLocalPlayer` in rollback state; recompute after rollback or on next frame. |
| **currentCharacter null or dead**                           | Define behavior: e.g. no vision (all hideable in fog) or full vision. Document in FogOfViewManager and handle in one place.                                                                                                                      |
| **Game end / camera on crystal**                            | Keep vision based on `currentCharacter.teamType2` so enemy units still fade in/out correctly when spectating.                                                                                                                                    |
| **Minimap click on hidden unit**                            | Minimap icons for enemies in fog are hidden, so no click. If "last seen" is added later, clicking last-seen could be disabled or show "no vision" feedback.                                                                                      |
| **Multiplayer / authority**                                 | Fog is client-side only; server does not need changes. No authority risk.                                                                                                                                                                        |
| **New modes**                                               | If some modes (e.g. tutorial) should have no fog, gate FogOfViewManager by `BattleGlobal` or config (e.g. `GameConfig.EnableFogOfView`).                                                                                                         |


## Test Cases

### Manual / in-editor

1. **Vision radius**
  - Enter battle; move hero toward an enemy. Enemy should appear when within ~VisionRadius and disappear when leaving. Tweak VisionRadius in config and confirm scale.
2. **Allies always visible**
  - Allied heroes and minions remain visible at any distance (no fog for same team).
3. **Neutrals**
  - If neutrals (e.g. jungle) use `TeamType2.Neutral`, they should hide when out of vision and appear when in range.
4. **HP bar sync**
  - Enemy in vision: 3D model and HP bar visible. Enemy in fog: both hidden. No orphaned HP bars.
5. **Minimap**
  - Enemy hero/minion icon on minimap visible only when in vision; icon hidden when in fog. Allies always on minimap.
6. **Death**
  - When currentCharacter is dead (or null), chosen behavior holds: either all enemies in fog or all visible; no crash.
7. **Game end**
  - After game over with camera on crystal, enemy units still respect fog based on local player's team.
8. **Fog disabled**
  - With fog disabled (config or flag), all units and minimap icons visible as before; no regression.

### Edge / regression

1. **Spawn**
  - Newly spawned enemy appears only after first visibility update (no flash of visible then hidden).
2. **Shadow**
  - Enemy in fog: shadow off; when entering vision, shadow on (if ShadowControl is tied to visibility).
3. **No double-hide**
  - Do not set `node.active = false` in FogOfViewManager for creatures that are already dead (CreatureManager/other code may handle death); only control visibility for alive hideable creatures, or explicitly allow both (death hides node, fog hides node—redundant but safe).

### Optional (later)

1. **Last seen on minimap**: If implemented, icon at last-seen position when in fog; disappears or updates when seen again.
2. **Multiple providers**: If allies/towers grant vision, stand near allied tower and confirm vision extends correctly.

## File Summary


| Action                                 | File                                                                                                                                        |
| -------------------------------------- | ------------------------------------------------------------------------------------------------------------------------------------------- |
| Add config key                         | [GameConfig.txt](assets/Game/Data/GameConfig.txt)                                                                                           |
| Add visionRadius, init                 | [BattleGlobal.ts](assets/Game/Scripts/UI/Battle/Utils/BattleGlobal.ts)                                                                      |
| Add isVisibleToLocalPlayer; tie shadow | [Creature.ts](assets/Game/Scripts/UI/Battle/Enities/Creature.ts)                                                                            |
| New                                    | `Managers/FogOfViewManager.ts`                                                                                                              |
| Call FogOfViewManager in lateUpdate    | [BattleManager.ts](assets/Game/Scripts/UI/Battle/Managers/BattleManager.ts)                                                                 |
| Hide HP bar when in fog                | [UIWorldElementManager.ts](assets/Game/Scripts/UI/Battle/UIWorldElementManager.ts)                                                          |
| Minimap hide/show by visibility        | [UIMinimapCreature.ts](assets/Game/Scripts/UI/Battle/Minimap/UIMinimapCreature.ts) (and any central minimap update that drives other icons) |


## Order of Implementation

1. Config + BattleGlobal.visionRadius
2. Creature.isVisibleToLocalPlayer and shadow
3. FogOfViewManager (core logic and node.active)
4. BattleManager lateUpdate hook
5. UIWorldElementManager fog check
6. Minimap visibility
7. Edge cases (null currentCharacter, spawn default, clear on disable)
8. Manual testing against checklist above

