---
name: Revert CollisionCheck Optimizations
overview: Revert all collision-check optimizations (obstacle cache, distance culling, and BattleManager hook) so collision behavior matches the pre-optimization version and the game no longer behaves incorrectly.
todos: []
isProject: false
---

# Revert CollisionCheck Optimizations

Revert the collision-check changes that are causing incorrect game behavior. Two files are affected.

---

## 1. [assets/Game/Scripts/UI/Battle/Managers/CollisionCheckManager.ts](assets/Game/Scripts/UI/Battle/Managers/CollisionCheckManager.ts)

**Remove added types and state**

- Delete the `CachedObstacleData` interface (lines 13–19).
- Remove obstacle-cache and helper state: `cachedObstacleData`, `lastObstacleCacheFrameId`, and the `readonly` rect vectors. Restore the original three private vectors: `rectObstaclesRenderPosition`, `rectObstaclesLogicPosition`, `rectObstaclesLogicRotation` (no `readonly`).
- In `Clear()`, remove the line that sets `this.lastObstacleCacheFrameId = -1`.
- Remove the method `getCreatureMaxRadius` (lines 42–51).
- Remove the method `RefreshObstacleCache` (lines 53–86).
- Remove the method `CreatureObstacleCollisionCheckWithCached` (the entire method that takes `CachedObstacleData`).

**Restore creature-vs-creature loop in `CollisionCheck**`

- Put `myLogicPosition` and `enemyLogicPosition` back inside the `for (let creature2 of this.creatureList)` loop (assign them at the start of each iteration).
- Remove the distance-culling block: `myMaxRadius`, `marginSq`, `dx`/`dz`/`distSq`/`maxR2`/`maxDist`, and the `if (distSq > ...) continue;`.
- Restore the original `continue` condition to use `creature.entityId == creature2.entityId` (double-equals) if the codebase style prefers it; the logic stays the same.

**Restore obstacle loop in `CollisionCheck**`

- Replace the cached-obstacle branch and fallback with the original single loop:
  - `let rectObstaclesNodeArr = BattleManager.Instance.RectObstaclesNode.children;`
  - `for (let i = 0; i < rectObstaclesNodeArr.length; i++)` with `let rectObstaclesNode = rectObstaclesNodeArr[i];` and `let creatureLogicPosition = ...` (or reuse the same variable as before the loop).
  - Call only `this.CreatureObstacleCollisionCheck(creature, creatureLogicPosition, rectObstaclesNode, myLogicRotation, isPrediction, isUpdateRendering);` (no cache, no `CreatureObstacleCollisionCheckWithCached`).

Result: `CollisionCheck` again loops over all creatures without distance culling and over `RectObstaclesNode.children` using only `CreatureObstacleCollisionCheck` with the node (no cache).

---

## 2. [assets/Game/Scripts/UI/Battle/Managers/BattleManager.ts](assets/Game/Scripts/UI/Battle/Managers/BattleManager.ts)

**Remove cache refresh call**

- Delete the two lines added after the prediction return (around 461–462):
  - The comment: `// Refresh obstacle cache once per frame so CollisionCheck avoids N×M getWorldPosition/getRotation`
  - The call: `CollisionCheckManager.Instance.RefreshObstacleCache(frameId);`

---

## Summary


| Location              | Action                                                                                                                                                                                                                                                  |
| --------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| CollisionCheckManager | Remove `CachedObstacleData`, cache state, `getCreatureMaxRadius`, `RefreshObstacleCache`, `CreatureObstacleCollisionCheckWithCached`; restore original creature loop (positions inside loop, no distance cull) and original obstacle loop (nodes only). |
| BattleManager         | Remove `RefreshObstacleCache(frameId)` and its comment.                                                                                                                                                                                                 |


After the revert, collision again uses live node transforms every time and checks every creature pair with no early-out, matching pre-optimization behavior.