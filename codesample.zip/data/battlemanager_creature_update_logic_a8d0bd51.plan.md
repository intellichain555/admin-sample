---
name: BattleManager creature update logic
overview: Change BattleManager creature sync (lines 466-486) so characters (heroes) update every frame with no distance check, and others (minions, towers, shuijins) update every 5 frames instead of every 3.
todos: []
isProject: false
---

# BattleManager creature update logic (lines 466-486)

## Current behavior (and bug)

- Logic uses **isPlayer**, **isNearby** (distance &lt; 5000 to `currentCharacter`), and **frameId % 3 === entityId % 3** to decide full vs minimal update.
- There is also a duplicate `creature.LogicUpdate(frameId);` on line 480 (before the if), so every creature gets one full update plus the conditional one — this should be removed so only one branch runs.

## Target behavior


| Creature kind                                | Rule                                                                                                                        |
| -------------------------------------------- | --------------------------------------------------------------------------------------------------------------------------- |
| **Characters** (heroes)                      | Full `LogicUpdate(frameId)` every frame. No nearby check.                                                                   |
| **Others** (minions, towers, shuijins, etc.) | Full update only when `frameId % 5 === (creature.entityId % 5)`; otherwise only `creature.attributes.LogicUpdate(frameId)`. |


Classification: use existing **CreatureType** enum in [assets/Game/Scripts/UI/Battle/enums/CreatureType.ts](assets/Game/Scripts/UI/Battle/enums/CreatureType.ts): `CreatureType.Character` = hero; everything else (e.g. `CreatureType.Monster` for minions/towers/shuijins) = “others”.

## Code changes

**File: [assets/Game/Scripts/UI/Battle/Managers/BattleManager.ts**](assets/Game/Scripts/UI/Battle/Managers/BattleManager.ts)

1. **Add import** (with other enum imports near top):
  - `import { CreatureType } from '../enums/CreatureType';`
2. **Replace lines 466-486** with:
  - Keep the comment that sync is for creature logic (optionally shorten to “Synchronize creature logic (characters every frame, others every 5 frames)”).
  - Keep: `let creatureList = CreatureManager.Instance.creatureMap.values();` and the `for` loop.
  - **Remove**: all `isPlayer`, `isNearby`, and distance-to-`currentCharacter` logic.
  - **New branch**:
    - If `creature.creatureType === CreatureType.Character`: call `creature.LogicUpdate(frameId);` (every frame).
    - Else: if `frameId % 5 === (creature.entityId % 5)` call `creature.LogicUpdate(frameId);`, else call `creature.attributes.LogicUpdate(frameId);`.
  - Ensure **only one** of full LogicUpdate or minimal attributes.LogicUpdate runs per creature per frame (no duplicate LogicUpdate).

Resulting structure:

```ts
// Synchronize creature logic (characters every frame, others every 5 frames)
let creatureList = CreatureManager.Instance.creatureMap.values();
for (let i = 0; i < creatureList.length; i++) {
  let creature = creatureList[i] as Creature;
  if (creature.creatureType === CreatureType.Character) {
    creature.LogicUpdate(frameId);
  } else {
    if (frameId % 5 === (creature.entityId % 5)) {
      creature.LogicUpdate(frameId);
    } else {
      creature.attributes.LogicUpdate(frameId);
    }
  }
}
```

No other files need changes; `Creature` already has `creatureType` and `attributes.LogicUpdate`.