---
name: Memory leak fix plan
overview: Fix the three identified memory leak sources (skill effect nodes, deferred PlayEffect3 FX nodes without a holder, and optional listener cleanup) with minimal, targeted changes that avoid affecting game logic, rollback, or rendering.
todos: []
isProject: false
---

# Memory Leak Fix Plan (Logic- and Rendering-Safe)

## Risk principles

- **Only recycle when the node is no longer needed** (interrupt, replace, or after a safe delay).
- **Do not change when or how effects are shown/hidden** (no new logic branches for visibility).
- **Do not touch state used by rollback** (SkillRecord does not store `effectNode`; recycling it does not affect rollback).
- **Recycle = removeFromParent + putNode** (same pattern as existing [FXManager.recoveryNode](assets/Game/Scripts/UI/Battle/Effects/FXManager.ts) and [EffectController.recoveryThisNode](assets/Game/Scripts/UI/Battle/Effects/EffectController.ts)).

---

## 1. Skill effect nodes (EntityEffectManager → Skill)

**Leak:** [Skill.SkillInterruptHandle](assets/Game/Scripts/UI/Battle/Models/Skill.ts) removes the effect node from the scene but never returns it to the pool; [SkillManager.setSkillEffectNode](assets/Game/Scripts/UI/Battle/Managers/SkillManager.ts) overwrites `skill.effectNode` without recycling the previous one.

**Fix (no logic/rendering change):**

- **In [Skill.ts](assets/Game/Scripts/UI/Battle/Models/Skill.ts) – `SkillInterruptHandle()**`
  - After `this.effectNode.removeFromParent()`, call `PoolManager.instance.putNode(this.effectNode)` and then `this.effectNode = null`.
  - Add `PoolManager` import.
  - **Risk:** None. The effect is already being removed from the scene; we only return it to the pool and clear the reference. No code reads `effectNode` after interrupt (only this method and `setSkillEffectNode` use it).
- **In [SkillManager.ts](assets/Game/Scripts/UI/Battle/Managers/SkillManager.ts) – `setSkillEffectNode()**`
  - Before `skill.effectNode = effectNode`, if `skill.effectNode` exists and is valid: call `skill.effectNode.removeFromParent()`, then `PoolManager.instance.putNode(skill.effectNode)`.
  - Add `PoolManager` import if missing.
  - **Risk:** None. We are replacing the old effect with a new one; the old node is no longer displayed. Pool name comes from `node['name2']` / `node.name` in [PoolManager.putNode](assets/Game/Scripts/Managers/PoolManager.ts), which was set when the node was created in EntityEffectManager (name + entity uuid).

**Do not:** Recycle when `Status === SkillStatus.None` in Skill update. That could remove an effect that is still playing for a frame; recycling only on interrupt and on replace keeps behavior unchanged.

---

## 2. Deferred PlayEffect3 FX nodes (no resultHolder)

**Leak:** In [DeferredWorkManager](assets/Game/Scripts/UI/Battle/Managers/DeferredWorkManager.ts), when `parentNode` is invalid the effect node is added to `AllBattleEffectsNode` and `resultHolder` is not set. Nothing ever recycles that node.

**Fix (no logic/rendering change):**

- **In [DeferredWorkManager.ts**](assets/Game/Scripts/UI/Battle/Managers/DeferredWorkManager.ts)
  - Add a small “pending recycle” list, e.g. `private pendingFXRecycle: Array<{ node: Node; recycleAtFrame: number }> = []`.
  - In the branch where the node is added to `AllBattleEffectsNode` (parent invalid): after `BattleGlobal.playParticleEffect(effectNode)`, push `{ node: effectNode, recycleAtFrame: BattleData.executeFrameId + RECYCLE_DELAY_FRAMES }` (e.g. `RECYCLE_DELAY_FRAMES = 600` for ~10s at 60 fps). Use [BattleData.executeFrameId](assets/Game/Scripts/UI/Battle/Utils/BattleData.ts).
  - At the start of `processDeferredWork()`, process `pendingFXRecycle`: for each entry where `BattleData.executeFrameId >= recycleAtFrame`, call the same recycle pattern as FXManager (node.active = false, removeFromParent, PoolManager.putNode), then remove from the list. Add `BattleData` and `PoolManager` imports.
  - **Do not** add delayed recycle when `resultHolder` is set; those nodes are owned by [Effect.ts](assets/Game/Scripts/UI/Battle/Models/Effect.ts) and are already recycled in `OnRemove` via `FXManager.recoveryNode`.
  - **Risk:** Only nodes that have no owner (no resultHolder) are recycled after a delay. Choosing a large delay (e.g. 10s) avoids cutting short any long-lived FX. If desired, the delay can be made configurable later (e.g. in [GameConfig](assets/Game/Scripts/Data/GameConfig.ts)).

---

## 3. Event listeners (optional, lower priority)

**Observation:** The memory profile shows listener count rising. Many components use `EventManager.Instance.addListener` or `node.on()`; if components are destroyed or pooled without a matching `removeListener` / `node.off`, listeners can keep objects alive.

**Recommendation:** Treat as a separate, incremental pass to avoid logic/rendering regressions:

- Audit components that register listeners in `onLoad`/`start` and ensure they call `removeListener` / `node.off` in `onDestroy` (or when the node is pooled/destroyed).
- Do **not** remove listeners earlier than destruction/pooling (e.g. not when a skill ends), to avoid breaking events that depend on that component’s lifetime.

No code changes are specified in this plan for listeners; only the two fixes above are in scope.

---

## 4. Testing and validation

- **Skill interrupt:** Cast a skill, interrupt it (e.g. move or die). Confirm the skill effect disappears as before and that no errors occur (no use of recycled node).
- **Skill replace:** Cast skill A, then skill B before A’s effect ends. Confirm A’s effect is replaced by B’s and no duplicate or missing FX.
- **Deferred FX (no holder):** Trigger effects that go through `enqueuePlayEffect3FX` without `resultHolder` (e.g. parent destroyed path). Run for 10+ seconds and confirm no errors and that JS heap / node count no longer grow unbounded.
- **Rollback/replay:** If the project has state rollback or replay, run a short battle and roll back; confirm no new errors and that skill/effect state is unchanged (effectNode is not part of SkillRecord, so recycling does not affect rollback).

---

## Summary


| Area                    | Change                                                                         | Logic / rendering risk                  |
| ----------------------- | ------------------------------------------------------------------------------ | --------------------------------------- |
| Skill interrupt         | Recycle `effectNode` in `SkillInterruptHandle` and set to `null`               | None; effect already removed from scene |
| Skill replace           | Recycle previous `effectNode` in `setSkillEffectNode` before assigning new     | None; old effect is being replaced      |
| Deferred FX (no holder) | Delayed recycle for nodes added to `AllBattleEffectsNode` without resultHolder | Low; long delay avoids cutting FX short |
| Listeners               | Not in scope; optional follow-up                                               | N/A                                     |


All changes follow existing patterns (recoveryNode / putNode) and do not alter when effects are shown, when skills run, or rollback state.