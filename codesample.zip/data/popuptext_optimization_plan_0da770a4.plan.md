---
name: PopupText optimization plan
overview: Apply Claude's ShowPopupText optimizations from the guide and the two optimized scripts to the current codebase, while preserving the existing Constant.SHOW_POPUP_TEXT flag and avoiding breaking changes.
todos: []
isProject: false
---

# ShowPopupText optimization plan

Apply the optimizations from [OPTIMIZATION_GUIDE.md](c:\Users\aaa\Downloads\OPTIMIZATION_GUIDE.md), [UIPopupText_HighlyOptimized.ts](c:\Users\aaa\Downloads\UIPopupText_HighlyOptimized.ts), and [UIWorldElementManager_Optimized.ts](c:\Users\aaa\Downloads\UIWorldElementManager_Optimized.ts) into the project, keeping the current `Constant.SHOW_POPUP_TEXT` flag and existing behavior.

---

## 1. UIWorldElementManager changes

**File:** [assets/Game/Scripts/UI/Battle/UIWorldElementManager.ts](assets/Game/Scripts/UI/Battle/UIWorldElementManager.ts)

- **Keep:** `Constant.SHOW_POPUP_TEXT` check and `Constant` import (the optimized file omits these).
- **Add component cache:** `private componentCache = new Map<Node, { popup?: UIPopupText, element?: UIWorldElement }>();`
- **Clear cache in `Clear()`:** `this.componentCache.clear();` so cache does not outlive the manager.
- **In `ShowPopupText`:**
  - After the `Constant.SHOW_POPUP_TEXT` and `getNode` guards, resolve `uiPopupText` and `uiWorldElement` via cache: if `componentCache.get(goPopup)` exists, use it; else `getComponent` for both and `componentCache.set(goPopup, { popup, element })`.
  - Set **cheap** `uiWorldElement` fields first: `Owner`, `isExecute`, `isExecuteOnce`, `type`, `id`, then `uiWorldElementMap.put`.
  - Call `uiPopupText.InitPopup(...)`, then set `uiWorldElement.height = uiPopupText.height`.
  - Activate last: `goPopup.active = true`.
- **In `RemovePopupText`:** Do **not** remove the node from `componentCache` (same node is reused from pool; cache stays valid).
- **In `preloadCreated()`:** Increase popup preload from 30 to 50: `PoolManager.instance.preloadPool(this.popupTextNode, 50, ...)`.

---

## 2. UIPopupText changes

**File:** [assets/Game/Scripts/UI/Battle/UIPopupText.ts](assets/Game/Scripts/UI/Battle/UIPopupText.ts)

### 2.1 Caching (one-time setup)

- **UITransform cache:** Add private fields for each label’s transform: `normalDamageTransform`, `critDamageTransform`, `healTransform`, `effectTipsTransform`, `hitTransform`, `critHitTransform` (all `UITransform | null`).
- **Children cache:** `private children: Node[] = [];`
- **Viewport cache:** Static `viewportRect` and `lastViewportUpdate`, plus `VIEWPORT_UPDATE_INTERVAL = 1000`, and a static `updateViewportRect()` that updates `viewportRect` only when `Date.now() - lastViewportUpdate > VIEWPORT_UPDATE_INTERVAL`.
- **In `start()`:** Call a new `cacheComponents()` that assigns each label’s `getComponent(UITransform)` to the corresponding field, and set `this.children = this.node.children`.

### 2.2 InitPopup

- **Children loop:** Replace `this.node.children` + `forEach` with a `for` loop over `this.children` and `children[i].active = false`.
- **Label + transform:** In each type branch, set a local `labelTransform` from the corresponding cached transform (e.g. `critDamageTransform`, `normalDamageTransform`).
- **Position clamping:** After `this.node.setScale(this._oriScale)` and `getPosition()`:
  - Use cached transform: `width = labelTransform?.width ?? 0`, `height = labelTransform?.height ?? 0` (no `label.getComponent(UITransform)`).
  - Call `UIPopupText.updateViewportRect()` and use `UIPopupText.viewportRect`.
  - Precompute `halfWidth`, `halfHeight`, `rectHalfWidth`, `rectHalfHeight` and use them in the clamp logic (matching optimized script).
- **Tween logic:** Extract the tween creation into a private `startTween(type: PopupType)` and call it at the end of `InitPopup` instead of inlining (reduces branching and keeps InitPopup shorter).

### 2.3 getTargetPos

- At the start, cache `ownerHeight = this.owner.characterDefine.Height` and `ownerWorldPos = this.ownerParent.worldPosition`; use these in all branches instead of repeating property access. Use `const nor = creature.node.parent.forward.normalize()` (reuse variable) where the optimized script does.

### 2.4 lateUpdate

- Add early exit: `if (!this._isChangePos) return;`.
- Keep existing `lerp` / `convertToUINode` / `setPosition` logic; ensure no extra allocations (reuse `this.newWorPos` and `this._curWorPos`).

### 2.5 Lifecycle

- **onDisable:** Add `onDisable()` that calls `this._closeTweenTip()` and sets `this._isChangePos = false` so pooled nodes are reset when hidden.

### 2.6 Optional cleanup

- Remove unused `static tempVec3` if introduced; the optimized file declares it but does not use it, so omit it to avoid dead code.

---

## 3. What we are not doing (per guide)

- **MAX_ACTIVE_POPUPS / limit active popups:** Not in the provided optimized scripts; add later if needed.
- **Batch queue (processBatch):** Not in the optimized scripts; optional follow-up.
- **Text string cache (damage number → string):** Not in the optimized scripts; optional follow-up.
- **Font/bitmap asset changes:** Asset/design work; out of scope for this code-only plan.

---

## 4. Verification

- After changes, ensure:
  - `Constant.SHOW_POPUP_TEXT === false` still skips showing popup text.
  - Popup text still appears and animates correctly for Damage, Crit, Hit, Heal, EffectTips.
  - No new linter errors; existing imports (e.g. `Util`, `Tween`, `tweenUtil`) remain only if still used.

---

## 5. Summary


| Area                  | Change                                                                                                                 |
| --------------------- | ---------------------------------------------------------------------------------------------------------------------- |
| UIWorldElementManager | Component cache, property order, pool size 50, keep SHOW_POPUP_TEXT                                                    |
| UIPopupText           | UITransform + children + viewport caching, startTween extraction, getTargetPos reuse, onDisable, lateUpdate early exit |


Expected impact (from guide): ~20–30% from component cache, ~30–40% from InitPopup/viewport/cache optimizations, ~10–15% from larger pool — combined on the order of ~50%+ reduction in ShowPopupText cost, subject to profiling.